import { useEffect } from 'react';
import { Logo, PRIMITIVES, GlyphRay } from './glyphs.jsx';

/* ── scroll reveal ── */
function useReveal() {
  useEffect(() => {
    const els = document.querySelectorAll('.reveal');
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add('in');
            io.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12, rootMargin: '0px 0px -8% 0px' }
    );
    els.forEach((el) => io.observe(el));
    return () => io.disconnect();
  }, []);
}

const REGISTER = [
  { code: '0', cls: 'r0', name: 'Carry', verb: 'Blue holds', color: 'var(--blue)', hex: '#0044AA',
    fn: 'Substrate, carry lock, base field. Hold, store, ground, preserve.',
    formula: 'BLUE CARRIES THE FIELD.' },
  { code: '2', cls: 'r2', name: 'Pause', verb: 'Amber interrupts', color: 'var(--amber)', hex: '#FFB300',
    fn: 'Pause layer, safety interlock, brake. Interrupt, suspend, protect, delay.',
    formula: 'AMBER PUTS A HAND ON THE BRAKE.' },
  { code: '1', cls: 'r1', name: 'Return', verb: 'Cyan activates', color: 'var(--cyan)', hex: '#00E5FF',
    fn: 'Return triangle, activation, forward state. Activate, resolve, recur, move forward.',
    formula: 'CYAN RELEASES THE SIGNAL FORWARD.' },
];

const VERBS = [
  { name: 'Carry', basis: 'Blue / 0', desc: 'Store an effect, reserve energy, hold a state for later.' },
  { name: 'Pause', basis: 'Amber / 2', desc: 'Suspend, interrupt, protect, delay, or freeze a sequence.' },
  { name: 'Return', basis: 'Cyan / 1', desc: 'Reactivate, recurse, resolve, or bring a state back into play.' },
  { name: 'Extend', basis: 'Line / F01', desc: 'Increase range, duration, continuity, or connection.' },
  { name: 'Commit', basis: 'Ray / F02', desc: 'Choose direction, lock intent, set a target, move forward.' },
  { name: 'Exchange', basis: 'Bilateral / F03', desc: 'Swap, mirror, negotiate, trade, or link two entities.' },
  { name: 'Seal', basis: 'Pending / F04', desc: 'Close, terminate, bind, or make permanent once confirmed.' },
];

const TERMINAL_LINES = [
  { prompt: 'ppxl inspect --glyph F02 --state return', output: 'FORM=RAY · STATE=1/RETURN · READING="directed intent released forward"', tone: 'cyan' },
  { prompt: 'ppxl render --register 0-2-1 --format specimen-card', output: 'BLUE holds field · AMBER interrupts motion · CYAN activates signal', tone: 'amber' },
  { prompt: 'ppxl merch compile --drop "0-2-1 Register"', output: '4 SKUS queued · cipher insert attached · operator metadata sealed', tone: 'blue' },
  { prompt: 'ppxl bind --object deckbox --glyph G07 --state pause', output: 'effect suspended without destroying origin · resume with CYAN return', tone: 'cyan' },
];

export default function App() {
  useReveal();
  const scrollTo = (id) => document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });

  return (
    <>
      {/* ───────── NAV ───────── */}
      <header className="nav">
        <div className="nav-inner">
          <div className="brand">
            <Logo size={32} />
            <div>
              <div className="brand-name">PPXL</div>
              <div className="brand-sub">Velmic Symbol-Language</div>
            </div>
          </div>
          <nav className="nav-links">
            <a onClick={() => scrollTo('register')}>Register</a>
            <a onClick={() => scrollTo('primitives')}>Operators</a>
            <a onClick={() => scrollTo('game')}>Game</a>
            <a onClick={() => scrollTo('terminal')}>CLI</a>
            <a onClick={() => scrollTo('merch')}>Merch</a>
            <a onClick={() => scrollTo('cipher')}>Cipher</a>
          </nav>
          <span className="nav-badge">Public Build</span>
        </div>
      </header>

      <main>
        {/* ───────── HERO ───────── */}
        <section className="hero">
          <div className="wrap hero-grid">
            <div className="reveal in">
              <span className="kicker">Velmic / 0-2-1 Register · Drop 0</span>
              <h1 className="hero-title">
                Symbols that<br />do <span className="accent-cyan">work.</span>
              </h1>
              <p className="hero-lead">
                Velmic is a symbolic operating language for state, signal, and passage.
                Each glyph carries a function. Each color carries a state. Use them as
                stickers, game tokens, seals, or composition marks — not decoration,
                <strong className="soft"> operators.</strong>
              </p>
              <div className="hero-statefns">
                <span><i className="dot" style={{ background: 'var(--blue)' }} /><b style={{ color: 'var(--blue)' }}>Blue</b> holds</span>
                <span><i className="dot" style={{ background: 'var(--amber)' }} /><b style={{ color: 'var(--amber)' }}>Amber</b> interrupts</span>
                <span><i className="dot" style={{ background: 'var(--cyan)' }} /><b style={{ color: 'var(--cyan)' }}>Cyan</b> activates</span>
              </div>
              <div className="hero-cta">
                <button className="btn btn-primary" onClick={() => scrollTo('launch')}>
                  View the launch drop
                </button>
                <button className="btn" onClick={() => scrollTo('register')}>
                  Read the grammar
                </button>
                <button className="btn btn-terminal" onClick={() => scrollTo('terminal')}>
                  Open CLI mode
                </button>
              </div>
            </div>

            <aside className="specimen reveal in">
              <div className="specimen-top">
                <span className="meta">Specimen</span>
                <span className="meta meta-cyan">F02 · State 1</span>
              </div>
              <div className="specimen-mark"><GlyphRay size={120} /></div>
              <div className="specimen-rows">
                <div className="row"><span>VELMIC</span><span>F02</span></div>
                <div className="row"><span>FORM</span><span>RAY</span></div>
                <div className="row"><span>FUNCTION</span><span>DIRECTED EXTENSION</span></div>
                <div className="row"><span>STATE</span><span>1 / RETURN</span></div>
                <div className="row"><span>READING</span><span>INTENT RELEASED</span></div>
              </div>
            </aside>
          </div>
        </section>

        {/* ───────── 0-2-1 REGISTER ───────── */}
        <section className="section" id="register">
          <div className="wrap">
            <div className="sec-head reveal">
              <span className="kicker">01 — State Encoding</span>
              <h2 className="sec-title">The 0-2-1 register</h2>
              <p className="sec-desc">
                The native palette is not a colorway. It is a three-state machine. Collect all
                three of a glyph and you hold its full state set — the same operator in carry,
                pause, and return.
              </p>
            </div>
            <div className="register-grid">
              {REGISTER.map((r) => (
                <article key={r.code} className={`reg-card ${r.cls} reveal`}>
                  <div className="reg-code">{r.code}</div>
                  <div className="reg-name">
                    <h3>{r.name}</h3>
                    <span className="meta">{r.verb}</span>
                  </div>
                  <p className="reg-fn">{r.fn}</p>
                  <div className="reg-hex meta" style={{ color: r.color }}>{r.hex}</div>
                  <div className="reg-formula">{r.formula}</div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* ───────── PRIMITIVES / OPERATORS ───────── */}
        <section className="section" id="primitives">
          <div className="wrap">
            <div className="sec-head reveal">
              <span className="kicker">02 — Primitive Operators</span>
              <h2 className="sec-title">Not icons. Operators.</h2>
              <p className="sec-desc">
                Four base forms compose the entire system. Each is a clean line-art mark — die-cut
                ready — and each carries one function and one game verb. The 22-glyph Mnemosyne
                alphabet derives from these.
              </p>
            </div>
            <div className="prim-grid">
              {PRIMITIVES.map(({ slot, name, Glyph, fn, verb, use, pending }) => (
                <article key={slot} className="prim-card reveal">
                  <div className="prim-glyphwrap">
                    <Glyph size={72} />
                    <div className="triplet">
                      <i style={{ background: 'var(--blue)' }} />
                      <i style={{ background: 'var(--amber)' }} />
                      <i style={{ background: 'var(--cyan)' }} />
                    </div>
                  </div>
                  <div>
                    <div className="prim-meta-top">
                      <span className="prim-slot">VELMIC / {slot}</span>
                      <span className="prim-verb">{verb}</span>
                    </div>
                    <h3 className="prim-name">{name}{pending && <span className="pending-tag"> ·</span>}</h3>
                    <p className="prim-fn">{fn}</p>
                    <p className="prim-use">{use}</p>
                    {pending && <p className="prim-use pending-tag">F04 pending canonical extraction from the Architecture Manual.</p>}
                  </div>
                </article>
              ))}
            </div>
          </div>
        </section>

        {/* ───────── GAME MECHANICS ───────── */}
        <section className="section" id="game">
          <div className="wrap">
            <div className="sec-head reveal">
              <span className="kicker">03 — Game System</span>
              <h2 className="sec-title">Glyphs for state, signal, and passage</h2>
              <p className="sec-desc">
                Velmic is playable immediately. Treat each glyph as a rule component — a state
                token, an activation marker, an interrupt, a direction lock. Seven core verbs map
                the whole language onto play.
              </p>
            </div>
            <div className="verbs">
              {VERBS.map((v) => (
                <article key={v.name} className="verb reveal">
                  <div className="verb-name">{v.name}</div>
                  <div className="verb-basis">{v.basis}</div>
                  <p className="verb-desc">{v.desc}</p>
                </article>
              ))}
            </div>

            <div className="statepath reveal">
              <div className="statepath-label meta">Sample card — G07 / Pause Register</div>
              <div className="statepath-flow">
                <span className="node"><i className="dot" style={{ background: 'var(--blue)' }} /><b style={{ color: 'var(--blue)' }}>Blue holds</b></span>
                <span className="arrow">→</span>
                <span className="node"><i className="dot" style={{ background: 'var(--amber)' }} /><b style={{ color: 'var(--amber)' }}>Amber pauses</b></span>
                <span className="arrow">→</span>
                <span className="node"><i className="dot" style={{ background: 'var(--cyan)' }} /><b style={{ color: 'var(--cyan)' }}>Cyan returns</b></span>
              </div>
              <p className="statepath-ex">
                Place Amber G07 on an active card. The effect remains present but cannot resolve
                until returned — a moving effect suspended without destroying its origin.
              </p>
            </div>
          </div>
        </section>

        {/* ───────── TERMINAL MODE ───────── */}
        <section className="section terminal-section" id="terminal">
          <div className="wrap terminal-grid">
            <div className="terminal-copy reveal">
              <span className="kicker">04 — Noir CLI Rendering</span>
              <h2 className="sec-title">Command-line specimen mode</h2>
              <p className="sec-desc">
                A neon terminal skin for the same grammar. Commands inspect glyphs, compile merch,
                bind state to objects, and render field-card specimens without turning the system
                into decoration.
              </p>
              <div className="terminal-actions">
                <span className="terminal-chip">phosphor glow</span>
                <span className="terminal-chip">mono metadata</span>
                <span className="terminal-chip">trading-card console</span>
              </div>
            </div>

            <article className="terminal-window reveal" aria-label="PPXL terminal rendering">
              <div className="terminal-bar">
                <span className="term-dot term-red" />
                <span className="term-dot term-amber" />
                <span className="term-dot term-cyan" />
                <span className="terminal-title">ppxl://velmic/register/0-2-1</span>
              </div>
              <div className="terminal-body">
                <div className="terminal-header">
                  <span>PPXL TERMINAL</span>
                  <span>SESSION: NOIR-021</span>
                </div>
                {TERMINAL_LINES.map((line) => (
                  <div key={line.prompt} className={`term-line tone-${line.tone}`}>
                    <div><span className="prompt">λ</span> {line.prompt}</div>
                    <div className="term-output">↳ {line.output}</div>
                  </div>
                ))}
                <div className="term-card">
                  <div className="term-card-meta">
                    <span>SPECIMEN / F02</span>
                    <span>STATE 1</span>
                  </div>
                  <div className="term-glyph"><GlyphRay size={86} /></div>
                  <div className="term-readout">
                    <span>FORM: RAY</span>
                    <span>FUNCTION: COMMIT</span>
                    <span>RESULT: MOVE WHEN READY</span>
                  </div>
                </div>
              </div>
            </article>
          </div>
        </section>

        {/* ───────── MERCH ARCHITECTURE ───────── */}
        <section className="section" id="merch">
          <div className="wrap">
            <div className="sec-head reveal">
              <span className="kicker">05 — Product Architecture</span>
              <h2 className="sec-title">A field kit, not a graphic collection</h2>
              <p className="sec-desc">
                The launch tier teaches the grammar: base forms, state colors, the full alphabet
                reference, and the instructions for use. A complete symbolic loop.
              </p>
            </div>
            <div className="merch-grid">
              <article className="merch-card span6 reveal">
                <div className="merch-head"><h3>Primitive Pack</h3><span className="merch-tier">Launch · Entry</span></div>
                <p className="merch-contents">F01–F04 in Blue, Amber, and Cyan. The entry product and teaching object — clear vinyl or die-cut.</p>
                <p className="merch-copy">"Four base forms. Three states. One grammar."</p>
                <div className="merch-sku">VEL-PACK-F01F04-021-MIXED-NATIVE</div>
              </article>
              <article className="merch-card span6 reveal">
                <div className="merch-head"><h3>State Singles</h3><span className="merch-tier">Launch · Utility</span></div>
                <p className="merch-contents">Individual Line, Ray, and Bilateral glyphs in each native state color. Low-cost impulse SKU.</p>
                <p className="merch-copy">"Choose the function. Choose the state. Mark the object."</p>
                <div className="merch-sku">VEL-PRIM-F02-1-CLEAR-NATIVE</div>
              </article>
              <article className="merch-card span4 reveal">
                <div className="merch-head"><h3>Mnemosyne Sheet</h3><span className="merch-tier">Collector</span></div>
                <p className="merch-contents">G01–G22 in a single chart format — sticker sheet, poster, or foil card sheet.</p>
                <p className="merch-copy">"Twenty-two operators across the arc."</p>
                <div className="merch-sku">VEL-SHEET-G01G22-X-SOLID</div>
              </article>
              <article className="merch-card span4 reveal">
                <div className="merch-head"><h3>Cipher Card</h3><span className="merch-tier">Insert · All orders</span></div>
                <p className="merch-contents">The 0-2-1 system, primitive meanings, game verbs, composition rules. Included with every order.</p>
                <p className="merch-copy">"This is not a logo sheet. It is a grammar key."</p>
                <div className="merch-sku">VEL-CARD-CIPHER-V1</div>
              </article>
              <article className="merch-card span4 reveal">
                <div className="merch-head"><h3>Operator Cards</h3><span className="merch-tier">Second-wave</span></div>
                <p className="merch-contents">One card per glyph — semantic plus game-facing function. A premium collector/game bridge.</p>
                <p className="merch-copy">"A deck of symbolic actions."</p>
                <div className="merch-sku">VEL-DECK-OPERATORS</div>
              </article>

              <article className="merch-card span12 bundle reveal">
                <div className="bundle-inner">
                  <div>
                    <div className="merch-head" style={{ justifyContent: 'flex-start', gap: 14 }}>
                      <h3>Field Kit Bundle</h3><span className="merch-tier">Flagship</span>
                    </div>
                    <p className="merch-contents">The complete launch in one archival envelope — everything needed to begin marking state.</p>
                    <div className="bundle-list">
                      <span className="chip">Primitive Pack</span>
                      <span className="chip">State Singles</span>
                      <span className="chip">Cipher Card</span>
                      <span className="chip">1 Patch</span>
                      <span className="chip">Alphabet Sheet</span>
                    </div>
                  </div>
                  <button className="btn btn-primary" onClick={() => scrollTo('launch')}>Reserve the kit</button>
                </div>
              </article>
            </div>
          </div>
        </section>

        {/* ───────── CIPHER CARD PREVIEW ───────── */}
        <section className="section" id="cipher">
          <div className="wrap">
            <div className="sec-head reveal">
              <span className="kicker">06 — Grammar Key</span>
              <h2 className="sec-title">The cipher card</h2>
              <p className="sec-desc">
                Shipped with every order. A 3.5 × 5 in field card that turns a sticker pack into a
                language kit — front holds the register and forms, back teaches the reading.
              </p>
            </div>
            <div className="cipher-grid">
              {/* FRONT */}
              <article className="cipher-card reveal">
                <div className="card-label"><span>Velmic / 0-2-1 Register</span><span>Front</span></div>
                <div className="cipher-title">Symbol-Language Field Card</div>
                <div className="cipher-sub">Each glyph carries a function. Each color carries a state.</div>
                <div className="cipher-row c0"><span className="c-code">0</span><span className="c-state">Blue · Carry</span><span className="c-fn">hold · store · ground</span></div>
                <div className="cipher-row c2"><span className="c-code">2</span><span className="c-state">Amber · Pause</span><span className="c-fn">interrupt · suspend · delay</span></div>
                <div className="cipher-row c1"><span className="c-code">1</span><span className="c-state">Cyan · Return</span><span className="c-fn">activate · resolve · recur</span></div>
                <div className="cipher-formula">
                  <b>F01</b> Line — Extend &nbsp;·&nbsp; <b>F02</b> Ray — Commit<br />
                  <b>F03</b> Bilateral — Exchange &nbsp;·&nbsp; <b>F04</b> Seal — Seal
                </div>
              </article>
              {/* BACK */}
              <article className="cipher-card reveal">
                <div className="card-label"><span>Velmic / Symbol Reference</span><span>Back</span></div>
                <div className="cipher-title">How to read a glyph</div>
                <div className="cipher-sub">Read every mark in three passes.</div>
                <div className="cipher-back-lines">
                  <div><span className="em">1. FORM</span> — what is the glyph doing?</div>
                  <div><span className="em">2. STATE</span> — what color condition is it in?</div>
                  <div><span className="em">3. POSITION</span> — where does it sit in the arc?</div>
                </div>
                <div className="cipher-formula" style={{ marginTop: 22 }}>
                  The glyph is the operator. The color is the state.<br />
                  The slot is the address. The arc is the memory.
                </div>
                <div className="cipher-mantra">
                  MARK THE OBJECT.<br />BIND THE STATE.<br />MOVE WHEN READY.
                </div>
              </article>
            </div>
          </div>
        </section>

        {/* ───────── LAUNCH / CTA ───────── */}
        <section className="section launch" id="launch">
          <div className="wrap">
            <span className="kicker" style={{ justifyContent: 'center' }}>Drop 0 — Carry Field</span>
            <h2 className="launch-title">The <span className="amber">0-2-1</span> Register</h2>
            <p className="launch-sub">
              The first drop: Primitive Pack, State Singles, Mnemosyne Alphabet Sheet, and the
              Cipher Card. The base forms, the state colors, the full reference, and the
              instructions for use.
            </p>
            <div className="launch-steps">
              <div className="step reveal">
                <div className="step-num">NEXT / 01</div>
                <h4>Extract glyph assets</h4>
                <p>Vectorize F04 and the 22 Mnemosyne glyphs from the Architecture Manual to production SVG.</p>
              </div>
              <div className="step reveal">
                <div className="step-num">NEXT / 02</div>
                <h4>Confirm colorways</h4>
                <p>Lock the four-line launch: Velmic Blue, Velmic Cyan, Howlbox, and Neutral.</p>
              </div>
              <div className="step reveal">
                <div className="step-num">NEXT / 03</div>
                <h4>Prototype print run</h4>
                <p>Home-printer test on vinyl, verify die-cut survivability, refine line weights.</p>
              </div>
              <div className="step reveal">
                <div className="step-num">NEXT / 04</div>
                <h4>Production vendor</h4>
                <p>Single-color test order, then the launch SKU files for the first drop.</p>
              </div>
            </div>
            <div className="launch-cta">
              <button className="btn btn-primary" onClick={() => scrollTo('register')}>Mark the object</button>
              <button className="btn" onClick={() => scrollTo('merch')}>See the full kit</button>
            </div>
          </div>
        </section>
      </main>

      {/* ───────── FOOTER ───────── */}
      <footer className="foot">
        <div className="wrap foot-inner">
          <div className="brand">
            <Logo size={30} />
            <div>
              <div className="brand-name">PPXL</div>
              <div className="brand-sub">A language for sealed, moving, and returning things</div>
            </div>
          </div>
          <div className="foot-meta">
            <div><b>STATUS:</b> SEED · SCAFFOLD COMPLETE · PUBLIC BUILD</div>
            <div><b>COMPILER:</b> BONE &amp; SAUCER LABS · MILTON, DE</div>
            <div><b>NOTE:</b> TERMINAL MODE READY FOR LIVE PUSH</div>
          </div>
        </div>
      </footer>
    </>
  );
}
