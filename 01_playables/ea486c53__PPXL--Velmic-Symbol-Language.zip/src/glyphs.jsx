// Velmic primitive glyphs + brand mark.
// Geometric, functional, state-aware. No fake-rune clutter.
// All strokes use currentColor so the parent sets the state color.

const baseProps = (size) => ({
  width: size,
  height: size,
  viewBox: '0 0 64 64',
  fill: 'none',
  stroke: 'currentColor',
  strokeWidth: 3,
  strokeLinecap: 'round',
  strokeLinejoin: 'round',
  'aria-hidden': true,
});

// F01 — LINE · unbounded extension, carrier signal
export function GlyphLine({ size = 64 }) {
  return (
    <svg {...baseProps(size)}>
      <line x1="10" y1="32" x2="54" y2="32" />
      <circle cx="10" cy="32" r="1.6" fill="currentColor" stroke="none" opacity="0.5" />
      <circle cx="54" cy="32" r="1.6" fill="currentColor" stroke="none" opacity="0.5" />
    </svg>
  );
}

// F02 — RAY · directed extension from a fixed origin
export function GlyphRay({ size = 64 }) {
  return (
    <svg {...baseProps(size)}>
      <circle cx="13" cy="32" r="3.4" fill="currentColor" stroke="none" />
      <line x1="16" y1="32" x2="48" y2="32" />
      <path d="M40 23 L52 32 L40 41" />
    </svg>
  );
}

// F03 — BILATERAL · bidirectional relation, dialogue, exchange
export function GlyphBilateral({ size = 64 }) {
  return (
    <svg {...baseProps(size)}>
      <line x1="16" y1="32" x2="48" y2="32" />
      <path d="M24 23 L12 32 L24 41" />
      <path d="M40 23 L52 32 L40 41" />
    </svg>
  );
}

// F04 — SEAL · closed / terminated form, confirmed once verified (pending canonical extraction)
export function GlyphSeal({ size = 64 }) {
  return (
    <svg {...baseProps(size)}>
      <rect x="16" y="16" width="32" height="32" rx="3" />
      <path d="M24 32 L30 39 L42 25" strokeWidth="3" />
    </svg>
  );
}

export const PRIMITIVES = [
  { slot: 'F01', name: 'Line', Glyph: GlyphLine, fn: 'Unbounded extension · carrier signal · raw potential', verb: 'Extend', use: 'Increase range, duration, continuity, or connection.' },
  { slot: 'F02', name: 'Ray', Glyph: GlyphRay, fn: 'Directed extension from a fixed origin · commitment', verb: 'Commit', use: 'Choose direction, lock intent, set a target, move forward.' },
  { slot: 'F03', name: 'Bilateral', Glyph: GlyphBilateral, fn: 'Bidirectional relation · dialogue · exchange', verb: 'Exchange', use: 'Swap, mirror, negotiate, trade, or link two entities.' },
  { slot: 'F04', name: 'Seal', Glyph: GlyphSeal, fn: 'Closed / terminated form · confirmed once verified', verb: 'Seal', use: 'Close, terminate, bind, or make permanent once confirmed.', pending: true },
];

// Brand mark — overlapping carry/pause/return registers locked into one operator.
// Blue ground (carry) · amber brake (pause) · cyan return (activate).
export function Logo({ size = 34 }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      fill="none"
      role="img"
      aria-label="PPXL Velmic mark"
    >
      {/* 0 — carry: enclosing ground */}
      <rect x="6" y="6" width="36" height="36" rx="7" stroke="var(--blue)" strokeWidth="2.4" />
      {/* 2 — pause: amber interlock bar */}
      <line x1="14" y1="24" x2="34" y2="24" stroke="var(--amber)" strokeWidth="2.6" strokeLinecap="round" />
      {/* 1 — return: cyan triangle releasing forward */}
      <path d="M20 15 L32 24 L20 33 Z" stroke="var(--cyan)" strokeWidth="2.6" strokeLinejoin="round" />
    </svg>
  );
}
