// ===== Theme toggle =====
(function () {
  const t = document.querySelector('[data-theme-toggle]');
  const r = document.documentElement;
  let d = matchMedia('(prefers-color-scheme:dark)').matches ? 'dark' : 'dark'; // default dark — it's the canonical mode
  r.setAttribute('data-theme', d);
  const render = () => {
    t.setAttribute('aria-label', 'Switch to ' + (d === 'dark' ? 'light' : 'dark') + ' mode');
    t.innerHTML =
      d === 'dark'
        ? '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>'
        : '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>';
  };
  render();
  t.addEventListener('click', () => {
    d = d === 'dark' ? 'light' : 'dark';
    r.setAttribute('data-theme', d);
    render();
    drawHex(); // recolor canvas
  });
})();

// ===== Scroll reveal =====
(function () {
  const io = new IntersectionObserver(
    (entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) {
          e.target.classList.add('in');
          io.unobserve(e.target);
        }
      });
    },
    { threshold: 0.12, rootMargin: '0px 0px -60px 0px' }
  );
  document.querySelectorAll('.reveal').forEach((el) => io.observe(el));
})();

// ===== Hex Forge =====
const canvas = document.getElementById('hexCanvas');
const ctx = canvas ? canvas.getContext('2d') : null;

const PRESETS = {
  open:    { radius: 38, density: 0.78, signal: 0.35, ember: 0.10, crystal: 0.02, ring: false },
  dense:   { radius: 22, density: 0.92, signal: 0.30, ember: 0.18, crystal: 0.05, ring: true },
  ember:   { radius: 30, density: 0.88, signal: 0.10, ember: 0.55, crystal: 0.04, ring: false },
  signal:  { radius: 30, density: 0.90, signal: 0.60, ember: 0.05, crystal: 0.06, ring: true },
  crystal: { radius: 28, density: 0.85, signal: 0.22, ember: 0.22, crystal: 0.22, ring: true },
};

let currentPreset = 'open';

function cssVar(name) {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}

// flat-top hex coords. axial → pixel
function hexCorner(cx, cy, r, i) {
  const angle = (Math.PI / 180) * (60 * i); // flat-top: 0,60,120...
  return [cx + r * Math.cos(angle), cy + r * Math.sin(angle)];
}

function drawHexShape(cx, cy, r) {
  ctx.beginPath();
  for (let i = 0; i < 6; i++) {
    const [x, y] = hexCorner(cx, cy, r, i);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.closePath();
}

// seeded random for deterministic redraws within a preset
function mulberry32(seed) {
  return function () {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function drawHex() {
  if (!ctx) return;
  const dpr = window.devicePixelRatio || 1;
  const w = canvas.clientWidth;
  const h = canvas.clientHeight;
  canvas.width = w * dpr;
  canvas.height = h * dpr;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);

  const p = PRESETS[currentPreset];
  const r = p.radius;
  const hSpacing = r * 1.5; // flat-top horizontal step
  const vSpacing = r * Math.sqrt(3);
  const cols = Math.ceil(w / hSpacing) + 2;
  const rows = Math.ceil(h / vSpacing) + 2;
  const seed = ({ open: 11, dense: 23, ember: 47, signal: 91, crystal: 137 })[currentPreset];
  const rand = mulberry32(seed);

  const primary = cssVar('--color-primary') || '#5fd9e8';
  const ember = cssVar('--color-ember') || '#ff7a3a';
  const bg = cssVar('--color-bg') || '#0a0b0e';
  const border = cssVar('--color-border') || '#2a303d';
  const muted = cssVar('--color-text-muted') || '#8c8a82';

  for (let q = -1; q < cols; q++) {
    for (let s = -1; s < rows; s++) {
      const cx = q * hSpacing + r;
      const cy = s * vSpacing + (q % 2 === 0 ? r : r + vSpacing / 2);
      if (cx < -r || cx > w + r || cy < -r || cy > h + r) continue;

      const roll = rand();
      if (roll > p.density) continue; // empty hex

      // choose fill class
      const t = rand();
      let fillStyle = 'transparent';
      let strokeStyle = border;
      let innerDot = null;
      let lineWidth = 1;

      if (t < p.crystal) {
        // crystal — prismatic gradient
        const grad = ctx.createLinearGradient(cx - r, cy - r, cx + r, cy + r);
        grad.addColorStop(0, primary);
        grad.addColorStop(0.5, '#c9a6ff');
        grad.addColorStop(1, ember);
        fillStyle = grad;
        strokeStyle = 'rgba(255,255,255,0.6)';
        lineWidth = 1.2;
      } else if (t < p.crystal + p.ember) {
        fillStyle = `${ember}33`;
        strokeStyle = ember;
        innerDot = ember;
        lineWidth = 1.4;
      } else if (t < p.crystal + p.ember + p.signal) {
        fillStyle = `${primary}26`;
        strokeStyle = primary;
        innerDot = primary;
        lineWidth = 1.4;
      } else {
        // neutral hex
        fillStyle = 'transparent';
        strokeStyle = `${muted}55`;
        lineWidth = 1;
      }

      drawHexShape(cx, cy, r - 2);
      if (fillStyle !== 'transparent') {
        ctx.fillStyle = fillStyle;
        ctx.fill();
      }
      ctx.strokeStyle = strokeStyle;
      ctx.lineWidth = lineWidth;
      ctx.stroke();

      if (innerDot) {
        ctx.beginPath();
        ctx.arc(cx, cy, 2.2, 0, Math.PI * 2);
        ctx.fillStyle = innerDot;
        ctx.fill();
      }

      // optional ring for "vault"/"weave" presets
      if (p.ring && innerDot) {
        drawHexShape(cx, cy, r - 7);
        ctx.strokeStyle = `${innerDot}55`;
        ctx.lineWidth = 0.8;
        ctx.stroke();
      }
    }
  }

  // central seal — fixed signature
  const cx = w / 2,
    cy = h / 2;
  drawHexShape(cx, cy, r * 1.6);
  ctx.strokeStyle = 'rgba(255,255,255,0.18)';
  ctx.lineWidth = 1.2;
  ctx.setLineDash([3, 4]);
  ctx.stroke();
  ctx.setLineDash([]);

  drawHexShape(cx, cy, r * 0.6);
  ctx.fillStyle = bg;
  ctx.fill();
  ctx.strokeStyle = primary;
  ctx.lineWidth = 1.5;
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(cx, cy, 3, 0, Math.PI * 2);
  ctx.fillStyle = ember;
  ctx.fill();
}

// wire up controls
document.querySelectorAll('.forge-controls button').forEach((btn) => {
  btn.addEventListener('click', () => {
    document
      .querySelectorAll('.forge-controls button')
      .forEach((b) => b.setAttribute('aria-pressed', 'false'));
    btn.setAttribute('aria-pressed', 'true');
    currentPreset = btn.dataset.preset;
    drawHex();
  });
});

window.addEventListener('resize', () => {
  // debounce
  clearTimeout(window.__hexResize);
  window.__hexResize = setTimeout(drawHex, 150);
});

// initial draw — wait for fonts/layout
window.addEventListener('load', drawHex);
setTimeout(drawHex, 100);
