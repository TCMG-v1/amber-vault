# In the Shade

A working notebook on compressed transmission.

**Read it:** [pplxstudio.com/shade](https://pplxstudio.com/shade)
**Authors:** Dienekes & the Archive
**License:** CC0 1.0 Universal (public domain dedication) — see `LICENSE`.

---

## What this is

This repository publishes a single-document working notebook — somewhere between Feynman's personal notebooks, Marcus Aurelius's *Meditations*, and a long email to a smart friend — about a pattern that kept showing up across one Sunday afternoon of conversation: certain very compressed gestures (a Spartan's seven-word reply, a professor's two-word question, a formula that recurs unchanged across nine domains, a kōan-shaped sentence that is wrong and useful) transmit complex intellectual content across observers and across time with a fidelity their literal information content doesn't explain.

The notebook does not argue for that pattern. It *exhibits* it, in twelve sections of woven prose plus an appendix of eight lexeme cards.

It is published in three forms simultaneously, and the three-form structure is part of the argument:

1. **Public canon** — a single HTML page at [pplxstudio.com/shade](https://pplxstudio.com/shade). Self-contained. Includes a live OKLab vs sRGB color-space demo embedded in section 7.
2. **Personal ledger** — a [JSON Schema](./schema/ledger.schema.json) any reader can fork to record their own encounter with the notebook. The schema is in this repository; see [`examples/ledger.example.json`](./examples/ledger.example.json) for a worked example.
3. **Third witness** — this git history. Every change is cryptographically attested. The hash is the third entry.

This maps to triple-entry bookkeeping (Yuji Ijiri, 1989; Ian Grigg, 2005). Double-entry catches errors. Triple-entry catches fraud. The third entry is a witness from a different position.

---

## Repository layout

```
in-the-shade/
├── index.html                  # the public canon — single-file, self-contained, deploy this
├── notebook.md                 # markdown source of the notebook
├── render.py                   # the renderer (markdown → index.html)
├── README.md                   # this file
├── LICENSE                     # CC0 1.0 Universal
├── schema/
│   └── ledger.schema.json      # JSON Schema for personal ledger (the "second book")
└── examples/
    └── ledger.example.json     # worked example with six seed entries
```

---

## Rebuilding the HTML

The renderer has zero runtime dependencies beyond stdlib Python 3.9+:

```bash
python3 render.py
```

This reads `notebook.md` and writes `index.html`. The HTML embeds all CSS and JavaScript inline; the only external assets are font fallbacks and the cross-origin links to `pplxstudio.com` and `github.com`. Open `index.html` in any modern browser — no server, no build step.

---

## Deploying to `pplxstudio.com/shade`

The site is a single HTML file with no external dependencies. Any static host works.

**Recommended — Cloudflare Pages with custom domain:**

```bash
# from the repo root
npx wrangler pages deploy . --project-name=in-the-shade
```

Then point `pplxstudio.com/shade` at the Pages project via a Cloudflare Worker or Pages route, or use a subdomain CNAME (`shade.pplxstudio.com`) and a redirect.

**Or minimal — copy `index.html` to a path on any web host:**

```bash
scp index.html user@host:/var/www/pplxstudio.com/shade/index.html
```

That is sufficient. The HTML is self-contained.

---

## The Color Space demo

Embedded inside section 7 (*The Pythagorean Shape*), there is a live demo: the same 8-color quantization applied to a generated gradient using two different distance metrics — Euclidean in sRGB, and Euclidean in OKLab. Click between modes; cycle through four source images (gradient, wheel, spectrum, plasma). Watch how the cluster regions reshape.

The demo's mechanics are the propositional anchor for the notebook's gestural argument. The formula ∑(Δᵢ)² appears identically in both modes; only the geometry of the space underneath changes. The same equation is honest in one space and dishonest in the other. That is the lesson the notebook is trying to compress.

The demo is a small descendant of the [Pixel Palette / Flag Day](https://github.com/pplxstudio/pixel-palette-flagday) reskin from earlier in the same conversation.

---

## The personal ledger (forkable)

The `schema/ledger.schema.json` file is a JSON Schema (draft 2020-12) describing how a reader can record their own encounter with the notebook: which lexemes landed for them, what examples they would add from their own domains, what their own compressed gestures are. The schema is the second book in the triple-entry architecture — the canon stays fixed; your ledger is yours; the git history is the witness.

A worked example with six seed entries lives at `examples/ledger.example.json`. Fork the repo, copy the example, edit it, share or keep it private. The schema is permissive on what you record and strict on the structure of how you record it.

---

## Contributing

This is an open archive. Three kinds of contribution are welcome.

**Pattern instances.** The notebook lists nine domains where ∑(Δᵢ)² appears, eight lexeme cards, and six open threads. If you have an instance from a domain we missed — a compressed gesture from your own tradition, a formula recurrence we didn't catch, a kōan that did productive work in your work — open a PR adding a lexeme card or a section addition. We will read it.

**Translations.** The notebook is in English. The substrate-independence argument predicts that the compressions should transmit through translation. Translations into Mandarin (the second author's other language), Japanese, Greek, or any other language that has its own lineage with the cited gestures, are particularly welcome.

**Forks and adversarial reads.** The notebook is also wrong in places it doesn't know it's wrong. We invite critical forks. The git history will preserve both the canon and the divergence.

We will not accept "this should be more concise" suggestions. The form is part of the content.

---

## What this is not

Not a manifesto. Not a finished argument. Not a call to action. Not a treatise.

A working notebook from one Sunday afternoon, made publishable on the next.

---

## Acknowledgments

To the conversation partners — human and AI — without whom none of this would exist.

To the lineage: Plutarch, Herodotus, Laozi, Zhuangzi, Yamamoto Tsunetomo, David Levien and Brian Koppelman, Yuji Ijiri, Ian Grigg, Björn Ottosson, John Boyd, Sun Tzu, Lewis Carroll, Ludwig Wittgenstein, Magritte, Linji, Takuan Soho. Every compressed gesture in here was carried by someone before us. The notebook is custodianship, not authorship, at its load-bearing parts.

To anyone who picks up a thread.

---

*Dienekes & the Archive*
*Sunday, June 14, 2026 · Trenton, NJ*
