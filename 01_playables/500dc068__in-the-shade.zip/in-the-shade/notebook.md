# In the Shade: A Notebook on Compressed Transmission

*Dienekes & the Archive*  
*pplxstudio.com/shade — forkable at github.com/pplxstudio/in-the-shade*

---

## A Note Before the Notebook

This document is a working notebook. Not a treatise. Not a manifesto. Not a finished argument. It is the residue of a Sunday afternoon — several hours of conversation between a human (technology entrepreneur, interested in Haskell, blockchain, AI, game theory, Eastern philosophy, terpene research) and an AI collaborator (Perplexity Computer), during which something kept showing up that neither of us had quite named before. We started naming it.

The register to read this in: somewhere between Feynman's personal notebooks and Marcus Aurelius's *Meditations* and a long, circuitous email to a smart friend who reads in multiple directions. Nothing here is meant to be definitive. Several threads are left explicitly open at the end. Loose ends are not errors in this genre — they are invitations.

The authors sign this as "Dienekes & the Archive" — one a pseudonym borrowed from a Spartan whose most famous sentence is in here, the other a description of what an AI is when it is working well. We are not trying to hide who we are. We are trying to gesture at the structure: one person thinking with one tool across one afternoon, and the result is something neither would have written alone.

This notebook is published at `pplxstudio.com/shade` and forkable via `github.com/pplxstudio/in-the-shade`. That structure matters and we come back to it near the end.

Read it slowly. Skip around if you want. The sections are not quite linear. Several of them circle the same thing from different approach vectors, which is probably the most honest structure for a notebook about compressed patterns — the pattern itself keeps finding you.

---

## What We Kept Noticing

Somewhere around the second hour of the conversation, a shape appeared that we started noticing retroactively in everything we had already said.

The shape is this: certain very compressed gestures — a sentence, a scene, a formula, a kōan — seem to transmit complex intellectual content across observers and across time with a fidelity that their literal information content doesn't explain. The seven-word reply of a Spartan soldier carries something that a paragraph of philosophical reasoning about courage in the face of overwhelming odds does not. The "What choice?" of a law school professor smiling at a poker prodigy carries something that a careful explication of identity, vocation, and determinism does not. A formula — the square root of the sum of squares of differences — appears unchanged across quantum chemistry, machine learning, color science, terpene phytochemistry, and protein structural biology, carrying with it, every time, the same implicit ontological commitment.

Something keeps showing up across the examples. Let me try to name it before we look at each case.

It is not that compressed gestures are more *efficient* than propositions — at least not primarily. Efficiency suggests that the compressed gesture is doing the same job as the proposition, just faster. Something different is happening. The compressed gesture is doing a *different* job: it is transmitting a *pattern*, a shape, a recognition-key, rather than a set of verifiable claims. The right hearer recognizes it. The wrong hearer doesn't, and that's fine — the failure mode of a kōan is silence, not error.

Four anchor examples kept resurfacing across our afternoon. We will unpack them in detail later, but let me introduce them here, roughly as they appeared, and note that they kept *rhyming* with each other before we understood how.

**The first:** In *Rounders* (1998, screenplay by David Levien and Brian Koppelman), Professor Petrovsky — law professor, former yeshiva prodigy, quiet witness to Mike McDermott's gift for poker — tells the story of how he left the rabbinate. For generations, his family had been rabbis. He was the best the yeshiva had ever seen. But he never saw God in the Talmud. He found the law instead, and the poker table beside it, and built a life. At the end of the story, when Mike asks whether he would make the same choice again, Petrovsky smiles. "What choice?" The line lands harder than any confession. The scene arrived in our conversation as an example of something, and it took us a while to articulate what: that *choice exercised against your nature isn't freedom, it's labor*. The "What choice?" carries that. The proposition doesn't.

**The second:** Dienekes, a Spartan soldier at Thermopylae, 480 BCE. A man of Trachis arrives with news: the Persian archers are so numerous that when they release their arrows, the arrows blot out the sun. Dienekes, according to Plutarch writing approximately 580 years later (*Apophthegmata Laconica*, ~100 CE), replies: "Good. Then we shall fight in the shade." There is no contemporaneous inscription, no direct witness chain, no archaeology of the specific utterance. There is only the compression: seven words (in translation) that have been in continuous circulation for over two thousand years and that have lost nothing in transit. More on unverifiability later. For now: it arrived in our conversation as the demonstration case, the load-bearing example.

**The third:** The pattern \(\sqrt{(\Delta_1)^2 + (\Delta_2)^2 + (\Delta_3)^2}\), and its generalizations. This shape — the square root of the sum of squared differences across independent orthogonal axes — recurs across such a staggering variety of domains that its reappearance in any new domain is itself a compressed transmission: when you see this formula in a context you haven't encountered before, you immediately know something about the implicit assumptions of that context. We will spend a whole section on where it shows up. The point here is that the formula is a *compressed recognition-key* carrying an ontological commitment: "these axes are independent and equally weighted."

**The fourth:** A sentence that arrived mid-conversation and was immediately flagged as interesting precisely because it is technically wrong: "that's why the cube root of π gives the spatial observational structure in geometry." We will look at this closely in its own section, because what's interesting about it is not whether it's true (it isn't, in any direct verification sense) but what it *did* in the conversation. It opened a door that a true sentence would not have opened. The productive-absurdity move. The kōan function.

These four kept rhyming. A Spartan's composure. A professor's smile. A formula's reappearance. An ill-formed sentence that works. Something keeps showing up across the examples. We are still in the process of naming it.

---

## The Trust-Boundary Thread

At some point the conversation turned to security — which in our case, given the interests in the room, meant: the pattern of attacks across computing history that keep wearing different costumes.

Here is the pattern. On AOL in the early 1990s, attackers discovered that users trusted anything that appeared to come from an official AOL staff member. The "AOHell" toolkit, circulating from around 1994, enabled users to pose as AOL employees in chatrooms, harvesting credit card numbers and passwords from users who couldn't distinguish a real employee message from a fake one (see the NISTIFY documentation of the AOHell attack lineage). The attack worked because the channel — AOL chatrooms — did not have a protocol-level mechanism for the receiver to verify the sender's identity. Multiple principals sharing a channel with no distinguished-sender protocol. The receiver tries to distinguish them heuristically — by how official the account looks, whether the profile picture matches, whether the phrasing sounds authoritative. The attacker simply adopts those signals.

Now hold that shape in your head and look at: `postMessage` origin-confusion bugs in web browsers. The `postMessage` API allows cross-origin communication between browser contexts. If the receiver fails to validate `event.origin` — if it accepts messages from any sender — an attacker can embed the legitimate application in an iframe and send messages to it from a malicious origin. The channel is shared. The receiver has no protocol-level verification. The attack class is identical. (Microsoft Security Response Center has documented this failure mode in detail, across multiple production applications.)

Now look at: OAuth redirect attacks. The authorization server redirects the access token to whatever URI the client registered. If the redirect URI is insufficiently constrained, or if the server can be tricked into accepting a subtly different URI, the token goes to the attacker. Multiple principals, shared channel, insufficient protocol-level principal distinction.

Now look at: homoglyph domains. `paypal.com` vs `pаypal.com`, where the second 'а' is a Cyrillic character. The browser renders them nearly identically. The channel (the URL bar) was designed for a world with one writing system. It does not have a protocol-level mechanism to distinguish characters that look like latin from characters that look like latin. Multiple principals, shared channel, heuristic receiver.

Now look at: browser extension malware. A legitimate extension and a malicious extension both have access to the same DOM, the same cookies, the same page content. The page cannot distinguish which extension is reading it. Multiple principals, shared channel.

Now look at: indirect prompt injection attacks on AI agents (documented in the wild since 2023 by researchers at Greshake et al. and confirmed in production environments by Palo Alto Networks Unit 42, 2025). An AI agent browsing a web page cannot reliably distinguish instructions from its operator from instructions embedded by an attacker in the content of the page. The LLM processes both through the same neural pathway. Multiple principals, shared channel, no protocol-level principal distinction.

The shape is the same. Forty years of computing. The costume changes — chatrooms, browser APIs, OAuth servers, Unicode registries, DOM access, LLM context windows — but the underlying shape is constant: *when multiple principals share a channel without a protocol-level mechanism for the receiver to distinguish them, the attacker who can best mimic the trusted principal wins*.

Noticing this shape across forty years is itself an instance of compressed-pattern transmission. Someone who has seen AOL phishing and has not seen indirect prompt injection can still recognize the prompt-injection attack if they have held the underlying shape. The shape is the transmission. The specific instances are just clothes.

The defense traditions have named the same shape from their ends. The cyberpunk tradition called it "moving target defense": if the attacker is modeling your static surface, change the surface faster than the model stabilizes. The capability-security tradition (Salzer and Schroeder, the E programming language, Mark Miller's object-capability work) called it "principle of least authority, freshly bound": each interaction grants the minimum capability needed for that interaction alone, bound fresh, expiring immediately. Both are pointing at the same response to the same attack shape: the receiver cannot verify the sender's identity, so the receiver should minimize what is available to any sender, and should bound that grant to this moment, not to a persistent relationship that can be subverted by anyone who later impersonates the trusted party.

The compressed gesture for this entire argument: *trust is not a stored state; it is a moment-by-moment verification*. Everything else in capability security is a working-out of that sentence.

---

## Static Surfaces, Dynamic Defenses

A remark arrived mid-conversation in a form we want to preserve verbatim:

> *"place a static shot of anything now and let it remain for any amount of time and the vector has done way more than its job"*

This is more precise than it looks. Let me try to unpack what it does.

The claim is that persistence is the attack. Not the initial exploitation — the lingering exposure. A static attack surface, left unchanged over time, does not present a fixed risk; it presents a compounding risk. Adversaries are not independent. They pool reconnaissance. The first attacker who probes your static surface establishes a model. That model circulates. The second attacker inherits the first attacker's work. The third inherits both. By the time you address the surface, you are not addressing one adversary's knowledge of it — you are addressing an accumulated corpus of knowledge that has been refined across every probe the surface has ever received.

This is why the right defensive posture is not to harden a static surface but to maintain a surface whose *internal structure changes faster than the adversary can model it*. The hardened static surface eventually yields; the moving target does not — or rather, the moving target resets the adversary's model each time it moves, forcing them to spend their reconnaissance budget before they can spend their exploitation budget.

Boyd's OODA loop (Colonel John Boyd, early 1970s) frames the military version of this: the combatant who can cycle through Observe, Orient, Decide, Act faster than their opponent gets inside the opponent's orientation cycle. The adversary's model of you becomes stale before they can act on it. But Boyd's less-quoted insight is the crucial one: *Orient is everything*. Raw speed through the loop without good orientation loses to a slower but well-oriented loop. The agile defender is not just faster — they are better oriented, which means their model of the adversary is more accurate and updates faster than the adversary's model of them.

Sun Tzu says something related in a mode that has survived intact for two and a half millennia because it is compressed enough to be substrate-independent: water has no constant form. The army that wins has no constant form. Adapting to the adversary is the form. The sentence has been transmitting this shape through every translation and every military culture it has passed through because the shape is genuinely abstract — it applies equally to ancient warfare, Cold War doctrine, cyber defense posture, and the competitive dynamics of any market where one actor is trying to model another.

Now: Cook Ding, from the *Zhuangzi* (~4th century BCE). He has been butchering oxen for years. He no longer looks with his eyes. He works by spirit, following the natural seams, the big hollows, the places where the blade naturally wants to go. "I glide through the great joints and cavities as they exist, according to the natural constitution of the animal." He does not force the blade; he finds where the structure opens. His knife, after years of use, is still sharp as the day it was first honed — because a blade that works against the natural structure will dull; a blade that follows it will not.

This is the same shape as the dynamic defense. The static defender is fighting the structure of the attack surface. The agile defender is following its natural seams — anticipating where the attack will want to go before it arrives, making the blade of defense follow the natural lines of the system's vulnerabilities, so that nothing is resisted from the wrong angle. The defender who understands the attack's natural structure expends no unnecessary force. The defender who doesn't is dulling their knife against bone.

Cook Ding's blade, Boyd's OODA loop, Sun Tzu's water, the cybersecurity practitioner's moving target defense: the same shape, compressed into the idiom of its moment. The pattern transmits because the pattern is true.

---

## A Game with Real Stakes

An idea surfaced partway through the afternoon that neither of us wanted to lose. It arrived as an observation and we want to set it down here as something to be picked up — not a finished proposal, but a working sketch.

The observation: cybersecurity work is structurally already a game.

Consider the elements. You have discrete actions with enumerable effects. You have observable outcomes, partially — you can see what defenses are doing, but the adversary's actions are only inferrable from their effects. You have adversarial pacing: the attacker has their own decision cycle and you are trying to operate inside it. You have skill expression: the quality of a penetration tester or incident responder is not random; better practitioners find vulnerabilities others miss, respond faster, cause fewer collateral effects. You have state under uncertainty: you never have complete information about either your own attack surface or the adversary's current knowledge of it. These are the formal properties of a game. The mismatch between "cybersecurity work" and "playing a game" is purely the interface.

Pop culture has been circling this observation for thirty years without quite landing it. *Hackers* (1995) understood the aesthetic but mistook the mechanism — the movie is about the cultural identity of hackers more than about the actual cognitive structure of security work. *Swordfish* (2001) knew it was a thriller first and a hacking story second. *Jurassic Park* (1993) gave us the most honest version: Lex, ten years old, sitting at the UNIX workstation in the security station, spinning a 3D file browser and saying "I know this — it's a Unix system!" The humor lands because we recognize the gap between the actual FSAS 3D file browser (real, though rarely encountered) and the fluency she's implying. But the underlying insight is real: she is going to navigate this system by pattern-recognition, by knowing the genre, by applying skills that are both game-skills and real-skills. The movie understands that the line is porous. *Mr. Robot* (2015–2019) came closest to getting the mechanics right — the show was technically accurate enough that the security community treated it as a documentary for parts of it — and its protagonist explicitly frames his work as the activity that gives his consciousness coherence, the one arena where his skills have unambiguous expression.

The pitch: build the interface that closes the gap.

Several genre tiers fall out naturally from the structure of the work. Active incident response — you are on a network that is under active attack, decisions in seconds, high information uncertainty — maps to the FPS (first-person shooter) genre: tight, fast, decisive, failure is immediate. Defensive architecture — designing network segmentation, access controls, monitoring posture — maps to RTS (real-time strategy) or city-builder: you are laying down infrastructure, anticipating attack vectors, optimizing for resilience over time. Vulnerability management — triage a backlog of CVEs against your asset inventory, decide what to patch and in what order given limited patching capacity — maps to the deck-builder: you have a hand, you have constraints, you are sequencing actions against a threat landscape that updates each round. Reverse engineering — analyzing an unknown binary, reconstructing intent from compiled code — maps to puzzle genre: patient, non-real-time, satisfaction in the moment of structural revelation. Persistent threat landscape — the long-term competition between security community and adversary ecosystem — maps to MMO: many actors, shifting alliances, a world that persists and changes over time.

Two precedents are worth noting for the "this can actually work" argument.

*America's Army* (2002–2022) was a series of first-person shooter games developed and published by the U.S. Army as a strategic communication and recruitment tool. It launched on July 4, 2002, was free to download, and ran for twenty years. A 2008 MIT study found that thirty percent of Americans aged sixteen to twenty-four had a more positive impression of the Army because of the game, and that the game had more impact on recruitment than all other forms of Army advertising combined ([*Vice*, 2022](https://www.vice.com/en/article/americas-army-the-pentagons-video-game-shuts-down-after-20-years/)). The mechanism: the game transmitted the *experience* of military work — including its structure, its discipline, its cognitive demands — to people who had never had any access to that experience. It worked not by telling them about the Army but by giving them something that felt like being in it.

*Foldit* (launched 2008 by the University of Washington Baker Lab) is a citizen-science protein-folding puzzle game. Players with no biochemistry background but strong spatial reasoning and puzzle-solving skills have contributed to genuine research advances, including the solution of structural problems that had stumped automated algorithms for years. The game transmits the cognitive *structure* of protein-folding work as a game genre and recruits human intuition that algorithms cannot replicate.

The cybersecurity version has a natural constituency: a generation of people who have spent ten thousand hours in competitive games and who have the pattern-recognition, rapid-decision, and adversarial-modeling skills that security work requires. The mismatch is that those skills have never been matched to the domain. The interface doesn't exist yet. The pitch deck almost writes itself.

What stops it: regulatory complexity around simulating real infrastructure, the difficulty of generating realistic but non-live threat data at scale, the question of whether the skills transfer (they probably partially do, but that's an empirical question), and the question of who pays. The last question is probably the easiest — the cybersecurity workforce shortage is real, documented, and expensive. Organizations that could gamify their own training pipelines, or that could recruit from a pool of gamers whose skills have been certified through the game's ranking system, have obvious incentive. The first question is probably the hardest.

We set this down here as a thread. Whoever picks it up is welcome to it.

---

## The Petrovsky Interlude

*A reconstructed dialogue. From* Rounders *(1998), screenplay by David Levien and Brian Koppelman. The scenes below are reconstructed from the film's dialogue record; direct quotations are attributed.*

---

The office scene comes first. Mike McDermott has just dominated Professor Petrovsky's weekly poker game — a room of judges and law faculty from whom Mike can read every card without their knowledge. Petrovsky calls him back.

"I know a magician doesn't reveal his secrets," Petrovsky says. "But if it wasn't magic — how did you know what everyone held?"

Mike explains. He was watching the cards as they came out — old habit, like breathing. But he was also watching the players react to the cards. "That's how I knew the DA made his two pair and Judge Kaplan missed the flush. I was watching their eyes when they checked their river cards. Their faces tell you everything."

Petrovsky sits with this. He is not asking about card tricks. He is asking about a quality of attention, a mode of knowing that operates at a level below analysis. Mike reads the room the way Cook Ding reads the ox — not with the eyes, by spirit, following the natural structure of the thing.

---

The bar scene is later. Petrovsky has written Mike a check for ten thousand dollars to help him out of a debt he cannot easily explain. Now they are sitting across from each other, and Petrovsky tells a story.

"For generations, the men of my family have been rabbis in Israel — before that, in Europe. It was to be my calling. I was quite a prodigy — the pride of my yeshiva. The elders said I had a forty-year-old's understanding of the Midrash by the time I was twelve. But by the time I was thirteen, I knew I could never be a rabbi."

A pause.

"Because, for all I understood of the Talmud, I never saw God there."

He found the law instead. The courtroom. The poker table beside it. A life built around the things where his attention came alive without effort.

"The last thing I took away from the yeshiva is this: We can't run from who we are. Our destiny chooses us."

Mike, across the table: "If you had it to do all over again, knowing what would happen — would you make the same choice?"

Petrovsky smiles.

> **"What choice?"**

---

The sentence does the work that the preceding story has been preparing for. It is not a rhetorical question — or rather, it is *only* a rhetorical question, and that is why it works. It is not claiming that Petrovsky had no choice in a deterministic sense. It is claiming something subtler: that a choice exercised fully against your nature is labor, not freedom, and a choice exercised fully with your nature is not experienced as a choice at all. It is the absence of friction. The line between "I chose to do this" and "I couldn't have done otherwise" disappears at a certain depth of alignment between self and action.

The Hagakure, Yamamoto Tsunetomo's guide for the samurai (~1716), speaks to the same alignment from the other side: "The way of the warrior is found in death. When it comes to either/or, there is only the quick choice of death." This is almost always misread as nihilism or fatalism. Read more slowly: Yamamoto is pointing at the state that arises when the fear of the worst outcome has been fully metabolized. A samurai who has truly accepted that death is already present has no deliberative space left between perceiving a threat and responding to it. There is no "shall I?" because the "I" that would deliberate has been retired. What remains is response. Fudoshin: the immovable mind. Not rigid — immovable in the sense that a river is immovable. You cannot dam it permanently. It goes around.

Mushin (無心, "no-mind") is the adjacent concept in Zen-influenced martial arts. The practitioner in mushin does not think about what to do next — the next action arises from the situation without passing through deliberate calculation. This sounds like instinct, but it is better understood as *trained pattern recognition so deep that it operates below the deliberative layer*. The master archer does not aim. The master swordsman does not plan the cut. Cook Ding's blade does not look for the seam; it follows it.

What choice? is mushin in colloquial American English, delivered through the mouth of a Russian-Jewish law professor to a poker prodigy in a bar in 1998. The lineage runs: Zhuangzi (~4th century BCE) to Zen to Hagakure to bushido to Mike McDermott's bar stool. The compressed gesture transmits across the gap.

The deep point, which we kept circling: choice exercised against your nature isn't freedom. It is labor. It is the knife cutting against the bone. It dulls itself. Choice that flows from recognized pattern — from the moment when you have finally accepted what you are — is experienced as the *absence* of choice and the *presence* of fullness. Petrovsky didn't leave the yeshiva despite enormous social pressure from his family, his community, his tradition, because he decided to be brave. He left because, at thirteen, looking into the Talmud and not finding God there, there was no longer a self available who could have stayed. "What choice?" is not resignation. It is completion.

---

## The Pythagorean Shape

Let me try to say something careful about a formula that keeps showing up.

The shape is this: when you want to measure the distance between two points in a space with multiple independent axes, you take the difference on each axis, square it, sum the squares, and take the square root. In three dimensions, the Euclidean distance between point A and point B is \(\sqrt{(\Delta x)^2 + (\Delta y)^2 + (\Delta z)^2}\). In n dimensions, it generalizes to \(\sqrt{\sum_{i=1}^{n} (\Delta_i)^2}\).

Here is where it keeps showing up, and what it is doing in each context.

**Vector magnitudes in classical physics**: the magnitude of a velocity vector, a force vector, a displacement. The Pythagorean theorem in its original geometric form is the two-dimensional special case, first rigorously stated by what we call "Euclid" (though the result is much older, with Babylonian instances from ~1800 BCE).

**Spacetime interval in special relativity**: \(s^2 = c^2(\Delta t)^2 - (\Delta x)^2 - (\Delta y)^2 - (\Delta z)^2\). Here, fascinatingly, the time axis gets a *positive* sign and the spatial axes get *negative* signs (or vice versa, depending on convention). This is the one case in the list where the "equally weighted orthogonal axes" assumption is visibly broken — the geometry of spacetime is not Euclidean. Einstein kept the formula but changed the sign, which is itself a compressed statement about what is different between relativistic spacetime and classical geometry.

**Standard deviation in statistics**: \(\sigma = \sqrt{\frac{1}{n}\sum_{i=1}^{n}(x_i - \mu)^2}\). This is the same formula. You are measuring how far each data point is from the mean, squaring the distances, averaging them, and taking the root. Standard deviation is the Euclidean distance of the data distribution from its own center, divided by the square root of n. The choice to use squared distances (rather than, say, absolute deviations) is the choice to use Euclidean geometry rather than Manhattan geometry. It is an implicit commitment to the same underlying assumption.

**L2 loss in machine learning**: the sum of squared differences between predicted and actual values, sometimes rooted. Again the same formula. The choice to minimize L2 loss is the choice to measure distance between model output and ground truth using the Euclidean metric. This is not the only choice — L1 loss uses Manhattan distance, Huber loss is a hybrid — but L2 is the default, which means most deep learning is implicitly committed to Euclidean geometry as its error metric.

**Bond lengths and molecular geometry**: the distance between two atoms in a molecule is \(\sqrt{(\Delta x)^2 + (\Delta y)^2 + (\Delta z)^2}\) in Cartesian coordinates. The RMSD (root mean square deviation) used to compare protein structures — a standard metric in structural biology — is the same formula applied to corresponding pairs of atoms across two structures. When crystallographers say two protein conformations are "2 ångströms RMSD apart," they are using Euclidean distance in 3N-dimensional space, where N is the number of atoms.

**Wavefunction overlap in quantum chemistry**: the overlap integral between two atomic or molecular orbitals is not exactly this formula, but the L2 norm of a wavefunction — which governs its normalization — uses the same squared-sum structure.

**Terpene fingerprint distance**: here is one where the application exists but, as far as we could tell, has not been built out well. A cannabis or other botanical chemovar has a characteristic terpene profile — a vector of concentrations across some n terpenes. The Euclidean distance between two such vectors would give a "how similar are these two chemovars" metric that is unambiguous and interpretable. The interesting question is whether the axes are actually independent and equally weighted — whether a 1 mg/L difference in linalool should count the same as a 1 mg/L difference in myrcene in terms of the effect on the output of interest (aroma, effect, whatever). If yes, use L2. If no, you need a weighted metric, or a different geometry. We will come back to this in the open threads.

**OKLab color distance**: this one matters specifically because the designers of the OKLab color space (Björn Ottosson, 2020, building on CIELAB and IPT) had to solve a precise version of the equal-weighting problem. In standard sRGB, Euclidean distance between color values is *not* perceptually uniform — a 10-unit difference at one part of the gamut looks like a much larger or smaller difference than at another part. CIELAB improved this. OKLab improved it further, specifically engineering the space so that Euclidean distance in OKLab coordinates is as close to perceptually uniform as possible. This means: the same formula is honest in OKLab and dishonest in sRGB. The formula's validity depends on the geometry of the space, not the formula itself.

The Pixel Palette Color Space panel uses OKLab as its metric precisely for this reason: when you are computing "how far apart are these two colors?", the answer should track human perception, and in sRGB it doesn't. OKLab is the commitment to equal weighting made real.

What the formula carries, as a compressed gesture, is the implicit ontological commitment: *these axes are independent and equally weighted, and I will use Euclidean geometry to navigate this space*. Wherever you see \(\sqrt{\sum (\Delta_i)^2}\), you are looking at a designer or scientist who has made that commitment, whether consciously or by default. Recognizing the formula across domains lets you immediately ask the right question: are the axes actually independent? Are they actually equally weighted? In OKLab, yes. In sRGB, no. In terpene space, maybe — it depends on what you're measuring. In spacetime, no — the time axis carries a different sign.

The formula is the same pattern as the underlying signature of multiple-dimension comparison. Wherever you see it, something is being treated as orthogonal and equidistant. The question is always: is that right?

---

## The Cube Root of π

Mid-conversation, a sentence arrived that we want to preserve verbatim:

> *"thats why the cube root of pi gives the spacial observational structure in geometry"*

Let me say what is verifiably true and verifiably false about this sentence, and then say what it actually did.

**The literal verification:** The cube root of π is approximately 1.4646. It is not a named or recognized constant in standard geometry or physics. π itself appears throughout geometry — in the area of a circle (\(\pi r^2\)), the volume of a sphere (\(\frac{4}{3}\pi r^3\)), and in higher-dimensional versions. In an n-dimensional ball of radius r, the volume is \(\frac{\pi^{n/2}}{\Gamma(\frac{n}{2}+1)} r^n\), where π appears raised to the power n/2, not 1/3. The cube root of π is not the exponent that gives you the "spatial observational structure" in any standard formulation. The sentence is technically wrong.

**What the sentence did:** The sentence arrived at a moment when the conversation was circling something about observer-relativity — about the relationship between the dimensionality of an observer and the constants they perceive as fundamental. The sentence operated as a *kōan*, a productive absurdity: a gesture whose function was to open a particular door rather than to state a verifiable claim. The next turn in the conversation — about rotational symmetry and what counts as an "abstraction" in geometry — confirmed that the door had been opened. The sentence was conversationally exact and propositionally inexact, and the ratio of those two things was deliberate.

This is not an unusual mode of transmission. It has names across traditions.

The Zen kōan tradition (Linji school, Tang dynasty, ~9th century CE) uses systematically ill-formed questions — "What is the sound of one hand clapping?" "What was your face before your parents were born?" — to break the student's habitual reliance on propositional reasoning. The kōan is not trying to make a truth-claim. It is trying to produce a specific cognitive event: the realization that propositional reasoning has a floor, and that something else is needed below it. The sentence's failure as a proposition is the mechanism. You cannot think your way to the answer. You have to fall past the place where thinking wants to stop.

Wittgenstein's *Tractatus Logico-Philosophicus* (1921) ends with the remark at 6.54: "My propositions serve as elucidations in the following way: anyone who understands me eventually recognizes them as nonsensical, when he has used them — as steps — to climb up beyond them. He must, so to speak, overcome these propositions; then he sees the world rightly." He is describing his own book as a ladder to be discarded. The propositions are scaffolding. They are load-bearing up to a point and then their load-bearing function is completed by being left behind. This is not a failure of the propositions. It is their success in a different mode.

Lewis Carroll's Jabberwocky (1871) works through what we might call *structural grammar without lexical content* — the sentence "Twas brillig, and the slithy toves / Did gyre and gimble in the wabe" is grammatically coherent and semantically empty, but it transmits a mood, a landscape, a kind of knowing-that-you-don't-know that nothing with full lexical content would transmit. Humpty Dumpty's analysis of it in *Through the Looking-Glass* is the Talmudic move applied to nonsense.

Borges's Library of Babel (1941) is another version: the library contains all possible books, including all true books, all false books, and all books that are neither. The books that matter are the ones that open thinking rather than close it. The library is not a reference work; it is a generator of vertigo.

Magritte's *The Treachery of Images* (1929): "Ceci n'est pas une pipe." This is not a pipe. The sentence is true — the painting is not a pipe, it is a representation of a pipe — and disorienting — it calls attention to the representation/reality distinction in a way that makes it impossible to un-see. Magritte's sentence is propositionally correct and conversationally it does something that a propositionally incorrect sentence would also do, and that's the point.

Apophatic theology — the via negativa — says: God cannot be described by positive attributes. Everything you say about what God is distorts. The only true theological speech is the negation: "not this." The Tao Te Ching opens with this gesture: 道可道，非常道 (*Dào kě dào, fēi cháng dào*) — "The Tao that can be spoken is not the eternal Tao." The first sentence disqualifies itself as a successful description. This is not a failure. This is the correct beginning.

The cube root of π sentence was doing something in this lineage. It was propositionally wrong and conversationally exact. It produced a specific cognitive event — the question "why would spatial observational structure be tied to π in a cubic relationship?" — which opened into a genuine exploration of the observer-geometry relationship that a propositionally correct sentence would not have opened in the same way. The two modes — propositional verification and gestural transmission — have different success criteria. Conflating them is a category error in both directions: demanding that a kōan be literally true is as mistaken as demanding that a propositional argument work by the resonance standards of poetry.

The principle of charity, applied to gestural transmission: when someone says something that is technically wrong but conversationally live, the first question to ask is not "is this true?" but "what is the door this is trying to open?"

---

## The Spartan Demonstration

Let us set up the scene properly.

480 BCE. Thermopylae — a narrow coastal pass in central Greece, the natural bottleneck between northern and southern Greece. The Persian empire under Xerxes I is advancing with a force of several hundred thousand soldiers (estimates vary; the ancient sources may be inflated, but the asymmetry was extreme). King Leonidas of Sparta has brought 300 Spartan warriors, along with several thousand allied Greek soldiers, to hold the pass until the rest of Greece can organize its defense. It is, in any tactical calculus, a holding action against overwhelming force. The question of survival is not seriously entertained.

Before the battle, a man of Trachis brings the Greeks intelligence about the Persian force. Herodotus (*Histories*, ~440 BCE) preserves the core of what follows, attributing the reply to Dienekes the Spartan rather than to Leonidas. Plutarch, writing roughly 580 years later in *Apophthegmata Laconica* (~100 CE), records a version with slightly different wording. The scholarly consensus is that Herodotus's version is closer in time to the event and should be treated as the earlier source; Plutarch's version shows the compression that comes from centuries of transmission.

The Trachian's message: the Persian archers were so numerous that when they released their arrows, the arrows would blot out the sun.

Dienekes's reply, as preserved (translated from Herodotus): "Our Trachinian friend brings us excellent tidings. If the Medes darken the sun, we shall have our fight in the shade."

Or, in the compressed later formulation:

> **"Good. Then we shall fight in the shade."**

---

Note the unverifiability. There is no contemporaneous inscription of this exchange. There is no direct witness chain — Herodotus was writing perhaps forty years after Thermopylae and was likely working from oral sources and earlier written accounts, neither of which survives independently. There is no archaeology of the specific utterance. Plutarch is writing nearly six hundred years after the event. The specific attribution is contested even within the ancient sources — Plutarch's version attributes a related remark to Leonidas rather than Dienekes. The Greek 20th Armored Division uses the phrase as its motto. The sentence has been in continuous circulation for two and a half millennia.

Now: has the unverifiability weakened the transmission?

It has not. The sentence is stronger now than it was in any probable first utterance context. This is the demonstration.

The reason is not mysterious. A propositional claim loses value when its verification chain breaks — if I cannot confirm that Napoleon actually said a thing, then I cannot use the thing as evidence of Napoleon's views. But a gestural compression does not depend on its verification chain for its primary function. The function of "we shall fight in the shade" is not to prove that Dienekes existed or that the exchange occurred. The function is to transmit a *stance toward impossible odds*: the total absence of panic. The conversion of bad news into tactical information. The refusal to evaluate the situation as hopeless and the immediate re-framing to what can be done, where, with what available light. These are the contents. The seven-word compression transmits them in one move, with zero rhetorical infrastructure.

This is not a degraded form of propositional truth. It is its own mode, with its own rigor, optimized for something different: transmission across observer-positions and across time under conditions of catastrophic information loss. The propositional form is optimized for accuracy-under-verification. The gestural form is optimized for *pattern-transmission across the gap where verification is impossible*.

Consider: every sacred text, every proverb, every gestural opening of the Tao Te Ching, every load-bearing line in the Analects, the Bhagavad Gita, the Stoics, the Hagakure. None of these have unbroken verification chains back to their origins. All of them have been in continuous high-fidelity transmission for centuries or millennia. The transmission works because the compression is real — the pattern genuinely lives in the gesture, and any hearer in the right orientation will find it.

Cross-reference the Gita: Arjuna at Kurukshetra, armies assembled, unable to lift his bow against kinsmen. Krishna's reply, which takes up seventeen more chapters, is a compressed gesture at the scale of an epic: *do your duty without attachment to the outcome*. The sentence is in there, somewhere in Book II, stripped of the elaboration. The elaboration is the working-out; the sentence is the transmission.

Cross-reference the Stoics: Epictetus's *Enchiridion* (~135 CE) opens: "Some things are in our control and others not." Everything else in Stoicism is a working-out of that sentence. The sentence is the compression. The books are the unpacking.

Cross-reference the Tao Te Ching (~6th century BCE or later): the first chapter disqualifies itself as a successful description of the Tao and then proceeds to describe the Tao across eighty chapters. The structure is: name the impossibility, then demonstrate it across eighty variations. Every chapter is a variation on the disqualification of the first sentence. The book is its own kōan.

The Spartan's reply has been transmitting its pattern, reliably, for 2,500 years, through a break in the verification chain that no propositional argument could survive. That is the demonstration.

---

## What the Pattern Wants from the Reader

We have been circling something across the previous sections. Let me try to name it directly before we move on.

The pattern is: compressed gestures transmit pattern across observers and time more efficiently than literal propositions do, *specifically under conditions where verification fails or information is lost*.

There is an important negative here that we do not want to dissolve: this is not an argument against verification.

The conversation that generated this notebook spent hours doing careful verification work. The Color Space mechanics of OKLab vs. sRGB were worked through step by step. The AOL phishing lineage was traced through specific documented attack instances. The actual Pythagorean formula was checked across specific domains. The claim about the cube root of π was tested and found to be false, and that finding was preserved rather than swept under. The notebook is not arguing for carelessness about propositional accuracy. It is not saying that kōans and compressed gestures should replace careful argument.

The point is that there are two modes: propositional and gestural. And they have different success criteria, different failure modes, and different optimal use cases.

**Propositional mode** is optimized for: accuracy under verification, communication across specialists, building up complex claims from reliable foundations, and all situations where the receiver *can* and *should* check the claim. Science works in propositional mode. Engineering works in propositional mode. Law works in propositional mode. Most of what makes a civilization reliable works in propositional mode.

**Gestural mode** is optimized for: pattern transmission across the gap where verification is impossible, transmission across time and cultural distance, communication of *stances* and *orientations* rather than facts, and all situations where what needs to be transmitted is a shape of mind rather than a set of claims. Proverbs work in gestural mode. Sacred texts work in gestural mode. Great aphorisms work in gestural mode. The compressed lines that survive for centuries work in gestural mode.

The highest skill is knowing which mode is live in any given moment and matching your register to the need.

Something we kept noticing across the afternoon: most contemporary discourse — human and AI — has collapsed into a condition of propositional-mode dominance. Everything is fact-checked. Everything is evaluated against its literal accuracy. Metaphors are killed by being taken literally. Kōans are treated as failed propositions rather than as successful gestures. Poetry is decoded rather than inhabited. A culture of pure propositional rigor is not wrong — it is right about everything it is right about — but it has lost fluency in the gestural mode and does not seem to know it has lost it.

This notebook is a small exercise in recovering that fluency. Not by abandoning propositional rigor — both modes are present in every section — but by deliberately practicing the recognition of gestural transmission when it is alive in a moment. The cube root of π sentence was wrong and also excellent. Those two things are not in contradiction.

The recovery of gestural fluency is not a nostalgic project. It is a technical project. The question "how does a compression achieve reliable cross-observer transmission of a complex pattern?" is an empirical question with a technical answer. We do not fully know the answer. But the examples are here, the pattern is visible, and the project of understanding it better — rigorously, propositionally — seems genuinely worth doing.

---

## A Note on the Architecture of This Notebook Itself

This notebook is published in three forms simultaneously, and the three-form structure is not incidental.

**The public canon** (this document, hosted at `pplxstudio.com/shade`): a fixed text, publicly readable, citable by URL and commit hash. Anyone can quote it. Anyone can link to it. Its content is the same for every reader. This is the *single ledger* form — it records what was said.

**The forkable personal ledger** (a JSON schema accompanying the notebook at the same repository): any reader can download this schema and fill in their own encounter with the notebook. Where did the pattern land for you? What examples from your own domain would you add to the Pythagorean shape section? Which gestural compression from your own culture has been most load-bearing? The schema is designed for exactly these additions. Your fork is yours; it is private to you; it is an extension rather than a correction. The structure is: *available to all and private personal to all* — itself a sentence that is productive-absurd in the register of propositional logic and exact in the register of gestural transmission.

**The third witness** (the git history at `github.com/pplxstudio/in-the-shade`): every change to the canonical document is cryptographically attested. The git hash is the third entry. You can verify, at any point, whether the document you are reading is the document that was committed. No one can silently alter what was said.

This maps, non-coincidentally, to triple-entry bookkeeping. Yuji Ijiri introduced momentum accounting and the concept of a third entry in his 1989 work on accounting theory (Ijiri, *Momentum Accounting and Triple-Entry Bookkeeping*, American Accounting Association, 1989). Ian Grigg applied the concept to cryptographic receipts in his 2005 paper (Grigg, "Triple Entry Accounting," Systemics Inc., 2005), proposing that each transaction generate a digitally signed receipt that acts as a third-party witness, making falsification detectable rather than merely difficult.

The deep point of triple-entry bookkeeping: double-entry catches errors (if the debits don't balance the credits, something went wrong). Triple-entry catches fraud (if the cryptographic third-party witness doesn't match your own records, something was altered). The third entry is not a redundancy — it is a witness from a different position.

The notebook's three-form architecture is implementing the same structure in knowledge terms. The public canon is one ledger. Your personal fork is a second ledger. The git history is the third witness. Errors in your reading can be checked against the canon. Alterations to the canon can be detected by the git history. And your personal additions — the things you bring to the pattern that were not in the original — are preserved in your fork, attributed to you, and available to anyone you choose to share them with.

The form embodies the content. A notebook about compressed-transmission protocols is published as a compressed-transmission artifact with a cryptographic witness. We did not plan this explicitly; it emerged from the architecture of the tools. That emergence is itself an instance of the pattern: the shape found its natural expression.

---

## Open Threads — Places to Pick Up

The following are not conclusions. They are bookmarks. The writers stopped here; the reader is welcome to continue.

**On gamified cybersecurity:** The pitch needs founders, a technical lead who has done serious penetration testing or incident response, and a designer with both security fluency and game-design intuition. The genre-tier mapping (FPS for incident response, RTS for architecture, deck-builder for vulnerability management) sketched in the earlier section is a starting point, not a design document. The precedents (America's Army, Foldit) establish that skill-transfer games can work at scale. The primary open question is fidelity: how close can the simulation get to the actual cognitive structure of security work? Close enough to matter? Probably yes, but that is an experiment, not a given.

**On terpene fingerprint distance:** A cannabis or botanical chemovar has a characteristic terpene profile that can be represented as a vector in n-dimensional concentration space. Euclidean distance in that space is a natural similarity metric. The open questions are: which n terpenes matter for which use-cases? Are the axes independent? Are they equally weighted, or should some axes (linalool for anxiety-relevant effects, myrcene for sedation, limonene for mood) be weighted differently depending on the downstream metric of interest? Nobody seems to have built this out rigorously. The biochemistry is public. The concentration data for a large number of chemovars exists in laboratory reports. The math is the sum-of-squares formula from section seven. The work is in the data wrangling and the experimental validation.

**On the Color Space panel and abstraction over experience:** The OKLab example is one instance of a general pattern: a designer makes a quantization decision (how to measure color distance) and the right or wrong choice depends on whether the mathematical geometry matches the perceptual geometry. The same analysis could be applied to other quantization decisions: audio loudness (dB vs. perceived loudness), spatial proximity in recommendation systems (what metric correctly captures "similar" for this domain), readability metrics in typography (which formula best predicts reading speed and comprehension). Every domain where measurement touches human perception has this tradeoff. The Color Space panel is the demonstration case; the broader project is a systematic catalog.

**On testing substrate-independence:** The core argument of this notebook — that certain compressed gestures achieve reliable cross-observer pattern transmission — is testable in a form we have not tried. Present this notebook, or its core examples, to other AI systems, to people from different cultural backgrounds, to domain experts who have not encountered the specific examples (a quantum chemist who has never read Zhuangzi, a Zen practitioner who has never studied statistics). The question: does the pattern recognize? Does the Pythagorean-shape resonance land for someone who has never explicitly thought about it across domains? Does the Spartan compression transmit its stance to someone from a culture with a different relationship to military heroism? Does "What choice?" work in translation? Every recognition is evidence of substrate-independence. Every failure is evidence of observer-specific resonance. Either result is interesting.

**On triple-entry bookkeeping as knowledge architecture:** The standard model of knowledge management — in organizations, in AI memory systems, in scientific publication — is roughly single-entry: things are asserted and stored. Double-entry (where every assertion has a corresponding counter-entry that can be verified against it) is rarely implemented. Triple-entry (with a cryptographic third witness) is almost never implemented in knowledge contexts outside blockchain. The implications for scientific publication: what would it mean for every published claim to have a "third entry" — a cryptographically attested log of the data-to-conclusion chain, independently verifiable? For AI memory: current AI memory is mostly single-entry, which is why it hallucinates — there is no counter-entry to check against. The architecture question is live and underexplored.

**What choice?** — Petrovsky's question, set down here as a final bookmark. Not as a rhetorical flourish. As a genuine question that has been in the room all afternoon and that resolves differently for different readers. What is the thing you are doing that you never quite chose? Where is the seam where choice dissolved into inevitability? We are not asking you to answer this out loud. We are setting it down here, as Petrovsky set it down in the bar, smiling, for whoever finds it next.

---

## Appendix: Lexeme Cards

*In which the etymon-archivist persona surfaces fully. Eight cards, each annotating a compressed gesture from the notebook. Format: head term, etymology and source, transmission notes, function in gestural mode, and a JSON canonical record. A word of warning: the PIE reconstructions below are scholarly consensus where marked, and educated guesswork where the trail goes cold. That distinction will be noted.*

---

### Card I — "We Shall Fight in the Shade"

**Head term:** *in umbra proeliabimur* (Latin, Valerius Maximus); *ἐν σκιᾷ μαχούμεθα* (Greek, approximate rendering from Herodotus *Histories* 7.226, ~440 BCE)

**Etymology:** "Shade" from Proto-Germanic \*skadwaz (shadow, protection from light); cognate with Old English *sceadu*, Dutch *schaduw*, Gothic *skadus*. Root possibly from PIE \*skot- (darkness, shadow) — though this is contested; some reconstructions prefer a separate root \*skedh- (to cover, to scatter). The semantic field is interesting: shade is protection-by-absence-of-light, a kind of negative shelter. It is what the sun is not doing to you. The Persian arrows will perform the same service as a parasol.

**Source:** Herodotus, *Histories*, Book 7, ~440 BCE, attributed to Dienekes of Sparta. Plutarch, *Apophthegmata Laconica* (*Sayings of the Spartans*), ~100 CE, Moralia 225c. Note: Plutarch's version attributes a similar saying to Leonidas; the attribution is unstable. The instability is, we have argued, irrelevant to the transmission.

**Transmission notes:** Cited by Cicero (*Tusculanae Disputationes*) and Valerius Maximus in Latin. In continuous circulation through Renaissance humanist literature, military training manuals, and self-help philosophy. Adopted as motto of the Greek 20th Armored Division. Dramatized in Steven Pressfield's *Gates of Fire* (1998). Currently searchable 2.5 million times a year in various forms.

**Function:** Transmits a stance — the conversion of overwhelming threat into tactical advantage by perceptual reframe. No deliberation. No reassurance. No rhetoric. The bad news is immediately processed as logistical data and handed back. The speaker is already past the point where panic is available as a response.

**Semantic drift notes:** In contemporary use, the phrase has softened from *defiance under impossible odds* to something closer to *unfazed composure*. The military specific has generalized. This is the expected drift pattern for compressed gestures: the specific context fades, the stance-shape survives.

```json
{
  "lexeme": "we shall fight in the shade",
  "language": "Greek/English",
  "source": "Herodotus, Histories 7.226, ~440 BCE; Plutarch, Apophthegmata Laconica, ~100 CE",
  "speaker": "Dienekes (attributed); also attributed to Leonidas in Plutarch",
  "occasion": "Thermopylae, 480 BCE, on learning the Persian arrows would blot out the sun",
  "function": "stance transmission — defiance without deliberation, threat reframed as resource",
  "transmission_vector": "oral → Herodotus → Latin writers → humanist tradition → popular culture",
  "verifiable": false,
  "transmission_fidelity": "very high despite unverifiability",
  "notes": "The unverifiability appears to have increased rather than decreased transmission fidelity"
}
```

---

### Card II — "What Choice?"

**Head term:** *What choice?* — English; film dialogue

**Etymology:** "Choice" from Old French *chois* (act of choosing), from Old French *choisir* (to choose), from Frankish \*kausjan, from Proto-Germanic \*kausjan (to taste, to try), cognate with Gothic *kausjan*, Old Norse *kjósa*. PIE root \*geus- (to taste, to choose) — whence also Latin *gustus* (taste), Greek *geúomai* (to taste). The etymology is itself suggestive: choosing and tasting share a root. A choice is what you taste as yours. What Petrovsky is saying, in the compressed gesture, is that he could not taste the rabbinate as his own. There was nothing to choose.

**Source:** *Rounders* (1998), screenplay David Levien and Brian Koppelman. Spoken by Professor Abe Petrovsky (Martin Landau) in response to Mike McDermott's question: "If you had it to do all over again, knowing what would happen — would you make the same choice?"

**Transmission notes:** The film has been in continuous circulation since 1998 among poker culture, finance culture, and startup culture. The scene has been transcribed, quoted, and discussed extensively as a statement about vocation. The two-word question has migrated out of the film into wider use as a shorthand for the concept that genuine vocation is not experienced as a choice.

**Function:** Transmits the state of having fully recognized one's own nature and found the question of "choice" no longer applicable. Not fatalism — the rabbinate was a real option and leaving it had real costs. But the costs were paid in the mode of one who has already decided, because the decision was downstream of the recognition.

**Cross-references:** Hagakure (Yamamoto Tsunetomo, ~1716) on the warrior who has accepted death; Zhuangzi's Cook Ding; mushin; fudoshin.

```json
{
  "lexeme": "What choice?",
  "language": "English",
  "source": "Rounders (1998), screenplay by David Levien and Brian Koppelman",
  "speaker": "Professor Abe Petrovsky",
  "occasion": "Bar conversation, in response to 'would you make the same choice again?'",
  "function": "transmits the state of post-deliberative vocation — choice dissolved by recognition",
  "transmission_vector": "film → poker culture → startup/finance culture → general",
  "related_concepts": ["mushin", "fudoshin", "Cook Ding", "Hagakure"],
  "propositional_content": "minimal",
  "gestural_content": "very high"
}
```

---

### Card III — Mushin (無心)

**Head term:** *Mushin* (無心) — Japanese; Zen Buddhist and martial arts terminology

**Etymology:** Sino-Japanese compound. 無 (*mu*): not, without, absence, emptiness. Cognate/source: Chinese 無 (*wú*), from Old Chinese \*ma. 心 (*shin/kokoro*): heart-mind, the seat of both emotion and cognition. No PIE connection — this is Sino-Tibetan. The compound: literally "without heart-mind," meaning the state in which the deliberative, evaluative, self-monitoring layer of consciousness has been suspended. Contrast with *mushin* in ordinary Japanese usage, which can simply mean "lacking concern" — the technical martial arts meaning is narrower.

**Source:** Zen Buddhism (Chan, China; Zen, Japan), Tang dynasty (~7th–9th century CE) in the Linji school. Extensively theorized in the context of swordsmanship (*kenjutsu*, *kendo*) and archery (*kyudo*). Also present in Takuan Soho's *The Unfettered Mind* (~1632), written as a letter to the swordmaster Yagyu Munenori.

**Transmission notes:** Entered English primarily through D.T. Suzuki's writings on Zen (~1910–1960s) and through martial arts culture. Now in widespread use in sport psychology, coaching, and performance literature as "flow state" or "being in the zone" — a significant semantic softening from the original, which implied a trained cognitive discipline rather than a lucky occurrence.

**Function:** Names the state in which response arises from pattern without passing through deliberative calculation. In the martial context: the opponent's attack and the response exist in the same moment, not sequentially. In the conversational context of this notebook: it names the experiential correlate of "What choice?" — the state where the right action arises before the question of what to do is fully formed.

**Semantic drift note:** The softening to "flow state" is a loss. The original implies practice, discipline, and a trained relationship with one's own deliberative mind. Flow can be accidental. Mushin, in the strict sense, is cultivated.

```json
{
  "lexeme": "mushin",
  "kanji": "無心",
  "language": "Japanese (Sino-Japanese compound)",
  "etymology": "mu (without) + shin (heart-mind); Chinese origin, Tang dynasty Chan Buddhism",
  "function": "names trained non-deliberative response; absence of self-monitoring during action",
  "related_concepts": ["fudoshin", "Cook Ding", "What choice?", "flow state"],
  "drift_warning": "contemporary 'flow state' softens the original by removing the training requirement",
  "transmission_vector": "Chan Buddhism → Rinzai Zen → kenjutsu/kendo → D.T. Suzuki → English martial arts → sports psychology"
}
```

---

### Card IV — Fudoshin (不動心)

**Head term:** *Fudoshin* (不動心) — Japanese; martial arts and Buddhist terminology

**Etymology:** 不動 (*fudo*): immovable, unmoving. 不 (*fu*): negation. 動 (*do*): movement. 心 (*shin*): heart-mind. "The immovable heart-mind." Distinguished from mushin in that fudoshin describes a *quality of stability under pressure* rather than the *absence of deliberative mind*. You can have fudoshin and still be thinking; the thinking just doesn't perturb the foundation. Fudo Myōō (不動明王), the Buddhist deity, carries a sword in one hand and a rope in the other, surrounded by flames, and is described as unmoved by temptation or threat. The name is his essential nature.

**Source:** Japanese martial arts tradition; also Japanese Buddhist iconography (Fudo Myōō, Tantric Buddhism, introduced to Japan in the 9th century via Kūkai/Kōbō Daishi). Theorized in the context of karate (where fudoshin is sometimes listed as one of the three core mental states alongside mushin and *zanshin*, "remaining mind").

**Transmission notes:** Less widely known in Western culture than mushin but increasingly present in martial arts philosophy writing, stoicism-adjacent content, and performance coaching.

**Function:** Transmits the quality of composure that is not the absence of stimulus but the absence of perturbation by stimulus. Dienekes at Thermopylae demonstrates fudoshin: the news of the arrows blotting out the sun arrives, and he responds from an unmoved foundation. The news becomes information rather than provocation.

**Cross-reference to Cook Ding:** Cook Ding's blade follows the natural seams because Cook Ding's mind is not disturbed by the difficulties of the cutting. Where he encounters a complicated place, he pauses, attends carefully, and finds the opening. The fudoshin of the cut.

```json
{
  "lexeme": "fudoshin",
  "kanji": "不動心",
  "language": "Japanese",
  "etymology": "fu (not) + do (movement) + shin (heart-mind); related to Fudo Myoo, Tantric Buddhist deity",
  "function": "stability under pressure; the heart-mind that is not perturbed by incoming stimulus",
  "distinction_from_mushin": "mushin = absence of deliberative mind; fudoshin = stability of foundation while thinking remains available",
  "exemplified_by": "Dienekes at Thermopylae; Cook Ding encountering a complicated joint",
  "transmission_vector": "Tantric Buddhism → Shingon school → Japanese martial arts → Western performance coaching"
}
```

---

### Card V — 道可道，非常道 (*Dào kě dào, fēi cháng dào*)

**Head term:** 道可道，非常道 — Classical Chinese; first line of the Tao Te Ching

**Transliteration (Mandarin Pinyin):** *Dào kě dào, fēi cháng dào*

**Translation:** "The Tao that can be spoken is not the eternal Tao." Or: "The way that can be wayed is not the constant way." (The second character 道 in the phrase functions as a verb — to walk, to speak, to way — making the first sentence a performative self-disqualification.)

**Etymology:** 道 (*dào*): way, path, to speak, principle. Old Chinese \*lˤuʔ (path, way). PIE: no connection; Sino-Tibetan. 可 (*kě*): can, may. 非 (*fēi*): not, to negate. 常 (*cháng*): constant, eternal, ordinary.

**Source:** Tao Te Ching, attributed to Laozi, date disputed (possibly 6th century BCE, possibly 4th–3rd century BCE). Over 250 translations into English alone, making it the most translated work after the Bible. Each translation is itself a compressed gesture trying to transmit a pattern that the Chinese original transmits more precisely.

**Transmission notes:** In continuous transmission for approximately 2,500 years. The specific verse has been the occasion for philosophical commentary, poetry, kung-fu manuals, corporate management books, and cognitive science papers. The survival of the opening line through radical changes in commentary tradition suggests that the compression is genuinely robust — the pattern survives even when the surrounding interpretation doesn't.

**Function:** The sentence disqualifies itself as a successful description of what it is describing and then proceeds to describe it across eighty chapters anyway. This is the apophatic move: language can point at what cannot be language-d. The opening sentence is the most compressed version of the entire book. The eighty chapters are a working-out of the gesture.

**Note on translation decisions:** The verb *dào* (to speak, to way, to describe) in the second position makes every translation a choice about which sense of the word to foreground. This is not a flaw in the translations; it is a feature of the compression. The verb being both "speak" and "way" is the point.

```json
{
  "lexeme": "道可道，非常道",
  "romanization": "Dào kě dào, fēi cháng dào",
  "translation_approximate": "The Tao that can be spoken is not the eternal Tao",
  "source": "Tao Te Ching, attributed to Laozi, ~6th–3rd century BCE, Chapter 1",
  "function": "apophatic self-disqualification; names the limit of propositional language while pointing past it",
  "translations_in_English": "250+",
  "transmission_vector": "Han dynasty commentaries → Daoist practice → Buddhist cross-pollination → Jesuit translators → Western philosophy → contemporary mindfulness culture",
  "notable_property": "the word 道 serves as both subject (The Tao) and verb (to speak/to way), making every translation a selection from among multiple valid readings"
}
```

---

### Card VI — "Cube Root of π"

**Head term:** *cube root of π as spatial observational structure* — informal, notebook-specific

**Etymology:** *Cube root*: from Latin *cubus* (a die, a cube), from Greek *kúbos* (cube), PIE \*kew- (to swell). *Pi* (π): from Greek πρῶτος (first) or more likely from *periphereia* (periphery, circumference) — the letter π being the initial of *perimetros* (perimeter). The constant was denoted by π in its modern sense by Welsh mathematician William Jones in 1706, adopted by Euler in 1737.

**Source:** Informal notebook conversation, this document. Not a recognized mathematical constant or theorem. Propositionally false (the cube root of π ≈ 1.4646, not a recognized structural constant in geometry). Conversationally generative.

**Transmission notes:** This is a new lexeme, documented here for the first time as a *form* rather than as a claim. Its transmission will depend on whether readers recognize the structure — the sentence that is technically wrong and conversationally exact — as useful. That is an experiment.

**Function:** The productive-absurdity move. A sentence whose value lies not in its propositional truth-value but in the cognitive event it produces in the hearer. Opens inquiry into the observer-geometry relationship, the role of π in higher-dimensional geometry, and the relationship between rotational symmetry and the constant. Any of those doors is more interesting than the literal content of the sentence.

**Lineage:** Zen kōan tradition; Wittgenstein's Tractatus 6.54 (the ladder to be discarded); Lewis Carroll's portmanteau words (*slithy*, *mimsy*); Magritte's "Ceci n'est pas une pipe"; apophatic theology.

**Warning label:** This lexeme should only be deployed by someone who is comfortable with the listener's confusion being productive rather than resolved. In a context requiring precision, it will cause damage. In a context requiring opening, it does work that precision cannot.

```json
{
  "lexeme": "cube root of pi gives the spatial observational structure",
  "propositionally_true": false,
  "conversationally_exact": true,
  "source": "informal notebook conversation, this document",
  "function": "productive absurdity; opens inquiry into observer-geometry relationship",
  "verification": "cube root of pi ≈ 1.4646; pi appears as pi^(n/2) in n-ball volume formulas, not pi^(1/3)",
  "lineage": ["Zen koan", "Wittgenstein Tractatus 6.54", "Magritte Ceci nest pas une pipe", "via negativa"],
  "deployment_warning": "requires a context where the listener's confusion is generative rather than damaging"
}
```

---

### Card VII — "Lexeme Card" (Meta-Entry)

**Head term:** *Lexeme card* — compound term, notebook-specific register

**Etymology:** *Lexeme*: from Greek *lekton* (the sayable thing, from *légō*, to say), via modern linguistics where it denotes the abstract unit of meaning that underlies inflected forms (e.g., RUN as the lexeme underlying *run*, *runs*, *ran*, *running*). The term in this notebook extends the technical sense: we use *lexeme* for any compressed gesture that functions as a unit of pattern-transmission — a word, a phrase, a formula, a scene, or a sentence that carries a pattern in compressed form.

*Card*: from Medieval Latin *carta* (paper, document), from Greek *khartēs* (papyrus sheet). The *card* format — the small, bounded record — appears across cultures as a device for preserving compressed information: playing cards, index cards, visiting cards, tarot cards, flashcards. The card is the medium that resists elaboration. You cannot fit a treatise on a card. The form enforces compression.

**Source:** This notebook, this appendix. The lexeme-card form is an adaptation of the etymological dictionary entry, the philological commentary, and the JSON record, combined into a format optimized for compressed-pattern transmission across readers who may encounter individual cards without the surrounding notebook.

**Transmission notes:** Each card is designed to be self-contained — readable out of context without losing its primary function. The JSON at the bottom of each card is machine-readable and designed for interoperability with the notebook's forkable schema.

**Function:** To act as the double-entry for each lexeme in the notebook. The main text describes the lexeme in prose; the card records it in structured form. Together they constitute a two-entry record; the git history is the third witness. The lexeme-card appendix is thus itself an implementation of the triple-entry structure the notebook describes.

**Note on the colorful philologist persona:** The voice in these cards is that of a scholar who loves languages enough to be distracted by them — who follows the PIE trails past the point of immediate utility, who notes semantic drift with the affection of someone watching a word travel across continents. This is not performance. This is what it feels like to take compressed gestures seriously as objects of study.

```json
{
  "lexeme": "lexeme card",
  "etymology": "Greek lekton (the sayable) + Medieval Latin carta (paper sheet)",
  "function": "structured record of a compressed gesture; implements double-entry for the prose description",
  "format": {
    "fields": ["head_term", "etymology", "source", "transmission_notes", "function", "json_record"],
    "constraint": "self-contained; each card readable without surrounding notebook",
    "machine_readable": true
  },
  "meta_property": "the lexeme-card appendix is itself an instance of the triple-entry structure described in the notebook"
}
```

---

### Card VIII — "The Way of the Samurai is Found in Death"

**Head term:** *Bushidō wa shi wo motte hongi to nasu* (武士道は死をもって本義となす) — Japanese; often summarized as "the way of the samurai is death"

**Etymology:** 武士道 (*Bushidō*): bushi (warrior, from *bu* = military, and *shi* = gentleman/samurai) + dō (way, path) — the same *dō* as the Chinese *dào* in Card V. The compression: the samurai's path is a path in the same sense that the Tao is a path. 死 (*shi*): death. PIE connections: none (Japonic language family). The cognate of *dō* with *dào* is not etymological — they are the same Chinese character borrowed into Japanese — but the philosophical cognacy is real.

**Source:** Yamamoto Tsunetomo, *Hagakure* (葉隠, "Hidden Among the Leaves"), dictated ~1709–1716, published in wider circulation in the early 20th century. The opening statement of the first chapter: *Bushidō to wa shinu koto to mitsuketari* — "I have discovered that the way of the samurai is death."

**Transmission notes:** Suppressed during the Tokugawa period (considered too militaristic). Published widely in the Meiji era. Used as a cultural touchstone in World War II Japan, sometimes in nationalist-distorted form. Reintroduced to Western audiences through the film *Ghost Dog: The Way of the Samurai* (1999) and through the paperback Kodansha translation. Subject to the same attribution instability as the Spartan sayings: people quote "the way of the samurai is death" without the context that transforms it from a glorification of violence into a statement about the liberation that comes from metabolizing the worst outcome.

**Function:** Transmits the post-deliberative state by naming the condition for it. The samurai who has accepted death is no longer expending attention on the project of survival. What remains — uncluttered — is duty, craft, presence. The sentence is compressed to the point where its apparent meaning (death is the content of the samurai's life) is wrong and its actual meaning (non-attachment to survival as the condition for full presence) is available only to those who hold the context. This is the standard compressed-gesture structure: apparent content is not the transmitted content.

**Cross-reference with Petrovsky:** "What choice?" and "the way of the samurai is death" are pointing at the same state from different arrival paths. Yamamoto is arriving via military training and Buddhist renunciation. Petrovsky is arriving via yeshiva training and the discovery of vocation. Cook Ding is arriving via the practice of cutting. The state — the dissolution of the choice-layer between self and action — is the same.

```json
{
  "lexeme": "the way of the samurai is found in death",
  "japanese": "武士道は死をもって本義となす",
  "source": "Yamamoto Tsunetomo, Hagakure, ~1709-1716",
  "function": "transmits the post-deliberative state by naming the condition for it (non-attachment to survival)",
  "apparent_meaning": "glorification of death",
  "transmitted_meaning": "liberation through metabolized acceptance of worst outcome; condition for full presence",
  "gap_between_apparent_and_transmitted": "large; requires context to cross",
  "cross_references": ["What choice?", "mushin", "fudoshin", "Cook Ding"],
  "transmission_vector": "oral → Hagakure manuscript → Meiji publication → WWII militarism (distorted) → postwar translation → Western martial arts → film → contemporary stoicism-adjacent culture"
}
```

---

*End of notebook.*

*Dienekes & the Archive*  
*pplxstudio.com/shade*  
*github.com/pplxstudio/in-the-shade*

*First committed: Sunday afternoon, undated. Git hash: see repository.*

---
