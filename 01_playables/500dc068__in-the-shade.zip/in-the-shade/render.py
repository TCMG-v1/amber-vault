#!/usr/bin/env python3
"""
Render /home/user/workspace/in-the-shade/notebook.md into a single-file
publishable HTML notebook with the Flag Day + gold patina colorway,
terminal-noir aesthetic, and an embedded interactive Color Space demo.

Output: /home/user/workspace/in-the-shade/index.html
"""

from __future__ import annotations
import os
import re
import html
import json
from pathlib import Path

ROOT = Path("/home/user/workspace/in-the-shade")
SRC = ROOT / "notebook.md"
OUT = ROOT / "index.html"


# ---------- minimal markdown converter (custom, since we want full control) ----------

def _esc(s: str) -> str:
    return html.escape(s, quote=False)


INLINE_MATH_RE = re.compile(r"\\\(([^()]+?)\\\)")
DISPLAY_MATH_RE = re.compile(r"\\\[([\s\S]+?)\\\]")


def render_inline(text: str) -> str:
    """Render inline markdown features without escaping math placeholders."""
    # protect math first
    placeholders = {}

    def stash(token: str, body: str) -> str:
        key = f"\x00{token}{len(placeholders)}\x00"
        placeholders[key] = body
        return key

    text = INLINE_MATH_RE.sub(lambda m: stash("IM", m.group(1)), text)
    text = DISPLAY_MATH_RE.sub(lambda m: stash("DM", m.group(1)), text)

    # protect inline code
    text = re.sub(r"`([^`\n]+)`", lambda m: stash("CD", m.group(1)), text)

    # escape html
    text = _esc(text)

    # markdown links [text](url) — basic
    def link_sub(m):
        label = m.group(1)
        url = m.group(2)
        return f'<a href="{url}" target="_blank" rel="noopener">{label}</a>'

    text = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", link_sub, text)

    # bold **text**
    text = re.sub(r"\*\*([^*\n]+)\*\*", r"<strong>\1</strong>", text)

    # italic *text* — careful: avoid double-underscore from already-bolded;
    # AGENT STYLE: user dislikes italics in markdown. But the source uses *text*
    # for emphasis on book titles and a few places. We *do* render those —
    # the style rule is for OUR prose, not the document content. We'll keep them.
    text = re.sub(r"(?<![\*\w])\*([^*\n]+)\*(?!\w)", r"<em>\1</em>", text)

    # restore placeholders
    for k, v in placeholders.items():
        if k.startswith("\x00IM"):
            text = text.replace(k, f'<span class="math math-inline">{_esc(v)}</span>')
        elif k.startswith("\x00DM"):
            text = text.replace(k, f'<div class="math math-block">{_esc(v)}</div>')
        elif k.startswith("\x00CD"):
            text = text.replace(k, f'<code>{_esc(v)}</code>')

    return text


def render_markdown(md: str) -> str:
    """Convert markdown notebook text to HTML, with gold-patina blockquotes
    and clean section anchors."""
    lines = md.splitlines()
    out: list[str] = []
    i = 0
    n = len(lines)
    in_code = False
    code_buf: list[str] = []
    code_lang = ""

    def flush_para(buf: list[str]):
        if not buf:
            return
        text = "\n".join(buf).strip()
        if not text:
            return
        out.append(f"<p>{render_inline(text)}</p>")

    para: list[str] = []

    while i < n:
        line = lines[i]

        # fenced code block
        if line.startswith("```"):
            if in_code:
                out.append(f'<pre class="code-block"><code class="lang-{_esc(code_lang)}">{_esc(chr(10).join(code_buf))}</code></pre>')
                code_buf = []
                code_lang = ""
                in_code = False
            else:
                flush_para(para)
                para = []
                code_lang = line[3:].strip()
                in_code = True
            i += 1
            continue

        if in_code:
            code_buf.append(line)
            i += 1
            continue

        # hr
        if line.strip() == "---":
            flush_para(para)
            para = []
            out.append('<hr class="trace" />')
            i += 1
            continue

        # headings
        m = re.match(r"^(#{1,6})\s+(.*)$", line)
        if m:
            flush_para(para)
            para = []
            level = len(m.group(1))
            text = m.group(2).strip()
            # build anchor slug
            slug = re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")
            tag = f"h{min(level,6)}"
            out.append(f'<{tag} id="{slug}"><a class="anchor" href="#{slug}">#</a>{render_inline(text)}</{tag}>')
            i += 1
            continue

        # blockquote: collect contiguous > lines into a single block
        if line.startswith(">"):
            flush_para(para)
            para = []
            bq: list[str] = []
            while i < n and lines[i].startswith(">"):
                bq.append(re.sub(r"^>\s?", "", lines[i]))
                i += 1
            body = "\n".join(bq).strip()
            # Detect if this looks like a gold-patina load-bearing quote: a single bold line.
            is_bold = bool(re.match(r"^\*+[^*]+\*+\s*$", body)) or bool(re.match(r"^\*\s*\*?[^*]+\*?\s*\*\s*$", body))
            cls = "quote quote-gold" if (("**" in body) or body.startswith("*") or body.endswith("*")) else "quote"
            out.append(f'<blockquote class="{cls}">{render_inline(body)}</blockquote>')
            continue

        # unordered lists
        if re.match(r"^\s*[-*+]\s+", line):
            flush_para(para)
            para = []
            items = []
            while i < n and re.match(r"^\s*[-*+]\s+", lines[i]):
                items.append(re.sub(r"^\s*[-*+]\s+", "", lines[i]))
                i += 1
            out.append("<ul>" + "".join(f"<li>{render_inline(it)}</li>" for it in items) + "</ul>")
            continue

        # blank line → paragraph break
        if not line.strip():
            flush_para(para)
            para = []
            i += 1
            continue

        para.append(line)
        i += 1

    flush_para(para)
    return "\n".join(out)


# ---------- styles ----------

CSS = r"""
:root {
  --shade-substrate: #050309;
  --shade-substrate-2: #0a0612;
  --shade-substrate-3: #100a1c;
  --shade-violet: #7a3cff;
  --shade-violet-glow: #b48cff;
  --shade-power: #39ff7c;
  --shade-data: #22e5ff;
  --shade-alert: #ff2e55;
  --shade-gold: #ffd166;
  --shade-gold-deep: #c69a3c;
  --shade-text: #d6c9ff;
  --shade-text-faint: #6b5b8f;
  --shade-text-bright: #efe6ff;
  --shade-rule: rgba(122, 60, 255, 0.22);
}

* { box-sizing: border-box; }

html, body {
  margin: 0;
  padding: 0;
  background: var(--shade-substrate);
  color: var(--shade-text);
  font-family: "Iosevka", "JetBrains Mono", "Source Code Pro", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
  font-size: 16px;
  line-height: 1.7;
  -webkit-font-smoothing: antialiased;
}

body::before {
  content: "";
  position: fixed; inset: 0;
  background:
    radial-gradient(1200px 600px at 12% -5%, rgba(122, 60, 255, 0.15), transparent 60%),
    radial-gradient(1000px 500px at 95% 20%, rgba(34, 229, 255, 0.08), transparent 60%),
    radial-gradient(900px 700px at 50% 100%, rgba(57, 255, 124, 0.05), transparent 70%),
    repeating-linear-gradient(
      0deg,
      transparent 0px,
      transparent 3px,
      rgba(122, 60, 255, 0.025) 3px,
      rgba(122, 60, 255, 0.025) 4px
    );
  pointer-events: none;
  z-index: 0;
}

main { position: relative; z-index: 1; }

.wrap {
  max-width: 760px;
  margin: 0 auto;
  padding: 88px 28px 140px;
}

/* Masthead */
.masthead {
  border-top: 1px solid var(--shade-violet);
  border-bottom: 1px solid var(--shade-violet);
  padding: 18px 0 14px;
  margin-bottom: 64px;
  position: relative;
}
.masthead::before, .masthead::after {
  content: "";
  position: absolute;
  left: 0; right: 0;
  height: 1px;
  background: var(--shade-violet);
  opacity: 0.4;
}
.masthead::before { top: 4px; }
.masthead::after  { bottom: 4px; }

.masthead .crest {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: 16px;
  flex-wrap: wrap;
}
.masthead .channel {
  font-size: 11px;
  letter-spacing: 0.26em;
  text-transform: uppercase;
  color: var(--shade-data);
}
.masthead .channel .dot {
  display: inline-block; width: 7px; height: 7px;
  background: var(--shade-power);
  border-radius: 50%;
  box-shadow: 0 0 8px var(--shade-power);
  margin-right: 8px;
  vertical-align: middle;
  animation: pulse 2.4s ease-in-out infinite;
}
.masthead .glyph {
  font-size: 11px;
  letter-spacing: 0.24em;
  text-transform: uppercase;
  color: var(--shade-text-faint);
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.35; }
}

h1.title {
  font-family: "Iosevka", ui-monospace, monospace;
  font-weight: 700;
  font-size: clamp(34px, 5.4vw, 54px);
  line-height: 1.08;
  letter-spacing: -0.01em;
  color: var(--shade-text-bright);
  margin: 18px 0 8px;
}
h1.title .accent {
  color: var(--shade-gold);
  text-shadow: 0 0 24px rgba(255, 209, 102, 0.25);
}

.subtitle {
  color: var(--shade-violet-glow);
  font-size: 18px;
  letter-spacing: 0.02em;
  margin: 0 0 22px;
}

.byline {
  display: flex;
  flex-wrap: wrap;
  gap: 18px 28px;
  font-size: 12px;
  letter-spacing: 0.16em;
  text-transform: uppercase;
  color: var(--shade-text-faint);
  padding-top: 4px;
}
.byline .author { color: var(--shade-gold); }
.byline a { color: var(--shade-data); text-decoration: none; border-bottom: 1px dotted rgba(34, 229, 255, 0.5); }
.byline a:hover { color: var(--shade-text-bright); border-bottom-color: var(--shade-text-bright); }

/* Body typography */
h2 {
  margin-top: 96px;
  margin-bottom: 18px;
  font-size: clamp(22px, 3vw, 30px);
  line-height: 1.2;
  font-weight: 600;
  color: var(--shade-text-bright);
  letter-spacing: -0.005em;
  border-left: 2px solid var(--shade-violet);
  padding-left: 14px;
}
h3 {
  margin-top: 56px;
  margin-bottom: 10px;
  font-size: 19px;
  font-weight: 600;
  color: var(--shade-violet-glow);
  letter-spacing: 0.005em;
}
h4, h5, h6 {
  margin-top: 32px;
  margin-bottom: 8px;
  color: var(--shade-data);
  font-weight: 600;
}
.anchor {
  display: inline-block;
  width: 22px;
  margin-left: -22px;
  color: var(--shade-text-faint);
  opacity: 0;
  text-decoration: none;
  transition: opacity 120ms ease;
}
h2:hover .anchor, h3:hover .anchor { opacity: 0.7; }

p {
  margin: 0 0 18px;
  color: var(--shade-text);
  font-size: 16px;
}

strong { color: var(--shade-text-bright); }
em { color: var(--shade-violet-glow); font-style: italic; }

a { color: var(--shade-data); text-decoration: none; border-bottom: 1px dotted rgba(34, 229, 255, 0.45); }
a:hover { color: var(--shade-text-bright); border-bottom-color: var(--shade-text-bright); }

ul { padding-left: 22px; }
ul li { margin-bottom: 8px; }

hr.trace {
  border: 0;
  height: 18px;
  margin: 36px 0;
  background-image:
    linear-gradient(90deg, transparent 0%, var(--shade-violet) 8%, var(--shade-violet) 92%, transparent 100%);
  background-size: 100% 1px;
  background-repeat: no-repeat;
  background-position: 0 50%;
  position: relative;
}
hr.trace::before, hr.trace::after {
  content: "";
  position: absolute;
  top: 50%;
  width: 7px; height: 7px;
  border-radius: 50%;
  transform: translateY(-50%);
  background: var(--shade-violet);
  box-shadow: 0 0 8px var(--shade-violet);
}
hr.trace::before { left: 8%; }
hr.trace::after  { right: 8%; background: var(--shade-data); box-shadow: 0 0 8px var(--shade-data); }

/* Quotes — standard violet sidebar */
blockquote.quote {
  margin: 26px 0;
  padding: 14px 18px 14px 22px;
  border-left: 2px solid var(--shade-violet);
  background: linear-gradient(90deg, rgba(122, 60, 255, 0.07), transparent 80%);
  color: var(--shade-text-bright);
  font-style: italic;
}

/* Gold patina — load-bearing compressed gestures */
blockquote.quote-gold {
  position: relative;
  margin: 36px 0;
  padding: 22px 26px 22px 28px;
  border: 1px solid rgba(255, 209, 102, 0.4);
  border-left: 2px solid var(--shade-gold);
  background:
    linear-gradient(90deg, rgba(255, 209, 102, 0.08), rgba(255, 209, 102, 0.02) 60%, transparent),
    var(--shade-substrate-2);
  color: var(--shade-text-bright);
  font-style: normal;
  font-size: 18px;
  letter-spacing: 0.005em;
  box-shadow:
    0 0 0 1px rgba(255, 209, 102, 0.08) inset,
    0 8px 32px -16px rgba(255, 209, 102, 0.4);
}
blockquote.quote-gold strong, blockquote.quote-gold em {
  color: var(--shade-gold);
  font-style: normal;
}
blockquote.quote-gold::before {
  content: "⌖";
  position: absolute;
  top: -10px; left: -10px;
  width: 22px; height: 22px;
  display: flex; align-items: center; justify-content: center;
  background: var(--shade-substrate);
  color: var(--shade-gold);
  border: 1px solid var(--shade-gold);
  font-size: 11px;
  border-radius: 50%;
}

/* Code blocks */
pre.code-block {
  margin: 24px 0;
  padding: 18px 20px;
  background: var(--shade-substrate-2);
  border: 1px solid rgba(122, 60, 255, 0.25);
  border-left: 2px solid var(--shade-power);
  border-radius: 4px;
  overflow-x: auto;
  font-size: 13.5px;
  line-height: 1.55;
  color: var(--shade-text-bright);
  position: relative;
}
pre.code-block::before {
  content: attr(data-lang) " // record";
  position: absolute;
  top: 6px; right: 12px;
  font-size: 10px;
  letter-spacing: 0.2em;
  text-transform: uppercase;
  color: var(--shade-text-faint);
}
code {
  font-family: inherit;
  color: var(--shade-power);
}
p code, li code {
  background: rgba(122, 60, 255, 0.1);
  padding: 1px 6px;
  border-radius: 3px;
  color: var(--shade-data);
  font-size: 0.92em;
}

/* Math */
.math-inline {
  color: var(--shade-violet-glow);
  font-style: italic;
  padding: 0 2px;
}
.math-block {
  display: block;
  text-align: center;
  margin: 18px 0;
  color: var(--shade-violet-glow);
  font-size: 17px;
  font-style: italic;
}

/* TOC */
nav.toc {
  margin: 24px 0 64px;
  padding: 18px 22px;
  border: 1px solid rgba(122, 60, 255, 0.25);
  background: linear-gradient(180deg, rgba(122, 60, 255, 0.04), transparent);
  font-size: 13px;
}
nav.toc .label {
  font-size: 10px;
  letter-spacing: 0.3em;
  text-transform: uppercase;
  color: var(--shade-text-faint);
  margin-bottom: 10px;
}
nav.toc ol {
  margin: 0;
  padding-left: 22px;
  color: var(--shade-text);
  counter-reset: tocitem;
  list-style: none;
}
nav.toc ol li {
  counter-increment: tocitem;
  margin: 4px 0;
  position: relative;
}
nav.toc ol li::before {
  content: counter(tocitem, decimal-leading-zero);
  position: absolute;
  left: -28px;
  color: var(--shade-violet);
  font-size: 11px;
  letter-spacing: 0.1em;
}
nav.toc a {
  color: var(--shade-text);
  border-bottom: none;
}
nav.toc a:hover { color: var(--shade-gold); }

/* Footer / sealed channel */
footer.seal {
  margin-top: 120px;
  padding-top: 20px;
  border-top: 1px solid var(--shade-violet);
  display: flex;
  flex-wrap: wrap;
  gap: 12px 28px;
  justify-content: space-between;
  font-size: 11px;
  letter-spacing: 0.2em;
  text-transform: uppercase;
  color: var(--shade-text-faint);
}
footer.seal .field { color: var(--shade-violet-glow); }
footer.seal a { color: var(--shade-data); border: none; }

/* Color space demo */
section.color-space {
  margin: 56px 0;
  padding: 24px;
  border: 1px solid rgba(34, 229, 255, 0.3);
  border-radius: 6px;
  background:
    radial-gradient(800px 300px at 100% 0%, rgba(34, 229, 255, 0.05), transparent 70%),
    var(--shade-substrate-2);
  position: relative;
}
section.color-space::before {
  content: "color space // live demo";
  position: absolute;
  top: -10px; left: 18px;
  background: var(--shade-substrate);
  padding: 0 10px;
  font-size: 10px;
  letter-spacing: 0.28em;
  text-transform: uppercase;
  color: var(--shade-data);
}
.cs-header {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-bottom: 14px;
  font-size: 11px;
  letter-spacing: 0.2em;
  text-transform: uppercase;
}
.cs-btn {
  background: transparent;
  border: 1px solid rgba(122, 60, 255, 0.4);
  color: var(--shade-text);
  padding: 6px 12px;
  cursor: pointer;
  font-family: inherit;
  font-size: 11px;
  letter-spacing: 0.18em;
  text-transform: uppercase;
  transition: all 120ms ease;
}
.cs-btn:hover { border-color: var(--shade-violet-glow); color: var(--shade-text-bright); }
.cs-btn.active {
  border-color: var(--shade-power);
  color: var(--shade-power);
  box-shadow: 0 0 12px -3px var(--shade-power), inset 0 0 12px -8px var(--shade-power);
}
.cs-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 14px;
}
@media (max-width: 640px) {
  .cs-grid { grid-template-columns: 1fr; }
}
.cs-cell {
  position: relative;
  aspect-ratio: 1 / 1;
  background: var(--shade-substrate);
  border: 1px solid rgba(122, 60, 255, 0.25);
  border-radius: 4px;
  overflow: hidden;
}
.cs-cell canvas { display: block; width: 100%; height: 100%; }
.cs-cell .label {
  position: absolute;
  top: 8px; left: 10px;
  font-size: 10px;
  letter-spacing: 0.24em;
  text-transform: uppercase;
  color: var(--shade-text-faint);
  background: rgba(5, 3, 9, 0.75);
  padding: 3px 8px;
  border: 1px solid rgba(122, 60, 255, 0.2);
}
.cs-meta {
  margin-top: 12px;
  font-size: 11px;
  letter-spacing: 0.15em;
  text-transform: uppercase;
  color: var(--shade-text-faint);
  display: flex;
  flex-wrap: wrap;
  gap: 18px;
}
.cs-meta span.k { color: var(--shade-data); margin-right: 6px; }
.cs-meta span.v { color: var(--shade-power); }
.cs-caption {
  margin-top: 14px;
  font-size: 13px;
  color: var(--shade-text-faint);
  font-style: italic;
  border-top: 1px dashed rgba(122, 60, 255, 0.2);
  padding-top: 12px;
}
.cs-caption strong { color: var(--shade-gold); }

/* Selection */
::selection { background: rgba(255, 209, 102, 0.3); color: var(--shade-text-bright); }
::-moz-selection { background: rgba(255, 209, 102, 0.3); color: var(--shade-text-bright); }

/* Print */
@media print {
  body::before { display: none; }
  body { background: white; color: black; }
  a { color: black; border-bottom: none; }
  .masthead, footer.seal { border-color: black; }
  section.color-space { display: none; }
  .anchor { display: none; }
}
"""


# ---------- Color Space demo (self-contained) ----------

COLOR_SPACE_HTML = r"""
<section class="color-space" id="color-space-demo">
  <div class="cs-header">
    <button class="cs-btn active" data-mode="srgb">sRGB</button>
    <button class="cs-btn" data-mode="oklab">OKLab</button>
    <button class="cs-btn" data-action="cycle">Cycle Source</button>
  </div>
  <div class="cs-grid">
    <div class="cs-cell"><span class="label">Source</span><canvas id="cs-src" width="320" height="320"></canvas></div>
    <div class="cs-cell"><span class="label">8-color Quantized</span><canvas id="cs-dst" width="320" height="320"></canvas></div>
  </div>
  <div class="cs-meta">
    <div><span class="k">METRIC</span><span class="v" id="cs-metric">sRGB</span></div>
    <div><span class="k">PALETTE</span><span class="v">8 colors · k-means</span></div>
    <div><span class="k">SAMPLE</span><span class="v" id="cs-sample">gradient</span></div>
  </div>
  <div class="cs-caption">
    The same 8-color quantization, two different distance metrics. <strong>sRGB</strong> measures
    Euclidean distance in RGB coordinates — straightforward but perceptually uneven. <strong>OKLab</strong>
    measures Euclidean distance in a space engineered for perceptual uniformity. Watch where banding
    appears under each metric and ask: are the axes actually independent and equally weighted?
  </div>
</section>
"""

COLOR_SPACE_JS = r"""
(function(){
  const srcC = document.getElementById('cs-src');
  const dstC = document.getElementById('cs-dst');
  if (!srcC || !dstC) return;
  const W = 256, H = 256;
  srcC.width = W; srcC.height = H;
  dstC.width = W; dstC.height = H;
  const sctx = srcC.getContext('2d');
  const dctx = dstC.getContext('2d');
  let mode = 'srgb';
  let sampleIdx = 0;
  const SAMPLES = ['gradient','wheel','spectrum','plasma'];

  // ---------- color space conversions ----------
  function srgbToLinear(u) {
    u = u / 255;
    return u <= 0.04045 ? u / 12.92 : Math.pow((u + 0.055) / 1.055, 2.4);
  }
  function linearToSrgb(u) {
    u = u <= 0.0031308 ? 12.92 * u : 1.055 * Math.pow(u, 1/2.4) - 0.055;
    return Math.max(0, Math.min(255, Math.round(u * 255)));
  }
  function rgbToOklab(r, g, b) {
    const lr = srgbToLinear(r);
    const lg = srgbToLinear(g);
    const lb = srgbToLinear(b);
    const l = 0.4122214708*lr + 0.5363325363*lg + 0.0514459929*lb;
    const m = 0.2119034982*lr + 0.6806995451*lg + 0.1073969566*lb;
    const s = 0.0883024619*lr + 0.2817188376*lg + 0.6299787005*lb;
    const l_ = Math.cbrt(l), m_ = Math.cbrt(m), s_ = Math.cbrt(s);
    return [
      0.2104542553*l_ + 0.7936177850*m_ - 0.0040720468*s_,
      1.9779984951*l_ - 2.4285922050*m_ + 0.4505937099*s_,
      0.0259040371*l_ + 0.7827717662*m_ - 0.8086757660*s_
    ];
  }

  function distSrgb(a, b) {
    const dr = a[0]-b[0], dg = a[1]-b[1], db = a[2]-b[2];
    return dr*dr + dg*dg + db*db;
  }
  function distOklab(a, b) {
    const aL = rgbToOklab(a[0],a[1],a[2]);
    const bL = rgbToOklab(b[0],b[1],b[2]);
    const dL = aL[0]-bL[0], da = aL[1]-bL[1], db_ = aL[2]-bL[2];
    return dL*dL + da*da + db_*db_;
  }

  // ---------- sample generators ----------
  function drawSample(ctx) {
    const img = ctx.createImageData(W, H);
    const d = img.data;
    const sample = SAMPLES[sampleIdx];
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        const i = (y*W + x) * 4;
        const u = x / (W-1), v = y / (H-1);
        let r, g, b;
        if (sample === 'gradient') {
          // diagonal multichannel gradient
          r = Math.round(255 * u);
          g = Math.round(255 * v);
          b = Math.round(255 * (1 - (u+v)/2));
        } else if (sample === 'wheel') {
          // hsv-ish wheel
          const cx = u - 0.5, cy = v - 0.5;
          const ang = Math.atan2(cy, cx);
          const rad = Math.min(0.5, Math.sqrt(cx*cx + cy*cy)) * 2;
          const h = (ang/(2*Math.PI) + 0.5) * 360;
          [r,g,b] = hsvToRgb(h, rad, 1);
        } else if (sample === 'spectrum') {
          const h = u * 360;
          const sat = 0.5 + 0.5 * Math.sin(v * Math.PI * 3);
          const val = 0.4 + 0.5 * v;
          [r,g,b] = hsvToRgb(h, sat, val);
        } else { // plasma
          const t = u, s = v;
          r = Math.round(255 * Math.pow(t, 0.7));
          g = Math.round(255 * 0.5 * (1 + Math.sin((t+s)*Math.PI*2)));
          b = Math.round(255 * (1 - s) * (0.5 + 0.5*Math.cos(t*Math.PI*4)));
        }
        d[i] = r; d[i+1] = g; d[i+2] = b; d[i+3] = 255;
      }
    }
    ctx.putImageData(img, 0, 0);
    return img;
  }
  function hsvToRgb(h, s, v) {
    h = ((h%360)+360)%360;
    const c = v * s;
    const x = c * (1 - Math.abs((h/60)%2 - 1));
    const m = v - c;
    let r=0,g=0,b=0;
    if      (h<60)  { r=c; g=x; }
    else if (h<120) { r=x; g=c; }
    else if (h<180) { g=c; b=x; }
    else if (h<240) { g=x; b=c; }
    else if (h<300) { r=x; b=c; }
    else            { r=c; b=x; }
    return [Math.round((r+m)*255), Math.round((g+m)*255), Math.round((b+m)*255)];
  }

  // ---------- k-means in chosen space ----------
  function kmeans(pixels, k, useOklab) {
    // sample to reduce cost
    const N = pixels.length / 4;
    const sample = [];
    const stride = Math.max(1, Math.floor(N / 4000));
    for (let i = 0; i < N; i += stride) {
      sample.push([pixels[i*4], pixels[i*4+1], pixels[i*4+2]]);
    }
    // seed centroids
    let centroids = [];
    for (let i = 0; i < k; i++) {
      centroids.push(sample[Math.floor((i+0.5) * sample.length / k)]);
    }
    const dfn = useOklab ? distOklab : distSrgb;
    for (let iter = 0; iter < 12; iter++) {
      const sums = Array.from({length:k}, () => [0,0,0,0]);
      for (const p of sample) {
        let bj = 0, bd = Infinity;
        for (let j = 0; j < k; j++) {
          const d = dfn(p, centroids[j]);
          if (d < bd) { bd = d; bj = j; }
        }
        sums[bj][0] += p[0]; sums[bj][1] += p[1]; sums[bj][2] += p[2]; sums[bj][3]++;
      }
      for (let j = 0; j < k; j++) {
        if (sums[j][3] > 0) {
          centroids[j] = [
            Math.round(sums[j][0]/sums[j][3]),
            Math.round(sums[j][1]/sums[j][3]),
            Math.round(sums[j][2]/sums[j][3])
          ];
        }
      }
    }
    return { centroids, dfn };
  }

  function quantize(srcImg) {
    const useOklab = (mode === 'oklab');
    const { centroids, dfn } = kmeans(srcImg.data, 8, useOklab);
    const out = dctx.createImageData(W, H);
    const od = out.data;
    const sd = srcImg.data;
    // precompute oklab if needed
    let lut = null;
    if (useOklab) {
      lut = centroids.map(c => rgbToOklab(c[0], c[1], c[2]));
    }
    for (let i = 0; i < sd.length; i += 4) {
      const p = [sd[i], sd[i+1], sd[i+2]];
      let bj = 0, bd = Infinity;
      if (useOklab) {
        const pl = rgbToOklab(p[0], p[1], p[2]);
        for (let j = 0; j < 8; j++) {
          const c = lut[j];
          const dl = pl[0]-c[0], da = pl[1]-c[1], db_ = pl[2]-c[2];
          const d = dl*dl + da*da + db_*db_;
          if (d < bd) { bd = d; bj = j; }
        }
      } else {
        for (let j = 0; j < 8; j++) {
          const c = centroids[j];
          const dr = p[0]-c[0], dg = p[1]-c[1], db_ = p[2]-c[2];
          const d = dr*dr + dg*dg + db_*db_;
          if (d < bd) { bd = d; bj = j; }
        }
      }
      const c = centroids[bj];
      od[i] = c[0]; od[i+1] = c[1]; od[i+2] = c[2]; od[i+3] = 255;
    }
    dctx.putImageData(out, 0, 0);
  }

  function render() {
    const srcImg = drawSample(sctx);
    quantize(srcImg);
    document.getElementById('cs-metric').textContent = mode === 'oklab' ? 'OKLab' : 'sRGB';
    document.getElementById('cs-sample').textContent = SAMPLES[sampleIdx];
  }

  document.querySelectorAll('.cs-btn[data-mode]').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.cs-btn[data-mode]').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      mode = btn.dataset.mode;
      render();
    });
  });
  const cycleBtn = document.querySelector('.cs-btn[data-action="cycle"]');
  if (cycleBtn) {
    cycleBtn.addEventListener('click', () => {
      sampleIdx = (sampleIdx + 1) % SAMPLES.length;
      render();
    });
  }
  render();
})();
"""


# ---------- main ----------

def build_toc(html_body: str) -> str:
    """Extract h2 headings to build a table of contents."""
    items = re.findall(r'<h2 id="([^"]+)">(?:<a [^>]+>#</a>)?([^<]+)</h2>', html_body)
    if not items:
        return ""
    parts = ['<nav class="toc">',
             '<div class="label">// Notebook · 13 sections</div>',
             '<ol>']
    for slug, title in items:
        # strip leading anchor placeholder
        title_clean = title.strip()
        parts.append(f'<li><a href="#{slug}">{title_clean}</a></li>')
    parts.append('</ol></nav>')
    return "\n".join(parts)


def main():
    md = SRC.read_text(encoding="utf-8")

    # Pull off masthead bits from the top of the document
    # Notebook starts with: # In the Shade: A Notebook on Compressed Transmission
    #                      *Dienekes & the Archive*
    #                      *pplxstudio.com/shade — forkable at github.com/pplxstudio/in-the-shade*
    #                      ---
    # We'll render those into a structured masthead instead of letting the
    # markdown converter handle them, then render the rest.

    # Split out the front matter (everything before first ## heading)
    match = re.search(r"^## ", md, flags=re.MULTILINE)
    if match:
        front = md[:match.start()]
        rest = md[match.start():]
    else:
        front = ""
        rest = md

    body_html = render_markdown(rest)

    # Insert the Color Space demo at the END of the Pythagorean section (right
    # before the next H2). The next H2 after "the-pythagorean-shape" is the
    # cube-root section; the slug strips the π, so we look for it by index.
    h2_ids = re.findall(r'<h2 id="([^"]+)">', body_html)
    if 'the-pythagorean-shape' in h2_ids:
        # find the H2 that immediately follows the pythagorean one
        idx_p = h2_ids.index('the-pythagorean-shape')
        if idx_p + 1 < len(h2_ids):
            next_slug = h2_ids[idx_p + 1]
            next_marker = f'<h2 id="{next_slug}">'
            cidx = body_html.find(next_marker)
            if cidx > 0:
                body_html = body_html[:cidx] + COLOR_SPACE_HTML + "\n" + body_html[cidx:]

    toc_html = build_toc(body_html)

    # masthead
    masthead = f"""
    <header class="masthead">
      <div class="crest">
        <div class="channel"><span class="dot"></span>SEALED CHANNEL · NAV ARCHIVE</div>
        <div class="glyph">PPLXSTUDIO / SHADE · v0.1 · 2026-06-14</div>
      </div>
      <h1 class="title">In the Shade<span class="accent">.</span></h1>
      <p class="subtitle">A Notebook on Compressed Transmission</p>
      <div class="byline">
        <span class="author">DIENEKES &amp; THE ARCHIVE</span>
        <a href="https://pplxstudio.com/shade">pplxstudio.com/shade</a>
        <a href="https://github.com/pplxstudio/in-the-shade">github.com/pplxstudio/in-the-shade</a>
      </div>
    </header>
    """

    footer = """
    <footer class="seal">
      <span class="field">SEAL · OPEN</span>
      <span class="field">CC0 · 1.0 UNIVERSAL</span>
      <a href="https://github.com/pplxstudio/in-the-shade">↗ fork the archive</a>
      <a href="#color-space-demo">↗ color space</a>
      <span class="field">GIT HASH · see repo</span>
    </footer>
    """

    full = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>In the Shade — A Notebook on Compressed Transmission</title>
<meta name="description" content="A working notebook on compressed gestural transmission, published by Dienekes &amp; the Archive at pplxstudio.com/shade." />
<meta name="author" content="Dienekes &amp; the Archive" />
<meta property="og:title" content="In the Shade — A Notebook on Compressed Transmission" />
<meta property="og:description" content="Sunday-afternoon notebook on how compressed gestures transmit pattern across observers and time." />
<meta property="og:type" content="article" />
<style>{CSS}</style>
</head>
<body>
<main class="wrap">
{masthead}
{toc_html}
{body_html}
{footer}
</main>
<script>{COLOR_SPACE_JS}</script>
</body>
</html>
"""

    OUT.write_text(full, encoding="utf-8")
    print(f"wrote {OUT}  ({len(full)} bytes)")


if __name__ == "__main__":
    main()
