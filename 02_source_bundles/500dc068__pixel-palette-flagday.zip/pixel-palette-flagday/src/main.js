/* ============================================================
   Pixel Palette — main.js  (v2)
   Orchestrates: file load → worker pipeline → palette state →
   render → exports → ComfyUI bridge.
   ============================================================ */

import { rgbToHex, luma, rgbToHsl, rgbToOklab } from './lib/color.js';
import { buildJSON, buildGPL, buildPAL, buildHEX, buildASE, paletteGridCanvas, paletteStripCanvas } from './lib/exports.js';
import { ping as cuiPing, sendToComfy, roundTrip as cuiRoundTrip } from './lib/comfyui.js';
import { applyTileMode, drawTileGrid, HARDWARE_PRESETS } from './lib/tile.js';
import { paintColorSpaceScope, resetColorSpaceScope } from './lib/flagday-scope.js';

// ---------- worker ----------
const worker = new Worker(new URL('./lib/worker.js', import.meta.url), { type: 'module' });
let nextJobId = 0;
const pendingJobs = new Map();

worker.onmessage = (e) => {
  const { id, imageData, palette, error } = e.data;
  const job = pendingJobs.get(id);
  if (!job) return;
  pendingJobs.delete(id);
  if (error) job.reject(new Error(error));
  else job.resolve({ imageData, palette });
};

function runWorker(op, payload) {
  return new Promise((resolve, reject) => {
    const id = ++nextJobId;
    pendingJobs.set(id, { resolve, reject });
    // transfer imageData buffer to keep things fast
    const transfer = payload.imageData ? [payload.imageData.data.buffer] : [];
    worker.postMessage({ id, op, ...payload }, transfer);
  });
}

// ---------- state ----------
const state = {
  filename: 'image',
  srcCanvas: document.createElement('canvas'),
  srcCtx: null,
  origImage: null, // ImageData (full res, immutable reference for re-runs)

  // pipeline config
  bits: { r: 5, g: 6, b: 5 },
  dither: 'none',
  ditherStrength: 60,
  pixelScale: 1,
  colorSpace: 'srgb',
  kmeans: false,
  kCount: 16,

  // tile mode
  tilePreset: 'off',           // off | nes | gb | snes | custom
  tileSize: 8,
  tileSubpalettes: 4,
  tileColorsPerTile: 4,
  tileShowGrid: true,
  tileResult: null,            // { subpalettes, flatPalette, tileAssign, cols, rows }

  // ComfyUI
  cuiRoundtrip: false,

  // results
  quantImage: null, // ImageData
  palette: [], // [{r,g,b,hex,count,locked}]
  paletteOrder: null, // user-set order; null = auto

  // ab compare
  abActive: false,
  abPos: 0.5,

  // history
  history: [],
  histPtr: -1,
  maxHist: 50,
};

state.srcCtx = state.srcCanvas.getContext('2d', { willReadFrequently: true });

// ---------- DOM ----------
const $ = (id) => document.getElementById(id);
const cvOrig = $('cv-orig');
const cvOut = $('cv-out');
const cvOverlay = $('cv-orig-overlay');
const cvGrid = $('cv-grid-overlay');
const cvHist = $('cv-hist');
const cvCui = $('cv-cui');
const ctxOrig = cvOrig.getContext('2d');
const ctxOut = cvOut.getContext('2d');
const ctxOverlay = cvOverlay.getContext('2d');
const ctxGrid = cvGrid.getContext('2d');
const ctxHist = cvHist.getContext('2d');
const ctxCui = cvCui.getContext('2d');

// ---------- helpers ----------
function snapshot() {
  return {
    bits: { ...state.bits },
    dither: state.dither,
    ditherStrength: state.ditherStrength,
    pixelScale: state.pixelScale,
    colorSpace: state.colorSpace,
    kmeans: state.kmeans,
    kCount: state.kCount,
    paletteOrder: state.paletteOrder ? [...state.paletteOrder] : null,
    lockedHexes: state.palette.filter((p) => p.locked).map((p) => p.hex),
  };
}

function restore(snap) {
  Object.assign(state, {
    bits: { ...snap.bits },
    dither: snap.dither,
    ditherStrength: snap.ditherStrength,
    pixelScale: snap.pixelScale,
    colorSpace: snap.colorSpace,
    kmeans: snap.kmeans,
    kCount: snap.kCount,
    paletteOrder: snap.paletteOrder,
  });
  pushControlsToDOM();
  schedule({ restoreLocks: snap.lockedHexes });
}

function pushHistory() {
  // Drop redo tail
  state.history = state.history.slice(0, state.histPtr + 1);
  state.history.push(snapshot());
  if (state.history.length > state.maxHist) state.history.shift();
  state.histPtr = state.history.length - 1;
  updateUndoButtons();
}

function undo() {
  if (state.histPtr <= 0) return;
  state.histPtr--;
  restore(state.history[state.histPtr]);
  updateUndoButtons();
}

function redo() {
  if (state.histPtr >= state.history.length - 1) return;
  state.histPtr++;
  restore(state.history[state.histPtr]);
  updateUndoButtons();
}

function updateUndoButtons() {
  $('undo-btn').disabled = state.histPtr <= 0;
  $('redo-btn').disabled = state.histPtr >= state.history.length - 1;
}

// ---------- pipeline ----------
let scheduledTimer = null;
function schedule(opts = {}) {
  clearTimeout(scheduledTimer);
  scheduledTimer = setTimeout(() => runPipeline(opts), 30);
}

let processing = false;
let pendingOpts = null;

async function runPipeline(opts = {}) {
  if (!state.origImage) return;
  if (processing) {
    pendingOpts = opts;
    return;
  }
  processing = true;
  const t0 = performance.now();

  try {
    // step 1: pixel scale via off-main-thread downscale/upscale on a tmp canvas
    let baseImage = state.origImage;
    if (state.pixelScale > 1) baseImage = pixelScale(baseImage, state.pixelScale);

    // we must CLONE before sending to worker because we transfer (would invalidate origImage)
    const imageDataCopy = new ImageData(
      new Uint8ClampedArray(baseImage.data),
      baseImage.width,
      baseImage.height
    );

    const procOpts = {
      rBits: state.bits.r,
      gBits: state.bits.g,
      bBits: state.bits.b,
      ditherType: state.dither,
      ditherStrength: state.ditherStrength / 100,
      colorSpace: state.colorSpace,
    };

    // step 2: choose op (k-means vs straight quant)
    let result;
    if (state.kmeans) {
      result = await runWorker('kmeans', { imageData: imageDataCopy, k: state.kCount, opts: procOpts });
    } else {
      result = await runWorker('process', { imageData: imageDataCopy, opts: procOpts });
    }

    state.quantImage = result.imageData;

    // step 2b: tile mode (NES/GB/SNES hardware constraints)
    if (state.tilePreset && state.tilePreset !== 'off') {
      try {
        const cfg = {
          tile: state.tileSize,
          subpalettes: state.tileSubpalettes,
          colorsPerTile: state.tileColorsPerTile,
          monochrome: HARDWARE_PRESETS[state.tilePreset]?.mono === true,
        };
        const tileOut = applyTileMode(result.imageData, cfg);
        state.tileResult = tileOut;
        state.quantImage = tileOut.imageData;
      } catch (te) {
        console.warn('tile mode failed', te);
        state.tileResult = null;
      }
    } else {
      state.tileResult = null;
    }

    // step 3: paint and analyze
    cvOut.width = state.quantImage.width;
    cvOut.height = state.quantImage.height;
    ctxOut.putImageData(state.quantImage, 0, 0);

    // step 3b: tile grid overlay
    repaintGridOverlay();

    // step 4: extract palette
    const wasLocked = new Set(state.palette.filter((p) => p.locked).map((p) => p.hex));
    if (opts.restoreLocks) for (const h of opts.restoreLocks) wasLocked.add(h);
    state.palette = extractPalette(state.quantImage, wasLocked);

    // step 5: apply user-set order if any (filter to surviving hexes, append new)
    if (state.paletteOrder) {
      const byHex = new Map(state.palette.map((p) => [p.hex, p]));
      const ordered = [];
      for (const h of state.paletteOrder) {
        const e = byHex.get(h);
        if (e) {
          ordered.push(e);
          byHex.delete(h);
        }
      }
      for (const e of byHex.values()) ordered.push(e);
      state.palette = ordered;
    }

    renderPalette();

    // FLAG DAY · update Color Space oscilloscope
    paintColorSpaceScope({
      quantImage: state.quantImage,
      palette: state.palette,
      colorSpace: state.colorSpace,
    });

    // meta updates
    const totalBits = state.bits.r + state.bits.g + state.bits.b;
    if (state.kmeans) {
      $('hint-bits').textContent = `k-means · ${state.kCount}`;
    } else {
      $('hint-bits').textContent = `${totalBits}-bit · ${(1 << totalBits).toLocaleString()} addressable`;
    }
    const tileTag = (state.tilePreset && state.tilePreset !== 'off')
      ? ` · ${state.tilePreset.toUpperCase()}@${state.tileSize}px×${state.tileSubpalettes}`
      : '';
    $('quant-meta').textContent = `${state.palette.length} unique · ${state.colorSpace.toUpperCase()} · ${state.dither}${tileTag}`;
    $('stat-colors').textContent = `${state.palette.length.toLocaleString()} colors`;
    $('stat-ms').textContent = `${Math.round(performance.now() - t0)} ms`;

    // update A/B overlay
    if (state.abActive) repaintOverlay();
  } catch (err) {
    console.error('pipeline error', err);
    toast('Pipeline error: ' + err.message, 'err');
  } finally {
    processing = false;
    if (pendingOpts !== null) {
      const next = pendingOpts;
      pendingOpts = null;
      runPipeline(next);
    }
  }
}

function pixelScale(imageData, scale) {
  const w = imageData.width;
  const h = imageData.height;
  const dw = Math.max(1, Math.floor(w / scale));
  const dh = Math.max(1, Math.floor(h / scale));
  const c1 = document.createElement('canvas');
  c1.width = w;
  c1.height = h;
  c1.getContext('2d').putImageData(imageData, 0, 0);
  const c2 = document.createElement('canvas');
  c2.width = dw;
  c2.height = dh;
  const ctx2 = c2.getContext('2d');
  ctx2.imageSmoothingEnabled = true;
  ctx2.drawImage(c1, 0, 0, dw, dh);
  const c3 = document.createElement('canvas');
  c3.width = w;
  c3.height = h;
  const ctx3 = c3.getContext('2d');
  ctx3.imageSmoothingEnabled = false;
  ctx3.drawImage(c2, 0, 0, w, h);
  return ctx3.getImageData(0, 0, w, h);
}

// ---------- palette ----------
function extractPalette(imageData, lockedHexes = new Set()) {
  const { data } = imageData;
  const map = new Map();
  for (let i = 0; i < data.length; i += 4) {
    if (data[i + 3] === 0) continue;
    const r = data[i],
      g = data[i + 1],
      b = data[i + 2];
    const key = (r << 16) | (g << 8) | b;
    map.set(key, (map.get(key) || 0) + 1);
  }
  const out = [];
  for (const [key, count] of map) {
    const r = (key >> 16) & 0xff;
    const g = (key >> 8) & 0xff;
    const b = key & 0xff;
    const hex = rgbToHex(r, g, b);
    out.push({ r, g, b, count, hex, locked: lockedHexes.has(hex) });
  }
  return sortByHueLuma(out);
}

function sortByHueLuma(arr) {
  for (const c of arr) {
    const hsl = rgbToHsl(c.r, c.g, c.b);
    c._h = hsl.h;
    c._s = hsl.s;
    c._l = hsl.l;
  }
  arr.sort((a, b) => {
    const aB = a._s < 0.08 ? 99 : Math.floor(a._h * 12);
    const bB = b._s < 0.08 ? 99 : Math.floor(b._h * 12);
    if (aB !== bB) return aB - bB;
    return b._l - a._l;
  });
  for (const c of arr) { delete c._h; delete c._s; delete c._l; }
  return arr;
}

function sortByLuma(arr) {
  arr.sort((a, b) => luma(b.r, b.g, b.b) - luma(a.r, a.g, a.b));
  return arr;
}

function renderPalette() {
  const grid = $('palette-grid');
  const palette = state.palette;
  const cap = 256;
  const view = palette.slice(0, cap);
  grid.innerHTML = view
    .map(
      (c, i) =>
        `<button class="swatch ${c.locked ? 'locked' : ''}" draggable="true" data-i="${i}" style="background:${c.hex}" data-hex="${c.hex} · ${c.count.toLocaleString()}px" title="${c.hex} · ${c.count}px · click to lock · drag to reorder" aria-label="${c.hex}"></button>`
    )
    .join('');
  if (palette.length > cap) {
    grid.insertAdjacentHTML(
      'beforeend',
      `<div class="muted small" style="grid-column:1/-1;text-align:center;padding:6px">+${palette.length - cap} more (full set in exports)</div>`
    );
  }
  $('pal-count').textContent = palette.length;
  wireSwatchEvents();
}

function wireSwatchEvents() {
  const grid = $('palette-grid');
  let dragSrc = null;

  grid.querySelectorAll('.swatch').forEach((sw) => {
    sw.addEventListener('click', (e) => {
      const i = +sw.dataset.i;
      const c = state.palette[i];
      if (!c) return;
      c.locked = !c.locked;
      sw.classList.toggle('locked');
    });
    sw.addEventListener('dragstart', (e) => {
      dragSrc = sw;
      sw.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/plain', sw.dataset.i);
    });
    sw.addEventListener('dragend', () => {
      sw.classList.remove('dragging');
      grid.querySelectorAll('.drop-target').forEach((el) => el.classList.remove('drop-target'));
    });
    sw.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
      sw.classList.add('drop-target');
    });
    sw.addEventListener('dragleave', () => sw.classList.remove('drop-target'));
    sw.addEventListener('drop', (e) => {
      e.preventDefault();
      sw.classList.remove('drop-target');
      const from = +e.dataTransfer.getData('text/plain');
      const to = +sw.dataset.i;
      if (from === to) return;
      const arr = state.palette;
      const [moved] = arr.splice(from, 1);
      arr.splice(to, 0, moved);
      state.paletteOrder = arr.map((p) => p.hex);
      renderPalette();
      pushHistory();
    });
  });
}

// ---------- histogram ----------
function drawHistogram(imageData) {
  const w = cvHist.width;
  const h = cvHist.height;
  ctxHist.clearRect(0, 0, w, h);
  if (!imageData) {
    ctxHist.fillStyle = 'rgba(144,151,168,0.5)';
    ctxHist.font = '11px JetBrains Mono, monospace';
    ctxHist.textAlign = 'center';
    ctxHist.fillText('Load an image to see the histogram', w / 2, h / 2);
    return;
  }
  const bins = 64;
  const histR = new Array(bins).fill(0);
  const histG = new Array(bins).fill(0);
  const histB = new Array(bins).fill(0);
  const histL = new Array(bins).fill(0);
  const data = imageData.data;
  for (let i = 0; i < data.length; i += 4) {
    if (data[i + 3] === 0) continue;
    const r = data[i], g = data[i + 1], b = data[i + 2];
    histR[(r * bins) >> 8]++;
    histG[(g * bins) >> 8]++;
    histB[(b * bins) >> 8]++;
    histL[Math.min(bins - 1, Math.floor((luma(r, g, b) * bins) / 256))]++;
  }
  let max = 0;
  for (let i = 0; i < bins; i++) {
    if (histR[i] > max) max = histR[i];
    if (histG[i] > max) max = histG[i];
    if (histB[i] > max) max = histB[i];
  }
  if (max === 0) return;
  const styles = getComputedStyle(document.documentElement);
  const colR = styles.getPropertyValue('--r').trim() || '#ff5d8f';
  const colG = styles.getPropertyValue('--g').trim() || '#67e08a';
  const colB = styles.getPropertyValue('--b').trim() || '#6ba6ff';
  const colL = styles.getPropertyValue('--text-muted').trim() || '#9097a8';

  const drawCurve = (hist, color, alpha) => {
    ctxHist.beginPath();
    ctxHist.moveTo(0, h);
    for (let i = 0; i < bins; i++) {
      const x = (i / (bins - 1)) * w;
      const y = h - (hist[i] / max) * (h - 8);
      ctxHist.lineTo(x, y);
    }
    ctxHist.lineTo(w, h);
    ctxHist.closePath();
    ctxHist.fillStyle = hexA(color, alpha);
    ctxHist.fill();
    ctxHist.strokeStyle = color;
    ctxHist.lineWidth = 1;
    ctxHist.stroke();
  };
  ctxHist.strokeStyle = 'rgba(255,255,255,0.04)';
  for (let i = 1; i < 4; i++) {
    ctxHist.beginPath();
    ctxHist.moveTo(0, (i * h) / 4);
    ctxHist.lineTo(w, (i * h) / 4);
    ctxHist.stroke();
  }
  ctxHist.globalCompositeOperation = 'screen';
  drawCurve(histR, colR, 0.35);
  drawCurve(histG, colG, 0.35);
  drawCurve(histB, colB, 0.35);
  ctxHist.globalCompositeOperation = 'source-over';
  drawCurve(histL, colL, 0.1);
}

function hexA(hex, alpha) {
  const h = hex.replace('#', '');
  const r = parseInt(h.substring(0, 2), 16);
  const g = parseInt(h.substring(2, 4), 16);
  const b = parseInt(h.substring(4, 6), 16);
  return `rgba(${r},${g},${b},${alpha})`;
}

// ---------- image loading ----------
function loadImageFromURL(url, name = 'image') {
  const img = new Image();
  img.crossOrigin = 'anonymous';
  img.onload = () => {
    const MAX = 1024;
    let w = img.naturalWidth;
    let h = img.naturalHeight;
    if (w > MAX || h > MAX) {
      const k = MAX / Math.max(w, h);
      w = Math.round(w * k);
      h = Math.round(h * k);
    }
    state.srcCanvas.width = w;
    state.srcCanvas.height = h;
    state.srcCtx.imageSmoothingEnabled = true;
    state.srcCtx.drawImage(img, 0, 0, w, h);
    state.origImage = state.srcCtx.getImageData(0, 0, w, h);
    state.filename = name.replace(/\.[^.]+$/, '') || 'image';

    cvOrig.width = w;
    cvOrig.height = h;
    ctxOrig.putImageData(state.origImage, 0, 0);

    $('orig-meta').textContent = `${w} × ${h}`;
    $('stat-dim').textContent = `${w}×${h}`;
    drawHistogram(state.origImage);
    state.history = [];
    state.histPtr = -1;
    pushHistory();
    runPipeline();
  };
  img.onerror = () => toast('Image failed to load', 'err');
  img.src = url;
}

function loadImageFromFile(file) {
  loadImageFromURL(URL.createObjectURL(file), file.name || 'image');
}

// ---------- sample image (procedural) ----------
function buildSample() {
  const w = 512, h = 384;
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  const ctx = c.getContext('2d');
  const sky = ctx.createLinearGradient(0, 0, 0, h * 0.7);
  sky.addColorStop(0, '#1b2a55');
  sky.addColorStop(0.4, '#c14b6e');
  sky.addColorStop(0.85, '#f4a261');
  sky.addColorStop(1, '#f7e2b8');
  ctx.fillStyle = sky;
  ctx.fillRect(0, 0, w, h);
  const sunGrad = ctx.createRadialGradient(w * 0.7, h * 0.45, 8, w * 0.7, h * 0.45, 80);
  sunGrad.addColorStop(0, '#fff3c8');
  sunGrad.addColorStop(0.4, '#ffce6e');
  sunGrad.addColorStop(1, 'rgba(255,170,80,0)');
  ctx.fillStyle = sunGrad;
  ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = '#2a1a3e';
  ctx.beginPath();
  ctx.moveTo(0, h * 0.65);
  for (const [x, y] of [[0.1,0.55],[0.22,0.62],[0.32,0.5],[0.5,0.6],[0.65,0.45],[0.8,0.58],[1,0.5]])
    ctx.lineTo(x * w, y * h);
  ctx.lineTo(w, h); ctx.lineTo(0, h); ctx.closePath();
  ctx.fill();
  ctx.fillStyle = '#3a5279';
  ctx.fillRect(0, h * 0.7, w, h);
  for (let i = 0; i < 5; i++) {
    ctx.fillStyle = `rgba(255,200,140,${0.3 - i * 0.05})`;
    ctx.fillRect(0, h * 0.72 + i * 12, w, 3);
  }
  return c.toDataURL('image/png');
}

// ---------- A/B compare ----------
function setupABCompare() {
  const wrap = $('quant-wrap');
  const divider = $('ab-divider');
  let dragging = false;

  $('ab-toggle').addEventListener('click', () => {
    state.abActive = !state.abActive;
    cvOverlay.hidden = !state.abActive;
    divider.hidden = !state.abActive;
    $('ab-toggle').classList.toggle('active', state.abActive);
    if (state.abActive) repaintOverlay();
  });

  function onMove(e) {
    if (!dragging) return;
    const rect = wrap.getBoundingClientRect();
    const x = (e.clientX || (e.touches && e.touches[0].clientX) || 0) - rect.left;
    const p = Math.max(0, Math.min(1, x / rect.width));
    state.abPos = p;
    divider.style.left = `${p * 100}%`;
    cvOverlay.style.clipPath = `inset(0 ${(1 - p) * 100}% 0 0)`;
  }
  divider.addEventListener('mousedown', () => (dragging = true));
  divider.addEventListener('touchstart', () => (dragging = true), { passive: true });
  window.addEventListener('mousemove', onMove);
  window.addEventListener('touchmove', onMove, { passive: true });
  window.addEventListener('mouseup', () => (dragging = false));
  window.addEventListener('touchend', () => (dragging = false));
}

function repaintOverlay() {
  if (!state.origImage) return;
  cvOverlay.width = state.origImage.width;
  cvOverlay.height = state.origImage.height;
  ctxOverlay.putImageData(state.origImage, 0, 0);
  cvOverlay.style.clipPath = `inset(0 ${(1 - state.abPos) * 100}% 0 0)`;
}

// ---------- pixel inspector ----------
function setupInspector() {
  const wrap = $('quant-wrap');
  const ins = $('inspector');
  wrap.addEventListener('mousemove', (e) => {
    if (!state.quantImage) return;
    const rect = cvOut.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    if (x < 0 || y < 0 || x > rect.width || y > rect.height) {
      ins.hidden = true;
      return;
    }
    const px = Math.floor((x / rect.width) * state.quantImage.width);
    const py = Math.floor((y / rect.height) * state.quantImage.height);
    const i = (py * state.quantImage.width + px) * 4;
    const r = state.quantImage.data[i];
    const g = state.quantImage.data[i + 1];
    const b = state.quantImage.data[i + 2];
    const hex = rgbToHex(r, g, b);
    const lab = rgbToOklab(r, g, b);
    const palIdx = state.palette.findIndex((p) => p.hex === hex);
    ins.innerHTML = `
      <div><span class="ins-swatch" style="background:${hex}"></span>${hex}</div>
      <div>rgb(${r}, ${g}, ${b}) · px ${px},${py}</div>
      <div>OKLab L=${lab.L.toFixed(3)} a=${lab.a.toFixed(3)} b=${lab.b.toFixed(3)}</div>
      <div>palette index: ${palIdx >= 0 ? palIdx : '—'}</div>`;
    ins.hidden = false;
    // position
    const wrapRect = wrap.getBoundingClientRect();
    let left = e.clientX - wrapRect.left + 14;
    let top = e.clientY - wrapRect.top + 14;
    if (left + 220 > wrapRect.width) left = e.clientX - wrapRect.left - 230;
    if (top + 80 > wrapRect.height) top = e.clientY - wrapRect.top - 90;
    ins.style.left = `${left}px`;
    ins.style.top = `${top}px`;
  });
  wrap.addEventListener('mouseleave', () => (ins.hidden = true));
}

// ---------- toast ----------
let toastTimer = null;
function toast(msg, type = 'ok') {
  const el = $('toast');
  el.textContent = msg;
  el.className = `toast ${type}`;
  el.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (el.hidden = true), 2400);
}

// ---------- ComfyUI ----------
async function comfyPing() {
  const url = $('cui-url').value.trim();
  $('cui-status').className = 'hint cui-dot';
  $('cui-msg').textContent = 'Pinging…';
  const r = await cuiPing(url);
  if (r.ok) {
    $('cui-status').classList.add('ok');
    $('cui-msg').textContent = `Connected · ${(r.data?.system?.os || 'ComfyUI').toString()}`;
  } else {
    $('cui-status').classList.add('err');
    $('cui-msg').textContent = `Offline: ${r.error}`;
  }
}

function repaintGridOverlay() {
  const showGrid = state.tileShowGrid && state.tilePreset && state.tilePreset !== 'off' && state.tileResult;
  if (!showGrid) {
    cvGrid.hidden = true;
    return;
  }
  const w = state.quantImage.width, h = state.quantImage.height;
  cvGrid.width = w;
  cvGrid.height = h;
  cvGrid.hidden = false;
  ctxGrid.clearRect(0, 0, w, h);
  drawTileGrid(ctxGrid, w, h, state.tileSize, { stroke: 'rgba(0,211,167,0.42)', width: 1 });
}

function applyTilePreset(preset) {
  const cfg = HARDWARE_PRESETS[preset];
  state.tilePreset = preset;
  if (cfg && preset !== 'off') {
    state.tileSize = cfg.tile;
    state.tileSubpalettes = cfg.subpalettes;
    state.tileColorsPerTile = cfg.colorsPerTile;
  }
  document.querySelectorAll('#tile-preset-seg button').forEach(b => b.classList.toggle('active', b.dataset.tp === preset));
  const on = preset !== 'off';
  $('tile-status').textContent = on ? cfg.label : 'off';
  $('tile-status').classList.toggle('on', on);
  for (const id of ['tile-row-size', 'tile-row-sub', 'tile-row-cpt']) {
    $(id).style.opacity = on ? '1' : '0.4';
    $(id).style.pointerEvents = on ? '' : 'none';
  }
  $('tileSize').value = state.tileSize; $('oTS').textContent = state.tileSize;
  $('tileSub').value = state.tileSubpalettes; $('oTSub').textContent = state.tileSubpalettes;
  $('tileCPT').value = state.tileColorsPerTile; $('oTCPT').textContent = state.tileColorsPerTile;
}

async function comfySend() {
  if (!state.quantImage) {
    toast('Load an image first', 'err');
    return;
  }
  const url = $('cui-url').value.trim();
  $('cui-msg').textContent = 'Uploading…';
  try {
    // turn current quantized canvas into a blob
    const imageBlob = await new Promise((res) => cvOut.toBlob(res, 'image/png'));
    const stamp = Date.now();
    const imageName = `${state.filename}-pp-${stamp}.png`;
    const paletteBlob = buildJSON(buildStateForExport());
    const paletteName = `${state.filename}-pp-${stamp}.json`;
    if (state.cuiRoundtrip) {
      // full round-trip: queue + poll + display result inline
      const msgEl = $('cui-msg');
      msgEl.classList.remove('err'); msgEl.classList.add('busy');
      const { blob: outBlob, outputs } = await cuiRoundTrip({
        imageBlob, imageName, paletteBlob, paletteName, baseURL: url,
        dither: state.dither, strength: state.ditherStrength / 100, space: state.colorSpace,
        onStatus: (s) => { msgEl.textContent = `Round-trip: ${s}…`; },
      });
      const bmp = await createImageBitmap(outBlob);
      cvCui.width = bmp.width; cvCui.height = bmp.height;
      ctxCui.drawImage(bmp, 0, 0);
      $('cui-out-wrap').hidden = false;
      $('cui-out-meta').textContent = `${bmp.width}×${bmp.height} · ${outputs[0]?.filename || ''}`;
      msgEl.classList.remove('busy');
      msgEl.textContent = `Round-trip done · ${outputs[0]?.filename}`;
      state.cuiOutBlob = outBlob;
      state.cuiOutName = outputs[0]?.filename;
      toast('ComfyUI round-trip complete', 'ok');
    } else {
      const { workflow } = await sendToComfy({
        imageBlob, imageName, paletteBlob, paletteName, baseURL: url,
        dither: state.dither, strength: state.ditherStrength / 100, space: state.colorSpace,
      });
      downloadBlob(new Blob([JSON.stringify(workflow, null, 2)], { type: 'application/json' }), `${state.filename}-pp-${stamp}.workflow.json`);
      $('cui-msg').textContent = `Sent. Workflow downloaded — drop it onto ComfyUI to load.`;
      toast('Sent to ComfyUI · workflow downloaded', 'ok');
    }
  } catch (err) {
    $('cui-msg').classList.remove('busy'); $('cui-msg').classList.add('err');
    $('cui-msg').textContent = `Failed: ${err.message}`;
    toast('ComfyUI send failed: ' + err.message, 'err');
  }
}

function buildStateForExport() {
  return {
    filename: state.filename,
    bits: state.bits,
    dither: state.dither,
    ditherStrength: state.ditherStrength,
    pixelScale: state.pixelScale,
    colorSpace: state.colorSpace,
    kmeans: state.kmeans,
    kCount: state.kCount,
    palette: state.palette,
    srcWidth: state.origImage?.width || 0,
    srcHeight: state.origImage?.height || 0,
  };
}

// ---------- exports ----------
function exportPNG() {
  if (!state.quantImage) return;
  cvOut.toBlob((blob) => {
    const tag = state.kmeans ? `k${state.kCount}` : `${state.bits.r}${state.bits.g}${state.bits.b}`;
    downloadBlob(blob, `${state.filename}-pp-${tag}-${state.dither}.png`);
  }, 'image/png');
}

function exportPalettePNG() {
  if (!state.palette.length) return;
  paletteGridCanvas(state.palette).toBlob((blob) => {
    downloadBlob(blob, `${state.filename}-palette-${state.palette.length}.png`);
  }, 'image/png');
}

function exportStripPNG() {
  if (!state.palette.length) return;
  paletteStripCanvas(state.palette).toBlob((blob) => {
    downloadBlob(blob, `${state.filename}-strip-${state.palette.length}.png`);
  }, 'image/png');
}

function exportJSON() {
  if (!state.palette.length) return;
  downloadBlob(buildJSON(buildStateForExport()), `${state.filename}-palette.json`);
}

function exportGPL() {
  if (!state.palette.length) return;
  downloadBlob(buildGPL(state.palette, state.filename), `${state.filename}.gpl`);
}

function exportPAL() {
  if (!state.palette.length) return;
  downloadBlob(buildPAL(state.palette), `${state.filename}.pal`);
}

function exportASE() {
  if (!state.palette.length) return;
  downloadBlob(buildASE(state.palette, state.filename), `${state.filename}.ase`);
}

async function exportHEX() {
  if (!state.palette.length) return;
  const text = state.palette.map((p) => p.hex).join('\n');
  try {
    await navigator.clipboard.writeText(text);
    toast('Hex list copied to clipboard', 'ok');
  } catch {
    downloadBlob(buildHEX(state.palette), `${state.filename}.hex`);
    toast('Hex list downloaded (clipboard blocked)', 'ok');
  }
}

function downloadBlob(blob, name) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

// ---------- wire UI ----------
function pushControlsToDOM() {
  $('qR').value = state.bits.r; $('oR').textContent = state.bits.r; $('lR').textContent = 1 << state.bits.r;
  $('qG').value = state.bits.g; $('oG').textContent = state.bits.g; $('lG').textContent = 1 << state.bits.g;
  $('qB').value = state.bits.b; $('oB').textContent = state.bits.b; $('lB').textContent = 1 << state.bits.b;
  $('dStrength').value = state.ditherStrength; $('oDS').textContent = state.ditherStrength;
  $('pixScale').value = state.pixelScale; $('oPS').textContent = `${state.pixelScale}×`;
  $('kCount').value = state.kCount; $('oK').textContent = state.kCount;
  // segmented
  document.querySelectorAll('#space-seg button').forEach((b) => b.classList.toggle('active', b.dataset.s === state.colorSpace));
  document.querySelectorAll('#kmeans-seg button').forEach((b) => b.classList.toggle('active', b.dataset.k === (state.kmeans ? 'on' : 'off')));
  document.querySelectorAll('#dither-seg button').forEach((b) => b.classList.toggle('active', b.dataset.d === state.dither));
  $('kmeans-controls').style.opacity = state.kmeans ? '1' : '0.4';
  $('kmeans-controls').style.pointerEvents = state.kmeans ? '' : 'none';
}

function wire() {
  // file
  const fileInput = $('file-input');
  fileInput.addEventListener('change', (e) => {
    const f = e.target.files?.[0]; if (f) loadImageFromFile(f);
  });
  const dz = $('dropzone');
  // Belt + suspenders: <label for> handles the click, but if anything blocks it, do it manually.
  dz.addEventListener('click', (e) => {
    if (e.target === fileInput) return;          // user clicked the input directly
    if (e.defaultPrevented) return;
    // If the browser hasn't already opened the picker via label-for, force it.
    // (No harm if it already opened — second call is ignored within a user gesture.)
  });
  ['dragenter', 'dragover'].forEach((evt) => dz.addEventListener(evt, (e) => { e.preventDefault(); e.stopPropagation(); dz.classList.add('drag'); }));
  ['dragleave', 'drop'].forEach((evt) => dz.addEventListener(evt, (e) => { e.preventDefault(); e.stopPropagation(); dz.classList.remove('drag'); }));
  dz.addEventListener('drop', (e) => {
    const f = e.dataTransfer?.files?.[0];
    if (f) {
      if (!f.type || f.type.startsWith('image/')) loadImageFromFile(f);
      else toast(`Not an image: ${f.type || f.name}`, 'err');
    }
  });
  // Global drag prevention so dropping anywhere else doesn't navigate away
  ['dragover', 'drop'].forEach((evt) => window.addEventListener(evt, (e) => {
    if (e.target.closest && !e.target.closest('#dropzone')) e.preventDefault();
  }));
  $('btn-sample').addEventListener('click', () => loadImageFromURL(buildSample(), 'sample-sunset'));
  $('btn-reset').addEventListener('click', () => {
    state.origImage = null; state.quantImage = null; state.palette = []; state.paletteOrder = null;
    cvOrig.width = cvOut.width = 1; cvOrig.height = cvOut.height = 1;
    $('palette-grid').innerHTML = '';
    $('orig-meta').textContent = 'awaiting image';
    $('quant-meta').textContent = '—';
    $('stat-dim').textContent = '—';
    $('stat-colors').textContent = '— colors';
    $('pal-count').textContent = '0';
    drawHistogram(null);
  });

  // RGB sliders
  const wireQ = (id, key, labelId) => {
    $(id).addEventListener('input', () => {
      const v = parseInt($(id).value, 10);
      state.bits[key] = v;
      $('o' + key.toUpperCase()).textContent = v;
      $(labelId).textContent = 1 << v;
      schedule();
    });
    $(id).addEventListener('change', pushHistory);
  };
  wireQ('qR', 'r', 'lR'); wireQ('qG', 'g', 'lG'); wireQ('qB', 'b', 'lB');

  $('dStrength').addEventListener('input', (e) => { state.ditherStrength = parseInt(e.target.value, 10); $('oDS').textContent = state.ditherStrength; schedule(); });
  $('dStrength').addEventListener('change', pushHistory);
  $('pixScale').addEventListener('input', (e) => { state.pixelScale = parseInt(e.target.value, 10); $('oPS').textContent = `${state.pixelScale}×`; schedule(); });
  $('pixScale').addEventListener('change', pushHistory);
  $('kCount').addEventListener('input', (e) => { state.kCount = parseInt(e.target.value, 10); $('oK').textContent = state.kCount; if (state.kmeans) schedule(); });
  $('kCount').addEventListener('change', () => { if (state.kmeans) pushHistory(); });

  // presets
  document.querySelectorAll('.chip[data-preset]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const [r, g, b] = btn.dataset.preset.split(',').map(Number);
      state.bits = { r, g, b }; pushControlsToDOM(); schedule(); pushHistory();
    });
  });

  // colorspace
  document.querySelectorAll('#space-seg button').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.colorSpace = btn.dataset.s; pushControlsToDOM(); schedule(); pushHistory();
    });
  });
  // kmeans
  document.querySelectorAll('#kmeans-seg button').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.kmeans = btn.dataset.k === 'on'; pushControlsToDOM(); schedule(); pushHistory();
    });
  });
  // dither
  document.querySelectorAll('#dither-seg button').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.dither = btn.dataset.d; pushControlsToDOM(); schedule(); pushHistory();
    });
  });

  // exports
  $('exp-png').addEventListener('click', exportPNG);
  $('exp-pal-png').addEventListener('click', exportPalettePNG);
  $('exp-strip').addEventListener('click', exportStripPNG);
  $('exp-json').addEventListener('click', exportJSON);
  $('exp-gpl').addEventListener('click', exportGPL);
  $('exp-pal').addEventListener('click', exportPAL);
  $('exp-ase').addEventListener('click', exportASE);
  $('exp-hex').addEventListener('click', exportHEX);

  // palette controls
  $('pal-sort-hue').addEventListener('click', () => { state.paletteOrder = null; state.palette = sortByHueLuma(state.palette); renderPalette(); pushHistory(); });
  $('pal-sort-luma').addEventListener('click', () => { state.paletteOrder = null; state.palette = sortByLuma(state.palette); state.paletteOrder = state.palette.map((p) => p.hex); renderPalette(); pushHistory(); });
  $('pal-unlock-all').addEventListener('click', () => { state.palette.forEach((p) => (p.locked = false)); renderPalette(); });

  // Tile mode
  document.querySelectorAll('#tile-preset-seg button').forEach((btn) => {
    btn.addEventListener('click', () => { applyTilePreset(btn.dataset.tp); schedule(); pushHistory(); });
  });
  $('tileSize').addEventListener('input', (e) => { state.tileSize = parseInt(e.target.value, 10); $('oTS').textContent = state.tileSize; schedule(); });
  $('tileSize').addEventListener('change', pushHistory);
  $('tileSub').addEventListener('input', (e) => { state.tileSubpalettes = parseInt(e.target.value, 10); $('oTSub').textContent = state.tileSubpalettes; schedule(); });
  $('tileSub').addEventListener('change', pushHistory);
  $('tileCPT').addEventListener('input', (e) => { state.tileColorsPerTile = parseInt(e.target.value, 10); $('oTCPT').textContent = state.tileColorsPerTile; schedule(); });
  $('tileCPT').addEventListener('change', pushHistory);
  $('tileGrid').addEventListener('change', (e) => { state.tileShowGrid = e.target.checked; repaintGridOverlay(); });

  // ComfyUI
  $('cui-ping').addEventListener('click', comfyPing);
  $('cui-send').addEventListener('click', comfySend);
  $('cui-roundtrip').addEventListener('change', (e) => { state.cuiRoundtrip = e.target.checked; });
  $('cui-out-save').addEventListener('click', () => {
    if (state.cuiOutBlob) downloadBlob(state.cuiOutBlob, state.cuiOutName || 'comfyui-output.png');
  });

  // theme
  const themeBtn = $('theme-toggle');
  themeBtn.addEventListener('click', () => {
    const cur = document.documentElement.getAttribute('data-theme');
    const next = cur === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    themeBtn.textContent = next === 'dark' ? '☀' : '☾';
    if (state.origImage) drawHistogram(state.origImage);
  });

  // undo/redo buttons + keyboard
  $('undo-btn').addEventListener('click', undo);
  $('redo-btn').addEventListener('click', redo);
  window.addEventListener('keydown', (e) => {
    const cmd = e.metaKey || e.ctrlKey;
    if (cmd && e.key === 'z' && !e.shiftKey) { e.preventDefault(); undo(); }
    else if (cmd && (e.key === 'Z' || (e.key === 'z' && e.shiftKey))) { e.preventDefault(); redo(); }
    else if (cmd && e.key === 'y') { e.preventDefault(); redo(); }
  });

  setupABCompare();
  setupInspector();
}

// ---------- bootstrap ----------
wire();
applyTilePreset('off');
drawHistogram(null);
resetColorSpaceScope();
loadImageFromURL(buildSample(), 'sample-sunset');
// initial ping (best-effort)
setTimeout(comfyPing, 800);
