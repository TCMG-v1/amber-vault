import { useState, useMemo } from "react";
import { useBlend } from "@/lib/blend-context";
import {
  CONDITIONS,
  conditionTargets,
  rankTerpenesForCondition,
  suggestCombos,
  receptorName,
} from "@/lib/score";
import { SectionLabel } from "@/components/archive-bits";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Download } from "lucide-react";

export default function Prescriber() {
  const { loadBlend } = useBlend();
  const [cond, setCond] = useState(CONDITIONS[0]);

  const targets = useMemo(() => conditionTargets(cond), [cond]);
  const ranked = useMemo(() => rankTerpenesForCondition(cond).slice(0, 5), [cond]);
  const combos = useMemo(() => suggestCombos(cond, 3), [cond]);
  const maxScore = ranked[0]?.score ?? 1;

  return (
    <div className="p-4 md:p-6">
      <header className="mb-5">
        <h1 className="font-serif text-2xl font-semibold text-foreground tracking-tight">Condition Prescriber</h1>
        <p className="text-xs text-muted-foreground font-serif italic mt-0.5">
          Rank single terpenes by priority-weighted receptor coverage; suggest mechanistically disjoint combos.
        </p>
      </header>

      <div className="flex items-center gap-3 mb-5">
        <span className="nav-label">§ INDICATION</span>
        <Select value={cond} onValueChange={setCond}>
          <SelectTrigger className="w-64 font-mono text-[12px] h-8" data-testid="select-condition">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {CONDITIONS.map((c) => (
              <SelectItem key={c} value={c} className="font-mono text-[12px]">
                {c}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[1fr_1fr] gap-6">
        <div className="space-y-6 min-w-0">
          {/* Target receptors */}
          <section>
            <SectionLabel>PRIORITY TARGETS · {targets.length}</SectionLabel>
            <div className="border border-border bg-card divide-y divide-border/60 max-h-44 overflow-y-auto">
              {targets.sort((a, b) => a.priority - b.priority).map((t, i) => (
                <div key={i} className="px-2 py-1 flex items-start gap-2 text-[11px]" data-testid={`target-${t.receptorId}`}>
                  <span className={`font-mono text-[9px] px-1 border ${t.priority === 1 ? "tier-H" : "tier-IV"} shrink-0 mt-0.5`}>
                    P{t.priority}
                  </span>
                  <span className="font-mono text-foreground/90 w-24 shrink-0">{t.receptorId}</span>
                  <span className="font-serif italic text-muted-foreground leading-snug">{t.rationale}</span>
                </div>
              ))}
            </div>
          </section>

          {/* Top-5 singles */}
          <section>
            <SectionLabel>TOP-5 SINGLE TERPENES</SectionLabel>
            <div className="space-y-1.5">
              {ranked.map((r, i) => (
                <div key={r.id} className="border border-border bg-card px-3 py-2" data-testid={`rank-${r.id}`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-[11px] text-muted-foreground">{i + 1}.</span>
                      <span className="font-serif text-[15px] text-foreground">{r.name}</span>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-6 px-2 font-mono text-[10px]"
                      onClick={() => loadBlend([r.id])}
                      data-testid={`button-load-single-${r.id}`}
                    >
                      <Download className="h-3 w-3 mr-1" /> load
                    </Button>
                  </div>
                  <div className="mt-1 h-1 bg-secondary">
                    <div className="h-1 bg-primary" style={{ width: `${(r.score / maxScore) * 100}%` }} />
                  </div>
                  <p className="font-mono text-[9.5px] text-muted-foreground mt-1 truncate">
                    score {r.score.toFixed(2)} · hits {r.hits.map((h) => h.receptorId).join(", ")}
                  </p>
                </div>
              ))}
              {ranked.length === 0 && (
                <p className="font-serif italic text-muted-foreground text-sm">No terpene engages this condition's targets in the codex.</p>
              )}
            </div>
          </section>
        </div>

        {/* Combos */}
        <section className="min-w-0">
          <SectionLabel>SUGGESTED COMBOS · Jaccard ≥ 0.5</SectionLabel>
          <div className="space-y-2">
            {combos.map((c, i) => (
              <div key={i} className="border border-border bg-card px-3 py-2.5" data-testid={`combo-${i}`}>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-serif text-[14px] text-foreground">{c.names.join(" + ")}</span>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-6 px-2 font-mono text-[10px] border-primary/50 text-primary"
                    onClick={() => loadBlend(c.ids)}
                    data-testid={`button-load-combo-${i}`}
                  >
                    <Download className="h-3 w-3 mr-1" /> load
                  </Button>
                </div>
                <div className="flex items-center gap-3 font-mono text-[9.5px] text-muted-foreground">
                  <span>cov-score {c.score.toFixed(2)}</span>
                  <span className="codex-teal">min-disjoint {c.minDistance.toFixed(2)}</span>
                  <span>{c.ids.length}-component</span>
                </div>
              </div>
            ))}
            {combos.length === 0 && (
              <p className="font-serif italic text-muted-foreground text-sm">
                No sufficiently disjoint combinations (all top candidates share &gt;50% targets).
              </p>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
