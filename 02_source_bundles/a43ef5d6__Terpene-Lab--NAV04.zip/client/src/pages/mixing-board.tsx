import { useState } from "react";
import { useBlend } from "@/lib/blend-context";
import {
  TERPENES,
  terpeneName,
  haskellSignature,
  blendTotal,
  normalize,
  computeAxes,
  AXES,
} from "@/lib/score";
import { Slider } from "@/components/ui/slider";
import { Input } from "@/components/ui/input";
import { SectionLabel, TierBadge, Val } from "@/components/archive-bits";
import { Plus, X, Search } from "lucide-react";

export default function MixingBoard() {
  const { blend, addTerpene, removeTerpene, setPct, has } = useBlend();
  const [q, setQ] = useState("");
  const norm = normalize(blend);
  const total = blendTotal(blend);
  const drifted = blend.length > 0 && Math.abs(total - 1) > 0.001;
  const { fired } = computeAxes(blend);

  const filtered = TERPENES.filter((t) => {
    const id = t.identity;
    const hay = `${id.name} ${id.class} ${t.id} ${id.natural_sources}`.toLowerCase();
    return hay.includes(q.toLowerCase());
  });

  return (
    <div className="p-4 md:p-6">
      <header className="mb-5">
        <h1 className="font-serif text-2xl font-semibold text-foreground tracking-tight">Mixing Board</h1>
        <p className="text-xs text-muted-foreground font-serif italic mt-0.5">
          Compose a mass-fraction blend; downstream receptor scores recompute on every tick.
        </p>
      </header>

      <div className="grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-6">
        {/* Left: blend editor */}
        <div className="space-y-5 min-w-0">
          <section>
            <SectionLabel>ACTIVE BLEND</SectionLabel>
            {blend.length === 0 ? (
              <div className="border border-dashed border-border p-6 text-center">
                <p className="font-serif italic text-sm text-muted-foreground">
                  Empty formulation. Select terpenes from the registry to add components.
                </p>
              </div>
            ) : (
              <div className="border border-border divide-y divide-border bg-card">
                {blend.map((c) => {
                  const frac = norm.find((n) => n.id === c.id)?.frac ?? 0;
                  return (
                    <div key={c.id} className="px-3 py-2.5" data-testid={`row-blend-${c.id}`}>
                      <div className="flex items-center justify-between mb-1.5">
                        <span className="font-serif text-[15px] text-foreground">{terpeneName(c.id)}</span>
                        <div className="flex items-center gap-3">
                          <span className="font-mono text-[12px] tabular-nums text-primary">
                            {(frac * 100).toFixed(1)}
                            <span className="text-[9px] text-muted-foreground">%</span>
                          </span>
                          <button
                            onClick={() => removeTerpene(c.id)}
                            className="text-muted-foreground hover:text-destructive"
                            aria-label={`Remove ${terpeneName(c.id)}`}
                            data-testid={`button-remove-${c.id}`}
                          >
                            <X className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </div>
                      <Slider
                        value={[Math.round(c.pct * 100)]}
                        min={0}
                        max={100}
                        step={1}
                        onValueChange={(v) => setPct(c.id, v[0] / 100)}
                        data-testid={`slider-${c.id}`}
                      />
                    </div>
                  );
                })}
                <div className={`px-3 py-1.5 font-mono text-[10px] ${drifted ? "seal-red" : "codex-teal"}`}>
                  {drifted
                    ? `⚠ raw Σ = ${(total * 100).toFixed(1)}% — display auto-normalised to 100%`
                    : `Σ = 100.0% · normalised`}
                </div>
              </div>
            )}
          </section>

          {/* Haskell signature */}
          {blend.length > 0 && (
            <section>
              <SectionLabel>HASKELL BLEND SIGNATURE</SectionLabel>
              <pre className="bg-background border border-border p-3 overflow-x-auto font-mono text-[11px] leading-relaxed text-foreground/85">
{haskellSignature(blend)}
              </pre>
            </section>
          )}

          {/* Fired receptors table */}
          {fired.length > 0 && (
            <section>
              <SectionLabel>RECEPTORS FIRED · {fired.length} edges</SectionLabel>
              <div className="border border-border bg-card overflow-x-auto">
                <table className="w-full text-[11px]">
                  <thead>
                    <tr className="border-b border-border text-left font-mono text-[9px] uppercase tracking-wider text-muted-foreground">
                      <th className="px-2 py-1.5">Receptor</th>
                      <th className="px-2 py-1.5">Terpene</th>
                      <th className="px-2 py-1.5">Action</th>
                      <th className="px-2 py-1.5">Tier</th>
                      <th className="px-2 py-1.5 text-right">Contrib</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border/60">
                    {fired.slice(0, 40).map((f, i) => (
                      <tr key={i} data-testid={`fired-${f.receptorId}-${f.terpeneId}`}>
                        <td className="px-2 py-1 font-mono text-foreground/90">{f.receptorId}</td>
                        <td className="px-2 py-1 font-serif text-foreground/80">{f.terpeneName}</td>
                        <td className="px-2 py-1 font-mono text-[10px] text-muted-foreground">{f.action}</td>
                        <td className="px-2 py-1"><TierBadge tier={f.tier} /></td>
                        <td className="px-2 py-1 text-right"><Val value={f.contribution.toFixed(3)} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          )}
        </div>

        {/* Right: terpene registry / picker */}
        <div className="min-w-0">
          <SectionLabel>TERPENE REGISTRY · 17</SectionLabel>
          <div className="relative mb-2">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="filter by name / class / source…"
              className="pl-8 font-mono text-[12px] h-8"
              data-testid="input-terpene-search"
            />
          </div>
          <div className="border border-border divide-y divide-border bg-card max-h-[calc(100vh-220px)] min-h-[400px] overflow-y-auto">
            {filtered.map((t) => {
              const id = t.identity;
              const inBlend = has(t.id);
              return (
                <button
                  key={t.id}
                  onClick={() => (inBlend ? removeTerpene(t.id) : addTerpene(t.id))}
                  className="w-full text-left px-3 py-2 hover-elevate flex items-start justify-between gap-2"
                  data-testid={`button-add-${t.id}`}
                >
                  <div className="min-w-0">
                    <p className="font-serif text-[14px] text-foreground truncate">{id.name}</p>
                    <p className="font-mono text-[10.5px] text-muted-foreground truncate" style={{ fontFeatureSettings: '"zero" 1', fontVariantNumeric: 'slashed-zero' }}>
                      {id.formula} · {id.class} · {id.structure}
                    </p>
                  </div>
                  <span className={`shrink-0 mt-0.5 ${inBlend ? "text-destructive" : "text-primary"}`}>
                    {inBlend ? <X className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
