import { useState, useMemo } from "react";
import { useBlend } from "@/lib/blend-context";
import { RECEPTORS, greedySetCover, receptorName, terpeneTargets } from "@/lib/score";
import { SectionLabel } from "@/components/archive-bits";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Download, Check, Search } from "lucide-react";

export default function ReverseDesign() {
  const { loadBlend } = useBlend();
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [q, setQ] = useState("");

  const toggle = (id: string) =>
    setSelected((s) => {
      const next = new Set(s);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });

  const targets = useMemo(() => Array.from(selected), [selected]);
  const result = useMemo(() => (targets.length ? greedySetCover(targets) : null), [targets]);

  // only receptors that some terpene engages are useful
  const reachable = useMemo(() => {
    const s = new Set<string>();
    for (const r of RECEPTORS) {
      // engaged by at least one terpene? approximate: any terpene targets it
      s.add(r.id);
    }
    return s;
  }, []);

  const filtered = RECEPTORS.filter((r) =>
    `${r.id} ${r.name} ${r.pathway}`.toLowerCase().includes(q.toLowerCase()),
  );

  return (
    <div className="p-4 md:p-6">
      <header className="mb-5">
        <h1 className="font-serif text-2xl font-semibold text-foreground tracking-tight">Reverse-Design Bench</h1>
        <p className="text-xs text-muted-foreground font-serif italic mt-0.5">
          Pick target receptors; greedy set-cover returns the minimal terpene set (max coverage, tier-weighted confidence tiebreak).
        </p>
      </header>

      <div className="grid grid-cols-1 xl:grid-cols-[360px_1fr] gap-6">
        {/* Receptor multi-select */}
        <section className="min-w-0">
          <SectionLabel>TARGET RECEPTORS · {selected.size} selected</SectionLabel>
          <div className="relative mb-2">
            <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <Input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="filter 55 nodes…"
              className="pl-8 font-mono text-[12px] h-8"
              data-testid="input-receptor-search"
            />
          </div>
          <div className="border border-border bg-card divide-y divide-border/60 max-h-[58vh] overflow-y-auto">
            {filtered.map((r) => {
              const on = selected.has(r.id);
              return (
                <button
                  key={r.id}
                  onClick={() => toggle(r.id)}
                  className={`w-full text-left px-2 py-1.5 flex items-center gap-2 hover-elevate ${on ? "bg-primary/10" : ""}`}
                  data-testid={`button-receptor-${r.id}`}
                >
                  <span className={`h-3 w-3 border flex items-center justify-center shrink-0 ${on ? "border-primary bg-primary/20" : "border-border"}`}>
                    {on && <Check className="h-2.5 w-2.5 text-primary" />}
                  </span>
                  <span className="font-mono text-[11px] text-foreground/90 w-24 shrink-0">{r.id}</span>
                  <span className="font-serif text-[11px] text-muted-foreground truncate">{r.name}</span>
                </button>
              );
            })}
          </div>
          {selected.size > 0 && (
            <button
              onClick={() => setSelected(new Set())}
              className="mt-2 font-mono text-[10px] text-muted-foreground hover:text-destructive"
              data-testid="button-clear-targets"
            >
              clear selection
            </button>
          )}
        </section>

        {/* Solver result */}
        <section className="min-w-0">
          <SectionLabel>MINIMAL TERPENE SET</SectionLabel>
          {!result ? (
            <div className="border border-dashed border-border p-8 text-center font-serif italic text-muted-foreground">
              Select one or more target receptors to run the set-cover solver.
            </div>
          ) : (
            <div className="space-y-3">
              <div className={`font-mono text-[11px] ${result.coveredAll ? "codex-teal" : "amber-alarm"}`}>
                {result.coveredAll
                  ? `✓ all ${targets.length} targets covered by ${result.steps.length} terpene${result.steps.length === 1 ? "" : "s"}`
                  : `⚠ partial cover — ${result.uncovered.length} target(s) unreachable: ${result.uncovered.join(", ")}`}
              </div>

              {result.steps.map((s, i) => (
                <div key={s.terpeneId} className="border border-border bg-card px-3 py-2" data-testid={`cover-step-${s.terpeneId}`}>
                  <div className="flex items-center justify-between">
                    <span className="font-serif text-[15px] text-foreground">
                      <span className="font-mono text-[11px] text-muted-foreground mr-2">{i + 1}.</span>
                      {s.terpeneName}
                    </span>
                    <span className="font-mono text-[10px] text-muted-foreground">
                      +{s.covered.length} new · w {s.weightSum.toFixed(2)}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-1 mt-1.5">
                    {s.covered.map((rid) => (
                      <span key={rid} className="font-mono text-[10px] border border-primary/40 px-1.5 py-0.5 text-primary/90 bg-primary/5">
                        {rid}
                      </span>
                    ))}
                  </div>
                </div>
              ))}

              {result.steps.length > 0 && (
                <Button
                  variant="outline"
                  className="font-mono text-[11px] border-primary/50 text-primary"
                  onClick={() => loadBlend(result.steps.map((s) => s.terpeneId))}
                  data-testid="button-load-cover"
                >
                  <Download className="h-3.5 w-3.5 mr-1.5" /> LOAD {result.steps.length}-TERPENE SET INTO MIXING BOARD
                </Button>
              )}
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
