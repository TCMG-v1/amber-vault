import { useEffect, useMemo, useRef, useState } from "react";
import {
  forceSimulation,
  forceManyBody,
  forceLink,
  forceCenter,
  forceCollide,
  type Simulation,
} from "d3-force";
import { TERPENES, terpeneName } from "@/lib/score";
import { useBlend } from "@/lib/blend-context";
import { SectionLabel, CitationPill } from "@/components/archive-bits";

// 3 canonical cannabinoid virtual nodes (always present) + extra agents appearing
// as synergy partners in the codex.
const CANNABINOIDS = ["THC", "CBD", "CBG"];
const EXTRA_AGENTS: Record<string, string> = {
  "2-AG": "2-AG",
  CP_55940: "CP-55940",
  morphine: "Morphine",
};

function colorForType(t: string): string {
  if (t === "synergistic" || t === "antianxiogenic" || t === "memory_protective" || t === "opioid_sparing")
    return "hsl(150 45% 52%)";
  if (t === "additive") return "hsl(186 50% 55%)";
  if (t === "contested") return "hsl(37 65% 58%)";
  if (t === "antagonistic") return "hsl(5 60% 56%)";
  return "hsl(213 10% 45%)"; // no_interaction / other
}
const TYPE_COLOR = new Proxy({}, { get: (_, k: string) => colorForType(k) }) as Record<string, string>;
const TYPES = ["synergistic", "additive", "contested", "antagonistic", "no_interaction"];
// fold extended interaction types into the 5 legend buckets
function bucket(t: string): string {
  if (t === "antianxiogenic" || t === "memory_protective" || t === "opioid_sparing") return "synergistic";
  if (TYPES.includes(t)) return t;
  return "no_interaction";
}

interface GNode { id: string; label: string; kind: "terpene" | "cannabinoid"; x?: number; y?: number; fx?: number | null; fy?: number | null; }
interface GLink { source: any; target: any; type: string; mechanism: string; reference?: string; url?: string; }

export default function Entourage() {
  const { addTerpene } = useBlend();
  const svgRef = useRef<SVGSVGElement>(null);
  const [, force] = useState(0); // re-render tick
  const [selected, setSelected] = useState<string | null>(null);
  const [activeTypes, setActiveTypes] = useState<Set<string>>(new Set(TYPES));
  const W = 640, H = 480;

  const { nodes, links } = useMemo(() => {
    const nodeIds = new Set<string>();
    const nodes: GNode[] = [];
    for (const t of TERPENES) {
      nodes.push({ id: t.id, label: terpeneName(t.id), kind: "terpene" });
      nodeIds.add(t.id);
    }
    for (const c of CANNABINOIDS) {
      nodes.push({ id: c, label: c, kind: "cannabinoid" });
      nodeIds.add(c);
    }
    for (const [id, label] of Object.entries(EXTRA_AGENTS)) {
      nodes.push({ id, label, kind: "cannabinoid" });
      nodeIds.add(id);
    }
    const links: GLink[] = [];
    const partnerToId: Record<string, string> = {
      THC: "THC", CBD: "CBD", CBG: "CBG", BCP: "bcp",
      "2-AG": "2-AG", CP_55940: "CP_55940", morphine: "morphine",
      CB1_orthosteric: "THC",
    };
    for (const t of TERPENES) {
      for (const s of t.synergy ?? []) {
        // partner can be a cannabinoid, agent, or another terpene name
        let targetId = partnerToId[s.partner];
        if (!targetId) {
          const match = TERPENES.find(
            (x) => terpeneName(x.id).toLowerCase().includes(s.partner.toLowerCase()) || x.id === s.partner.toLowerCase(),
          );
          targetId = match?.id ?? "";
        }
        if (targetId && nodeIds.has(targetId) && targetId !== t.id) {
          links.push({
            source: t.id,
            target: targetId,
            type: s.interaction_type,
            mechanism: s.mechanism,
            reference: s.reference,
            url: s.url,
          });
        }
      }
    }
    return { nodes, links };
  }, []);

  const simRef = useRef<Simulation<GNode, undefined> | null>(null);
  useEffect(() => {
    const sim = forceSimulation(nodes)
      .force("charge", forceManyBody().strength(-220))
      .force("link", forceLink(links).id((d: any) => d.id).distance(90).strength(0.4))
      .force("center", forceCenter(W / 2, H / 2))
      .force("collide", forceCollide(26))
      .on("tick", () => force((n) => n + 1));
    simRef.current = sim;
    return () => { sim.stop(); };
  }, [nodes, links]);

  const visibleLinks = links.filter((l) => activeTypes.has(bucket(l.type)));
  const neighborIds = useMemo(() => {
    if (!selected) return new Set<string>();
    const s = new Set<string>([selected]);
    for (const l of visibleLinks) {
      const sid = (l.source as GNode).id, tid = (l.target as GNode).id;
      if (sid === selected) s.add(tid);
      if (tid === selected) s.add(sid);
    }
    return s;
  }, [selected, visibleLinks]);

  const selectedTerpene = selected && TERPENES.find((t) => t.id === selected);
  const selectedLinks = visibleLinks.filter(
    (l) => (l.source as GNode).id === selected || (l.target as GNode).id === selected,
  );

  const toggleType = (t: string) =>
    setActiveTypes((s) => {
      const n = new Set(s);
      n.has(t) ? n.delete(t) : n.add(t);
      return n;
    });

  return (
    <div className="p-4 md:p-6">
      <header className="mb-5">
        <h1 className="font-serif text-2xl font-semibold text-foreground tracking-tight">Entourage Graph</h1>
        <p className="text-xs text-muted-foreground font-serif italic mt-0.5">
          Force-directed synergy network · 17 terpenes + 3 cannabinoid virtual nodes · {links.length} synergy edges.
        </p>
      </header>

      {/* filter legend */}
      <div className="flex flex-wrap gap-2 mb-3">
        {TYPES.map((t) => (
          <button
            key={t}
            onClick={() => toggleType(t)}
            className={`flex items-center gap-1.5 border px-2 py-1 font-mono text-[10px] ${activeTypes.has(t) ? "border-border text-foreground" : "border-border/40 text-muted-foreground/50"}`}
            data-testid={`filter-${t}`}
          >
            <span className="h-2 w-2 rounded-full" style={{ background: TYPE_COLOR[t] }} />
            {t}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-6">
        <div className="border border-border bg-card overflow-hidden">
          <svg ref={svgRef} viewBox={`0 0 ${W} ${H}`} className="w-full" style={{ aspectRatio: `${W}/${H}` }} data-testid="entourage-svg">
            {visibleLinks.map((l, i) => {
              const s = l.source as GNode, t = l.target as GNode;
              const dim = selected && !(neighborIds.has(s.id) && neighborIds.has(t.id));
              return (
                <line
                  key={i}
                  x1={s.x} y1={s.y} x2={t.x} y2={t.y}
                  stroke={TYPE_COLOR[l.type] ?? "hsl(213 10% 45%)"}
                  strokeWidth={selected && neighborIds.has(s.id) && neighborIds.has(t.id) ? 2 : 1}
                  opacity={dim ? 0.08 : 0.6}
                />
              );
            })}
            {nodes.map((n) => {
              const dim = selected && !neighborIds.has(n.id);
              const isCanna = n.kind === "cannabinoid";
              return (
                <g
                  key={n.id}
                  transform={`translate(${n.x ?? W / 2},${n.y ?? H / 2})`}
                  onClick={() => setSelected(n.id === selected ? null : n.id)}
                  style={{ cursor: "pointer", opacity: dim ? 0.2 : 1 }}
                  data-testid={`node-${n.id}`}
                >
                  <circle
                    r={isCanna ? 9 : 7}
                    fill={isCanna ? "hsl(5 52% 38%)" : "hsl(207 17% 14%)"}
                    stroke={n.id === selected ? "hsl(168 34% 56%)" : isCanna ? "hsl(5 55% 50%)" : "hsl(200 22% 30%)"}
                    strokeWidth={n.id === selected ? 2 : 1}
                  />
                  <text x={11} y={4} fontSize={10} fontFamily="Spectral, serif" fill="hsl(41 47% 78%)">
                    {n.label}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* side card */}
        <div className="min-w-0">
          <SectionLabel>NODE METADATA</SectionLabel>
          {!selected ? (
            <p className="font-serif italic text-sm text-muted-foreground">Click a node to inspect its synergy edges and metadata.</p>
          ) : (
            <div className="border border-border bg-card">
              <div className="px-3 py-2 border-b border-border flex items-center justify-between">
                <span className="font-serif text-[16px] text-foreground">{nodes.find((n) => n.id === selected)?.label}</span>
                {selectedTerpene && (
                  <button
                    onClick={() => addTerpene(selected)}
                    className="font-mono text-[10px] border border-primary/50 text-primary px-1.5 py-0.5"
                    data-testid="button-graph-add"
                  >
                    + blend
                  </button>
                )}
              </div>
              {selectedTerpene && (
                <p className="px-3 py-1.5 font-mono text-[10px] text-muted-foreground border-b border-border">
                  {selectedTerpene.identity.formula} · {selectedTerpene.identity.class}
                </p>
              )}
              <div className="px-3 py-2 space-y-2 max-h-[50vh] overflow-y-auto">
                <p className="nav-label">{selectedLinks.length} EDGES</p>
                {selectedLinks.map((l, i) => {
                  const other = (l.source as GNode).id === selected ? (l.target as GNode) : (l.source as GNode);
                  return (
                    <div key={i} className="border-b border-border/50 pb-1.5">
                      <div className="flex items-center gap-1.5">
                        <span className="h-2 w-2 rounded-full" style={{ background: TYPE_COLOR[l.type] }} />
                        <span className="font-serif text-[12px] text-foreground">{other.label}</span>
                        <span className="font-mono text-[9px] text-muted-foreground">{l.type}</span>
                      </div>
                      <p className="font-serif text-[11px] text-muted-foreground leading-snug mt-0.5">{l.mechanism}</p>
                      {l.url && <CitationPill url={l.url} reference={l.reference} />}
                    </div>
                  );
                })}
                {selectedLinks.length === 0 && (
                  <p className="font-serif italic text-[12px] text-muted-foreground">No visible synergy edges (check filters).</p>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
