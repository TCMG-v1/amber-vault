import { useMemo } from "react";
import { useBlend } from "@/lib/blend-context";
import { computeAxes, radarData, AXES, FiredReceptor } from "@/lib/score";
import { SectionLabel, TierBadge, Val } from "@/components/archive-bits";
import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  ResponsiveContainer,
} from "recharts";

export default function Scoreboard() {
  const { blend } = useBlend();
  const { fired, axisScores, allergenBurden } = useMemo(() => computeAxes(blend), [blend]);
  const { data } = useMemo(() => radarData(blend), [blend]);

  // group fired by axis
  const byAxis = useMemo(() => {
    const m: Record<string, FiredReceptor[]> = {};
    for (const f of fired) (m[f.axisKey] ??= []).push(f);
    return m;
  }, [fired]);

  const empty = blend.length === 0;

  return (
    <div className="p-4 md:p-6">
      <header className="mb-5">
        <h1 className="font-serif text-2xl font-semibold text-foreground tracking-tight">Receptor Scoreboard</h1>
        <p className="text-xs text-muted-foreground font-serif italic mt-0.5">
          Mechanism-axis projection · Σ (mass_fraction × tier_weight × confidence_weight) per axis.
        </p>
      </header>

      {empty ? (
        <div className="border border-dashed border-border p-8 text-center font-serif italic text-muted-foreground">
          Compose a blend on the Mixing Board to project mechanism axes.
        </div>
      ) : (
        <div className="grid grid-cols-1 xl:grid-cols-[1fr_1fr] gap-6">
          {/* Radar */}
          <section>
            <SectionLabel>MECHANISM RADAR · 11 axes</SectionLabel>
            <div className="border border-border bg-card p-2 radar-phosphor" style={{ height: 420 }}>
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={data} outerRadius="72%">
                  <PolarGrid stroke="hsl(210 14% 22%)" />
                  <PolarAngleAxis
                    dataKey="axis"
                    tick={{ fill: "hsl(39 30% 70%)", fontSize: 9, fontFamily: "JetBrains Mono" }}
                  />
                  <PolarRadiusAxis domain={[0, 100]} tick={false} axisLine={false} />
                  <Radar
                    dataKey="value"
                    stroke="hsl(45 65% 56%)"
                    fill="hsl(4 60% 50%)"
                    fillOpacity={0.30}
                    strokeWidth={1.5}
                    isAnimationActive={false}
                  />
                </RadarChart>
              </ResponsiveContainer>
            </div>
            <div className="mt-2 grid grid-cols-2 gap-x-4 gap-y-1">
              {AXES.map((ax) => (
                <div key={ax.key} className="flex items-center justify-between text-[11px] border-b border-border/40 py-0.5">
                  <span className="font-mono text-muted-foreground">{ax.label}</span>
                  <Val value={axisScores[ax.key].toFixed(3)} className="text-foreground/85" />
                </div>
              ))}
              <div className="flex items-center justify-between text-[11px] py-0.5 col-span-2 mt-1">
                <span className="font-mono seal-red">raw allergen burden</span>
                <Val value={(allergenBurden * 100).toFixed(3)} unit="%·frac" className="seal-red" />
              </div>
            </div>
          </section>

          {/* Detailed numeric table per axis */}
          <section>
            <SectionLabel>RECEPTORS FIRED · per axis</SectionLabel>
            <div className="space-y-3 max-h-[560px] overflow-y-auto pr-1">
              {AXES.filter((a) => !a.invert).map((ax) => {
                const rows = byAxis[ax.key] ?? [];
                if (rows.length === 0) return null;
                return (
                  <div key={ax.key} className="border border-border bg-card">
                    <div className="flex items-center justify-between px-2 py-1 border-b border-border bg-secondary/30">
                      <span className="font-mono text-[10px] uppercase tracking-wider text-foreground">{ax.label}</span>
                      <Val value={axisScores[ax.key].toFixed(3)} className="text-primary" />
                    </div>
                    <table className="w-full text-[11px]">
                      <tbody className="divide-y divide-border/50">
                        {rows.map((r, i) => (
                          <tr key={i} data-testid={`axisrow-${ax.key}-${r.receptorId}-${r.terpeneId}`}>
                            <td className="px-2 py-1 font-mono text-foreground/90 w-20">{r.receptorId}</td>
                            <td className="px-2 py-1 font-serif text-foreground/75">{r.terpeneName}</td>
                            <td className="px-2 py-1"><TierBadge tier={r.tier} /></td>
                            <td className="px-2 py-1 font-mono text-[9px] text-muted-foreground">{r.confidence}</td>
                            <td className="px-2 py-1 text-right"><Val value={r.contribution.toFixed(3)} /></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                );
              })}
            </div>
          </section>
        </div>
      )}
    </div>
  );
}
