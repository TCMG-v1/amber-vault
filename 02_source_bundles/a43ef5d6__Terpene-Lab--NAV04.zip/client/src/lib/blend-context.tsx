import { createContext, useContext, useState, useCallback, ReactNode } from "react";
import type { Blend, Component } from "@/lib/score";

export interface SealedEntry {
  hash: string;
  blend: Blend;
  sealedAt: string;
}

interface BlendCtx {
  blend: Blend;
  addTerpene: (id: string, pct?: number) => void;
  removeTerpene: (id: string) => void;
  setPct: (id: string, pct: number) => void;
  clear: () => void;
  loadBlend: (ids: string[]) => void;
  has: (id: string) => boolean;
  sealed: SealedEntry | null;
  setSealed: (s: SealedEntry | null) => void;
}

const Ctx = createContext<BlendCtx | null>(null);

export function BlendProvider({ children }: { children: ReactNode }) {
  const [blend, setBlend] = useState<Blend>([]);
  const [sealed, setSealed] = useState<SealedEntry | null>(null);

  const addTerpene = useCallback((id: string, pct = 0.25) => {
    setBlend((b) => (b.some((c) => c.id === id) ? b : [...b, { id, pct }]));
    setSealed(null);
  }, []);

  const removeTerpene = useCallback((id: string) => {
    setBlend((b) => b.filter((c) => c.id !== id));
    setSealed(null);
  }, []);

  const setPct = useCallback((id: string, pct: number) => {
    setBlend((b) => b.map((c) => (c.id === id ? { ...c, pct } : c)));
    setSealed(null);
  }, []);

  const clear = useCallback(() => {
    setBlend([]);
    setSealed(null);
  }, []);

  const loadBlend = useCallback((ids: string[]) => {
    const even = ids.length > 0 ? 1 / ids.length : 0;
    setBlend(ids.map((id) => ({ id, pct: even })));
    setSealed(null);
  }, []);

  const has = useCallback((id: string) => blend.some((c) => c.id === id), [blend]);

  return (
    <Ctx.Provider
      value={{ blend, addTerpene, removeTerpene, setPct, clear, loadBlend, has, sealed, setSealed }}
    >
      {children}
    </Ctx.Provider>
  );
}

export function useBlend() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useBlend must be used within BlendProvider");
  return c;
}
