// ─────────────────────────────────────────────────────────────────────────────
// score.ts — Terpene Codex scoring engine (pure functions)
//
// All scoring is derived directly from the philological codex (terpenes.ts).
// Tier weights:  H = 1.0, R = 0.6, IV = 0.3
// Confidence:    strong = 1.0, moderate = 0.7, weak = 0.4, contested = 0.2, rejected = 0
//
// Unit-test examples (commented):
//   tierWeight('H') === 1.0
//   confWeight('moderate') === 0.7
//   normalize([{id:'a',pct:0.7},{id:'b',pct:0.7}])  -> each 0.5  (sum 1.0)
//   axisScore for a single-component blend of bcp on 'CB1/CB2' is > 0
// ─────────────────────────────────────────────────────────────────────────────

import { terpeneDB } from "@/data/terpenes";

export type TierKey = "H" | "R" | "IV";
export type ConfKey = "strong" | "moderate" | "weak" | "contested" | "rejected";

export const TIER_WEIGHT: Record<string, number> = { H: 1.0, R: 0.6, IV: 0.3 };
export const CONF_WEIGHT: Record<string, number> = {
  strong: 1.0,
  moderate: 0.7,
  weak: 0.4,
  contested: 0.2,
  rejected: 0.0,
};

export const tierWeight = (t?: string | null) => (t ? TIER_WEIGHT[t] ?? 0 : 0);
export const confWeight = (c?: string | null) => (c ? CONF_WEIGHT[c] ?? 0 : 0);

// ── Types mirrored from the codex JSON ───────────────────────────────────────
export interface Interaction {
  id: number;
  terpene_id: string;
  receptor_id: string;
  action: string;
  binding_mode?: string | null;
  affinity_type?: string | null;
  affinity_value?: number | null;
  affinity_unit?: string | null;
  efficacy_pct?: number | null;
  tier: string;
  confidence: string;
  notes?: string | null;
  reference?: string | null;
  url?: string | null;
}
export interface AllergicReaction {
  id: number;
  terpene_id: string;
  reaction_type: string;
  trigger_form: string;
  population: string;
  rate_pct: number | null;
  regulatory: string;
  threshold: string;
  notes: string;
  reference: string;
  url: string;
}
export interface SynergyRow {
  id: number;
  terpene_id: string;
  partner: string;
  partner_class: string;
  interaction_type: string;
  mechanism: string;
  assay?: string;
  quantitative_result?: string;
  confidence: string;
  tier: string;
  reference?: string;
  url?: string;
}
export interface Terpene {
  id: string;
  identity: any;
  interactions: Interaction[];
  effects: any[];
  pharmacokinetics: any[];
  metabolism: any[];
  safety: any[];
  synergy: SynergyRow[];
  evidence_gaps: any[];
  allergic_reactions: AllergicReaction[];
  clinical_trials: any[];
}
export interface Receptor {
  id: string;
  name: string;
  family: string;
  location: string;
  pathway: string;
}
export interface ConditionTarget {
  id: number;
  condition: string;
  receptor_id: string;
  rationale: string;
  priority: number;
}

export const TERPENES = terpeneDB.terpenes as unknown as Terpene[];
export const RECEPTORS = terpeneDB.receptors as unknown as Receptor[];
export const CONDITION_TARGETS = terpeneDB.condition_targets as unknown as ConditionTarget[];
export const EVIDENCE_TIERS = terpeneDB.evidence_tiers as Record<string, string>;
export const SCHEMA_VERSION = terpeneDB.schema_version as string;
export const COMPILED = terpeneDB.compiled as string;

export const TERPENE_BY_ID: Record<string, Terpene> = Object.fromEntries(
  TERPENES.map((t) => [t.id, t]),
);
export const RECEPTOR_BY_ID: Record<string, Receptor> = Object.fromEntries(
  RECEPTORS.map((r) => [r.id, r]),
);

export const terpeneName = (id: string) =>
  TERPENE_BY_ID[id]?.identity?.name ?? id;
export const receptorName = (id: string) => RECEPTOR_BY_ID[id]?.name ?? id;

// ── Blend representation ──────────────────────────────────────────────────────
export interface Component {
  id: string; // terpene id
  pct: number; // mass fraction 0..1 (un-normalized weight; UI manages display %)
}
export type Blend = Component[];

/** Sum of weights. */
export const blendTotal = (b: Blend) => b.reduce((s, c) => s + c.pct, 0);

/** Returns components with mass fraction renormalised to sum 1.0. */
export function normalize(b: Blend): { id: string; frac: number }[] {
  const tot = blendTotal(b);
  if (tot <= 0) return b.map((c) => ({ id: c.id, frac: 0 }));
  return b.map((c) => ({ id: c.id, frac: c.pct / tot }));
}

// ── Axis → receptor mapping (from the codex receptor ids) ─────────────────────
// Note: ht1a_5 in the spec maps to the codex id `5ht1a`; gly_alpha3 is not a
// codex node so it simply never fires.
export const AXES: { key: string; label: string; receptors: string[]; invert?: boolean }[] = [
  { key: "mast", label: "Mast cell", receptors: ["fceri", "bhex", "mrgprx2", "cav32_pruritus", "tryptase"] },
  { key: "th2", label: "Th2 / IgE", receptors: ["il4r", "il5", "il13", "ige"] },
  { key: "nlrp3", label: "NLRP3 / Inflammasome", receptors: ["nlrp3", "casp1", "il1b"] },
  { key: "jakstat", label: "JAK / STAT", receptors: ["jak1", "jak2", "jak3", "stat3", "stat6"] },
  { key: "th17", label: "Th17 / Treg", receptors: ["rorgt", "foxp3", "il17a"] },
  { key: "nfkb", label: "NF-κB", receptors: ["nfkb", "inos", "cox2"] },
  { key: "trp", label: "TRP / Pain", receptors: ["trpv1", "trpa1", "trpm8", "mu_opioid", "gly_alpha3", "a2a"] },
  { key: "gaba", label: "GABA / Anxiety", receptors: ["gaba_a", "5ht1a"] },
  { key: "cb", label: "CB1 / CB2", receptors: ["cb1", "cb2"] },
  { key: "ache", label: "AChE / Cognition", receptors: ["ache"] },
  { key: "allergen", label: "Allergen burden (inv)", receptors: [], invert: true },
];

const RECEPTOR_TO_AXIS: Record<string, string> = {};
for (const ax of AXES) for (const r of ax.receptors) RECEPTOR_TO_AXIS[r] = ax.key;

export interface FiredReceptor {
  receptorId: string;
  receptorName: string;
  terpeneId: string;
  terpeneName: string;
  frac: number;
  tier: string;
  confidence: string;
  action: string;
  contribution: number; // frac * tierW * confW
  axisKey: string;
}

/** Compute the raw (un-normalised-to-radar) contribution per axis + the fired list. */
export function computeAxes(blend: Blend): {
  axisScores: Record<string, number>;
  fired: FiredReceptor[];
  allergenBurden: number;
} {
  const norm = normalize(blend);
  const fracById: Record<string, number> = Object.fromEntries(norm.map((n) => [n.id, n.frac]));
  const axisScores: Record<string, number> = {};
  for (const ax of AXES) axisScores[ax.key] = 0;
  const fired: FiredReceptor[] = [];

  for (const { id, frac } of norm) {
    if (frac <= 0) continue;
    const terp = TERPENE_BY_ID[id];
    if (!terp) continue;
    for (const it of terp.interactions) {
      const axisKey = RECEPTOR_TO_AXIS[it.receptor_id];
      if (!axisKey) continue;
      const contribution = frac * tierWeight(it.tier) * confWeight(it.confidence);
      if (contribution <= 0) continue;
      axisScores[axisKey] += contribution;
      fired.push({
        receptorId: it.receptor_id,
        receptorName: receptorName(it.receptor_id),
        terpeneId: id,
        terpeneName: terpeneName(id),
        frac,
        tier: it.tier,
        confidence: it.confidence,
        action: it.action,
        contribution,
        axisKey,
      });
    }
  }

  // Allergen burden = Σ (rate_pct/100 × mass_fraction). Higher burden -> lower score.
  let allergenBurden = 0;
  for (const { id, frac } of norm) {
    const terp = TERPENE_BY_ID[id];
    if (!terp) continue;
    for (const ar of terp.allergic_reactions ?? []) {
      if (typeof ar.rate_pct === "number") allergenBurden += (ar.rate_pct / 100) * frac;
    }
  }
  // Inverted axis: 1 - burden scaled. Max plausible burden ~0.07; scale x for visibility.
  axisScores["allergen"] = Math.max(0, 1 - allergenBurden * 8);

  fired.sort((a, b) => b.contribution - a.contribution);
  return { axisScores, fired, allergenBurden };
}

/** Radar-ready data: each axis scaled 0..100 for charting (allergen already 0..1). */
export function radarData(blend: Blend) {
  const { axisScores, allergenBurden } = computeAxes(blend);
  // Find max non-allergen axis for relative scaling, with a sane floor.
  const dyn = AXES.filter((a) => !a.invert).map((a) => axisScores[a.key]);
  const max = Math.max(0.001, ...dyn);
  return {
    data: AXES.map((ax) => ({
      axis: ax.label,
      key: ax.key,
      value: ax.invert
        ? Math.round(axisScores[ax.key] * 100)
        : Math.round((axisScores[ax.key] / max) * 100),
      raw: axisScores[ax.key],
    })),
    allergenBurden,
  };
}

// ── Haskell-ish blend signature ──────────────────────────────────────────────
const HS_NAME: Record<string, string> = {
  linalool: "Linalool", limonene: "Limonene", myrcene: "Myrcene",
  alpha_pinene: "APinene", beta_pinene: "BPinene", bcp: "BCP",
  humulene: "Humulene", terpinolene: "Terpinolene", bisabolol: "Bisabolol",
  geraniol: "Geraniol", camphene: "Camphene", terpineol: "Terpineol",
  ocimene: "Ocimene", nerolidol: "Nerolidol", guaiol: "Guaiol",
  phytol: "Phytol", cineole: "Cineole",
};
export const hsName = (id: string) => HS_NAME[id] ?? id;

export function haskellSignature(blend: Blend): string {
  const norm = normalize(blend);
  if (norm.length === 0) return "blend :: Blend = Blend []  -- empty";
  const lines = norm.map(
    (c, i) =>
      `  ${i === 0 ? "[" : ","} Component ${hsName(c.id)} ${c.frac.toFixed(2)}`,
  );
  return `blend :: Blend = Blend\n${lines.join("\n")}\n  ]`;
}

// ── Allergen / safety lint ────────────────────────────────────────────────────
export interface LintWarning {
  terpeneId: string;
  severity: "high" | "moderate" | "low";
  message: string;
  reference?: string;
  url?: string;
}

// Curated, data-backed lint strings keyed off the codex allergic_reactions.
export function lintBlend(blend: Blend): LintWarning[] {
  const warnings: LintWarning[] = [];
  const norm = normalize(blend);
  const fracById: Record<string, number> = Object.fromEntries(norm.map((n) => [n.id, n.frac]));
  for (const { id, frac } of norm) {
    if (frac <= 0) continue;
    const terp = TERPENE_BY_ID[id];
    if (!terp) continue;
    for (const ar of terp.allergic_reactions ?? []) {
      let severity: LintWarning["severity"] = "low";
      if (ar.regulatory === "EU_mandatory_allergen") severity = "high";
      else if (ar.regulatory === "IFRA_restricted") severity = "moderate";
      else if (ar.reaction_type === "irritant") severity = "high";
      const ratePart = typeof ar.rate_pct === "number" ? ` (${ar.rate_pct}% patch positivity)` : "";
      let msg = `${terpeneName(id)}: ${ar.notes}${ratePart}`;
      if (ar.regulatory === "EU_mandatory_allergen")
        msg = `${terpeneName(id)} — EU mandatory allergen label required${ar.threshold !== "—" ? ` (${ar.threshold})` : ""}. ${ar.notes}${ratePart}`;
      warnings.push({ terpeneId: id, severity, message: msg, reference: ar.reference, url: ar.url });
    }
  }
  const order = { high: 0, moderate: 1, low: 2 };
  warnings.sort((a, b) => order[a.severity] - order[b.severity]);
  return warnings;
}

// ── Condition prescriber ──────────────────────────────────────────────────────
export const CONDITIONS = Array.from(new Set(CONDITION_TARGETS.map((c) => c.condition))).sort();

export interface ConditionTargetInfo {
  receptorId: string;
  priority: number;
  rationale: string;
}
export function conditionTargets(cond: string): ConditionTargetInfo[] {
  return CONDITION_TARGETS.filter((c) => c.condition === cond).map((c) => ({
    receptorId: c.receptor_id,
    priority: c.priority,
    rationale: c.rationale,
  }));
}

/** The set of receptor ids a terpene meaningfully engages (tier×conf weighted). */
export function terpeneTargets(id: string): Map<string, number> {
  const m = new Map<string, number>();
  const terp = TERPENE_BY_ID[id];
  if (!terp) return m;
  for (const it of terp.interactions) {
    const w = tierWeight(it.tier) * confWeight(it.confidence);
    if (w <= 0) continue;
    m.set(it.receptor_id, Math.max(m.get(it.receptor_id) ?? 0, w));
  }
  return m;
}

export interface RankedTerpene {
  id: string;
  name: string;
  score: number;
  hits: { receptorId: string; priority: number; weight: number }[];
}

/** Rank single terpenes for a condition; priority-1 receptors weighted higher. */
export function rankTerpenesForCondition(cond: string): RankedTerpene[] {
  const targets = conditionTargets(cond);
  const out: RankedTerpene[] = [];
  for (const t of TERPENES) {
    const tt = terpeneTargets(t.id);
    let score = 0;
    const hits: RankedTerpene["hits"] = [];
    for (const tgt of targets) {
      const w = tt.get(tgt.receptorId);
      if (w && w > 0) {
        const priW = tgt.priority === 1 ? 3 : tgt.priority === 2 ? 1.5 : 1;
        score += w * priW;
        hits.push({ receptorId: tgt.receptorId, priority: tgt.priority, weight: w });
      }
    }
    if (score > 0) out.push({ id: t.id, name: terpeneName(t.id), score, hits });
  }
  out.sort((a, b) => b.score - a.score);
  return out;
}

/** Jaccard distance over target receptor sets. */
function jaccardDistance(a: Set<string>, b: Set<string>): number {
  const inter = Array.from(a).filter((x) => b.has(x)).length;
  const uni = new Set([...Array.from(a), ...Array.from(b)]).size;
  if (uni === 0) return 1;
  return 1 - inter / uni;
}

export interface ComboSuggestion {
  ids: string[];
  names: string[];
  score: number;
  minDistance: number;
}

/** Top combos (2–3 terpenes) with maximally disjoint mechanisms (Jaccard ≥ 0.5). */
export function suggestCombos(cond: string, limit = 3): ComboSuggestion[] {
  const ranked = rankTerpenesForCondition(cond).slice(0, 8);
  const sets: Record<string, Set<string>> = {};
  for (const r of ranked) sets[r.id] = new Set(Array.from(terpeneTargets(r.id).keys()));
  const scoreById: Record<string, number> = Object.fromEntries(ranked.map((r) => [r.id, r.score]));
  const combos: ComboSuggestion[] = [];

  const ids = ranked.map((r) => r.id);
  // pairs
  for (let i = 0; i < ids.length; i++)
    for (let j = i + 1; j < ids.length; j++) {
      const d = jaccardDistance(sets[ids[i]], sets[ids[j]]);
      if (d >= 0.5) {
        combos.push({
          ids: [ids[i], ids[j]],
          names: [terpeneName(ids[i]), terpeneName(ids[j])],
          score: scoreById[ids[i]] + scoreById[ids[j]],
          minDistance: d,
        });
      }
    }
  // triples
  for (let i = 0; i < ids.length; i++)
    for (let j = i + 1; j < ids.length; j++)
      for (let k = j + 1; k < ids.length; k++) {
        const d1 = jaccardDistance(sets[ids[i]], sets[ids[j]]);
        const d2 = jaccardDistance(sets[ids[i]], sets[ids[k]]);
        const d3 = jaccardDistance(sets[ids[j]], sets[ids[k]]);
        const minD = Math.min(d1, d2, d3);
        if (minD >= 0.5) {
          combos.push({
            ids: [ids[i], ids[j], ids[k]],
            names: [ids[i], ids[j], ids[k]].map(terpeneName),
            score: scoreById[ids[i]] + scoreById[ids[j]] + scoreById[ids[k]],
            minDistance: minD,
          });
        }
      }
  combos.sort((a, b) => b.score + b.minDistance - (a.score + a.minDistance));
  // dedupe by id-set string, keep best
  const seen = new Set<string>();
  const uniq: ComboSuggestion[] = [];
  for (const c of combos) {
    const key = [...c.ids].sort().join("|");
    if (seen.has(key)) continue;
    seen.add(key);
    uniq.push(c);
    if (uniq.length >= limit) break;
  }
  return uniq;
}

// ── Reverse-design greedy set cover ───────────────────────────────────────────
export interface CoverStep {
  terpeneId: string;
  terpeneName: string;
  covered: string[]; // newly covered receptor ids
  weightSum: number;
}
export interface CoverResult {
  steps: CoverStep[];
  coveredAll: boolean;
  uncovered: string[];
}

export function greedySetCover(targets: string[]): CoverResult {
  const targetSet = new Set(targets);
  const remaining = new Set(targets);
  const steps: CoverStep[] = [];
  const used = new Set<string>();

  while (remaining.size > 0) {
    let best: { id: string; covered: string[]; weight: number } | null = null;
    for (const t of TERPENES) {
      if (used.has(t.id)) continue;
      const tt = terpeneTargets(t.id);
      const covered: string[] = [];
      let weight = 0;
      for (const r of Array.from(remaining)) {
        const w = tt.get(r);
        if (w && w > 0) {
          covered.push(r);
          weight += w;
        }
      }
      if (covered.length === 0) continue;
      // maximise (# newly covered) then tier×conf weight
      if (
        !best ||
        covered.length > best.covered.length ||
        (covered.length === best.covered.length && weight > best.weight)
      ) {
        best = { id: t.id, covered, weight };
      }
    }
    if (!best) break; // no progress
    used.add(best.id);
    steps.push({
      terpeneId: best.id,
      terpeneName: terpeneName(best.id),
      covered: best.covered,
      weightSum: best.weight,
    });
    for (const r of best.covered) remaining.delete(r);
  }
  return {
    steps,
    coveredAll: remaining.size === 0 && targetSet.size > 0,
    uncovered: Array.from(remaining),
  };
}

// ── Sealed-blend hashing ──────────────────────────────────────────────────────
export function sealHash(blend: Blend): string {
  const norm = normalize(blend);
  const str = norm.map((c) => `${c.id}:${c.frac.toFixed(4)}`).join("|") + COMPILED;
  let h = 0x811c9dc5;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  // 6-hex
  return h.toString(16).padStart(8, "0").slice(0, 6).toUpperCase();
}

// ── Unit formatting helper ────────────────────────────────────────────────────
export const pct = (frac: number) => `${(frac * 100).toFixed(1)}%`;
