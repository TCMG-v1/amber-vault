import { AlertTriangle } from "lucide-react";
import type { LintWarning } from "@/lib/score";

// Tier badge — H gold, R teal, IV slate
export function TierBadge({ tier }: { tier: string }) {
  const cls =
    tier === "H" ? "tier-H" : tier === "R" ? "tier-R" : "tier-IV";
  return (
    <span
      className={`inline-block font-mono text-[10px] leading-none px-1 py-0.5 border ${cls}`}
      data-testid={`badge-tier-${tier}`}
    >
      {tier}
    </span>
  );
}

const CONF_COLOR: Record<string, string> = {
  strong: "codex-teal",
  moderate: "amber-alarm",
  weak: "text-muted-foreground",
  contested: "amber-alarm",
  rejected: "seal-red",
};

export function ConfBadge({ confidence }: { confidence: string }) {
  return (
    <span className={`font-mono text-[10px] uppercase tracking-wider ${CONF_COLOR[confidence] ?? "text-muted-foreground"}`}>
      {confidence}
    </span>
  );
}

// Citation pill: [arch://pubmed/12645832]
export function CitationPill({ url, reference }: { url?: string | null; reference?: string | null }) {
  if (!url) {
    return reference ? (
      <span className="font-mono text-[10px] text-muted-foreground">[arch://{reference}]</span>
    ) : null;
  }
  let token = url;
  const m = url.match(/pubmed\.ncbi\.nlm\.nih\.gov\/(\d+)/);
  const pmc = url.match(/PMC(\d+)/);
  const pat = url.match(/patents\.google\.com\/patent\/([A-Z0-9]+)/);
  if (m) token = `pubmed/${m[1]}`;
  else if (pmc) token = `pmc/${pmc[1]}`;
  else if (pat) token = `patent/${pat[1]}`;
  else token = (reference ?? "ref").replace(/\s+/g, "_").toLowerCase();
  return (
    <a
      href={url}
      target="_blank"
      rel="noreferrer"
      className="font-mono text-[10px] text-muted-foreground hover:text-primary underline-offset-2 hover:underline"
      data-testid="link-citation"
    >
      [arch://{token}]
    </a>
  );
}

// Numeric value with tiny mono unit, e.g. 155 nM
export function Val({ value, unit, className = "" }: { value: number | string; unit?: string; className?: string }) {
  return (
    <span className={`font-mono tabular-nums ${className}`}>
      {value}
      {unit ? <span className="text-[10px] text-muted-foreground ml-0.5">{unit}</span> : null}
    </span>
  );
}

// Section label: § MIXING BOARD
export function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="nav-label flex items-center gap-2 mb-2">
      <span className="text-primary">§</span>
      <span>{children}</span>
    </div>
  );
}

// Wax seal SVG with hash
export function WaxSeal({ hash, size = 96 }: { hash: string; size?: number }) {
  return (
    <div className="flex flex-col items-center gap-1">
      <svg width={size} height={size} viewBox="0 0 100 100" aria-label={`Seal ${hash}`}>
        <circle cx="50" cy="50" r="44" fill="hsl(5 52% 32%)" stroke="hsl(5 52% 24%)" strokeWidth="2" />
        <circle cx="50" cy="50" r="38" fill="none" stroke="hsl(5 40% 46%)" strokeWidth="1" strokeDasharray="2 3" />
        <circle cx="50" cy="50" r="30" fill="hsl(5 55% 38%)" stroke="hsl(5 50% 28%)" strokeWidth="1.5" />
        {Array.from({ length: 16 }).map((_, i) => {
          const a = (i / 16) * Math.PI * 2;
          return (
            <line
              key={i}
              x1={50 + Math.cos(a) * 44}
              y1={50 + Math.sin(a) * 44}
              x2={50 + Math.cos(a) * 40}
              y2={50 + Math.sin(a) * 40}
              stroke="hsl(5 40% 24%)"
              strokeWidth="1.5"
            />
          );
        })}
        <text x="50" y="46" textAnchor="middle" fill="hsl(41 50% 78%)" fontSize="7" fontFamily="monospace" letterSpacing="1">SEALED</text>
        <text x="50" y="58" textAnchor="middle" fill="hsl(41 55% 82%)" fontSize="11" fontFamily="monospace" fontWeight="600">{hash}</text>
      </svg>
    </div>
  );
}

// Lint warning row
export function LintRow({ w }: { w: LintWarning }) {
  const color =
    w.severity === "high" ? "seal-red" : w.severity === "moderate" ? "amber-alarm" : "text-muted-foreground";
  return (
    <div className="flex items-start gap-2 py-1.5 border-b border-border/60 last:border-0" data-testid={`lint-${w.terpeneId}`}>
      <AlertTriangle className={`h-3 w-3 mt-0.5 shrink-0 ${color}`} />
      <div className="min-w-0 flex-1">
        <p className="text-[11px] leading-snug text-foreground/90 break-words">{w.message}</p>
        {w.url ? (
          <div className="mt-0.5">
            <CitationPill url={w.url} reference={w.reference} />
          </div>
        ) : null}
      </div>
    </div>
  );
}
