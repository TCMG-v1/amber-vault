import { useBlend } from "@/lib/blend-context";
import {
  haskellSignature,
  lintBlend,
  blendTotal,
  normalize,
  sealHash,
  terpeneName,
  hsName,
} from "@/lib/score";
import { SectionLabel, WaxSeal, LintRow } from "@/components/archive-bits";
import { Button } from "@/components/ui/button";
import { X, Lock } from "lucide-react";

export function RightRailContent() {
  const { blend, removeTerpene, clear, sealed, setSealed } = useBlend();
  const total = blendTotal(blend);
  const drifted = blend.length > 0 && Math.abs(total - 1) > 0.001;
  const lint = lintBlend(blend);
  const norm = normalize(blend);

  return (
    <div className="flex flex-col gap-5 text-sm">
      {/* Current blend */}
      <section>
        <SectionLabel>CURRENT BLEND</SectionLabel>
        {blend.length === 0 ? (
          <p className="text-xs text-muted-foreground italic font-serif">
            No components sealed. Add terpenes from a bench to begin formulation.
          </p>
        ) : (
          <div className="border border-border divide-y divide-border bg-card">
            {norm.map((c) => (
              <div key={c.id} className="flex items-center justify-between px-2 py-1.5" data-testid={`rail-comp-${c.id}`}>
                <span className="font-serif text-[13px] text-foreground truncate">{terpeneName(c.id)}</span>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="font-mono text-[11px] tabular-nums text-foreground/80">
                    {(c.frac * 100).toFixed(1)}
                    <span className="text-[9px] text-muted-foreground">%</span>
                  </span>
                  <button
                    onClick={() => removeTerpene(c.id)}
                    className="text-muted-foreground hover:text-destructive"
                    aria-label={`Remove ${terpeneName(c.id)}`}
                    data-testid={`button-rail-remove-${c.id}`}
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
        {blend.length > 0 && (
          <div className="flex items-center justify-between mt-1.5">
            <span className={`font-mono text-[10px] ${drifted ? "seal-red" : "codex-teal"}`}>
              {drifted ? `⚠ Σ drift ${(total * 100).toFixed(1)}% → auto-normalised` : "Σ = 100.0% normalised"}
            </span>
            <button onClick={clear} className="font-mono text-[10px] text-muted-foreground hover:text-destructive" data-testid="button-rail-clear">
              clear
            </button>
          </div>
        )}
      </section>

      {/* Haskell signature */}
      {blend.length > 0 && (
        <section>
          <SectionLabel>BLEND SIGNATURE</SectionLabel>
          <pre className="bg-background border border-border p-2 overflow-x-auto font-mono text-[10.5px] leading-relaxed text-foreground/85">
{haskellSignature(blend)}
          </pre>
        </section>
      )}

      {/* Seal */}
      {blend.length > 0 && (
        <section>
          {sealed ? (
            <div className="flex flex-col items-center gap-2 border border-destructive/40 bg-card py-3">
              <WaxSeal hash={sealed.hash} size={84} />
              <div className="text-center">
                <p className="font-mono text-[10px] text-muted-foreground">SEALED ENTRY · {sealed.sealedAt}</p>
                <p className="font-mono text-[11px] seal-red">arch://seal/{sealed.hash}</p>
                <p className="font-mono text-[9px] text-muted-foreground mt-0.5">
                  {sealed.blend.map((c) => hsName(c.id)).join(" · ")}
                </p>
              </div>
            </div>
          ) : (
            <Button
              variant="outline"
              size="sm"
              className="w-full font-mono text-[11px] tracking-wider border-destructive/40 text-destructive hover:bg-destructive/10"
              onClick={() =>
                setSealed({
                  hash: sealHash(blend),
                  blend: norm.map((c) => ({ id: c.id, pct: c.frac })),
                  sealedAt: new Date().toISOString().slice(0, 10),
                })
              }
              data-testid="button-seal-blend"
            >
              <Lock className="h-3 w-3 mr-1.5" /> SEAL THIS BLEND
            </Button>
          )}
        </section>
      )}

      {/* Lint */}
      {lint.length > 0 && (
        <section>
          <SectionLabel>ALLERGEN · SAFETY LINT</SectionLabel>
          <div className="border border-border bg-card px-2">
            {lint.map((w, i) => (
              <LintRow key={i} w={w} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
