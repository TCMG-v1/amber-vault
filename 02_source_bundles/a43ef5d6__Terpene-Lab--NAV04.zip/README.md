# Terpene Codex — Sealed Channel · NAV Archive

An interactive chemistry set / formulation lab built over a peer-reviewed terpene
synergy database (17 terpenes · 55 receptor nodes · 106 quantitative interactions ·
6 human RCTs · 8 allergic-reaction profiles · schema_version 2.0.0). The aesthetic is
a deliberate *Sealed Channel / NAV Archive* — dark, archival, philological — treating
the database as a scientific codex with typed records visible on screen and Haskell-ish
syntax for blends.

## Stack

- **React + TypeScript** (Vite) — single-page app, hash routing via `wouter` + `useHashLocation`
- **Tailwind CSS v3** + **shadcn/ui** (template defaults; only Tailwind utility classes for layout)
- **Recharts** — mechanism-axis radar chart
- **d3-force** — lightweight force-directed entourage graph (SVG, custom renderer)
- Fonts: **Spectral** (display/headword serif), **IBM Plex Sans** (body), **IBM Plex Mono** (data/code/IPA)
- No backend persistence. All blend state lives in in-memory React context
  (`client/src/lib/blend-context.tsx`). No `localStorage` (blocked in the sandbox iframe).
- The Express server from the webapp template is retained only as a static host; the app
  makes no API calls.

## Lab benches

1. **Mixing Board** (`pages/mixing-board.tsx`) — add terpenes, per-component mass-fraction
   sliders auto-normalised to 100%, live Haskell blend signature, fired-receptor table,
   and a "Seal" action that hashes the blend into a wax-seal entry.
2. **Receptor Scoreboard** (`pages/scoreboard.tsx`) — 11-axis mechanism radar plus a
   per-axis numeric breakdown of which receptors fired from which terpenes.
3. **Condition Prescriber** (`pages/prescriber.tsx`) — top-5 single terpenes (priority-
   weighted receptor coverage) and top-3 mechanistically disjoint combos (Jaccard ≥ 0.5)
   for each condition in `condition_targets`. One-click "load into Mixing Board".
4. **Reverse-Design Bench** (`pages/reverse-design.tsx`) — pick target receptors; a greedy
   set-cover solver returns the minimal terpene set and which terpenes cover which targets.
5. **Entourage Graph** (`pages/entourage.tsx`) — force-directed synergy network: 17
   terpenes + THC/CBD/CBG virtual nodes (and extra agents that appear as synergy partners),
   edges coloured by interaction type, click-to-highlight + metadata side card.
6. **Codex / Lexemes** (`pages/codex.tsx`) — each terpene as a NAV-archive etymological
   card (headword, IPA, morphemes, etymon, semantic drift, cognate pills, mock-Haskell
   snippet, sealed line). Clicking a card cross-references it into the blend.

An **allergen + safety lint** panel is pervasive in the right rail / bottom sheet,
driven by the codex `allergic_reactions` rows (EU mandatory-allergen flags, hydroperoxide
oxidation risk, Refsum-disease contraindication, etc.).

## Data layer

The two source files are copied verbatim into the project as TypeScript modules — the app
never references files outside its own directory:

- `client/src/data/terpenes.ts` — exports `terpeneDB`, the full
  `terpenes.json` codex (terpenes, receptors, condition_targets, evidence_tiers).
- `client/src/data/lexemes.ts` — exports `lexemeData`, the 17 etymological lexeme cards.

All scoring is pure and lives in `client/src/lib/score.ts`:

- Tier weights `H=1.0, R=0.6, IV=0.3`; confidence weights
  `strong=1.0, moderate=0.7, weak=0.4, contested=0.2, rejected=0`.
- Axis → receptor mapping in `AXES` (the spec id `ht1a_5` maps to the codex node `5ht1a`).
- `computeAxes`, `radarData`, `rankTerpenesForCondition`, `suggestCombos`,
  `greedySetCover`, `haskellSignature`, `lintBlend`, `sealHash`. Unit-test examples are
  documented as comments at the top of the file.

## Run locally

```bash
npm install
npm run dev        # Express + Vite on http://localhost:5000
```

Production build / static output:

```bash
npm run build      # emits dist/public
```

## Point a custom subdomain at the deployed site

The app is deployed to a private `*.pplx.app` preview URL. To front it with your own
subdomain (e.g. `codex.yourstudio.com`):

1. In your DNS provider, create a **CNAME** record:
   - **Host / Name:** `codex` (the subdomain label)
   - **Value / Target:** the deployed `pplx.app` host (without `https://`),
     e.g. `terpene-lab.pplx.app`
   - **TTL:** default / 3600
2. Wait for propagation (usually minutes, up to ~24h).
3. If the host requires domain verification or HTTPS issuance, follow the platform's
   custom-domain instructions; the CNAME above is the routing piece.

Apex domains (`yourstudio.com` with no subdomain) cannot use CNAME — use your provider's
ALIAS/ANAME record or a `www` CNAME + redirect instead.
