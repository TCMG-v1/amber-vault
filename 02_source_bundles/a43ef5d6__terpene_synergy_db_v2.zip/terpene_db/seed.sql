-- ============================================================================
-- TERPENE SYNERGY DATABASE — Seed Data
-- ============================================================================
-- All values sourced from /home/user/workspace/terpene_research.md
-- and /home/user/workspace/terpene_synergy.md (113+19 inline citations)
-- ============================================================================

-- ---------------------------------------------------------------------------
-- TERPENES
-- ---------------------------------------------------------------------------
INSERT INTO terpenes VALUES
('linalool','Linalool',
 '(3S)-3,7-dimethylocta-1,6-dien-3-ol','78-70-6','CC(=CCC[C@@](C)(O)C=C)C',
 'C10H18O',154.25,'monoterpenol','acyclic',198.5,2.97,1.6,
 'Lavender,Coriander,Cannabis','FEMA #2635'),
('limonene','D-Limonene',
 '(R)-(+)-1-methyl-4-(prop-1-en-2-yl)cyclohex-1-ene','5989-27-5','CC(=C)C1CCC(=CC1)C',
 'C10H16',136.23,'monoterpene','monocyclic',176.0,4.57,0.01,
 'Orange peel,Lemon,Cannabis','FEMA #2633'),
('myrcene','beta-Myrcene',
 '(E)-7-methyl-3-methyleneocta-1,6-diene','123-35-3','C=CC(=C)CCC=C(C)C',
 'C10H16',136.23,'monoterpene','acyclic',167.0,4.30,0.01,
 'Cannabis,Hops,Bay leaves,Mango','FEMA #2762'),
('alpha_pinene','alpha-Pinene',
 '(1R,5R)-4,6,6-trimethylbicyclo[3.1.1]hept-3-ene','80-56-8','CC1=CCC2CC1C2(C)C',
 'C10H16',136.23,'monoterpene','bicyclic',155.0,4.44,0.001,
 'Pine resin,Cannabis,Rosemary,Fir','FEMA #2902'),
('beta_pinene','beta-Pinene',
 '(1S,5S)-6,6-dimethyl-2-methylenebicyclo[3.1.1]heptane','127-91-3','CC1(C)C2CCC(=C)C1CC2',
 'C10H16',136.23,'monoterpene','bicyclic',163.0,4.04,0.001,
 'Pine,Cannabis,Rosemary','FEMA #2903'),
('bcp','beta-Caryophyllene',
 '(1R,9S,E)-4,11,11-trimethyl-8-methylenebicyclo[7.2.0]undec-4-ene','87-44-5','CC1=CCCC(=C)C2CC(C)(C)C2CC1',
 'C15H24',204.35,'sesquiterpene','bicyclic',254.5,6.63,0.0001,
 'Black pepper,Cannabis,Clove,Copaiba','FEMA #2252');

-- ---------------------------------------------------------------------------
-- RECEPTORS / TARGETS
-- ---------------------------------------------------------------------------
INSERT INTO receptors VALUES
('cb1','Cannabinoid receptor type 1','GPCR','CNS_dominant','Gi/cAMP'),
('cb2','Cannabinoid receptor type 2','GPCR','immune_PNS','Gi/cAMP'),
('a2a','Adenosine A2A receptor','GPCR','spinal_cord,CNS,immune','Gs/cAMP'),
('a1','Adenosine A1 receptor','GPCR','CNS,heart','Gi/cAMP'),
('gaba_a','GABA-A receptor (alpha1-beta2-gamma2)','ion_channel','CNS','Cl- influx'),
('trpv1','TRPV1 / capsaicin receptor','ion_channel','PNS,DRG','Ca2+ influx'),
('trpa1','TRPA1','ion_channel','PNS,DRG','Ca2+ influx'),
('trpm8','TRPM8 / cold-menthol receptor','ion_channel','PNS','Ca2+ influx'),
('5ht1a','Serotonin 5-HT1A receptor','GPCR','CNS','Gi/cAMP'),
('ppar_alpha','PPAR-alpha','nuclear_receptor','liver,muscle,immune','transcription'),
('ppar_gamma','PPAR-gamma','nuclear_receptor','adipose,immune','transcription'),
('mu_opioid','Mu-opioid receptor','GPCR','CNS','Gi/cAMP'),
('nav','Voltage-gated Na+ channels','ion_channel','neurons','depolarization'),
('cav32','Cav3.2 T-type Ca2+ channel','ion_channel','neurons,DRG','Ca2+ influx'),
('ache','Acetylcholinesterase','enzyme','synapse,RBC','ACh hydrolysis'),
('nfkb','NF-kB','transcription_factor','immune,ubiquitous','cytokine transcription'),
('cox2','COX-2','enzyme','immune,neural','prostaglandin synthesis'),
('inos','iNOS','enzyme','immune','NO synthesis'),
('nrf2','NRF2 / HO-1 axis','transcription_factor','ubiquitous','antioxidant response'),
('alpha2','alpha-2 adrenoceptor','GPCR','CNS,PNS','Gi/cAMP');

-- ---------------------------------------------------------------------------
-- INTERACTIONS — terpene × receptor with quantitative binding/efficacy
-- ---------------------------------------------------------------------------

-- LINALOOL
INSERT INTO interactions(terpene_id,receptor_id,action,binding_mode,affinity_type,affinity_value,affinity_unit,efficacy_pct,tier,confidence,notes,reference,url) VALUES
('linalool','gaba_a','PAM','allosteric','functional',1.6,'fold_at_2mM',NULL,'IV','moderate','1.6-fold potentiation at supra-physiological 2 mM; relevance at therapeutic doses unclear','Kessler 2014 / Kamatou & Viljoen 2017','https://www.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2017.00046/full'),
('linalool','a2a','agonist','functional','functional',NULL,NULL,NULL,'R','strong','Antinociception fully blocked by istradefylline 3.2 mg/kg; spinal A2A CRISPR knockdown abolishes effect','LaVigne 2025','https://pmc.ncbi.nlm.nih.gov/articles/PMC11511650/'),
('linalool','a1','agonist','functional','functional',NULL,NULL,NULL,'R','moderate','A1 antagonist partially reverses antinociception','de Sousa 2006','https://doi.org/10.1016/j.lfs.2005.10.025'),
('linalool','nav','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','moderate','Non-selective Na+ channel suppression in olfactory neurons and Purkinje cells','Narusuye 2005','https://www.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2017.00046/full'),
('linalool','trpv1','agonist','orthosteric',NULL,NULL,NULL,NULL,'IV','weak','Low-concentration activity, weaker than myrcene','Jansen 2019','https://pmc.ncbi.nlm.nih.gov/articles/PMC6768052/'),
('linalool','5ht1a','agonist','functional',NULL,NULL,NULL,NULL,'R','weak','No direct Ki published; behavioral inference','Linck 2010','https://pmc.ncbi.nlm.nih.gov/articles/PMC3612440/'),
('linalool','nfkb','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','moderate','Reduces LPS-induced IL-1b, IL-6, TNF-a','Ahammed 2025','https://link.springer.com/10.1007/s00210-025-03984-5'),
('linalool','cox2','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','moderate','Anti-arthritic in vitro/in vivo','Ahammed 2025','https://link.springer.com/10.1007/s00210-025-03984-5'),
('linalool','cb1','partial_agonist','functional','EC50',NULL,'uM',30,'IV','moderate','~10-50% of THC cAMP efficacy at uM','Raz 2023','https://www.sciencedirect.com/science/article/pii/S0006295223001399');

-- LIMONENE
INSERT INTO interactions(terpene_id,receptor_id,action,binding_mode,affinity_type,affinity_value,affinity_unit,efficacy_pct,tier,confidence,notes,reference,url) VALUES
('limonene','5ht1a','agonist','functional',NULL,NULL,NULL,NULL,'R','moderate','Elevated DA and 5-HT in frontal cortex/hippocampus; no direct Ki','Russo 2011','https://pmc.ncbi.nlm.nih.gov/articles/PMC6239267/'),
('limonene','nfkb','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','strong','Reduces transcription; decreases IL-1b, IL-6, TNF-a, MPO','De Souza 2019','https://pubmed.ncbi.nlm.nih.gov/30668410/'),
('limonene','trpv1','agonist','orthosteric',NULL,NULL,NULL,NULL,'IV','weak','Weak high-concentration activation; EC50 not precisely defined','Jansen 2019','https://pmc.ncbi.nlm.nih.gov/articles/PMC6768052/'),
('limonene','ache','inhibitor','functional','IC50',10,'ug/mL',NULL,'IV','moderate','Moderate inhibition 10-50 ug/mL range','PMC7996600','https://pmc.ncbi.nlm.nih.gov/articles/PMC7996600/'),
('limonene','a2a','agonist','functional',NULL,NULL,NULL,NULL,'IV','moderate','In silico docking + cAMP consistent with A2A agonism','LaVigne 2025','https://pmc.ncbi.nlm.nih.gov/articles/PMC11511650/'),
('limonene','cox2','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','moderate','Reduces NO, PGE2 in macrophages','De Souza 2019','https://pubmed.ncbi.nlm.nih.gov/30668410/'),
('limonene','cb1','partial_agonist','functional','EC50',NULL,'uM',30,'IV','moderate','~10-50% THC efficacy at uM','Raz 2023','https://www.sciencedirect.com/science/article/pii/S0006295223001399');

-- MYRCENE
INSERT INTO interactions(terpene_id,receptor_id,action,binding_mode,affinity_type,affinity_value,affinity_unit,efficacy_pct,tier,confidence,notes,reference,url) VALUES
('myrcene','trpv1','agonist','orthosteric','functional',5,'uM',NULL,'IV','strong','Dominant TRPV1 activator among terpenes at 1-10 uM; triggers desensitization','Jansen 2019','https://pmc.ncbi.nlm.nih.gov/articles/PMC6768052/'),
('myrcene','cb1','no_orthosteric_binding','orthosteric','Ki',NULL,'uM',NULL,'IV','strong','Does NOT displace CP-55,940 at 10 uM; rules out direct CB1 binding','LaVigne 2025','https://pmc.ncbi.nlm.nih.gov/articles/PMC12353019/'),
('myrcene','cb1','indirect_modulator','indirect','functional',NULL,NULL,NULL,'R','strong','Enhances endocannabinoid (2-AG/AEA) tone; SR141716A blocks analgesia','LaVigne 2025','https://pmc.ncbi.nlm.nih.gov/articles/PMC12353019/'),
('myrcene','cb1','partial_agonist','functional','EC50',NULL,'uM',30,'IV','moderate','~10-50% THC efficacy at uM in HEK cAMP','Raz 2023','https://www.sciencedirect.com/science/article/pii/S0006295223001399'),
('myrcene','mu_opioid','indirect_activator','indirect',NULL,NULL,NULL,NULL,'R','moderate','Naloxone partially reverses analgesia; proposed endogenous opioid release','NIH R01-AT010762','https://grantome.com/grant/NIH/R01-AT010762-01'),
('myrcene','a2a','agonist','functional',NULL,NULL,NULL,NULL,'R','strong','Istradefylline 3.2 mg/kg blocks antinociception','LaVigne 2025','https://pmc.ncbi.nlm.nih.gov/articles/PMC11511650/'),
('myrcene','gaba_a','PAM','allosteric',NULL,NULL,NULL,NULL,'R','weak','Proposed; behavioral evidence only; not quantified','Russo 2011','https://pubmed.ncbi.nlm.nih.gov/21749363/'),
('myrcene','nfkb','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','moderate','Reduces LPS-induced cytokines','Multiple','https://pmc.ncbi.nlm.nih.gov/articles/PMC12353019/');

-- ALPHA-PINENE
INSERT INTO interactions(terpene_id,receptor_id,action,binding_mode,affinity_type,affinity_value,affinity_unit,efficacy_pct,tier,confidence,notes,reference,url) VALUES
('alpha_pinene','ache','inhibitor','functional','IC50',670,'ug/mL',NULL,'IV','moderate','IC50 0.67-2.9 mg/mL; weaker than donepezil but notable for volatile terpene','PMC7996600','https://pmc.ncbi.nlm.nih.gov/articles/PMC7996600/'),
('alpha_pinene','gaba_a','modulator','allosteric',NULL,NULL,NULL,NULL,'IV','weak','Bicyclic structure consistent with GABA-A activity (myrtenol, verbenol stronger)','Kessler 2014','https://www.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2017.00046/full'),
('alpha_pinene','cb1','partial_agonist','functional','EC50',NULL,'uM',30,'IV','moderate','~10-50% THC efficacy','Raz 2023','https://www.sciencedirect.com/science/article/pii/S0006295223001399'),
('alpha_pinene','trpm8','agonist','orthosteric',NULL,NULL,NULL,NULL,'IV','weak','Proposed; no Ki','Russo 2011','https://pubmed.ncbi.nlm.nih.gov/21749363/'),
('alpha_pinene','nav','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','weak','Anticonvulsant mechanism proposed','Russo 2011','https://pubmed.ncbi.nlm.nih.gov/21749363/'),
('alpha_pinene','nfkb','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','moderate','Reduces LPS-induced cytokines','de Sa Silveira 2013','https://pmc.ncbi.nlm.nih.gov/articles/PMC6269770/'),
('alpha_pinene','a2a','agonist','functional',NULL,NULL,NULL,NULL,'R','moderate','Shared A2A mechanism in CIPN','LaVigne 2025','https://pmc.ncbi.nlm.nih.gov/articles/PMC11511650/');

-- BETA-PINENE
INSERT INTO interactions(terpene_id,receptor_id,action,binding_mode,affinity_type,affinity_value,affinity_unit,efficacy_pct,tier,confidence,notes,reference,url) VALUES
('beta_pinene','cb1','partial_agonist','functional','EC50',NULL,'uM',30,'IV','moderate','10-50% THC efficacy','Raz 2023','https://www.sciencedirect.com/science/article/pii/S0006295223001399'),
('beta_pinene','nfkb','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','weak','Less studied than alpha-pinene','de Sa Silveira 2013','https://pmc.ncbi.nlm.nih.gov/articles/PMC6269770/');

-- BETA-CARYOPHYLLENE
INSERT INTO interactions(terpene_id,receptor_id,action,binding_mode,affinity_type,affinity_value,affinity_unit,efficacy_pct,tier,confidence,notes,reference,url) VALUES
('bcp','cb2','full_agonist','orthosteric','Ki',155,'nM',100,'IV','strong','CB2 Ki = 155 +/- 4 nM; functional EC50 1.9 +/- 0.3 uM; selective vs CB1 (Ki 485 +/- 36 nM); confirmed by CB2-KO carrageenan study','Gertsch 2008 PNAS','https://pubmed.ncbi.nlm.nih.gov/18574142/'),
('bcp','cb1','weak_binder','orthosteric','Ki',485,'nM',NULL,'IV','strong','Sub-functional binding; no CB1-mediated effects observed in vivo','Gertsch 2008','https://pubmed.ncbi.nlm.nih.gov/18574142/'),
('bcp','ppar_alpha','activator','orthosteric',NULL,NULL,NULL,NULL,'IV','moderate','Drives fatty acid oxidation via PGC-1a, SIRT1','Jha 2021','https://www.frontiersin.org/journals/pharmacology/articles/10.3389/fphar.2021.590201/full'),
('bcp','ppar_gamma','activator','orthosteric',NULL,NULL,NULL,NULL,'IV','strong','Anti-inflammatory cytokine suppression; antiobesity','PMC12565869','https://pmc.ncbi.nlm.nih.gov/articles/PMC12565869/'),
('bcp','nfkb','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','strong','Inhibits ERK1/2 and JNK1/2 phosphorylation (CB2-dependent)','Gertsch 2008','https://pubmed.ncbi.nlm.nih.gov/18574142/'),
('bcp','nrf2','activator','functional',NULL,NULL,NULL,NULL,'IV','moderate','Activates NRF2/HO-1 antioxidant pathway','PMC10970213','https://pmc.ncbi.nlm.nih.gov/articles/PMC10970213/'),
('bcp','a2a','agonist','functional',NULL,NULL,NULL,NULL,'R','moderate','Shared A2A mechanism + dominant CB2 component','LaVigne 2025','https://pmc.ncbi.nlm.nih.gov/articles/PMC11511650/'),
('bcp','mu_opioid','indirect_activator','indirect',NULL,NULL,NULL,NULL,'R','moderate','Opioid-sparing in rodent models','NIH R01-AT010762','https://grantome.com/grant/NIH/R01-AT010762-01');

-- ---------------------------------------------------------------------------
-- THERAPEUTIC EFFECTS
-- ---------------------------------------------------------------------------

-- LINALOOL
INSERT INTO effects(terpene_id,effect,condition,model,species,dose_value,dose_unit,route,sex,outcome,tier,reference,url) VALUES
('linalool','analgesic','acute_pain','acetic_acid_writhing','mouse',100,'mg/kg','i.p.','M','Comparable to low-dose morphine','R','de Sousa 2010','https://www.sciencedirect.com/science/article/pii/S1526590010003883'),
('linalool','analgesic','neuropathic_pain','CIPN','mouse',200,'mg/kg','i.p.','mixed','Efficacy ~equal to morphine 10 mg/kg','R','LaVigne 2025','https://pmc.ncbi.nlm.nih.gov/articles/PMC11511650/'),
('linalool','anxiolytic','anxiety','EPM,light_dark','mouse',NULL,'ng/mL','inhalation','mixed','Anxiolysis without locomotor suppression','R','Linck 2010','https://pmc.ncbi.nlm.nih.gov/articles/PMC3612440/'),
('linalool','anxiolytic','prehypertension','clinical_BP_cortisol','human',80,'mg','oral','mixed','Silexan 80 mg/day; reduced cortisol, daytime BP','H','PMC9886818','https://pmc.ncbi.nlm.nih.gov/articles/PMC9886818/'),
('linalool','anti_inflammatory','neuroinflammation','carrageenan_LPS','mouse',50,'mg/kg','i.p.','M','IL-1b, IL-6, TNF-a, COX-2 reduction','R','Ahammed 2025','https://link.springer.com/10.1007/s00210-025-03984-5'),
('linalool','anticonvulsant','seizure','PTZ_electroshock','rodent',NULL,'mg/kg','i.p.','mixed','Effective; dose unspecified','R','PMC3612440','https://pmc.ncbi.nlm.nih.gov/articles/PMC3612440/'),
('linalool','antioxidant','oxidative_stress','DPPH_in_vitro','IV',NULL,NULL,NULL,NULL,'Reduces MDA, increases SOD/catalase','IV','PMC9886818','https://pmc.ncbi.nlm.nih.gov/articles/PMC9886818/'),
('linalool','gastroprotective','peptic_ulcer','ethanol_ulcer','rat',50,'mg/kg','oral','M','Reduction in ulcer index','R','PMC3612440','https://pmc.ncbi.nlm.nih.gov/articles/PMC3612440/');

-- LIMONENE
INSERT INTO effects(terpene_id,effect,condition,model,species,dose_value,dose_unit,route,sex,outcome,tier,reference,url) VALUES
('limonene','anxiolytic','anxiety','EPM','mouse',10,'mg/kg','i.p.','M','Correlates with elevated DA/5-HT','R','Russo 2011','https://pmc.ncbi.nlm.nih.gov/articles/PMC6239267/'),
('limonene','analgesic','chronic_pain','musculoskeletal','rodent',75,'mg/kg','oral','M','Antihyperalgesic 50-100 mg/kg range','R','Russo 2011','https://pubmed.ncbi.nlm.nih.gov/21749363/'),
('limonene','gastroprotective','peptic_ulcer','ethanol_Wistar','rat',50,'mg/kg','oral','M','93% reduction ulcer area; lowest effective dose','R','De Souza 2019','https://pubmed.ncbi.nlm.nih.gov/30668410/'),
('limonene','anti_inflammatory','systemic_inflammation','multi_model','rodent',50,'mg/kg','oral','M','25-100 mg/kg active range','R','PMC12000914','https://pmc.ncbi.nlm.nih.gov/articles/PMC12000914/'),
('limonene','antioxidant','diabetes','STZ_diabetic_rats','rat',100,'mg/kg','oral','M','Restores SOD/CAT/GPx/GSH','R','PMC12000914','https://pmc.ncbi.nlm.nih.gov/articles/PMC12000914/'),
('limonene','anticancer','breast_cancer','phase2_43_women','human',2000,'mg','oral','F','22% HER2 reduction; perillic acid active','H','Vigushin 1998','https://pmc.ncbi.nlm.nih.gov/articles/PMC6239267/'),
('limonene','antimicrobial','infection','H1N1_in_vitro','IV',NULL,'ug/mL',NULL,NULL,'EC50 1.87 ug/mL vs H1N1','IV','PMC12000914','https://pmc.ncbi.nlm.nih.gov/articles/PMC12000914/'),
('limonene','antidiabetic','metabolic','STZ_diabetic','rat',100,'mg/kg','oral','M','Hypoglycemic trend, antioxidant improvement','R','PMC12000914','https://pmc.ncbi.nlm.nih.gov/articles/PMC12000914/');

-- MYRCENE
INSERT INTO effects(terpene_id,effect,condition,model,species,dose_value,dose_unit,route,sex,outcome,tier,reference,url) VALUES
('myrcene','analgesic','neuropathic_pain','CCI_vonFrey','mouse',10,'mg/kg','i.p.','F','Min effective dose female','R','LaVigne 2025','https://pmc.ncbi.nlm.nih.gov/articles/PMC12353019/'),
('myrcene','analgesic','neuropathic_pain','CCI_vonFrey','mouse',100,'mg/kg','i.p.','M','Min effective dose male; F>M sensitivity','R','LaVigne 2025','https://pmc.ncbi.nlm.nih.gov/articles/PMC12353019/'),
('myrcene','analgesic','inflammatory_pain','arthritic_vonFrey','rat',3,'mg/kg','s.c.','M','1-5 mg/kg effective range','R','LaVigne 2025','https://pmc.ncbi.nlm.nih.gov/articles/PMC12353019/'),
('myrcene','analgesic','CIPN','mixed_terpene','mouse',200,'mg/kg','i.p.','mixed','~equal morphine 10 mg/kg','R','LaVigne 2025','https://pmc.ncbi.nlm.nih.gov/articles/PMC11511650/'),
('myrcene','anti_inflammatory','systemic_inflammation','carrageenan_LPS','rodent',50,'mg/kg','i.p.','M','Cytokine and edema reduction','R','fundacion-canna','https://www.fundacion-canna.es/en/anti-inflammatory-anti-nociceptive-properties-v-myrcene'),
('myrcene','no_sedation','locomotor_test','open_field','mouse',200,'mg/kg','i.p.','mixed','NO locomotor or temperature change at analgesic doses (debunks couch-lock)','R','LaVigne 2025','https://pmc.ncbi.nlm.nih.gov/articles/PMC12353019/'),
('myrcene','opioid_sparing','pain','morphine_combo','mouse',100,'mg/kg','i.p.','mixed','Enhanced antinociception with morphine 3.2 mg/kg vs either alone','R','LaVigne 2025','https://pmc.ncbi.nlm.nih.gov/articles/PMC11511650/');

-- ALPHA-PINENE
INSERT INTO effects(terpene_id,effect,condition,model,species,dose_value,dose_unit,route,sex,outcome,tier,reference,url) VALUES
('alpha_pinene','anti_inflammatory','inflammation','carrageenan_acetic','mouse',25,'mg/kg','oral','M','10-50 mg/kg range; effect persists >48h','R','de Sa Silveira 2013','https://pmc.ncbi.nlm.nih.gov/articles/PMC6269770/'),
('alpha_pinene','analgesic','CIPN','terpene_mix','mouse',200,'mg/kg','i.p.','mixed','~equal morphine 10 mg/kg','R','LaVigne 2025','https://pmc.ncbi.nlm.nih.gov/articles/PMC11511650/'),
('alpha_pinene','anticonvulsant','seizure','PTZ_electroshock','rodent',NULL,NULL,'i.p.','mixed','Pinene EO preparations effective','R','Russo 2011','https://pubmed.ncbi.nlm.nih.gov/21749363/'),
('alpha_pinene','bronchodilator','asthma','airway_challenge','rodent',25,'mg/kg','oral','mixed','Expectorant; inhibits bronchoconstriction','R','de Sa Silveira 2013','https://pmc.ncbi.nlm.nih.gov/articles/PMC6269770/'),
('alpha_pinene','neuroprotective','alzheimers','in_vitro_AChE','IV',NULL,NULL,NULL,NULL,'AChE inhibition; potential Ab-aggregation reduction','IV','PMC7996600','https://pmc.ncbi.nlm.nih.gov/articles/PMC7996600/'),
('alpha_pinene','memory_protective','THC_memory_impairment','hypothesis','human',NULL,NULL,'inhalation','mixed','Russo 2011 hypothesis via AChEI; no direct confirmation','H','Russo 2011','https://pubmed.ncbi.nlm.nih.gov/21749363/');

-- BETA-CARYOPHYLLENE
INSERT INTO effects(terpene_id,effect,condition,model,species,dose_value,dose_unit,route,sex,outcome,tier,reference,url) VALUES
('bcp','anti_inflammatory','systemic_inflammation','carrageenan_CB2KO','mouse',5,'mg/kg','oral','M','Strong reduction; absent in CB2-KO -> CB2-dependent','R','Gertsch 2008','https://pubmed.ncbi.nlm.nih.gov/18574142/'),
('bcp','analgesic','inflammatory_pain','CFA_carrageenan','rodent',25,'mg/kg','oral','M','5-50 mg/kg effective','R','PMC12072555','https://pmc.ncbi.nlm.nih.gov/articles/PMC12072555/'),
('bcp','analgesic','neuropathic_pain','SNL_CCI','mouse',50,'mg/kg','oral','mixed','CB2-dependent; F>M sensitivity','R','Frontiers Neurosci 2020','https://www.frontiersin.org/journals/neuroscience/articles/10.3389/fnins.2020.00850/full'),
('bcp','anxiolytic','anxiety','EPM_OFT_MBT','mouse',30,'mg/kg','i.p.','M','10-200 mg/kg dose-dependent','R','PMC10970213','https://pmc.ncbi.nlm.nih.gov/articles/PMC10970213/'),
('bcp','antidepressant','depression','FST_TST','mouse',30,'mg/kg','oral','mixed','30 mg/kg/day x 4 weeks; CB2R + PPARg','R','PMC10970213','https://pmc.ncbi.nlm.nih.gov/articles/PMC10970213/'),
('bcp','neuroprotective','neuroinflammation','Ab_Alzheimer','rodent',50,'mg/kg','oral','mixed','Reduced neuroinflammation, oxidative stress','R','PMC10970213','https://pmc.ncbi.nlm.nih.gov/articles/PMC10970213/'),
('bcp','gastroprotective','peptic_ulcer','human_case_series','human',NULL,NULL,'oral','mixed','Viphyllin; improved dyspepsia/epigastric pain','H','PMC10970213','https://pmc.ncbi.nlm.nih.gov/articles/PMC10970213/'),
('bcp','antiobesity','metabolic','HFD','rodent',50,'mg/kg','oral','M','Reduces adiposity, insulin resistance; PPARg/CB2','R','PMC12565869','https://pmc.ncbi.nlm.nih.gov/articles/PMC12565869/'),
('bcp','antioxidant','oxidative_stress','NRF2_HO1','IV',NULL,NULL,NULL,NULL,'NRF2/HO-1 activation','IV','PMC10970213','https://pmc.ncbi.nlm.nih.gov/articles/PMC10970213/');

-- ---------------------------------------------------------------------------
-- PHARMACOKINETICS
-- ---------------------------------------------------------------------------
INSERT INTO pharmacokinetics(terpene_id,species,route,formulation,parameter,value,unit,notes,reference,url) VALUES
-- Linalool
('linalool','human','oral','EO_capsule','Tmax',1.0,'h','Rapid GI absorption','Wang 2023','https://media.doterra.com/us/en/brochures/science-articles/linalool-oral-pharmacokinetics.pdf'),
('linalool','human','oral','EO_capsule','Cmax',85.5,'ng/mL','SD +/- 42.6','Wang 2023','https://media.doterra.com/us/en/brochures/science-articles/linalool-oral-pharmacokinetics.pdf'),
('linalool','human','oral','EO_capsule','t_half',3.9,'h','SD +/- 2.9; wide variability','Wang 2023','https://media.doterra.com/us/en/brochures/science-articles/linalool-oral-pharmacokinetics.pdf'),
('linalool','human','oral','EO_capsule','AUC',442,'h*ng/mL','SD +/- 243','Wang 2023','https://media.doterra.com/us/en/brochures/science-articles/linalool-oral-pharmacokinetics.pdf'),
('linalool','human','oral','EO_capsule','Vd',1495,'L','High Vd consistent with logP ~3','Wang 2023','https://media.doterra.com/us/en/brochures/science-articles/linalool-oral-pharmacokinetics.pdf'),
('linalool','human','oral','EO_capsule','CL',385,'L/h','High clearance','Wang 2023','https://media.doterra.com/us/en/brochures/science-articles/linalool-oral-pharmacokinetics.pdf'),
-- Limonene
('limonene','rat','oral','neat','Tmax',1.0,'h','Inferred from rat data','PMID 9682146','https://pubmed.ncbi.nlm.nih.gov/9682146/'),
('limonene','human','oral','neat','t_half',1.5,'h','Parent compound 1-2 h','PMC6239267','https://pmc.ncbi.nlm.nih.gov/articles/PMC6239267/'),
('limonene','human','oral','neat','t_half_metabolite',12.0,'h','Perillic acid metabolite t1/2','Chow & Salazar','https://www.semanticscholar.org/paper/Pharmacokinetics-of-perillic-acid-in-humans-after-a-Chow-Salazar/c092dbfb52bf79816059282ebcf7b97e5a962272'),
-- Alpha-pinene
('alpha_pinene','human','inhalation','vapor','pulmonary_uptake',60,'%','At >=225 mg/m3; linear with concentration','Falk 1990 / SJWEH 2004','https://www.sjweh.fi/article/1771'),
('alpha_pinene','human','inhalation','vapor','t_half_alpha',4.8,'min','Distribution phase','Falk 1990','https://www.sjweh.fi/article/1771'),
('alpha_pinene','human','inhalation','vapor','t_half_beta',38,'min','Intermediate phase','Falk 1990','https://www.sjweh.fi/article/1771'),
('alpha_pinene','human','inhalation','vapor','t_half_gamma',695,'min','Adipose depot; ~11.6 h terminal','Falk 1990','https://www.sjweh.fi/article/1771'),
('alpha_pinene','human','inhalation','vapor','CL',1.1,'L/h/kg','Total blood clearance','Falk 1990','https://www.sjweh.fi/article/1771'),
-- BCP
('bcp','human','oral','neat_oil','Tmax',3.07,'h','Pure compound; poor solubility','PMC9104399','https://pmc.ncbi.nlm.nih.gov/articles/PMC9104399/'),
('bcp','human','oral','SEDDS','Tmax',1.43,'h','Self-emulsifying drug delivery system','PMC9104399','https://pmc.ncbi.nlm.nih.gov/articles/PMC9104399/'),
('bcp','rat','oral','beta_cyclodextrin','AUC_fold_vs_free',2.6,'fold','2.6x increase in AUC_0-12h','PMID 23598076','https://pubmed.ncbi.nlm.nih.gov/23598076/');

-- ---------------------------------------------------------------------------
-- METABOLISM
-- ---------------------------------------------------------------------------
INSERT INTO metabolism(terpene_id,enzyme,metabolite,bioactive,notes,reference,url) VALUES
('linalool','CYP_oxidation','8-hydroxylinalool',0,'Primary C8 oxidation','Wang 2023','https://media.doterra.com/us/en/brochures/science-articles/linalool-oral-pharmacokinetics.pdf'),
('linalool','CYP_oxidation','8-oxolinalool',1,'1.66-fold GABA-A PAM (in vitro)','Kessler 2017','https://www.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2017.00046/full'),
('linalool','CYP_oxidation','8-carboxylinalool',0,NULL,'Wang 2023','https://media.doterra.com/us/en/brochures/science-articles/linalool-oral-pharmacokinetics.pdf'),
('limonene','CYP2C9_CYP3A4','perillyl_alcohol',1,'Intermediate metabolite','PMC6239267','https://pmc.ncbi.nlm.nih.gov/articles/PMC6239267/'),
('limonene','CYP3A4','perillic_acid',1,'Active metabolite; likely cancer-active species','PMC6239267','https://pmc.ncbi.nlm.nih.gov/articles/PMC6239267/'),
('limonene','CYP','limonene_1_2_diol',0,NULL,'PMC6239267','https://pmc.ncbi.nlm.nih.gov/articles/PMC6239267/'),
('myrcene','CYP3A4','unspecified',NULL,'Presumed epoxidation/hydroxylation; limited human data',NULL,NULL),
('alpha_pinene','CYP','cis_trans_verbenol',1,'Allylic oxidation; urinary marker','Eriksson 1996','https://pmc.ncbi.nlm.nih.gov/articles/PMC9298155/'),
('alpha_pinene','CYP','myrtenol',1,'Allylic oxidation product','Eriksson 1996','https://pmc.ncbi.nlm.nih.gov/articles/PMC9298155/'),
('bcp','CYP3A4','bcp_oxide',1,'Caryophyllene oxide also bioactive','PMC9104399','https://pmc.ncbi.nlm.nih.gov/articles/PMC9104399/');

-- ---------------------------------------------------------------------------
-- SAFETY
-- ---------------------------------------------------------------------------
INSERT INTO safety(terpene_id,category,species,route,value,unit,severity,description,reference,url) VALUES
('linalool','LD50','rat','oral',5000,'mg/kg','low','>5000 mg/kg; GRAS','FEMA #2635','https://www.femaflavor.org/fema-gras'),
('linalool','contact_allergy','human','dermal',NULL,NULL,'moderate','Linalool hydroperoxides ~7-10% positivity in fragrance-allergic patients','PMC6040011','https://pmc.ncbi.nlm.nih.gov/articles/PMC6040011/'),
('linalool','drug_interaction','human','oral',NULL,NULL,'low','CYP3A4 inhibitor potential at high concentrations; caffeine/sclareol counter sedation','Islam 2025','https://link.springer.com/10.1007/s00210-025-03915-4'),
('limonene','LD50','rat','oral',5000,'mg/kg','low','>5000 mg/kg; GRAS','FEMA #2633','https://www.femaflavor.org/sites/default/files/15.%20GRAS%20Substances%20(3755-3774).pdf'),
('limonene','contact_allergy','human','dermal',NULL,NULL,'high','Hydroperoxides + epoxides; 1-2.5% patch-test positivity, higher in occupational exposure','PMC6040011','https://pmc.ncbi.nlm.nih.gov/articles/PMC6040011/'),
('limonene','carcinogen','rat','oral',NULL,NULL,'low','Male F-344 rat renal tubular tumors via alpha-2u-globulin: rat-specific, NOT human-extrapolatable','FEMA','https://www.femaflavor.org/sites/default/files/15.%20GRAS%20Substances%20(3755-3774).pdf'),
('limonene','NOAEL','rat','oral',250,'mg/kg/day','low','13-week study','PMC6239267','https://pmc.ncbi.nlm.nih.gov/articles/PMC6239267/'),
('myrcene','LD50','rat','oral',1600,'mg/kg','moderate','1600-5000 mg/kg conflicting sources','Aus NICNAS','https://www.industrialchemicals.gov.au/sites/default/files/2022-05/EVA00048%20-%20Evaluation%20statement%20-%2030%20May%202022.pdf'),
('myrcene','embryotoxicity','rat','oral',300,'mg/kg','moderate','Embryo-fetotoxic 300-600 mg/kg; not relevant at physiological exposure','PMID 8474729','https://www.sciencedirect.com/science/article/abs/pii/027869159390175X'),
('alpha_pinene','LD50','rat','oral',3700,'mg/kg','low','GRAS','FEMA #2902','https://www.femaflavor.org/fema-gras'),
('alpha_pinene','occupational','human','inhalation',10,'mg/m3','moderate','Sensory irritation threshold','PMC9298155','https://pmc.ncbi.nlm.nih.gov/articles/PMC9298155/'),
('alpha_pinene','contact_allergy','human','dermal',NULL,NULL,'moderate','Pinene hydroperoxides and alpha-pinene epoxide','PMC6040011','https://pmc.ncbi.nlm.nih.gov/articles/PMC6040011/'),
('bcp','LD50','rat','oral',5000,'mg/kg','low','>5000 mg/kg oral and dermal','FEMA #2252','https://www.frontiersin.org/journals/pharmacology/articles/10.3389/fphar.2021.590201/full'),
('bcp','contact_allergy','human','dermal',NULL,NULL,'low','Very low sensitization risk','PMC6040011','https://pmc.ncbi.nlm.nih.gov/articles/PMC6040011/'),
('bcp','drug_interaction','human','oral',NULL,NULL,'low','PPARg + CB2: theoretical interaction with thiazolidinediones, immunosuppressants','PMC10970213','https://pmc.ncbi.nlm.nih.gov/articles/PMC10970213/');

-- ---------------------------------------------------------------------------
-- SYNERGY — entourage effect data
-- ---------------------------------------------------------------------------
INSERT INTO synergy(terpene_id,partner,partner_class,interaction_type,mechanism,assay,quantitative_result,confidence,tier,reference,url) VALUES
-- BCP synergies
('bcp','THC','phytocannabinoid','additive','Independent CB2 + CB1 pathways converge on inflammation','carrageenan CB2-KO','5 mg/kg oral BCP fully active WT, abolished CB2-KO','strong','R','Gertsch 2008','https://pubmed.ncbi.nlm.nih.gov/18574142/'),
('bcp','CBD','phytocannabinoid','synergistic','BCP CB2 + CBD anti-inflammatory cascades','LPS macrophage cytokine','Greater than additive IL-6/TNF-a reduction (multiple)','moderate','IV','PMC10970213','https://pmc.ncbi.nlm.nih.gov/articles/PMC10970213/'),
('bcp','morphine','opioid','opioid_sparing','Sub-effective opioid + sub-effective BCP yields full antinociception','rodent CIPN','Confirmed in NIH-funded work','moderate','R','NIH R01-AT010762','https://grantome.com/grant/NIH/R01-AT010762-01'),
('bcp','CB1_orthosteric','phytocannabinoid','no_interaction','BCP does not bind CB1 functionally','radioligand transfected cells','Weak Ki only (485 nM); no functional response','strong','IV','Gertsch 2008 / Finlay 2020','https://pubmed.ncbi.nlm.nih.gov/18574142/'),
-- Myrcene synergies
('myrcene','THC','phytocannabinoid','synergistic','CB1 cAMP partial agonism adds to THC','HEK CB1 cAMP','10-50% THC efficacy alone; combination > THC alone','moderate','IV','Raz 2023','https://www.sciencedirect.com/science/article/pii/S0006295223001399'),
('myrcene','THC','phytocannabinoid','contested','Hastens THC onset (mango folk-claim)','no_rigorous_data','No peer-reviewed support','weak','H','Russo 2011','https://pubmed.ncbi.nlm.nih.gov/21749363/'),
('myrcene','2-AG','endocannabinoid','synergistic','Enhances endocannabinoid tone (SR141716A-reversible)','spinal_cord_neurons','In vivo CB1 antagonist blocks myrcene analgesia','strong','R','LaVigne 2025','https://pmc.ncbi.nlm.nih.gov/articles/PMC12353019/'),
('myrcene','morphine','opioid','opioid_sparing','A2A + endogenous opioid release; subadditive doses synergize','CIPN','100 mg/kg myrcene + 3.2 mg/kg morphine > either alone','strong','R','LaVigne 2025','https://pmc.ncbi.nlm.nih.gov/articles/PMC11511650/'),
('myrcene','CB1_orthosteric','phytocannabinoid','no_interaction','No direct CB1 binding','radioligand','No CP-55,940 displacement at 10 uM','strong','IV','LaVigne 2025','https://pmc.ncbi.nlm.nih.gov/articles/PMC12353019/'),
-- Linalool synergies
('linalool','THC','phytocannabinoid','synergistic','Weak CB1 partial agonism + GABA + A2A complementary','HEK CB1 cAMP','10-50% THC efficacy','moderate','IV','Raz 2023','https://www.sciencedirect.com/science/article/pii/S0006295223001399'),
('linalool','CBD','phytocannabinoid','synergistic','Anticonvulsant + anxiolytic complementarity','behavioral','Hypothesis-level','weak','R','Russo 2011','https://pubmed.ncbi.nlm.nih.gov/21749363/'),
('linalool','morphine','opioid','opioid_sparing','Spinal A2A mechanism','CIPN','Terpene + morphine 3.2 mg/kg synergistic','strong','R','LaVigne 2025','https://pmc.ncbi.nlm.nih.gov/articles/PMC11511650/'),
-- Limonene synergies
('limonene','THC','phytocannabinoid','synergistic','5-HT1A + A2A independent pathways','HEK CB1 cAMP','10-50% THC efficacy in cAMP','moderate','IV','Raz 2023','https://www.sciencedirect.com/science/article/pii/S0006295223001399'),
('limonene','THC','phytocannabinoid','antianxiogenic','Counters THC-induced anxiety','behavioral_hypothesis','Russo 2011 hypothesis','weak','R','Russo 2011','https://pubmed.ncbi.nlm.nih.gov/21749363/'),
-- alpha-Pinene synergies
('alpha_pinene','THC','phytocannabinoid','memory_protective','AChE inhibition preserves ACh against THC short-term memory deficit','hypothesis','No direct confirmation as of 2025','weak','H','Russo 2011','https://pubmed.ncbi.nlm.nih.gov/21749363/'),
('alpha_pinene','THC','phytocannabinoid','synergistic','CB1 cAMP partial agonism','HEK CB1','10-50% THC efficacy','moderate','IV','Raz 2023','https://www.sciencedirect.com/science/article/pii/S0006295223001399'),
-- Aggregate negative finding
('myrcene','CP_55940','synthetic_cb','no_interaction','Pooled terpene mix did not displace radioligand or potentiate THC/CBD/2-AG at CB1/CB2','radioligand_cAMP_transfected','No allosteric shift in EC50 or Emax','strong','IV','Finlay 2020 / Heblinski 2020','https://www.frontiersin.org/journals/pharmacology/articles/10.3389/fphar.2020.00359/full');

-- ---------------------------------------------------------------------------
-- CONDITION TARGETS — for query-driven design
-- ---------------------------------------------------------------------------
INSERT INTO condition_targets(condition,receptor_id,rationale,priority) VALUES
-- Chronic / neuropathic pain
('chronic_pain','a2a','Spinal A2A is the convergent terpene analgesic mechanism (LaVigne 2025); opioid-sparing',1),
('chronic_pain','cb2','BCP-validated peripheral immune analgesia without psychotropism',1),
('chronic_pain','cb1','THC + terpene partial agonism for central analgesia',2),
('chronic_pain','trpv1','Myrcene activation/desensitization paradigm',2),
('chronic_pain','mu_opioid','Indirect engagement enables opioid-sparing combos',2),
('chronic_pain','cav32','Camphene/bisabolol T-type Ca block (secondary terpenes)',3),
-- Neuroinflammation
('neuroinflammation','cb2','BCP CB2-dependent cytokine suppression',1),
('neuroinflammation','nfkb','Master inflammatory transcription factor; all 5 terpenes inhibit',1),
('neuroinflammation','ppar_gamma','BCP-PPARg axis modulates microglial polarization',1),
('neuroinflammation','nrf2','BCP NRF2/HO-1 antioxidant defense',2),
('neuroinflammation','cox2','Downstream prostaglandin reduction',2),
('neuroinflammation','inos','NO production reduction',2),
-- Anxiety / mood
('anxiety','gaba_a','Linalool PAM (caveat: supra-physiological in vitro concentration)',1),
('anxiety','5ht1a','Limonene-mediated DA/5-HT elevation',1),
('anxiety','cb2','BCP-PPARg-CB2 antidepressant axis',2),
('anxiety','a2a','Adenosinergic anxiolysis',2),
-- Neurodegeneration / cognition
('neurodegeneration','ache','Alpha-pinene AChEI for Alzheimers adjunct',2),
('neurodegeneration','nrf2','BCP NRF2 activation',1),
('neurodegeneration','cb2','BCP microglial CB2 modulation',1),
-- Metabolic
('metabolic_disease','ppar_alpha','BCP fatty acid oxidation',1),
('metabolic_disease','ppar_gamma','BCP insulin sensitization',1);

-- ---------------------------------------------------------------------------
-- EVIDENCE GAPS — for design honesty
-- ---------------------------------------------------------------------------
INSERT INTO evidence_gaps(terpene_id,receptor_id,description,severity) VALUES
('linalool','gaba_a','PAM activity quantified at 2 mM (supra-physiological); relevance at therapeutic plasma levels (ng/mL) unproven','weak_evidence'),
('limonene','5ht1a','No direct Ki published; behavioral inference only','weak_evidence'),
('myrcene',NULL,'Couch-lock / indica-determinism claim disproven by LaVigne 2025 PMC12353019','hypothesis_only'),
('myrcene',NULL,'No human PK study; oral F%, Tmax, t1/2 unknown','blocker'),
('alpha_pinene','cb1','THC-memory-counter hypothesis (Russo 2011) lacks direct confirmation','hypothesis_only'),
('bcp',NULL,'No randomized controlled trials in pain or anxiety despite robust preclinical data','blocker'),
(NULL,'cb1','Finlay 2020 / Heblinski 2020 negative binding vs LaVigne 2021 / Raz 2023 functional positive — concentration/native-tissue effects unresolved','weak_evidence');
