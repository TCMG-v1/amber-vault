# Terpene Entourage Effect: Quantitative Review

*Focus: Phytocannabinoid–terpenoid interactions, receptor-level evidence, contested claims*

---

## Overview: The Entourage Hypothesis

The "entourage effect" was proposed by Ben-Shabat et al. (1998) to describe how endocannabinoid system components potentiate each other. Russo (2011) extended this to cannabis terpenoids. The field has since become contentious due to conflicting experimental evidence at the receptor level vs. whole-animal data.

**Core question**: Do terpenes (1) directly bind CB1/CB2, (2) allosterically modulate cannabinoid receptors, (3) act through independent but synergistic pathways, or (4) produce no receptor-level interaction?

---

## 1. Foundational Papers

### 1.1 Russo 2011 — "Taming THC"

| Parameter | Detail |
|---|---|
| Citation | Russo EB. Taming THC: potential cannabis synergy and phytocannabinoid-terpenoid entourage effects. *Br J Pharmacol.* 2011;163(7):1344–1364 |
| PMID | 21749363 / PMC3165946 |
| DOI | 10.1111/j.1476-5381.2011.01238.x |
| URL | [PubMed](https://pubmed.ncbi.nlm.nih.gov/21749363/) |
| Type | Narrative review; no new experimental data |
| Claim | Terpenoids contribute to entourage effects via independent pharmacological pathways (serotonergic, GABAergic, adrenergic, opioid) that synergize with cannabinoids |
| Key quantitative claims | Terpenes affect behavior at ambient air serum concentrations in "single digits ng/mL"; specific terpene pharmacology summarized per compound |
| Evidence tier | Literature review / expert opinion |
| Limitations | No direct receptor binding studies presented; most cited data is pre-2010 rodent work; does not test terpene–CB1/CB2 binding |
| Status | **Highly cited** (>2,500 citations); foundational hypothesis but explicitly labeled as "potential" synergy |

**Terpene-specific synergy claims in Russo 2011:**

| Terpene | Proposed Synergy with Cannabinoids | Mechanistic Basis (2011) |
|---|---|---|
| Linalool | Anticonvulsant synergy with CBD; anxiolysis complementary to CBD | GABA-A PAM + glutamate inhibition |
| Limonene | Anxiolytic + antidepressant complementary to THC | 5-HT1A, DA system |
| Myrcene | Sedative + analgesic amplification; possible THC onset hastening (mango urban legend) | GABA-A, opioid system |
| α-Pinene | Counters THC-induced memory impairment via AChEI | AChE inhibition preserves ACh |
| β-Caryophyllene | Complements THC/CBD anti-inflammatory via independent CB2 pathway | CB2 agonism (Gertsch 2008) |

**Critical evaluation**: α-Pinene's proposed counter-effect on THC memory impairment is particularly interesting as a testable hypothesis but lacks direct experimental confirmation as of 2025.

### 1.2 Russo & Marcu 2017 — "Cannabis Pharmacology"

| Parameter | Detail |
|---|---|
| Citation | Russo EB, Marcu J. Cannabis Pharmacology: The Usual Suspects and a Few Promising Leads. *Adv Pharmacol.* 2017;80:67–134 |
| URL | [ethanrusso.org](http://ethanrusso.org/wp-content/uploads/2020/02/Russo-Marcu-Cannabis-Pharmacology-The-Usual-Suspects-and-a-Few-Promising-Leads-Adv-Pharmacol-2017-1.pdf) |
| Type | Comprehensive review |
| Claim | Terpenoids contribute modulatory and therapeutic roles "far beyond expectations considering their modest concentrations in the plant" |
| Evidence added vs. 2011 | Updated preclinical data; no new receptor binding data for terpenes at CB1/CB2 |
| Limitations | Still primarily review-based; direct CB1/CB2 binding evidence absent |

---

## 2. Evidence AGAINST Direct CB1/CB2 Activity — Finlay 2020 (Heblinski)

### 2.1 Finlay et al. 2020 — Negative Findings

| Parameter | Detail |
|---|---|
| Citation | Finlay DB, Sircombe KJ, Nimick M, Jones C, Glass M. Terpenoids From Cannabis Do Not Mediate an Entourage Effect by Acting at Cannabinoid Receptors. *Front Pharmacol.* 2020;11:359 |
| DOI | 10.3389/fphar.2020.00359 |
| URL | [Frontiers Pharmacol](https://www.frontiersin.org/journals/pharmacology/articles/10.3389/fphar.2020.00359/full) |
| Terpenes tested | Myrcene, α-pinene, β-pinene, β-caryophyllene, limonene (individually and in mixtures) |
| Methods | Radioligand binding ([³H]-CP55,940 displacement), functional cAMP assays, CB1/CB2 transfected cells |

**Key quantitative findings:**

| Assay | Finding |
|---|---|
| [³H]-CP55,940 binding at CB1 | No displacement by any terpene at tested concentrations |
| [³H]-CP55,940 binding at CB2 | No significant displacement, except **β-caryophyllene showed a weak interaction** |
| CB1 cAMP (functional) | No terpene alone showed significant functional CB1 activity |
| CB2 cAMP (functional) | No terpene produced detectable CB2 functional response (except weak BCP trend) |
| Terpene mixtures | No potentiation of THC, CBD, or 2-AG activity at CB1 or CB2 |
| Allosteric interaction test | No allosteric shift in agonist EC50 or Emax detected |

**Conclusion**: "With the possible exception of a weak interaction of β-caryophyllene with CB2, no data were produced to support the hypothesis that any of the five terpenes tested (either alone or in mixtures) have direct interactions with CB1 or CB2."

**Interpretation and limitations**:
- Study used standard radioligand binding — appropriate for detecting orthosteric and allosteric interactions
- Does not rule out: (a) non-cannabinoid mechanisms causing independent analgesia, or (b) terpenes acting at non-CB receptors that produce additive analgesic/anxiolytic effects
- Concentration range tested may not replicate in vivo tissue concentrations at effector sites

### 2.2 Heblinski et al. 2020 — Independent Negative Replication

| Parameter | Detail |
|---|---|
| Citation | Heblinski M et al. Evaluation of the profiles of CB1 cannabinoid receptor activity. *Br J Pharmacol.* 2020 |
| PMC | PMC7369624 |
| URL | [PMC7369624](https://pmc.ncbi.nlm.nih.gov/articles/PMC7369624/) |
| Finding | Similarly found no significant CB1 or CB2 receptor-mediated activity for common cannabis terpenes |

Together, Finlay 2020 and Heblinski 2020 represent the strongest evidence against the simple "terpenes bind cannabinoid receptors" model. Both are peer-reviewed, well-controlled studies.

---

## 3. Evidence FOR Terpene–CB Receptor Synergy

### 3.1 LaVigne et al. 2021 — "Cannabis sativa terpenes are cannabimimetic"

| Parameter | Detail |
|---|---|
| Citation | LaVigne JE et al. Cannabis sativa terpenes are cannabimimetic and selectively enhance cannabinoid activity. *Sci Rep.* 2021;11:8232 |
| DOI | 10.1038/s41598-021-87740-8 |
| URL | [Nature Scientific Reports](https://www.nature.com/articles/s41598-021-87740-8) |
| Terpenes tested | Linalool, myrcene, α-pinene, β-caryophyllene, geraniol |
| In vitro system | Spinal cord dorsal horn neurons; mouse brain preparations |

**Key quantitative findings:**

| Terpene | CB1 Activity (in vitro) | Notes |
|---|---|---|
| Linalool | Activated CB1-mediated signaling | Blocked by CB1 antagonist AM251 |
| Myrcene | Activated CB1-mediated signaling | CB1-dependent in neuronal preparation |
| α-Pinene | Activated CB1-mediated signaling | CB1-dependent |
| β-Caryophyllene | Activated CB1 (minor) + CB2 | Dual activity |
| Geraniol | Activated CB1-mediated signaling | CB1-dependent |

**Important caveat from LaVigne 2021**: Effects were seen at **very low concentrations (0.001–0.01 µM)** in dorsal horn preparations using neuronal activity readouts — a different assay system than Finlay 2020's radioligand binding / transfected cell lines. The discrepancy may reflect:
- Native protein environments (dorsal horn neurons) vs. overexpressed receptors
- Functional assays capturing allosteric/indirect effects invisible to binding assays
- Concentration-dependent phenomena

**In vivo**: The same group (LaVigne 2021, then 2025) found that terpene antinociception in CIPN is **blocked by CB1 antagonist SR141716A** for myrcene, suggesting CB1 involvement in vivo.

### 3.2 Raz et al. 2023 — CB1 cAMP Synergy with THC

| Parameter | Detail |
|---|---|
| Citation | Raz N, Eyal AM, Berneman Zeitouni D, Hen-Shoval D, Davidson EM, Danieli A, Tauber M, Ben-Chaim Y. Selected cannabis terpenes synergize with THC to produce increased CB1 receptor activation. *Biochem Pharmacol.* 2023;212:115548 |
| DOI | 10.1016/j.bcp.2023.115548 |
| URL | [ScienceDirect](https://www.sciencedirect.com/science/article/pii/S0006295223001399) |

**Key quantitative findings:**

| Terpene | CB1 Activation (alone vs. THC) | Effect |
|---|---|---|
| α-Pinene | 10–50% of THC's cAMP inhibition alone at µM | Synergizes with THC to increase total CB1 activation |
| β-Pinene | 10–50% of THC cAMP efficacy | Synergy with THC |
| Linalool | 10–50% of THC efficacy | Synergy with THC |
| Limonene | 10–50% of THC efficacy | Synergy with THC |
| Myrcene | 10–50% of THC efficacy | Synergy with THC |
| Geraniol, terpineol, others | Similar range | Active at 0.001–0.01 µM |

**This study is important because it directly measured cAMP responses** — a standard functional readout for Gi-coupled receptors. Terpenes produced 10–50% of THC's maximal CB1 cAMP inhibition. The combination of THC + terpene produced **greater total CB1 activation** than THC alone.

**Limitations**:
- Publication from Israeli group with commercial cannabis interests (disclosure needed in interpretation)
- Exact concentration–response curves and EC50 shift values not widely reproduced yet
- The 10–50% THC efficacy range means these are weak partial agonists at best

### 3.3 LaVigne 2025 (in vivo, A2A mechanism) — Mechanistic Clarity

| Parameter | Detail |
|---|---|
| Citation | LaVigne JE et al. Terpenes from Cannabis sativa Induce Antinociception in a Mouse Model of Chronic Neuropathic Pain via Activation of Adenosine A2A Receptors. *J Pain.* 2025 |
| PMC | PMC11511650 |
| URL | [PMC11511650](https://pmc.ncbi.nlm.nih.gov/articles/PMC11511650/) |

**Key quantitative findings:**

| Aspect | Finding |
|---|---|
| Terpenes tested | Linalool, myrcene, α-pinene, β-caryophyllene, geraniol |
| Dose | 200 mg/kg i.p. |
| Efficacy | Antinociception ~equal to morphine 10 mg/kg OR WIN55,212 3.2 mg/kg |
| A2A antagonist (istradefylline 3.2 mg/kg) | **Completely blocked** terpene-induced antinociception |
| Spinal A2A CRISPR knockdown | **Abolished** terpene antinociception |
| In vitro cAMP and binding | Terpenes act as A2A agonists (consistent with in silico modeling) |
| Reward/addiction liability | **None** — no conditioned place preference at 100 mg/kg |
| Opioid combination | 100 mg/kg terpene + morphine 3.2 mg/kg → enhanced antinociception vs. either alone |

**Interpretation**: This landmark 2025 study **identifies the spinal adenosine A2A receptor as the primary mechanism** for terpene antinociception in CIPN. This reconciles the Finlay 2020 negative data (no CB1/CB2 binding) with the clear in vivo analgesic effects: terpenes don't need to bind cannabinoid receptors to produce cannabis-synergistic analgesia — they act independently via A2A with downstream convergence on pain circuits.

---

## 4. Synthesis: Reconciling Conflicting Data

### 4.1 Summary of Evidence Status

| Hypothesis | Evidence Level | Status |
|---|---|---|
| Terpenes directly bind CB1 (orthosteric) | Low | **Rejected** — Finlay 2020, Heblinski 2020 radioligand data |
| Terpenes allosterically modulate CB1 | Contested | Possible at very low concentrations in native neurons (LaVigne 2021); not detected in transfected cells (Finlay 2020) |
| Terpenes weakly activate CB1 (cAMP) | Moderate | Supported by Raz 2023 (10–50% THC efficacy) — partial agonism |
| Terpenes activate spinal A2A for analgesia | Strong | **Confirmed** — LaVigne 2025 with A2A antagonist + CRISPR knockdown |
| BCP selectively activates CB2 | Very strong | **Confirmed** — Gertsch 2008 (Ki 155 nM), multiple labs |
| Terpene–opioid synergy | Moderate | Naloxone reversal data; NIH clinical trial ongoing; opioid-sparing confirmed in rodents |
| GABA-A modulation (linalool) | Moderate | In vitro PAM confirmed; physiological relevance at in vivo concentrations uncertain |
| α-Pinene counters THC memory impairment | Weak | Plausible via AChEI mechanism; direct experimental confirmation absent |

### 4.2 Quantitative Summary: Terpene CB1 Activity

| Source | Terpenes | Assay | CB1 Efficacy | THC Comparison |
|---|---|---|---|---|
| Finlay 2020 | Myrcene, limonene, α/β-pinene, BCP | Radioligand binding + cAMP (transfected cells) | **None detected** | N/A |
| Heblinski 2020 | Multiple | Radioligand binding | **None detected** | N/A |
| LaVigne 2021 | Linalool, myrcene, α-pinene, geraniol | Neuronal activity (dorsal horn) | **Detectable; CB1-dependent** | Not quantified vs. THC |
| Raz 2023 | α-pinene, β-pinene, linalool, limonene, myrcene, terpineol, others | cAMP assay (hCB1 HEK cells) | **10–50% of THC** at 0.001–10 µM | Direct comparison reported |
| LaVigne 2025 (CIPN, in vivo) | Linalool, myrcene, α-pinene, BCP, geraniol | Antinociception + A2A blockade | Antinociception = morphine 10 mg/kg | CB1 antagonist reverses myrcene (partial) |

### 4.3 Quantitative Summary: Terpene–THC Synergy

| Study | System | Finding | Magnitude |
|---|---|---|---|
| Raz 2023 | hCB1 cAMP assay | Terpene + THC → greater total CB1 cAMP inhibition than THC alone | ~10–50% additional effect from terpene; exact EC50 shift not published in available data |
| LaVigne 2025 | CIPN mouse | Morphine 3.2 mg/kg + terpene 100 mg/kg → enhanced antinociception | "Enhanced" — synergy not quantified as isobologram |
| Gertsch 2008 | CB2 agonist (BCP) | BCP 5 mg/kg oral anti-inflammatory in WT, absent in CB2 KO | CB2-pathway independent of THC/CB1; additive for overall cannabis analgesia |
| Russo 2011 | Review | Proposed synergy: linalool + CBD for anxiety/epilepsy; myrcene + THC for sedation | Theoretical; no EC50 data |

### 4.4 Myrcene-Specific Mechanistic Resolution (2025)

The 2025 LaVigne et al. study (PMC12353019) directly addressed the myrcene–CB1 question:

| Experiment | Result |
|---|---|
| CP 55,940 radioligand displacement by myrcene 10 µM | **No displacement** — confirms no orthosteric CB1 binding |
| Patch-clamp: myrcene 1 µM effect on EPSC amplitude | No effect — no direct CB1-mediated synaptic suppression |
| SR141716A (CB1 antagonist) + myrcene (in vivo) | **Completely blocks** myrcene's antinociceptive effect |
| Interpretation | Myrcene enhances endogenous 2-AG/AEA tone → CB1 activation indirect; OR A2A agonism converges on same circuit |

**The leading mechanistic model for myrcene (2025)**: Myrcene stimulates endocannabinoid release (2-AG/AEA) at peripheral/spinal sites → CB1 activation by endogenous ligands. The CB1 antagonist reversal is consistent with this model. The A2A pathway provides additional/synergistic antinociception.

---

## 5. BCP Entourage: The Strongest Evidence

β-Caryophyllene represents the clearest case for a terpene-specific contribution to cannabis pharmacology via a distinct cannabinoid receptor:

| Aspect | Data |
|---|---|
| CB2 Ki | **155 ± 4 nM** (selective; CB1 Ki = 485 nM) — Gertsch 2008 |
| Functional EC50 (CB2 cAMP) | ~1.9 µM — Gertsch 2008 |
| In vivo validation | 5 mg/kg oral → strong anti-inflammatory in WT; zero effect in CB2-KO mice |
| PPAR-α/γ agonism | Additional independent pathway |
| Clinical relevance | Non-psychoactive dietary cannabinoid → GRAS; complements THC/CBD without CB1 psychotropic effects |
| Entourage value | Provides CB2-mediated immune/pain modulation that THC (primarily CB1) does not cover |

BCP is the **only terpene with confirmed, quantitative receptor-binding entourage pharmacology at therapeutically relevant receptor concentrations**.

---

## 6. Contested Claims and Known Myths

### 6.1 "Indica vs. Sativa" Terpene Determinism

The popular model that indica strains (high myrcene) cause sedation and sativa strains (high limonene/pinene) cause energization has **no rigorous scientific basis**:
- Chemotaxonomy studies show no reliable chemical distinction between "indica" and "sativa" as marketed
- Myrcene does not produce sedation/locomotor suppression at analgesic doses (PMC12353019, 2025)
- Terpene profiles alone do not determine the pharmacological experience of a cannabis product
- [Frontiers Pharmacol 2020 Finlay confirms no CB1 activity for myrcene or limonene](https://www.frontiersin.org/journals/pharmacology/articles/10.3389/fphar.2020.00359/full)

### 6.2 "Mango Myrcene Enhances THC High"

The claim that eating mango (high myrcene) before cannabis use intensifies the high by facilitating THC BBB crossing has **no published experimental support**. No pharmacokinetic study has tested this. Myrcene plasma concentrations achievable from mango consumption have not been characterized.

### 6.3 "Linalool from Lavender + Cannabis = Anxiolytic"

Plausible mechanism (GABA-A PAM + A2A + glutamate modulation + possible CB1 functional activity), but the in vitro GABA-A data at 2 mM is supra-physiological, and no human study has co-administered linalool with THC or CBD to assess synergistic anxiolysis.

---

## 7. Key Gap Analysis

| Gap | Status | Priority |
|---|---|---|
| Terpene A2A agonism: Ki/EC50 at human A2A receptor | Not published (docking only) | High |
| Terpene + THC isobologram studies (in vivo) | Absent for most terpenes | High |
| Human PK at analgesic doses (200 mg/kg equivalent) | Absent for all terpenes | High |
| Clinical RCT: terpene + cannabinoid vs. cannabinoid alone in pain | Zero completed (2025) | Critical |
| Myrcene effect on 2-AG/AEA levels directly measured | Absent | High |
| α-Pinene reversal of THC amnesia (direct experiment) | Absent | Moderate |
| Dose-response CB1 cAMP for individual terpenes (independent lab replication of Raz 2023) | Absent | High |

---

## 8. Key References for Entourage Literature

1. [Russo EB 2011 – *Br J Pharmacol* 163:1344–1364](https://pubmed.ncbi.nlm.nih.gov/21749363/) — Foundational review; PMID 21749363
2. [Russo EB & Marcu J 2017 – *Adv Pharmacol* 80:67–134](http://ethanrusso.org/wp-content/uploads/2020/02/Russo-Marcu-Cannabis-Pharmacology-The-Usual-Suspects-and-a-Few-Promising-Leads-Adv-Pharmacol-2017-1.pdf) — Extended review
3. [Gertsch J et al. 2008 – *PNAS* 105:9099–9104](https://pubmed.ncbi.nlm.nih.gov/18574142/) — BCP as dietary CB2 cannabinoid; Ki = 155 nM
4. [Finlay DB et al. 2020 – *Front Pharmacol* 11:359](https://www.frontiersin.org/journals/pharmacology/articles/10.3389/fphar.2020.00359/full) — Terpenes do NOT mediate entourage at CB1/CB2
5. [Heblinski M et al. 2020 – *Br J Pharmacol* PMC7369624](https://pmc.ncbi.nlm.nih.gov/articles/PMC7369624/) — Independent negative replication
6. [LaVigne JE et al. 2021 – *Sci Rep* 11:8232](https://www.nature.com/articles/s41598-021-87740-8) — Terpenes cannabimimetic in dorsal horn neurons
7. [Raz N et al. 2023 – *Biochem Pharmacol* 212:115548](https://www.sciencedirect.com/science/article/pii/S0006295223001399) — Terpenes synergize with THC for CB1 activation (10–50% THC efficacy)
8. [LaVigne JE et al. 2025 – *J Pain* PMC11511650](https://pmc.ncbi.nlm.nih.gov/articles/PMC11511650/) — A2A mechanism confirmed; opioid-sparing effects
9. [LaVigne JE et al. 2025 – *Pain* PMC12353019](https://pmc.ncbi.nlm.nih.gov/articles/PMC12353019/) — Myrcene: no direct CB1 binding; indirect endocannabinoid-mediated; sex differences
10. [NIH Grant R01-AT010762](https://grantome.com/grant/NIH/R01-AT010762-01) — Ongoing human clinical trial of myrcene + BCP with opioid-sparing focus
11. [Cannakeys summary of Raz 2023](https://cannakeys.com/spotlights/terpenes-that-activate-cb1/) — Accessible summary; terpenes activate CB1 at 0.001–0.01 µM

---

## 9. Working Mechanistic Model (2025 State of Knowledge)

```
                    ┌─────────────────────────────────────────────┐
                    │   CANNABIS TERPENE ENTOURAGE MECHANISMS     │
                    └─────────────────────────────────────────────┘
                              
Terpene ──→ Adenosine A2A agonism ──→ Spinal cord A2A-R ──→ ANTINOCICEPTION
              (linalool, myrcene,                               ↑
               α-pinene, geraniol)                         OPIOID SYNERGY
                                                               ↑
Myrcene ──→ Enhances 2-AG/AEA tone ──→ CB1 activation ─────┘
              (indirect; no direct binding)

BCP ──→ CB2 agonism (Ki 155 nM) ──→ ↓ NF-κB/ERK/JNK ──→ ANTI-INFLAMMATION
      + PPAR-γ/α activation ──────→ ↓ cytokine storm       IMMUNE MODULATION

Linalool ──→ GABA-A PAM ──→ ↑ GABAergic tone ──→ ANXIOLYSIS / SEDATION
           + A2A agonism
           + Glutamate inhibition

α-Pinene ──→ AChEI ──→ ↑ Acetylcholine ──→ Cognitive protection
                                              (potential counter to THC amnesia)

Limonene ──→ 5-HT1A + monoamine ──→ Antidepressant/anxiolytic
           + A2A agonism
           + NF-κB inhibition

            CONVERGENCE: Multiple independent pathways →
            additive/synergistic effects without requiring
            direct cannabinoid receptor binding
```

**The modern understanding**: Terpenes are **multitarget pharmacological agents** that independently produce pain, anxiety, and inflammation modulation primarily through A2A, GABAergic, serotonergic, and monoaminergic pathways. Their "entourage" contribution to cannabis pharmacology is largely through **pharmacodynamic complementarity** rather than direct CB1/CB2 agonism (with the notable exception of BCP at CB2).

---

*Compiled 2025. Evidence graded: IV = in vitro, R = rodent, H = human.*
