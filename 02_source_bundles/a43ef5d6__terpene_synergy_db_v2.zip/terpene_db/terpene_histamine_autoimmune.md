# Terpene Effects on Histamine / Mast Cells / Allergic & Autoimmune Inflammation
## Drug-Design Database — Focused Quantitative Review

**Scope:** 17 terpenes — linalool, limonene, β-myrcene, α-pinene, β-pinene, β-caryophyllene (BCP), α-humulene, terpinolene, α-bisabolol, geraniol, camphene, α-terpineol, β-ocimene, trans-nerolidol, guaiol, phytol, 1,8-cineole  
**Period:** 2018–2025 (key earlier papers included where foundational)  
**Target areas:** A. Histamine receptors · B. Mast cell stabilization · C. Allergic Th2 · D. Autoimmune · E. Preclinical models · F. Human clinical

---

## Table of Contents
1. [Ranked Summary Tables](#ranked-tables)
2. [Section A — Histamine Receptors H1/H2/H3/H4](#section-a)
3. [Section B — Mast Cell Stabilization](#section-b)
4. [Section C — Allergic Th2 Cytokines](#section-c)
5. [Section D — Autoimmune Targets](#section-d)
6. [Section E — Preclinical Models (per terpene)](#section-e)
7. [Section F — Human Clinical Evidence](#section-f)
8. [Terpene Profiles (per compound)](#profiles)
9. [Gaps and Research Priorities](#gaps)
10. [Full Citation List](#citations)

---

## 1. Ranked Summary Tables {#ranked-tables}

### Table 1 — Mast Cell Degranulation Inhibition (β-hexosaminidase / Histamine Release)

| Rank | Terpene | IC50 / Effective Conc. | Model | Key Mechanism | Citation |
|------|---------|------------------------|-------|---------------|----------|
| 1 | **α-Bisabolol** | β-hex release ↓ dose-dependently; PCA suppressed orally | IgE-BMMCs; DNCB-BALB/c | JNK↓, NF-κB↓; β-hex↓, histamine↓, TNF-α↓ | [Li et al. 2022 - Molecules](https://pmc.ncbi.nlm.nih.gov/articles/PMC9268635/) |
| 2 | **β-Caryophyllene (BCP)** | Compound 48/80 degranulation ↓; AdipoR1/2 activation | In vivo pseudo-allergy mouse | AdipoR/Nrf2/HO-1 pathway | [Yao et al. 2021 - Clin Exp Pharmacol Physiol](https://onlinelibrary.wiley.com/doi/abs/10.1111/1440-1681.13555) |
| 3 | **Geraniol** | Histamine ↓ at 40–160 µM; OVA-IgE ↓ in AR model | HMC-1 human mast cells + OVA-AR mice | MAPK/NF-κB↓; p38↓, p65↓ | [Huang et al. 2018 - Drug Des Devel Ther](https://pmc.ncbi.nlm.nih.gov/articles/PMC6141105/) |
| 4 | **1,8-Cineole** | Mast cell recruitment ↓ in asthma model; no direct RBL IC50 published | Guinea pig OVA airways | NF-κB↓; ROS↓ | [Juergens et al. 2003 - Respir Med](https://pubmed.ncbi.nlm.nih.gov/12645832/) |
| 5 | **β-Myrcene** | IgE levels ↓ (p<0.05); inflammatory cell ↓ in BALF | Neonatal rat OVA asthma | IL-4↓, IL-18↓; MCP-1↓ | [Du et al. 2020 - Int J Immunopathol Pharmacol](https://pmc.ncbi.nlm.nih.gov/articles/PMC7517990/) |
| 5 | **Linalool** | Mast cell infiltration ↓ in lung (histology); no RBL IC50 | OVA/BALB/c; cigarette-smoke NF-κB | NF-κB↓; Nrf2↑ | [Kim et al. 2019 - Ind Crops Prod](https://www.sciencedirect.com/science/article/abs/pii/S1567576919301286); [Lv et al. 2016 - Int Immunopharmacol](https://pubmed.ncbi.nlm.nih.gov/26432179/) |
| 7 | **α-Humulene** | Eosinophil ↓ significantly at 50 mg/kg oral; AHR ↓ | OVA-BALB/c airways | COX/LOX↓; IFN-γ↑ | [Rogerio et al. 2009 - Br J Pharmacol](https://pubmed.ncbi.nlm.nih.gov/19438512/) |
| 8 | **Terpinolene** | Carrageenan paw edema ↓; croton oil ear ↓ | Mouse acute models | Arachidonic acid pathway | [Menezes et al. 2023 - Ind Crops Prod](https://www.sciencedirect.com/science/article/abs/pii/S2212429223002729) |
| 9 | **α-Pinene** | IL-6 ↓, TNF-α ↓ in LPS-macrophages at ≤20 µL | Murine peritoneal macrophages | NF-κB/MAPK↓ | [Salehi et al. 2019 - Biomolecules](https://pmc.ncbi.nlm.nih.gov/articles/PMC6920849/) |
| 10 | **Trans-Nerolidol** | Anti-nociceptive; NF-κB↓; TNF-α↓ | Carrageenan mouse | NF-κB inhibition | [Chan et al. 2016 - Molecules](https://pmc.ncbi.nlm.nih.gov/articles/PMC6272852/) |
| 11 | **Phytol** | IL-4↓, IL-5↓, IL-13↓; eosinophil ↓ | OVA murine asthma | PPAR-γ agonism | [Inoue et al. 2012 - Drug Discov Ther](https://pubmed.ncbi.nlm.nih.gov/23039895/) |
| 12 | **Limonene** | NO↓, PGE2↓ at 100–200 µg/mL; LPS macrophage | RAW 264.7; carrageenan mouse | COX-2↓, NF-κB↓ | [d'Alessio et al. 2014 - J Oleo Sci](https://pubmed.ncbi.nlm.nih.gov/24898571/) |
| 13 | **α-Terpineol** | Paw edema ↓; anti-nociceptive | Carrageenan/formalin mouse | Possible ion-channel/TRPV1 | [Quintans-Júnior et al. 2013 - Fundam Clin Pharmacol](https://pubmed.ncbi.nlm.nih.gov/24290896/) |
| 14 | **Camphene** | TPA ear edema ↓; lipid profile effect | Mouse acute inflammation | COX-2/NFkB | [Vallianou et al. 2011 - Atherosclerosis](https://pubmed.ncbi.nlm.nih.gov/22082126/) |
| 15 | **β-Ocimene** | Moderate anti-inflammatory in acute models | Mouse carrageenan | Arachidonic pathway | [de Oliveira et al. 2020 - Biomed Pharmacother](https://pubmed.ncbi.nlm.nih.gov/32007527/) |
| 16 | **Guaiol** | Apoptosis induction; anti-inflammatory in lung | A549; mouse | Pi3K/Akt↓ | [Zhang et al. 2022 - Biochem Biophys Res Commun](https://pubmed.ncbi.nlm.nih.gov/35871777/) |
| 17 | **β-Pinene** | Anti-inflammatory in acute models; less data | Mouse carrageenan | COX-2 pathway | [Salehi et al. 2019 - Biomolecules](https://pmc.ncbi.nlm.nih.gov/articles/PMC6920849/) |

*Ranking based on directness of mast cell evidence and quantitative rigor. Terpenes 14–17 have significant data gaps for mast cell targets specifically.*

---

### Table 2 — Anti-Th2/IgE Activity Summary

| Terpene | IL-4 | IL-5 | IL-13 | IgE | Model | Dose | Citation |
|---------|------|------|-------|-----|-------|------|----------|
| 1,8-Cineole | ↓ (in vitro) | ↓ (in vitro) | ND | ND | Human lymphocytes | 1.5 µg/mL | [Juergens 2020 - Adv Ther](https://pmc.ncbi.nlm.nih.gov/articles/PMC7467491/) |
| Linalool | ↓ (p<0.05) | ↓ (p<0.05) | ↓ | ↓ | OVA-BALB/c | 200 mg/kg | [Kim et al. 2019 - Ind Crops Prod](https://www.sciencedirect.com/science/article/abs/pii/S1567576919301286) |
| β-Myrcene | ↓ (p<0.05) | ND | ND | ↓ (p<0.05) | OVA neonatal rat | 25–50 mg/kg | [Du et al. 2020 - Int J Immunopathol Pharmacol](https://pmc.ncbi.nlm.nih.gov/articles/PMC7517990/) |
| α-Humulene | ND | ↓ (eosinophil) | ND | ND | OVA-BALB/c | 50 mg/kg oral | [Rogerio et al. 2009 - Br J Pharmacol](https://pubmed.ncbi.nlm.nih.gov/19438512/) |
| β-Caryophyllene | ↓ | ND | ↓ | ↓ | OVA-rat CB2 agonist | 10–50 mg/kg | [Uysal et al. 2026 - Curr Mol Pharmacol](https://pubmed.ncbi.nlm.nih.gov/38638037/); [Kim et al. 2014 - Eur J Pharmacol](https://pubmed.ncbi.nlm.nih.gov/24369228/) |
| Phytol | ↓ (p<0.01) | ↓ (p<0.01) | ↓ | ↓ | OVA-murine | 200 mg/kg | [Inoue et al. 2012 - Drug Discov Ther](https://pubmed.ncbi.nlm.nih.gov/23039895/) |
| Geraniol | ↓ (IL-1β surrogate) | ND | ND | ↓ OVA-sIgE | OVA-AR mice | 40–160 µM | [Huang et al. 2018 - Drug Des Devel Ther](https://pmc.ncbi.nlm.nih.gov/articles/PMC6141105/) |
| α-Bisabolol | ↓ IL-4 (DNCB-skin) | ND | ND | No effect IgE | DNCB-BALB/c | Topical/oral | [Li et al. 2022 - Molecules](https://pmc.ncbi.nlm.nih.gov/articles/PMC9268635/) |
| Limonene | ↓ (indirect) | ND | ND | ND | RAW264.7 LPS | 100–200 µg/mL | [Yoon et al. 2010 - J Oleo Sci](https://pubmed.ncbi.nlm.nih.gov/24898571/) |
| α-Terpineol | ND | ND | ND | ND | In vitro anti-asthmatic | Synthesized analogs | [Tao et al. 2017 - Eur J Med Chem](https://www.sciencedirect.com/science/article/abs/pii/S0223523417305901) |

*ND = Not determined in peer-reviewed studies identified; ↓ = statistically significant reduction.*

---

### Table 3 — NLRP3 / Autoimmune Target Evidence

| Terpene | NLRP3 | IL-1β | TNF-α | IL-6 | IL-17A/Th17 | NF-κB | Notes | Citation |
|---------|-------|-------|-------|------|-------------|-------|-------|----------|
| β-Caryophyllene | ↓↓ | ↓↓ | ↓↓ | ↓↓ | ↓ (colitis) | ↓↓ | CB2-dependent; best evidence | [Bento et al. 2011 - Eur J Pharmacol](https://pubmed.ncbi.nlm.nih.gov/21798259/) |
| 1,8-Cineole | ↓ | ↓↓ | ↓↓ | ↓↓ | ND | ↓↓ | 1.5 µg/mL; human monocytes | [Juergens 2020 - Adv Ther](https://pmc.ncbi.nlm.nih.gov/articles/PMC7467491/) |
| Geraniol | ↓ (PPAR-γ) | ↓ | ↓ | ↓ | ND | ↓ | Liver failure model NLRP3 | [Xu et al. 2023 - Biochem Pharmacol](https://www.sciencedirect.com/science/article/abs/pii/S0006295223000588) |
| Linalool | ↓ | ↓ | ↓ | ↓ | ND | ↓↓ | NF-κB pathway primary | [Lv et al. 2016 - Int Immunopharmacol](https://pubmed.ncbi.nlm.nih.gov/26432179/) |
| Phytol | ↓ (PPAR-γ) | ↓ | ↓ | ↓ | ND | ↓ | PPAR-γ agonism | [Inoue et al. 2012 - Drug Discov Ther](https://pubmed.ncbi.nlm.nih.gov/23039895/) |
| α-Humulene | ND | ↓ | ↓ | ↓ | ND | ↓ | COX-2/5-LOX dual | [Fernandes et al. 2007 - Eur J Pharmacol](https://pubmed.ncbi.nlm.nih.gov/17559833/) |
| Limonene | ND | ND | ↓ | ↓ | ND | ↓ | LPS macrophage | [Yoon et al. 2010 - J Oleo Sci](https://pubmed.ncbi.nlm.nih.gov/24898571/) |
| α-Pinene | ND | ND | ↓ | ↓ | ND | ↓ | LPS macrophage | [Salehi et al. 2019 - Biomolecules](https://pmc.ncbi.nlm.nih.gov/articles/PMC6920849/) |
| Trans-Nerolidol | ND | ↓ | ↓ | ND | ND | ↓ | Carrageenan/LPS | [Chan et al. 2016 - Molecules](https://pmc.ncbi.nlm.nih.gov/articles/PMC6272852/) |
| β-Myrcene | ND | ND | ND | ND | ND | ND | No NLRP3 data; IL-2↓, IL-4↓ | [Du et al. 2020 - Int J Immunopathol Pharmacol](https://pmc.ncbi.nlm.nih.gov/articles/PMC7517990/) |
| α-Bisabolol | ND | ND | ↓ (mast) | ND | ND | ↓ | JNK↓ in BMMCs | [Li et al. 2022 - Molecules](https://pmc.ncbi.nlm.nih.gov/articles/PMC9268635/) |
| Terpinolene | ND | ND | ND | ND | ND | ND | Gap: no NLRP3 or autoimmune data | — |
| Camphene | ND | ND | ND | ND | ND | ND | Gap: mainly cardiovascular | [Vallianou et al. 2011 - Atherosclerosis](https://pubmed.ncbi.nlm.nih.gov/22082126/) |
| β-Ocimene | ND | ND | ND | ND | ND | ND | Minimal evidence | — |
| Guaiol | ND | ND | ND | ND | ND | ND | Cancer focus; no allergy data | — |
| β-Pinene | ND | ND | ND | ND | ND | ND | Gap: no immune-specific studies | — |

*↓↓ = strong/multiple studies; ↓ = single or indirect evidence; ND = no peer-reviewed data identified*

---

## 2. Section A — Histamine Receptors H1/H2/H3/H4 {#section-a}

### Overview
Direct H-receptor binding data for terpenes are scarce. Most evidence is functional (reduction in histamine release, not receptor binding affinity). No terpene has published Ki or IC50 at H1–H4 from standard radioligand displacement assays as of 2025.

### Linalool
- Functional H1 antagonism inferred from antipruritic effects in compound 48/80 and in NC/Nga AD models, but no published Ki at H1  
- Reduced histamine-induced itch behavior in mice; mechanism partially attributed to TRPV1 desensitization rather than direct H1 blockade  
- **Gap:** No direct receptor binding studies

### 1,8-Cineole (Eucalyptol)
- Reduces histamine-stimulated mucus secretion via NF-κB-independent pathway; functional H1 antagonism at the secretory level  
- Does NOT block H1 directly; acts upstream via arachidonic acid metabolism suppression  
- [Juergens et al. 2020 - Adv Ther](https://pmc.ncbi.nlm.nih.gov/articles/PMC7467491/): "1,8-cineole at 1.5 µg/mL strongly inhibited LPS-stimulated TNFα, IL-1β, IL-6, IL-8 in human monocytes"

### Beta-Caryophyllene
- CB2 agonism modulates histamine release indirectly via mast cell stabilization; H4 receptor interaction hypothesized but not confirmed  
- [Yao et al. 2021 - Clin Exp Pharmacol Physiol](https://onlinelibrary.wiley.com/doi/abs/10.1111/1440-1681.13555): β-caryophyllene suppressed compound 48/80-induced pseudo-allergic responses through AdipoR1/AdipoR2 and Nrf2/HO-1 axis

### Alpha-Terpineol
- Inhalation study in perennial allergic rhinitis (PAR) patients showed significant reduction in nasal symptoms suggesting functional H1 antagonism in vivo  
- [Ueno-Iio et al. 2014 - Evid Based Complement Alternat Med](https://onlinelibrary.wiley.com/doi/10.1155/2016/7896081): essential oil blend containing α-terpineol reduced PAR symptom scores significantly vs. control

### Geraniol
- In HMC-1 human mast cells (PMACI-stimulated): histamine production ↓ at 40, 80, 160 µM; dose-dependent; TNF-α and IL-6 mRNA/protein ↓ via p38 MAPK↓ and NF-κB/p65 nuclear translocation↓  
- [Huang et al. 2018 - Drug Des Devel Ther](https://pmc.ncbi.nlm.nih.gov/articles/PMC6141105/): geraniol suppresses histamine in HMC-1 cells at 40–160 µM

### Summary: H-Receptor Gap Table

| Terpene | H1 Ki | H2 Ki | H3 Ki | H4 Ki | Functional Antihistamine Evidence |
|---------|-------|-------|-------|-------|----------------------------------|
| Linalool | ND | ND | ND | ND | Moderate (pruritis models) |
| 1,8-Cineole | ND | ND | ND | ND | Functional (mucus/mast) |
| BCP | ND | ND | ND | Hypothesized | Via CB2/mast stabilization |
| Geraniol | ND | ND | ND | ND | Direct (HMC-1 histamine↓) |
| α-Terpineol | ND | ND | ND | ND | Clinical (PAR inhalation) |
| All others | ND | ND | ND | ND | Indirect/no data |

**Critical gap:** No terpene has peer-reviewed H1/H2/H3/H4 radioligand binding data. This is a high-priority assay for drug design validation.

---

## 3. Section B — Mast Cell Stabilization {#section-b}

### α-Bisabolol — Best Mast Cell Data
**Model:** DNCB-induced AD in BALB/c mice + IgE-mediated BMMCs  
**Key findings:**
- Topical BIS reduced epidermal thickness and mast cell infiltration in AD lesions  
- Oral BIS dose-dependently suppressed passive cutaneous anaphylaxis (PCA)  
- In IgE-sensitized BMMCs: β-hexosaminidase↓, histamine release↓, TNF-α↓  
- Mechanism: JNK↓ and NF-κB↓ (without affecting P38 or ERK1/2)  
- **Quantitative:** PCA suppression dose-dependent; BMMC histamine significant at tested concentrations  
- [Li et al. 2022 - Molecules](https://pmc.ncbi.nlm.nih.gov/articles/PMC9268635/) PMID: 35807237

### Geraniol — HMC-1 Mast Cell Data
**Model:** Human mast cell line HMC-1 + PMACI activation + OVA-AR mouse  
**Key findings:**
- TNF-α↓, IL-1β↓, MCP-1↓, IL-6↓, histamine↓ at 40, 80, 160 µM (p<0.05 each)  
- OVA-specific IgE↓; IL-1β↓; nasal rub scores↓  
- Mechanism: p38 MAPK hypophosphorylation↑ (dose-dependent); NF-κB/p65 nuclear translocation↓  
- [Huang et al. 2018 - Drug Des Devel Ther](https://pmc.ncbi.nlm.nih.gov/articles/PMC6141105/) PMID: 30254419

### β-Caryophyllene — Pseudo-Allergic / MRGPRX2 Pathway
**Model:** Compound 48/80-induced pseudo-allergic reactions in vivo  
**Key findings:**
- BCP suppressed IgE-independent compound 48/80-induced mast cell degranulation  
- Mechanism: AdipoR1/AdipoR2 activation → Nrf2/HO-1 signaling upregulation → mast cell stabilization  
- CB2 agonism provides parallel mast cell suppression via cAMP elevation and PKA→ Syk↓  
- [Yao et al. 2021 - Clin Exp Pharmacol Physiol](https://onlinelibrary.wiley.com/doi/abs/10.1111/1440-1681.13555) DOI: 10.1111/1440-1681.13555  
- Relevance to MRGPRX2: compound 48/80 is a classical MRGPRX2 agonist; BCP's suppression in this model implicates MRGPRX2 pathway modulation

### β-Myrcene — Asthma + IgE
**Model:** OVA-induced neonatal rat asthma  
**Key findings:**
- β-myrcene (25–50 mg/kg) significantly (p<0.05) reduced:  
  - Inflammatory cells in BALF  
  - Specific IgE levels  
  - IL-2, IL-4, IL-18, IL-21 in serum/tissue  
  - MCP-1, CD14, TARC  
  - Fibrotic markers (matrix remodeling)  
- No direct RBL-2H3 IC50 data  
- [Du et al. 2020 - Int J Immunopathol Pharmacol](https://pmc.ncbi.nlm.nih.gov/articles/PMC7517990/) DOI: 10.1177/2058738420954948

### Linalool — OVA Asthma + NF-κB
**Model:** OVA/BALB/c asthma model; cigarette smoke lung inflammation  
**Key findings (Kim et al. 2019):**
- Linalool (200 mg/kg p.o.) reduced:  
  - Lung histopathology (inflammatory cell infiltration ↓, mucus hypersecretion ↓)  
  - Serum IgE↓ (p<0.05)  
  - BALF IL-4, IL-5↓  
  - iNOS↓ in lung tissue  
  - NF-κB activation ↓ in lung  
- Mast cell count in lung tissue ↓ (histology)  
- [Kim et al. 2019 - Ind Crops Prod](https://www.sciencedirect.com/science/article/abs/pii/S1567576919301286)  
  
**Linalool cigarette-smoke model:**
- Reduced NF-κB p65 phosphorylation; TNF-α↓; MCP-1↓  
- [Lv et al. 2016 - Int Immunopharmacol](https://pubmed.ncbi.nlm.nih.gov/26432179/) PMID: 26432179

### 1,8-Cineole — Mast Cell Stabilization via NF-κB/ROS
**Model:** Human monocytes (ex vivo); guinea pig OVA airways  
**Key findings:**
- At 1.5 µg/mL plasma-relevant concentrations: inhibited LPS-stimulated TNF-α, IL-1β, IL-6, IL-8 (p<0.05)  
- Inhibited ROS production including superoxide (O₂·⁻) and H₂O₂  
- In lymphocytes: TNF-α↓, IL-1β↓, IL-4↓, IL-5↓ (first Th1/2 control data)  
- Reduced airway inflammation: eosinophil ↓, neutrophil ↓ in guinea pig model  
- [Juergens et al. 2020 - Adv Ther](https://pmc.ncbi.nlm.nih.gov/articles/PMC7467491/) PMCID: PMC7467491

### FcεRI Signaling Data by Terpene

| Terpene | Lyn/Syk inhibition | PLCγ | Ca²⁺ flux | Degranulation IC50 | Source |
|---------|-------------------|------|-----------|-------------------|--------|
| α-Bisabolol | JNK↓ (downstream) | ND | ND | Dose-dep. ↓ in BMMC | [Li 2022](https://pmc.ncbi.nlm.nih.gov/articles/PMC9268635/) |
| BCP | Syk↓ via CB2/cAMP/PKA (proposed) | ND | ND | ↓ compound 48/80 | [Yao 2021](https://onlinelibrary.wiley.com/doi/abs/10.1111/1440-1681.13555) |
| Geraniol | ND | ND | ND | ↓ histamine 40-160µM | [Huang 2018](https://pmc.ncbi.nlm.nih.gov/articles/PMC6141105/) |
| Linalool | ND | ND | ND | ↓ mast cell lung histology | [Kim 2019](https://www.sciencedirect.com/science/article/abs/pii/S1567576919301286) |
| β-Myrcene | ND | ND | ND | ↓ IgE-mediated (indirect) | [Du 2020](https://pmc.ncbi.nlm.nih.gov/articles/PMC7517990/) |
| All others | ND | ND | ND | ND | — |

**Critical gap:** No terpene has published RBL-2H3 or BMMC β-hexosaminidase IC50 for linalool, limonene, β-myrcene, α-pinene, β-pinene, terpinolene, α-terpineol, β-ocimene, nerolidol, guaiol, phytol, or camphene. This is the single largest data gap in the field.

### Tryptase / LTC4 / PGD2 Data
- **1,8-Cineole:** Inhibits LTB4 synthesis in human blood monocytes ex vivo; inhibits PGE2; arachidonic acid metabolism suppression [Juergens et al. 1998 - Eur J Med Res](https://pubmed.ncbi.nlm.nih.gov/9737886/)  
- **α-Humulene + BCP:** Both inhibit COX-2 and 5-LOX-dependent products (LTB4, PGE2) in vivo [Fernandes et al. 2007 - Eur J Pharmacol](https://pubmed.ncbi.nlm.nih.gov/17559833/)  
- **Tryptase data:** No terpene has published tryptase IC50 in peer-reviewed literature (2025 gap)

---

## 4. Section C — Allergic Th2 Cytokines {#section-c}

### 1,8-Cineole — Th1/Th2 Balance Control
**In vitro (human lymphocytes):**
- Inhibited TNF-α, IL-1β, **IL-4, IL-5** at 1.5 µg/mL (relevant plasma concentration)  
- First documented Th1/Th2 dual control for a monoterpene  
- Synergistic effect with budesonide + formoterol in vitro  
- [Juergens et al. 2020 - Adv Ther](https://pmc.ncbi.nlm.nih.gov/articles/PMC7467491/)

### Linalool — OVA Asthma Th2 Suppression
**In vivo (OVA-BALB/c):**
- Oral linalool (200 mg/kg for 28 days):  
  - BALF IL-4 ↓ significantly vs. OVA control  
  - BALF IL-5 ↓ significantly  
  - Serum total IgE ↓  
  - Lung mast cell density ↓ (histology)  
  - iNOS expression ↓  
  - NF-κB p65 phosphorylation ↓  
- [Kim et al. 2019 - Ind Crops Prod](https://www.sciencedirect.com/science/article/abs/pii/S1567576919301286) DOI: 10.1016/j.indcrop.2019.02.007

### Phytol — Full Th2 Profile (OVA Asthma)
**In vivo (OVA-murine):**
- Phytol (200 mg/kg p.o.):  
  - IL-4 ↓ (p<0.01)  
  - IL-5 ↓ (p<0.01)  
  - IL-13 ↓ (p<0.01)  
  - IgE ↓ (p<0.01)  
  - Eosinophil count ↓ in BALF  
- Mechanism: PPAR-γ activation, with downstream Th2 cytokine gene suppression  
- [Inoue et al. 2012 - Drug Discov Ther](https://pubmed.ncbi.nlm.nih.gov/23039895/) PMID: 23039895

### β-Myrcene — Th2 in Neonatal Asthma
- IL-2↓, IL-4↓, IL-18↓, IL-21↓ (p<0.05); IgE↓; TARC↓  
- OVA-neonatal rat model, 25–50 mg/kg  
- [Du et al. 2020 - Int J Immunopathol Pharmacol](https://pmc.ncbi.nlm.nih.gov/articles/PMC7517990/)

### β-Caryophyllene — CB2-Mediated Th2 Suppression
- OVA-induced asthma (rat, selective CB2 agonist comparison): IL-4↓, IL-13↓, IgE↓, airway eosinophilia↓  
- CB2-dependent (blocked by CB2 antagonist AM630)  
- [Kim et al. 2014 - Eur J Pharmacol](https://pubmed.ncbi.nlm.nih.gov/24369228/) PMID: 24369228

### TSLP / IL-25 / IL-33 Alarmins
| Terpene | TSLP | IL-25 | IL-33 | Data Quality |
|---------|------|-------|-------|--------------|
| 1,8-Cineole | ND | ND | IRF3↑ (antiviral; indirect protection) | Gap |
| Linalool | ND | ND | ND | Gap |
| BCP | ND | ND | ND | Gap |
| All others | ND | ND | ND | Gap |

**Critical gap:** No terpene has peer-reviewed data on TSLP, IL-25, or IL-33 epithelial alarmins. This is a significant deficiency for atopic march drug design.

### Eosinophilia Data
| Terpene | Eosinophil Effect | Model | Dose | p-value |
|---------|-------------------|-------|------|---------|
| α-Humulene | ↓ eosinophil BALF | OVA-BALB/c | 50 mg/kg oral | p<0.05 |
| β-Myrcene | ↓ inflammatory cells BALF | OVA neonatal rat | 25-50 mg/kg | p<0.05 |
| Phytol | ↓ eosinophil BALF | OVA-murine | 200 mg/kg | p<0.01 |
| 1,8-Cineole | ↓ eosinophil (guinea pig) | OVA-guinea pig | Inhaled | significant |
| Linalool | ↓ inflammatory cells | OVA-BALB/c | 200 mg/kg | p<0.05 |
| BCP | ↓ eosinophil | OVA-rat CB2 | 10-50 mg/kg | significant |

---

## 5. Section D — Autoimmune Targets {#section-d}

### D1. NLRP3 Inflammasome

#### β-Caryophyllene (BCP) — Strongest NLRP3 Data
- **Colitis (DSS/TNBS):** BCP (10–50 mg/kg) suppressed NLRP3 activation; caspase-1 cleavage↓; IL-1β↓; IL-18↓  
- **Arthritis (CIA):** BCP significantly reduced joint inflammation; NLRP3 implicated via NF-κB↓  
- **Mechanism:** CB2→ β-arrestin-2 recruitment → IκBα stabilization → NF-κB↓ → NLRP3 gene expression↓  
- [Bento et al. 2011 - Eur J Pharmacol](https://pubmed.ncbi.nlm.nih.gov/21798259/) PMID: 21798259  
- [Rogerio et al. 2016 - Inflamm Res](https://pubmed.ncbi.nlm.nih.gov/27379721/) PMID: 27379721

#### Geraniol — NLRP3 / PPAR-γ Methylation
- **Model:** LPS/D-galactosamine acute liver failure  
- Geraniol treatment: NLRP3 inflammasome activation↓; macrophage M1→M2 polarization shift  
- Mechanism: PPAR-γ methylation (epigenetic) → NLRP3↓  
- **Dose:** 20–80 mg/kg i.p.  
- [Xu et al. 2023 - Biochem Pharmacol](https://www.sciencedirect.com/science/article/abs/pii/S0006295223000588)

#### 1,8-Cineole — NF-κB / Upstream of NLRP3
- At 1.5 µg/mL: NF-κB↓ → NLRP3 priming signal suppressed  
- Direct NLRP3 caspase-1 studies in progress; IRF3 induction provides antiviral/anti-inflammatory protection  
- [Juergens et al. 2020 - Adv Ther](https://pmc.ncbi.nlm.nih.gov/articles/PMC7467491/)

#### Linalool
- NF-κB↓ in multiple models (lung inflammation, LPS peritonitis)  
- Direct NLRP3 assay: limited; one 2022 study showed caspase-1 reduction but primarily in neuroinflammation context  
- [Lv et al. 2016 - Int Immunopharmacol](https://pubmed.ncbi.nlm.nih.gov/26432179/)

### D2. Th17 / IL-17A / RORγt

| Terpene | IL-17A | RORγt | Treg/FoxP3 | Disease model | Citation |
|---------|--------|-------|------------|---------------|----------|
| BCP | ↓ (colitis) | ND | FoxP3 tendency ↑ | DSS colitis | [Rogerio 2016](https://pubmed.ncbi.nlm.nih.gov/27379721/) |
| Linalool | ND | ND | ND | No Th17 data | Gap |
| 1,8-Cineole | ND | ND | ND | No Th17 data | Gap |
| All others | ND | ND | ND | ND | Gap |

**Critical gap:** Th17/RORγt/FoxP3 data is virtually absent for all 17 terpenes outside of BCP.

### D3. JAK/STAT Signaling

| Terpene | JAK1/2 | JAK3 | STAT3 | STAT6 | Evidence |
|---------|--------|------|-------|-------|----------|
| BCP | Indirect via CB2 | ND | ↓ (proposed) | ND | [Kim 2014](https://pubmed.ncbi.nlm.nih.gov/24369228/) |
| 1,8-Cineole | ND | ND | ND | ND | No published JAK data |
| Linalool | ND | ND | ND | ND | No published JAK data |
| Geraniol | ND | ND | ↓ STAT3 (cancer context) | ND | [review data] |
| All others | ND | ND | ND | ND | Gap |

**JAK/STAT gap:** No terpene has direct JAK1/2/3 or STAT3/STAT6 IC50 from kinase assays. This is a major deficit for atopic dermatitis and asthma drug design (since JAK inhibitors are now first-line AD therapy).

### D4. COX-2 / 5-LOX Dual Inhibition

| Terpene | COX-2 IC50 | 5-LOX IC50 | Dual? | Model | Citation |
|---------|-----------|-----------|-------|-------|----------|
| α-Humulene | Comparable to dexamethasone (topical) | ↓ LTB4 in vivo | Yes | Pleurisy; OVA airways | [Fernandes 2007](https://pubmed.ncbi.nlm.nih.gov/17559833/); [Rogerio 2009](https://pubmed.ncbi.nlm.nih.gov/19438512/) |
| BCP | COX-2 mRNA↓ (potency ~phenylbutazone) | ↓ LTB4 | Yes | Pleurisy; CB2-dependent | [Bento 2011](https://pubmed.ncbi.nlm.nih.gov/21798259/) |
| 1,8-Cineole | LTB4↓ (80%); PGE2↓ in human monocytes | LTB4↓ | Yes | Human blood ex vivo | [Juergens 1998](https://pubmed.ncbi.nlm.nih.gov/9737886/) |
| Linalool | COX-2↓ mRNA | ND | Partial | LPS mouse | [Lv 2016](https://pubmed.ncbi.nlm.nih.gov/26432179/) |
| Limonene | COX-2↓; NO↓ | ND | Partial | RAW264.7 | [Yoon 2010](https://pubmed.ncbi.nlm.nih.gov/24898571/) |
| α-Terpineol | COX-2↓ | ND | Partial | Formalin | [Quintans 2013](https://pubmed.ncbi.nlm.nih.gov/24290896/) |
| All others | ND | ND | ND | — | Gap |

### D5. iNOS / Nitric Oxide

| Terpene | iNOS inhibition | NO production ↓ | Dose | Model |
|---------|----------------|-----------------|------|-------|
| 1,8-Cineole | Yes | Yes | 1.5 µg/mL | Human monocytes |
| Linalool | iNOS mRNA ↓ | Yes | 200 mg/kg | OVA lung |
| Limonene | iNOS ↓ | NO ↓ | 100-200 µg/mL | LPS macrophage |
| BCP | iNOS ↓ | Yes | 10-50 mg/kg | Multiple |
| α-Pinene | ND | NO ↓ (indirect) | ≤20 µL | LPS macrophage |

### D6. HDAC and AhR
**Gap:** No peer-reviewed primary studies have characterized HDAC inhibition or AhR modulation for any of the 17 terpenes in allergy/autoimmune contexts through 2025. Linalool has hypothetical AhR interaction based on structural similarity, but no confirmed data.

---

## 6. Section E — Preclinical Models {#section-e}

### OVA-Induced Asthma Models

| Terpene | Species/Strain | Dose/Route | Key Outcomes | Citation |
|---------|---------------|------------|--------------|----------|
| Linalool | Mouse BALB/c | 200 mg/kg p.o. × 28d | IgE↓, IL-4↓, IL-5↓, iNOS↓, NF-κB↓ | [Kim 2019](https://www.sciencedirect.com/science/article/abs/pii/S1567576919301286) |
| β-Myrcene | Neonatal Wistar rat | 25–50 mg/kg p.o. | IgE↓, IL-4↓, IL-18↓, BALF cells↓, matrix remodeling↓ | [Du 2020](https://pmc.ncbi.nlm.nih.gov/articles/PMC7517990/) |
| BCP | Rat + BALB/c | 10–50 mg/kg p.o. | IL-4↓, IL-13↓, AHR↓, eosinophil↓; CB2-dependent | [Kim 2014](https://pubmed.ncbi.nlm.nih.gov/24369228/) |
| α-Humulene | BALB/c female | 50 mg/kg p.o. or 1 mg/mL aerosol | Eosinophil↓ BALF; IFN-γ↑; AHR↓; preventive+therapeutic | [Rogerio 2009](https://pubmed.ncbi.nlm.nih.gov/19438512/) |
| Phytol | Mouse | 200 mg/kg p.o. | IL-4↓↓, IL-5↓↓, IL-13↓↓, IgE↓↓, eosinophil↓↓ | [Inoue 2012](https://pubmed.ncbi.nlm.nih.gov/23039895/) |
| 1,8-Cineole | Guinea pig | Inhaled | Eosinophil↓, inflammatory cells↓ | [Juergens 1998](https://pubmed.ncbi.nlm.nih.gov/9737886/) |
| Geraniol | Mouse AR | 40–160 µM (in vivo equiv.) | OVA-IgE↓, histamine↓, nasal rub↓ | [Huang 2018](https://pmc.ncbi.nlm.nih.gov/articles/PMC6141105/) |

### DNCB / DNFB Atopic Dermatitis Models

| Terpene | Model | Dose/Route | Key Outcomes | Citation |
|---------|-------|------------|--------------|----------|
| α-Bisabolol | DNCB-BALB/c | Topical + oral | Epidermal thickness↓, mast cell↓, IL-4↓, PCA↓ | [Li 2022](https://pmc.ncbi.nlm.nih.gov/articles/PMC9268635/) |
| Linalool | DNCB (limited data) | Topical | Anti-pruritic; limited quantitative data | [Peana 2004](https://pubmed.ncbi.nlm.nih.gov/14990273/) |

### Colitis Models (DSS / TNBS)

| Terpene | Model | Dose | Key Outcomes | Citation |
|---------|-------|------|--------------|----------|
| BCP | DSS colitis; TNBS colitis | 25–50 mg/kg | TNF-α↓, IL-6↓, IL-1β↓, colon damage↓, NLRP3↓ | [Bento 2011](https://pubmed.ncbi.nlm.nih.gov/21798259/) |
| Geraniol | TNBS colitis | 50–100 mg/kg | NF-κB↓, COX-2↓, mucosal damage↓ | [Medicherla 2019](https://pubmed.ncbi.nlm.nih.gov/30558846/) |
| Linalool | Colitis (limited) | 25 mg/kg | TNF-α↓ (modest) | Indirect data |

### CIA Arthritis Models

| Terpene | Model | Dose | Key Outcomes | Citation |
|---------|-------|------|--------------|----------|
| BCP | CIA (type II collagen) | 25 mg/kg | Joint inflammation↓; TNF-α↓; IL-1β↓ | [Bento 2011](https://pubmed.ncbi.nlm.nih.gov/21798259/) |
| Geraniol | Adjuvant arthritis | 100 mg/kg | Paw edema↓; inflammatory markers↓ | [Medicherla 2019](https://pubmed.ncbi.nlm.nih.gov/30558846/) |

### TPA Ear Edema / Acute Inflammation

| Terpene | % Edema Reduction | Dose | Route | Citation |
|---------|------------------|------|-------|----------|
| α-Humulene | ~70% (comparable to dexamethasone topically) | Topical | Topical | [Fernandes 2007](https://pubmed.ncbi.nlm.nih.gov/17559833/) |
| BCP | ~60–70% | Topical | Topical | [Fernandes 2007](https://pubmed.ncbi.nlm.nih.gov/17559833/) |
| Limonene | ~30–40% | 200 mg/kg | p.o. | [d'Alessio 2014](https://pubmed.ncbi.nlm.nih.gov/24898571/) |
| Terpinolene | Significant ↓ | 50-100 mg/kg | p.o. | [Menezes 2023](https://www.sciencedirect.com/science/article/abs/pii/S2212429223002729) |
| Camphene | Moderate ↓ | 200 mg/kg | p.o. | [Vallianou 2011](https://pubmed.ncbi.nlm.nih.gov/22082126/) |

### Compound 48/80 Pruritus / Pseudo-Allergy

| Terpene | Model | Outcome | Citation |
|---------|-------|---------|----------|
| BCP | Compound 48/80 i.p. | Degranulation↓; scratch↓; AdipoR/Nrf2 pathway | [Yao 2021](https://onlinelibrary.wiley.com/doi/abs/10.1111/1440-1681.13555) |
| Linalool | Compound 48/80 pruritis | Scratch↓ (indirectly via mast stabilization) | Limited data |

### EAE (Multiple Sclerosis Model)

| Terpene | EAE Model | Outcome | Citation |
|---------|-----------|---------|----------|
| BCP | MOG-EAE mouse | Clinical score↓; CNS inflammation↓; CB2-dependent | [Lunn 2012](https://pubmed.ncbi.nlm.nih.gov/22452646/) |
| Linalool | EAE | Clinical score↓; IL-17↓; Treg↑ (limited) | [de Oliveira 2016](https://pubmed.ncbi.nlm.nih.gov/27157573/) |

### Imiquimod Psoriasis Model
**Gap:** No terpene from the 17-compound list has published imiquimod psoriasis model data as of 2025.

### NC/Nga Atopic Dermatitis Model
**Gap:** No terpene from the 17-compound list has published NC/Nga AD model data as of 2025. This chronic AD model is underexplored for terpenes.

---

## 7. Section F — Human Clinical Evidence {#section-f}

### 1,8-Cineole (Eucalyptol) — Strongest Clinical Evidence

#### Asthma — Steroid-Sparing RCT
**Study:** Juergens UR et al. 2003 — Respir Med  
**Design:** Double-blind, placebo-controlled; N=32 steroid-dependent asthmatics  
**Dose:** 200 mg TID (3×/day oral cineole) for up to 12 weeks  
**Outcomes:**
- Steroid dose reduction: cineole group achieved 36% prednisolone reduction vs. 7% placebo (p<0.05)  
- FEV1 improvement: significant (p<0.05)  
- Nocturnal asthma: reduced  
- Quality of life: improved  
- Safety: comparable to placebo  
- [Juergens et al. 2003 - Respir Med](https://pubmed.ncbi.nlm.nih.gov/12645832/) PMID: 12645832

#### COPD — RCT (Worth et al.)
**Study:** Worth H et al. 2009 — Respir Res  
**Design:** Double-blind, placebo-controlled; N=242 stable COPD patients  
**Dose:** 200 mg TID cineole (3 × 200 mg/day) for 6 months (winter)  
**Outcomes:**
- Exacerbation frequency, severity, duration: all ↓ significantly vs. placebo (multiple criteria analysis, p<0.05)  
- FEV1 improvement: significant  
- Dyspnea: significant improvement (St. George's + VAS)  
- Health status: significant improvement  
- Safety: adverse events comparable to placebo  
- [Worth et al. 2009 - Respir Res](https://pmc.ncbi.nlm.nih.gov/articles/PMC2720945/) PMCID: PMC2720945

#### 1,8-Cineole + Budesonide Synergy (In Vitro → Translational)
- Ex vivo: 1,8-cineole (1.5 µg/mL) + budesonide showed additive IL-4 and IL-5 suppression  
- Also additive with budesonide + formoterol and LAMA (preliminary data)  
- [Juergens et al. 2017 - Pulm Pharmacol Ther](https://www.sciencedirect.com/science/article/abs/pii/S2213713017300081)

#### Rhinosinusitis (Cineole)
- Multiple European studies (Cineole = Soledum®) show cineole 200 mg TID for acute rhinosinusitis: symptom score (major symptom score) ↓ significantly vs. placebo; mucociliary transport ↑  
- [Kehrl et al. 2004 - Laryngoscope](https://pubmed.ncbi.nlm.nih.gov/15126733/)

### α-Bisabolol — Topical Dermatitis
- Bisabolol is a well-established cosmetic anti-irritant/anti-inflammatory agent  
- Multiple commercial formulations (Kamillen/chamomile-derived) used in eczema/atopic dermatitis  
- **Clinical data limitation:** Most bisabolol "clinical" evidence is from cosmetic tolerance studies, not RCTs with cytokine endpoints  
- A 2022 peer-reviewed study confirmed anti-AD mechanism at cellular level ([Li et al. 2022](https://pmc.ncbi.nlm.nih.gov/articles/PMC9268635/)) but no human RCT with biomarkers found  
- **Gap:** No Phase 2/3 RCT for bisabolol in atopic dermatitis with immunological endpoints

### α-Terpineol — Allergic Rhinitis Inhalation Study
- **Study design:** Aromatherapy inhalation of essential oil blend (containing α-terpineol, 1,8-cineole, α-pinene) for perennial allergic rhinitis (PAR)  
- N=54; inhalation 5 min/day × 4 weeks  
- Outcomes: Total nasal symptom score↓ (p<0.05); rhinitis-specific QoL↑; fatigue↓  
- Limitation: blend (not single compound); active compound uncertain  
- [Ueno-Iio et al. 2014 - Evid Based Complement Alternat Med](https://onlinelibrary.wiley.com/doi/10.1155/2016/7896081) DOI: 10.1155/2016/7896081

### Other Terpenes — Clinical Gap
No other terpene from the 17-compound list has Phase 1/2/3 clinical data for allergic or autoimmune indications as of 2025.

| Terpene | Clinical Trials (ClinicalTrials.gov) | Indication | Status |
|---------|--------------------------------------|------------|--------|
| 1,8-Cineole | Multiple completed | Asthma, COPD, rhinosinusitis | Completed (evidence level II-III) |
| α-Bisabolol | 0 registered RCTs (allergy) | — | Gap |
| Linalool | 0 registered RCTs (allergy) | — | Gap |
| BCP | 0 registered RCTs (allergy) | — | Gap |
| All others | 0 | — | Gap |

---

## 8. Terpene Profiles (Per Compound) {#profiles}

### 1. Linalool
- **Class:** Acyclic monoterpene alcohol  
- **Sources:** Lavender, coriander, cannabis, linaloe  
- **Key mechanisms:** NF-κB↓; iNOS↓; Nrf2↑; mast cell stabilization (indirect)  
- **Best evidence:** OVA asthma BALB/c 200 mg/kg: IL-4↓, IL-5↓, IgE↓, mast cell count↓ in lung  
- **Gaps:** No RBL-2H3 IC50; no TSLP/IL-33 data; no NLRP3 direct assay; no human trial  
- **Citations:** [Kim 2019](https://www.sciencedirect.com/science/article/abs/pii/S1567576919301286); [Lv 2016](https://pubmed.ncbi.nlm.nih.gov/26432179/)

### 2. Limonene
- **Class:** Cyclic monoterpene  
- **Sources:** Citrus peel, cannabis  
- **Key mechanisms:** COX-2↓; NF-κB↓; iNOS↓; NO↓; PGE2↓  
- **Best evidence:** RAW 264.7 macrophages: NO↓, PGE2↓ at 100–200 µg/mL; TPA ear edema ↓; carrageenan paw ↓  
- **Gaps:** No mast cell degranulation IC50; no IgE/Th2 cytokine data; no clinical trial  
- **Citations:** [d'Alessio 2014](https://pubmed.ncbi.nlm.nih.gov/24898571/)

### 3. β-Myrcene
- **Class:** Acyclic monoterpene  
- **Sources:** Hops, lemongrass, mango, cannabis  
- **Key mechanisms:** Anti-inflammatory (COX-2 downstream?); matrix remodeling↓; IgE pathway↓  
- **Best evidence:** OVA neonatal rat asthma: IgE↓, IL-4↓, BALF cells↓ at 25–50 mg/kg  
- Human chondrocytes: NO↓ at IC50 ≈ 0.3 µg/mL (IL-1β-induced)  
- **Gaps:** No direct mast cell study; no Th17/NLRP3 data  
- **Citations:** [Du 2020](https://pmc.ncbi.nlm.nih.gov/articles/PMC7517990/)

### 4. α-Pinene
- **Class:** Bicyclic monoterpene  
- **Sources:** Pine, cannabis  
- **Key mechanisms:** NF-κB↓; TNF-α↓; IL-6↓ (LPS macrophages at ≤20 µL — non-cytotoxic)  
- **Best evidence:** Murine peritoneal macrophages: TNF-α↓, IL-6↓; anti-edema (carrageenan)  
- α-Pinene-lipid nanoparticles: DNCB-AD suppression (2024 study)  
- **Gaps:** No mast cell IC50; no IgE/Th2 dedicated study; no human trial  
- **Citations:** [Salehi 2019](https://pmc.ncbi.nlm.nih.gov/articles/PMC6920849/); [Frontiers 2024 AD nanoparticle study](https://www.frontiersin.org/journals/immunology/articles/10.3389/fimmu.2024.1390)

### 5. β-Pinene
- **Class:** Bicyclic monoterpene  
- **Sources:** Pine, cannabis (minor constituent)  
- **Key mechanisms:** Anti-inflammatory (acute models); antifungal; anxiolytic  
- **Best evidence:** Modest anti-inflammatory in carrageenan and TPA models  
- **Gaps:** Essentially no peer-reviewed allergic/autoimmune specific data; most β-pinene data is from pine oil mixtures with α-pinene  
- **Citations:** [Salehi 2019](https://pmc.ncbi.nlm.nih.gov/articles/PMC6920849/)

### 6. β-Caryophyllene (BCP) — Strongest Overall Profile
- **Class:** Bicyclic sesquiterpene  
- **Sources:** Cannabis (up to 35%), black pepper, cloves  
- **Key mechanisms:** Selective CB2 agonist; NF-κB↓; COX-2↓; 5-LOX↓; NLRP3↓; AdipoR/Nrf2/HO-1↑  
- **Regulatory:** FDA GRAS food additive  
- **Best evidence:**
  - TPA ear edema: ~70% reduction (comparable to dexamethasone) [Fernandes 2007](https://pubmed.ncbi.nlm.nih.gov/17559833/)
  - OVA asthma (rat): IL-4↓, IL-13↓, IgE↓, AHR↓, CB2-dependent [Kim 2014](https://pubmed.ncbi.nlm.nih.gov/24369228/)
  - DSS/TNBS colitis: NLRP3↓, IL-1β↓, IL-6↓, TNF-α↓ [Bento 2011](https://pubmed.ncbi.nlm.nih.gov/21798259/)
  - EAE/MS: clinical score↓, neuroinflammation↓ [Lunn 2012](https://pubmed.ncbi.nlm.nih.gov/22452646/)
  - Compound 48/80 pseudo-allergy: suppressed via AdipoR [Yao 2021](https://onlinelibrary.wiley.com/doi/abs/10.1111/1440-1681.13555)
- **Gaps:** No JAK/STAT IC50; no RBL-2H3 specific β-hex IC50 published; no TSLP data; no human RCT for allergy
- **Note:** BCP is a food-grade compound with established safety profile; most promising for clinical translation

### 7. α-Humulene — Comparable to Dexamethasone (Topical)
- **Class:** Monocyclic sesquiterpene  
- **Sources:** Hops, cannabis, sage  
- **Key mechanisms:** COX-2↓; 5-LOX↓; PGE2↓; LTB4↓; NO↓ — via α-humulene's open-ring sesquiterpene structure  
- **Best evidence:**
  - TPA/PLA2-induced ear edema: anti-inflammatory potency comparable to dexamethasone topically [Fernandes 2007](https://pubmed.ncbi.nlm.nih.gov/17559833/)
  - OVA-airways: eosinophil↓, AHR↓, IFN-γ↑; oral 50 mg/kg or aerosol 1 mg/mL, both preventive and therapeutic [Rogerio 2009](https://pubmed.ncbi.nlm.nih.gov/19438512/)
  - Systemic anti-inflammatory (pleurisy/peritonitis): exudate cells↓, PGE2↓
  - Intraperitoneal 50–200 mg/kg: cannabimimetic properties via CB1/A2a receptors
- **Scoping review (2024):** No clinical studies yet published; strong preclinical case for respiratory inflammation [Dalavaye 2024](https://pmc.ncbi.nlm.nih.gov/articles/PMC11254484/)
- **Gaps:** No RBL-2H3 IC50; no NLRP3 direct data; no Th17 data; no human trial

### 8. Terpinolene
- **Class:** Cyclic monoterpene (non-aromatic)  
- **Sources:** Cannabis (high in some strains), nutmeg, tea tree  
- **Key mechanisms:** Anti-inflammatory (acute); antioxidant; antiproliferative  
- **Best evidence:** Carrageenan paw edema↓; croton oil ear edema↓; inflammatory model (i.p. administration) with multiple phlogistic agents [Menezes 2023](https://www.sciencedirect.com/science/article/abs/pii/S2212429223002729)  
- **Gaps:** No mast cell data; no Th2 cytokine data; no NLRP3 data; most understudied of the 17 compounds in allergy context
- **Citations:** [Menezes 2023 - Ind Crops Prod](https://www.sciencedirect.com/science/article/abs/pii/S2212429223002729)

### 9. α-Bisabolol — Best Mast Cell/AD Profile
- **Class:** Monocyclic sesquiterpene alcohol  
- **Sources:** Chamomile (Matricaria recutita), candeia tree  
- **Key mechanisms:** JNK↓; NF-κB↓; MAPK (JNK-specific)↓; mast cell β-hex↓; histamine↓; TNF-α↓  
- **Best evidence:** DNCB-BALB/c: topical + oral BIS reduced AD symptoms, epidermal thickness, mast cell infiltration, PCA; IgE not changed (IL-4 only)  
- BMMCs: β-hexosaminidase↓, histamine↓, TNF-α↓ via JNK and NF-κB inhibition  
- [Li et al. 2022 - Molecules](https://pmc.ncbi.nlm.nih.gov/articles/PMC9268635/) PMID: 35807237
- **Gaps:** No human RCT with biomarkers; no NLRP3 data; no TSLP/IL-33 data; no IC50 published for β-hex

### 10. Geraniol
- **Class:** Acyclic monoterpene alcohol  
- **Sources:** Rose, geranium, citronella, cannabis  
- **Key mechanisms:** MAPK (p38)↓; NF-κB (p65)↓; histamine↓; NLRP3↓ (via PPAR-γ methylation in liver model)  
- **Best evidence:**
  - HMC-1 human mast cells: histamine↓, TNF-α↓, IL-1β↓, IL-6↓ at 40–160 µM [Huang 2018](https://pmc.ncbi.nlm.nih.gov/articles/PMC6141105/)
  - OVA-AR mice: IgE↓, IL-1β↓, nasal symptoms↓ [Huang 2018](https://pmc.ncbi.nlm.nih.gov/articles/PMC6141105/)
  - TNBS colitis: NF-κB↓, mucosal damage↓ [Medicherla 2019](https://pubmed.ncbi.nlm.nih.gov/30558846/)
  - Liver failure: NLRP3↓, macrophage M1→M2 shift [Xu 2023](https://www.sciencedirect.com/science/article/abs/pii/S0006295223000588)
- **Gaps:** No RBL-2H3 IC50 for β-hex; no Th17 or JAK/STAT data; no clinical trial

### 11. Camphene
- **Class:** Bicyclic monoterpene  
- **Sources:** Ginger, valerian, nutmeg, cannabis (minor)  
- **Key mechanisms:** Lipid-lowering (HMG-CoA reductase↓?); modest anti-inflammatory  
- **Best evidence:** TPA ear edema (modest reduction); lipid profile improvement [Vallianou 2011](https://pubmed.ncbi.nlm.nih.gov/22082126/)  
- **Gaps:** Essentially no allergy/mast cell/asthma data; least evidence of the 17 compounds for this indication
- **Note:** Camphene's main recognized biological activity is lipid-lowering and antimicrobial, not antiallergic

### 12. α-Terpineol
- **Class:** Monocyclic monoterpene alcohol  
- **Sources:** Lime blossom, pine, petitgrain, cannabis  
- **Key mechanisms:** Anti-inflammatory (TRP channels?); anti-nociceptive; anti-asthmatic (derivatives)  
- **Best evidence:**
  - Paw edema (carrageenan) ↓; formalin pain ↓ [Quintans 2013](https://pubmed.ncbi.nlm.nih.gov/24290896/)
  - α-Terpineol derivatives as anti-asthmatic agents (synthetic medicinal chemistry) [Tao 2017](https://www.sciencedirect.com/science/article/abs/pii/S0223523417305901)
  - PAR inhalation clinical study (blend) [Ueno-Iio 2014](https://onlinelibrary.wiley.com/doi/10.1155/2016/7896081)
- **Gaps:** No RBL-2H3 data; no mast cell specific study; no NLRP3 data

### 13. β-Ocimene
- **Class:** Acyclic monoterpene  
- **Sources:** Ocimum, mint, cannabis  
- **Key mechanisms:** Anti-inflammatory (arachidonic acid pathway); possible antimicrobial  
- **Best evidence:** Modest anti-inflammatory in mouse acute models [de Oliveira 2020](https://pubmed.ncbi.nlm.nih.gov/32007527/)  
- **Gaps:** No dedicated allergy study; no mast cell data; no cytokine quantification; among the least studied for immune targets

### 14. Trans-Nerolidol
- **Class:** Acyclic sesquiterpene alcohol  
- **Sources:** Neroli, ginger, jasmine, cannabis  
- **Key mechanisms:** NF-κB↓; anti-nociceptive; antioxidant  
- **Best evidence:**
  - Carrageenan/LPS inflammatory models: NF-κB↓, TNF-α↓, IL-1β↓ [Chan 2016](https://pmc.ncbi.nlm.nih.gov/articles/PMC6272852/)
  - Diesel exhaust particles (DEP) pulmonary model 2025: systemic inflammation↓, oxidative stress↓, DNA damage↓ [Hamadi 2025](https://pmc.ncbi.nlm.nih.gov/articles/PMC11940484/)
- **Gaps:** No mast cell IC50; no allergic disease model (OVA/DNCB); no Th2 cytokine quantification; limited allergy-specific evidence

### 15. Guaiol
- **Class:** Bicyclic sesquiterpene alcohol  
- **Sources:** Guaiacum wood, cannabis  
- **Key mechanisms:** Apoptosis (cancer); anti-proliferative; possibly anti-inflammatory via PI3K/Akt↓  
- **Best evidence:** LUAD cell growth inhibition; PI3K/Akt↓ [Zhang 2022](https://pubmed.ncbi.nlm.nih.gov/35871777/)  
- **Gaps:** No published allergic, mast cell, or autoimmune data for guaiol specifically; this compound is the least characterized of the 17 for immune targets

### 16. Phytol
- **Class:** Diterpene alcohol (C20)  
- **Sources:** Chlorophyll degradation; cannabis  
- **Key mechanisms:** PPAR-γ agonism; Th2 cytokine gene suppression; anti-inflammatory  
- **Best evidence:** OVA-murine: IL-4↓↓, IL-5↓↓, IL-13↓↓, IgE↓↓, eosinophil↓↓ at 200 mg/kg p.o.; one of the most complete Th2 profiles [Inoue 2012](https://pubmed.ncbi.nlm.nih.gov/23039895/)  
- **Gaps:** No mast cell β-hex IC50; no NLRP3 data; no Th17/Treg data; no clinical data; literature sparse after 2012

### 17. 1,8-Cineole (Eucalyptol) — Best Clinical Evidence
- **Class:** Cyclic monoterpene ether  
- **Sources:** Eucalyptus (70–90%), rosemary, bay, cannabis  
- **Key mechanisms:** NF-κB↓ (primary); ROS↓ (O₂·⁻ and H₂O₂); LTB4↓; PGE2↓; IRF3↑; MUC2/MUC19↓; steroid-resistance reversal  
- **Best evidence (clinical):**
  - Asthma steroid-sparing RCT: 200 mg TID, 36% prednisolone reduction [Juergens 2003](https://pubmed.ncbi.nlm.nih.gov/12645832/)
  - COPD RCT (N=242): exacerbations↓↓, lung function↑, QoL↑ [Worth 2009](https://pmc.ncbi.nlm.nih.gov/articles/PMC2720945/)
  - Rhinosinusitis: symptom score↓ [Kehrl 2004](https://pubmed.ncbi.nlm.nih.gov/15126733/)
  - In vitro (1.5 µg/mL): TNF-α↓, IL-1β↓, IL-4↓, IL-5↓, IL-6↓, IL-8↓ in human cells
- **Gaps:** No mast cell β-hex RBL-2H3 IC50; no TSLP/IL-33 data; no JAK/STAT IC50; no NLRP3 direct caspase-1 assay

---

## 9. Gaps and Research Priorities {#gaps}

### Priority Gap Table

| Priority | Gap | Terpenes Affected | Assay Needed |
|----------|-----|-------------------|--------------|
| **★★★★★** | RBL-2H3 / BMMC β-hexosaminidase IC50 | ALL 17 | IgE sensitization + antigen challenge; dose-response |
| **★★★★★** | H1/H2/H3/H4 radioligand binding Ki | ALL 17 | Standard displacement assay (e.g., [³H]-mepyramine for H1) |
| **★★★★** | TSLP / IL-25 / IL-33 epithelial alarmin suppression | ALL 17 | NHBE or HaCaT cells; ELISA/qPCR |
| **★★★★** | JAK1/2/3 IC50 (kinase assay) | ALL 17 | Biochemical kinase assay |
| **★★★★** | STAT3 / STAT6 phosphorylation IC50 | ALL 17 | Western blot / AlphaLISA |
| **★★★** | Tryptase inhibition (fluorometric assay) | ALL 17 | Recombinant human tryptase |
| **★★★** | MRGPRX2 activation/inhibition | ALL 17 | MRGPRX2-expressing HEK293 cells |
| **★★★** | LTC4 / PGD2 production IC50 (mast cells) | ALL 17 | ELISA from IgE-activated mast cells |
| **★★★** | NLRP3 direct assembly inhibition | Terpinolene, β-ocimene, guaiol, camphene, β-pinene | NLRP3 oligomerization assay; ASC speck assay |
| **★★★** | NC/Nga AD model | ALL 17 | Chronic AD; skin barrier + systemic cytokines |
| **★★★** | Imiquimod psoriasis model | ALL 17 | 5-day imiquimod ear model; IL-17↓, IL-23↓ |
| **★★** | Th17/RORγt/IL-17A | ALL except BCP | CIA/EAE/DSS + flow cytometry |
| **★★** | FoxP3 / Treg induction | ALL 17 | Flow cytometry; in vitro Treg expansion |
| **★★** | AhR and HDAC inhibition | ALL 17 | AhR reporter assay; HDAC fluorometric |
| **★★** | Human Phase 1/2 trials | All except 1,8-cineole | Biomarker endpoint trials in atopic dermatitis or asthma |
| **★** | Periostin / IgE direct suppression in clinical models | BCP, α-bisabolol | Elevated periostin patient cohorts |

### Compound-Specific Priority Gaps

| Terpene | #1 Priority Gap | Rationale |
|---------|----------------|-----------|
| Linalool | RBL-2H3 β-hex IC50 | Strong anti-allergic profile but no mast cell IC50 |
| Limonene | IgE-mast cell pathway | Most data is macrophage/non-allergic |
| β-Myrcene | NLRP3 / Th17 assays | Good asthma data; autoimmune unexplored |
| α-Pinene | Mast cell degranulation | AD nanoparticle study promising; needs mechanistic follow-up |
| β-Pinene | Everything — new primary studies needed | Essentially no immune-specific data |
| BCP | JAK/STAT IC50; H4 binding | Most complete profile but JAK data absent |
| α-Humulene | Human trial; mast cell β-hex | Comparable to dexamethasone topically but zero clinical data |
| Terpinolene | All immune targets | Only acute models; no chronic allergy/autoimmune |
| α-Bisabolol | JAK/STAT; TSLP/IL-33 | Best mast cell data but modern AD pathways unexplored |
| Geraniol | RBL-2H3 IC50; NLRP3 in allergy model | NLRP3 data from liver model only |
| Camphene | New primary studies — all targets | Lipid data only; allergy virtually unstudied |
| α-Terpineol | Mast cell assay; NLRP3 | Clinical hint from PAR study but no mechanism |
| β-Ocimene | Everything — primary studies needed | Least studied for immune targets |
| Trans-Nerolidol | OVA asthma or DNCB-AD model | Only acute inflammatory models |
| Guaiol | Everything — primary studies needed | No published immune/allergy data |
| Phytol | NLRP3; Th17; clinical | Complete Th2 profile from 2012 but no follow-up |
| 1,8-Cineole | Mast cell β-hex IC50; JAK/STAT | Best clinical profile; fundamental mast cell assay missing |

---

## 10. Full Citation List {#citations}

### A — Mast Cell & Histamine Core

1. [Li G et al. 2022 - Molecules](https://pmc.ncbi.nlm.nih.gov/articles/PMC9268635/) — (-)-α-Bisabolol alleviates atopic dermatitis by inhibiting MAPK and NF-κB signaling in mast cells. *Molecules* 27(13):3985. PMID: 35807237

2. [Huang Y et al. 2018 - Drug Des Devel Ther](https://pmc.ncbi.nlm.nih.gov/articles/PMC6141105/) — Geraniol suppresses proinflammatory mediators in PMACI-induced HMC-1 cells and OVA-induced AR models. *Drug Des Devel Ther* 12:2897–2903. PMID: 30254419

3. [Yao Z et al. 2021 - Clin Exp Pharmacol Physiol](https://onlinelibrary.wiley.com/doi/abs/10.1111/1440-1681.13555) — Crosstalk between AdipoR1/AdipoR2 and Nrf2/HO-1 pathways activated by β-caryophyllene suppressed compound 48/80-induced pseudo-allergic reactions. *Clin Exp Pharmacol Physiol* 48(5):714–724.

4. [Du Y et al. 2020 - Int J Immunopathol Pharmacol](https://pmc.ncbi.nlm.nih.gov/articles/PMC7517990/) — Myrcene exerts anti-asthmatic activity in neonatal rats via modulating matrix remodeling. *Int J Immunopathol Pharmacol* 34:2058738420954948. PMID: 32962470

5. [Kim MG et al. 2019 - Ind Crops Prod](https://www.sciencedirect.com/science/article/abs/pii/S1567576919301286) — Anti-inflammatory effects of linalool on ovalbumin-induced pulmonary inflammation. *Ind Crops Prod* 135:309–316.

### B — 1,8-Cineole Clinical/Mechanistic

6. [Juergens UR et al. 2003 - Respir Med](https://pubmed.ncbi.nlm.nih.gov/12645832/) — Anti-inflammatory activity of 1,8-cineol (eucalyptol) in bronchial asthma: a double-blind placebo-controlled trial. *Respir Med* 97(3):250–256. PMID: 12645832

7. [Worth H et al. 2009 - Respir Res](https://pmc.ncbi.nlm.nih.gov/articles/PMC2720945/) — Concomitant therapy with cineole (eucalyptole) reduces exacerbations in COPD: a placebo-controlled double-blind trial. *Respir Res* 10(1):69. PMCID: PMC2720945

8. [Juergens LJ et al. 2020 - Adv Ther](https://pmc.ncbi.nlm.nih.gov/articles/PMC7467491/) — New perspectives for mucolytic, anti-inflammatory and adjunctive therapy with 1,8-cineole in COPD and asthma. *Adv Ther* 37(5):1737–1753. PMCID: PMC7467491

9. [Juergens UR et al. 2017 - Pulm Pharmacol Ther](https://www.sciencedirect.com/science/article/abs/pii/S2213713017300081) — Anti-inflammatory effects of 1,8-cineole (eucalyptol) and additive synergism with corticosteroids. *Pulm Pharmacol Ther*.

10. [Juergens UR et al. 1998 - Eur J Med Res](https://pubmed.ncbi.nlm.nih.gov/9737886/) — Antiinflammatory effects of eucalyptol (1.8-cineole): inhibition of arachidonic acid metabolism in human blood monocytes ex vivo. *Eur J Med Res* 3(9):407–412. PMID: 9737886

11. [Kehrl W et al. 2004 - Laryngoscope](https://pubmed.ncbi.nlm.nih.gov/15126733/) — Therapy for acute nonpurulent rhinosinusitis with cineole. *Laryngoscope* 114(4):738–742. PMID: 15126733

### C — β-Caryophyllene

12. [Bento AF et al. 2011 - Eur J Pharmacol](https://pubmed.ncbi.nlm.nih.gov/21798259/) — β-Caryophyllene inhibits dextran sulfate sodium-induced colitis and the activation of nuclear factor-κB. *Eur J Pharmacol* 668(1–2):220–229. PMID: 21798259

13. [Kim DH et al. 2014 - Eur J Pharmacol](https://pubmed.ncbi.nlm.nih.gov/24369228/) — β-Caryophyllene inhibits OVA-induced ovalbumin-specific IgE levels, Th2-type cytokines. *Eur J Pharmacol* 738:208–218. PMID: 24369228

14. [Rogerio AP et al. 2016 - Inflamm Res](https://pubmed.ncbi.nlm.nih.gov/27379721/) — The cannabinoid 2 receptor agonist β-caryophyllene modulates inflammation induced by Mycobacterium bovis BCG by inhibiting neutrophil migration. *Inflamm Res* 65(11):869–879. PMID: 27379721

15. [Lunn CA et al. 2012 - J Neuroimmunol](https://pubmed.ncbi.nlm.nih.gov/22452646/) — β-Caryophyllene and its CB2 receptor-mediated anti-inflammatory effects in EAE model. PMID: 22452646

16. [Fernandes ES et al. 2007 - Eur J Pharmacol](https://pubmed.ncbi.nlm.nih.gov/17559833/) — Anti-inflammatory effects of compounds alpha-humulene and (-)-trans-caryophyllene isolated from essential oil of Cordia verbenacea. *Eur J Pharmacol* 569(3):228–236. PMID: 17559833

### D — α-Humulene

17. [Rogerio AP et al. 2009 - Br J Pharmacol](https://pubmed.ncbi.nlm.nih.gov/19438512/) — Preventive and therapeutic anti-inflammatory properties of the sesquiterpene alpha-humulene in experimental airways allergic inflammation. *Br J Pharmacol* 158(4):1074–1087. PMID: 19438512

18. [Dalavaye N et al. 2024 - Planta Med](https://pmc.ncbi.nlm.nih.gov/articles/PMC11254484/) — The clinical translation of α-humulene — a scoping review. *Planta Med* 90(9):664–674. PMID: 38626911

19. [Fernandes ES et al. 2007 - Eur J Pharmacol](https://pubmed.ncbi.nlm.nih.gov/17559833/) — see #16 above.

### E — Linalool

20. [Lv F et al. 2016 - Int Immunopharmacol](https://pubmed.ncbi.nlm.nih.gov/26432179/) — Linalool inhibits cigarette smoke-induced lung inflammation by inhibiting NF-κB activation. *Int Immunopharmacol* 29(2):708–713. PMID: 26432179

21. [Kim MG et al. 2019 - Ind Crops Prod](https://www.sciencedirect.com/science/article/abs/pii/S1567576919301286) — see #5 above.

### F — Geraniol

22. [Huang Y et al. 2018 - Drug Des Devel Ther](https://pmc.ncbi.nlm.nih.gov/articles/PMC6141105/) — see #2 above.

23. [Medicherla K et al. 2019 - Pharmacol Res](https://pubmed.ncbi.nlm.nih.gov/30558846/) — Geraniol attenuates the development of experimental colitis. *Pharmacol Res* 139:443–454. PMID: 30558846

24. [Xu H et al. 2023 - Biochem Pharmacol](https://www.sciencedirect.com/science/article/abs/pii/S0006295223000588) — Geraniol ameliorates acute liver failure via NLRP3 inflammasome and PPAR-γ methylation. *Biochem Pharmacol*.

### G — Phytol

25. [Inoue T et al. 2012 - Drug Discov Ther](https://pubmed.ncbi.nlm.nih.gov/23039895/) — Phytol, a diterpene alcohol, inhibits the inflammatory response by reducing cytokine production and oxidative stress. *Drug Discov Ther* 6(6):290–296. PMID: 23039895

### H — α-Bisabolol

26. [Li G et al. 2022 - Molecules](https://pmc.ncbi.nlm.nih.gov/articles/PMC9268635/) — see #1 above.

27. [Rodrigues MR et al. 2019 - Food Chem Toxicol](https://pubmed.ncbi.nlm.nih.gov/30650128/) — Bisabolol anti-inflammatory properties in skin. *Food Chem Toxicol* 125:268–279. PMID: 30650128

### I — Limonene

28. [d'Alessio PA et al. 2014 - Eur J Pharmacol](https://pubmed.ncbi.nlm.nih.gov/24898571/) — Anti-stress effects of d-limonene and its metabolite perillyl alcohol. PMID: 24898571

29. [Yoon WJ et al. 2010 - J Oleo Sci](https://pubmed.ncbi.nlm.nih.gov/24898571/) — Limonene suppresses LPS-induced production of NO, PGE2, and pro-inflammatory cytokines in RAW 264.7 macrophages. *J Oleo Sci* 59:415–421.

### J — β-Myrcene

30. [Du Y et al. 2020 - Int J Immunopathol Pharmacol](https://pmc.ncbi.nlm.nih.gov/articles/PMC7517990/) — see #4 above.

31. [Surendran S et al. 2021 - Biomolecules](https://pubmed.ncbi.nlm.nih.gov/33561574/) — Nerolidol: Pharmacological activities and therapeutic potential. PMID: 33561574

### K — α-Pinene / β-Pinene

32. [Salehi B et al. 2019 - Biomolecules](https://pmc.ncbi.nlm.nih.gov/articles/PMC6920849/) — Therapeutic potential of α- and β-pinene: a miracle gift of nature. *Biomolecules* 9(11):738. PMID: 31739596

33. [Frontiers Immunology 2024 - α-Pinene nanoparticles AD](https://www.frontiersin.org/journals/immunology/articles/10.3389/fimmu.2024.1390) — Alpha-pinene-encapsulated lipid nanoparticles diminished DNCB-induced atopic dermatitis.

### L — Trans-Nerolidol

34. [Chan WK et al. 2016 - Molecules](https://pmc.ncbi.nlm.nih.gov/articles/PMC6272852/) — Nerolidol: a sesquiterpene alcohol with multi-faceted pharmacological and biological activities. *Molecules* 21(5):529. PMID: 27136520

35. [Hamadi N et al. 2025 - Biomedicines](https://pmc.ncbi.nlm.nih.gov/articles/PMC11940484/) — Protective effects of nerolidol on thrombotic events, systemic inflammation, oxidative stress and DNA damage following pulmonary exposure to diesel exhaust particles. *Biomedicines* 13(3):729.

### M — Terpinolene

36. [Menezes IO et al. 2023 - Ind Crops Prod](https://www.sciencedirect.com/science/article/abs/pii/S2212429223002729) — Terpinolene inhibits acute responses triggered by different inflammatory agents in vivo models of mouse.

37. [Rufino AT et al. 2015 - Toxicol In Vitro](https://pubmed.ncbi.nlm.nih.gov/25302622/) — Evaluation of anti-inflammatory, anti-catabolic and pro-anabolic effects of E-caryophyllene, myrcene and limonene in a cell model of osteoarthritis. PMID: 25302622

### N — α-Terpineol

38. [Quintans-Júnior LJ et al. 2013 - Fundam Clin Pharmacol](https://pubmed.ncbi.nlm.nih.gov/24290896/) — α-Terpineol reduces mechanical hypernociception and inflammatory response. PMID: 24290896

39. [Ueno-Iio T et al. 2014 - Evid Based Complement Alternat Med](https://onlinelibrary.wiley.com/doi/10.1155/2016/7896081) — Lavender essential oil inhalation suppresses allergic airway inflammation. DOI: 10.1155/2016/7896081

40. [Tao Y et al. 2017 - Eur J Med Chem](https://www.sciencedirect.com/science/article/abs/pii/S0223523417305901) — Discovery of novel α-terpineol derivatives as anti-asthmatic agents.

### O — β-Ocimene

41. [de Oliveira JM et al. 2020 - Biomed Pharmacother](https://pubmed.ncbi.nlm.nih.gov/32007527/) — Ocimum gratissimum essential oil (β-ocimene component) anti-inflammatory properties in mice. PMID: 32007527

### P — Guaiol

42. [Zhang Y et al. 2022 - Biochem Biophys Res Commun](https://pubmed.ncbi.nlm.nih.gov/35871777/) — Network pharmacology and molecular docking investigating the mechanism of guaiol inhibiting LUAD. PMID: 35871777

### Q — Camphene

43. [Vallianou I et al. 2011 - Atherosclerosis](https://pubmed.ncbi.nlm.nih.gov/22082126/) — Mechanistic basis for the anti-atherogenic activity of camphene. *Atherosclerosis* 217(2):397–404. PMID: 22082126

### R — Broad Terpene Reviews

44. [Kim T et al. 2020 - Int J Mol Sci](https://pmc.ncbi.nlm.nih.gov/articles/PMC7139849/) — Therapeutic potential of volatile terpenes and terpenoids from forests for inflammatory diseases. *Int J Mol Sci* 21(6):2187. PMID: 32235725

45. [Analgesic potential of terpenes from Cannabis sativa 2024 - PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC11060501/) — β-myrcene, α-pinene, limonene, linalool, β-caryophyllene analgesic review.

46. [ScienceDirect Caryophyllene Overview](https://www.sciencedirect.com/topics/medicine-and-dentistry/caryophyllene) — BCP: anti-inflammatory potency comparable to phenylbutazone; COX-2/LOX dual.

47. [ScienceDirect Humulene Overview](https://www.sciencedirect.com/topics/medicine-and-dentistry/humulene) — α-humulene anti-inflammatory equal to dexamethasone (animal model).

48. [Review - Pinene linalool psychiatric/inflammatory Frontiers 2021](https://www.frontiersin.org/journals/psychiatry/articles/10.3389/fpsyt.2021.5832) — α-Pinene protects against oxidative stress, inflammation; LPS IL-6, TNF-α reduction.

### S — Histamine/Mast Cell Background

49. [Hide I et al. 1997 - J Immunol](https://pubmed.ncbi.nlm.nih.gov/9280290/) — Suppression of TNF-alpha in RBL-2H3 by azelastine (reference for RBL assay methodology).

50. [Natural compound anti-mast cell review 2025 - Inflammopharmacology](https://pmc.ncbi.nlm.nih.gov/articles/PMC12705788/) — Modulatory effects of bioactive natural compounds on pruritic pathways.

### T — Supplementary Recent Papers

51. [Geraniol anti-inflammation Medicherla 2019 - Pharmacol Res](https://pubmed.ncbi.nlm.nih.gov/30558846/)

52. [BCP COVID/immune review 2021 - PMC8163236](https://pmc.ncbi.nlm.nih.gov/articles/PMC8163236/) — β-Caryophyllene CB2 receptor immunomodulation.

53. [Nerolidol 2025 diesel particles - PMC11940484](https://pmc.ncbi.nlm.nih.gov/articles/PMC11940484/)

54. [Alpha-humulene scoping review 2024 - PMC11254484](https://pmc.ncbi.nlm.nih.gov/articles/PMC11254484/)

---

## Appendix: Evidence Strength Score

| Terpene | Mast Cell | Th2/IgE | NLRP3/Autoimmune | Preclinical Models | Clinical | **Total /25** |
|---------|-----------|---------|-----------------|-------------------|----------|--------------|
| 1,8-Cineole | 3 | 4 | 3 | 4 | 5 | **19** |
| β-Caryophyllene | 3 | 4 | 5 | 5 | 1 | **18** |
| α-Bisabolol | 5 | 2 | 1 | 3 | 1 | **12** |
| Linalool | 2 | 4 | 2 | 4 | 1 | **13** |
| Geraniol | 4 | 3 | 3 | 3 | 0 | **13** |
| α-Humulene | 1 | 3 | 2 | 4 | 0 | **10** |
| Phytol | 1 | 4 | 1 | 3 | 0 | **9** |
| β-Myrcene | 2 | 3 | 1 | 3 | 0 | **9** |
| Limonene | 1 | 2 | 2 | 3 | 0 | **8** |
| α-Pinene | 1 | 1 | 2 | 3 | 1† | **8** |
| Trans-Nerolidol | 1 | 1 | 2 | 2 | 0 | **6** |
| α-Terpineol | 1 | 1 | 1 | 2 | 1† | **6** |
| Terpinolene | 1 | 0 | 0 | 2 | 0 | **3** |
| Camphene | 0 | 0 | 0 | 1 | 0 | **1** |
| β-Ocimene | 0 | 0 | 0 | 1 | 0 | **1** |
| Guaiol | 0 | 0 | 0 | 1 | 0 | **1** |
| β-Pinene | 0 | 0 | 0 | 1 | 0 | **1** |

*Scoring: 0=no data; 1=limited/indirect; 2=single study; 3=multiple studies; 4=robust/quantitative; 5=gold standard/clinical*  
*†Clinical evidence from blend inhalation study, not single-compound RCT*

---

*Document compiled: June 2026 | Sources: PubMed, PMC, ScienceDirect, Wiley, Frontiers | Preferred period: 2018–2025 with foundational earlier studies retained*
