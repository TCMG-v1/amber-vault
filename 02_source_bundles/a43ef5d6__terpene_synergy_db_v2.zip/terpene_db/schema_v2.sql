-- ============================================================================
-- TERPENE SYNERGY DATABASE v2 — Schema Extensions
-- ============================================================================
-- Adds: histamine receptors (H1-H4), MRGPRX2, mast-cell pathway nodes,
-- JAK/STAT axis, autoimmune transcription factors, adiponectin receptors,
-- alarmins, plus two new tables: allergic_reactions and clinical_trials.
--
-- This file is APPLIED AFTER schema.sql. The build script (build_v2.sh)
-- runs schema.sql, then schema_v2.sql, then seed.sql + seed_v2.sql.
-- ============================================================================

PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------------------
-- 11. ALLERGIC REACTIONS — adverse hypersensitivity events per terpene
-- ---------------------------------------------------------------------------
-- A safety subtype focused on type-I/type-IV hypersensitivity since the
-- v2 emphasis is histamine/allergy; tracks oxidation-derived allergens,
-- regulatory status (EU 26 fragrance allergens), and patch-test rates.
CREATE TABLE allergic_reactions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    terpene_id      TEXT NOT NULL REFERENCES terpenes(id),
    reaction_type   TEXT,                       -- type_I_IgE, type_IV_contact, irritant, oxidation_product
    trigger_form    TEXT,                       -- neat, oxidized, hydroperoxide, photo_isomer
    population      TEXT,                       -- eczema_patients, general_dermatitis, occupational
    rate_pct        REAL,                       -- patch-test positivity %
    n_tested        INTEGER,
    regulatory      TEXT,                       -- EU_mandatory_allergen, IFRA_restricted, GRAS
    threshold       TEXT,                       -- e.g. >0.001% rinse-off
    notes           TEXT,
    reference       TEXT,
    url             TEXT
);

-- ---------------------------------------------------------------------------
-- 12. CLINICAL TRIALS — human evidence pointer (RCT, open-label, case series)
-- ---------------------------------------------------------------------------
CREATE TABLE clinical_trials (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    terpene_id      TEXT NOT NULL REFERENCES terpenes(id),
    design          TEXT,                       -- RCT_double_blind, open_label, case_series
    indication      TEXT,                       -- asthma, COPD, rhinosinusitis, atopic_dermatitis
    n_subjects      INTEGER,
    dose            TEXT,                       -- e.g. "200 mg TID p.o."
    duration        TEXT,                       -- e.g. "12 weeks"
    primary_outcome TEXT,
    result_summary  TEXT,                       -- e.g. "36% prednisolone reduction vs 7% placebo (p=0.006)"
    p_value         REAL,
    nct_id          TEXT,                       -- ClinicalTrials.gov ID if any
    reference       TEXT,
    url             TEXT
);

CREATE INDEX idx_allergy_terp ON allergic_reactions(terpene_id);
CREATE INDEX idx_trial_terp ON clinical_trials(terpene_id);
CREATE INDEX idx_trial_indication ON clinical_trials(indication);
