-- ============================================================================
-- TERPENE SYNERGY DATABASE — Schema for Therapeutic Drug Design
-- ============================================================================
-- A normalized relational model for terpene pharmacology, receptor binding,
-- dose-effect relationships, pharmacokinetics, and cannabinoid synergy.
--
-- Evidence tiers (used throughout): IV=in vitro, R=rodent, H=human
-- All Ki/EC50/IC50 stored in nanomolar (nM) unless noted in unit column
-- ============================================================================

PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------------------
-- 1. TERPENES — canonical compound identity
-- ---------------------------------------------------------------------------
CREATE TABLE terpenes (
    id              TEXT PRIMARY KEY,        -- slug e.g. 'linalool', 'bcp'
    name            TEXT NOT NULL,
    iupac           TEXT,
    cas             TEXT,
    smiles          TEXT,
    formula         TEXT,
    mol_weight      REAL,                    -- g/mol
    class           TEXT,                    -- monoterpene/sesquiterpene/monoterpenol
    structure       TEXT,                    -- acyclic/monocyclic/bicyclic
    boiling_point_c REAL,
    logp            REAL,
    water_sol_mg_ml REAL,
    natural_sources TEXT,                    -- comma-separated
    fema_gras       TEXT
);

-- ---------------------------------------------------------------------------
-- 2. RECEPTORS / MOLECULAR TARGETS
-- ---------------------------------------------------------------------------
CREATE TABLE receptors (
    id          TEXT PRIMARY KEY,             -- 'cb1','cb2','trpv1','gaba_a','a2a',...
    name        TEXT NOT NULL,
    family      TEXT,                         -- GPCR, ion_channel, nuclear_receptor, enzyme, transcription_factor
    location    TEXT,                         -- CNS, PNS, immune, peripheral
    pathway     TEXT                          -- e.g. Gi/cAMP, NF-kB cascade
);

-- ---------------------------------------------------------------------------
-- 3. TERPENE × RECEPTOR INTERACTIONS
-- ---------------------------------------------------------------------------
CREATE TABLE interactions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    terpene_id      TEXT NOT NULL REFERENCES terpenes(id),
    receptor_id     TEXT NOT NULL REFERENCES receptors(id),
    action          TEXT NOT NULL,            -- agonist/partial_agonist/antagonist/PAM/NAM/inhibitor/activator/inducer
    binding_mode    TEXT,                     -- orthosteric/allosteric/indirect/functional
    affinity_type   TEXT,                     -- Ki, EC50, IC50, Kd, functional
    affinity_value  REAL,                     -- numeric, in unit below
    affinity_unit   TEXT,                     -- nM, uM, mg/mL
    efficacy_pct    REAL,                     -- % of reference agonist Emax where known
    tier            TEXT,                     -- IV/R/H
    confidence      TEXT,                     -- strong/moderate/weak/contested
    notes           TEXT,
    reference       TEXT,                     -- short citation
    url             TEXT                      -- primary source URL
);

-- ---------------------------------------------------------------------------
-- 4. THERAPEUTIC EFFECTS — observed pharmacology
-- ---------------------------------------------------------------------------
CREATE TABLE effects (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    terpene_id      TEXT NOT NULL REFERENCES terpenes(id),
    effect          TEXT NOT NULL,            -- analgesic, anti_inflammatory, anxiolytic, ...
    condition       TEXT,                     -- chronic_pain, neuropathic_pain, anxiety, neuroinflammation
    model           TEXT,                     -- CCI, carrageenan, EPM, LPS macrophage, ...
    species         TEXT,                     -- mouse/rat/human/IV
    dose_value      REAL,
    dose_unit       TEXT,                     -- mg/kg, mg, ng/mL
    route           TEXT,                     -- oral, i.p., s.c., inhalation, intraplantar
    sex             TEXT,                     -- M, F, mixed
    outcome         TEXT,
    tier            TEXT,
    reference       TEXT,
    url             TEXT
);

-- ---------------------------------------------------------------------------
-- 5. PHARMACOKINETICS
-- ---------------------------------------------------------------------------
CREATE TABLE pharmacokinetics (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    terpene_id      TEXT NOT NULL REFERENCES terpenes(id),
    species         TEXT,                     -- human, rat, mouse
    route           TEXT,                     -- oral, inhalation, i.v., topical
    formulation     TEXT,                     -- neat, SEDDS, beta-cyclodextrin, EO capsule
    parameter       TEXT NOT NULL,            -- F, Tmax, Cmax, t_half, AUC, Vd, CL, BBB
    value           REAL,
    unit            TEXT,                     -- h, ng/mL, %, L, L/h, dimensionless
    notes           TEXT,
    reference       TEXT,
    url             TEXT
);

-- ---------------------------------------------------------------------------
-- 6. METABOLISM — CYP routes and metabolites
-- ---------------------------------------------------------------------------
CREATE TABLE metabolism (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    terpene_id      TEXT NOT NULL REFERENCES terpenes(id),
    enzyme          TEXT,                     -- CYP3A4, CYP2C9, etc.
    metabolite      TEXT,                     -- perillic acid, 8-oxolinalool, etc.
    bioactive       BOOLEAN,                  -- is metabolite pharmacologically active
    notes           TEXT,
    reference       TEXT,
    url             TEXT
);

-- ---------------------------------------------------------------------------
-- 7. SAFETY / TOXICOLOGY / ADRs
-- ---------------------------------------------------------------------------
CREATE TABLE safety (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    terpene_id      TEXT NOT NULL REFERENCES terpenes(id),
    category        TEXT,                     -- LD50, NOAEL, contact_allergy, drug_interaction, carcinogen
    species         TEXT,
    route           TEXT,
    value           REAL,
    unit            TEXT,
    severity        TEXT,                     -- low, moderate, high
    description     TEXT,
    reference       TEXT,
    url             TEXT
);

-- ---------------------------------------------------------------------------
-- 8. SYNERGY — cannabinoid entourage interactions
-- ---------------------------------------------------------------------------
CREATE TABLE synergy (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    terpene_id          TEXT NOT NULL REFERENCES terpenes(id),
    partner             TEXT NOT NULL,        -- THC, CBD, 2-AG, AEA, morphine, WIN55212
    partner_class       TEXT,                 -- phytocannabinoid, endocannabinoid, opioid, synthetic_cb
    interaction_type    TEXT,                 -- additive, synergistic, antagonistic, opioid_sparing, no_interaction
    mechanism           TEXT,                 -- e.g. independent CB2 pathway, spinal A2A convergence
    assay               TEXT,                 -- cAMP, radioligand, CIPN-mice, EPM
    quantitative_result TEXT,                 -- free text - exact numbers from study
    confidence          TEXT,                 -- strong/moderate/weak/contested/rejected
    tier                TEXT,
    reference           TEXT,
    url                 TEXT
);

-- ---------------------------------------------------------------------------
-- 9. CONDITION INDEX — for query-driven drug design
-- ---------------------------------------------------------------------------
CREATE TABLE condition_targets (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    condition       TEXT NOT NULL,            -- chronic_pain, neuropathic_pain, neuroinflammation, anxiety, ...
    receptor_id     TEXT REFERENCES receptors(id),
    rationale       TEXT,
    priority        INTEGER                   -- 1 = primary target, 2 = secondary
);

-- ---------------------------------------------------------------------------
-- 10. EVIDENCE GAPS — explicit "what we don't know"
-- ---------------------------------------------------------------------------
CREATE TABLE evidence_gaps (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    terpene_id      TEXT REFERENCES terpenes(id),
    receptor_id     TEXT REFERENCES receptors(id),
    description     TEXT NOT NULL,
    severity        TEXT                      -- blocker, weak_evidence, hypothesis_only
);

-- ---------------------------------------------------------------------------
-- INDICES for query performance
-- ---------------------------------------------------------------------------
CREATE INDEX idx_int_terp ON interactions(terpene_id);
CREATE INDEX idx_int_recep ON interactions(receptor_id);
CREATE INDEX idx_eff_terp ON effects(terpene_id);
CREATE INDEX idx_eff_cond ON effects(condition);
CREATE INDEX idx_pk_terp ON pharmacokinetics(terpene_id);
CREATE INDEX idx_syn_terp ON synergy(terpene_id);
CREATE INDEX idx_syn_partner ON synergy(partner);
