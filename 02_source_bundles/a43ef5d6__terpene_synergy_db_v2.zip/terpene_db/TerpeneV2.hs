{-# LANGUAGE DeriveGeneric        #-}
{-# LANGUAGE DerivingStrategies   #-}
{-# LANGUAGE OverloadedStrings    #-}
{-# LANGUAGE StrictData           #-}
{-# LANGUAGE LambdaCase           #-}

-- |
-- Module      : TerpeneV2
-- Description : v2 extensions to the terpene synergy database — histamine,
--               mast cell, JAK/STAT, Th17/Treg, alarmin, inflammasome axes.
--
-- Builds on @Terpene.hs@ (the v1 module). Re-exports the v1 surface and
-- introduces:
--
--   * A widened 'Receptor' set covering H1-H4, MRGPRX2, FcεRI, β-Hex,
--     JAK1/2/3, STAT3/6, FoxP3, RORγt, NLRP3, CASP1, IL-1β, AdipoR1/2,
--     IL-4/5/13/17/33, TSLP, IgE, LOX5, LTB4, PGE2, IFN-γ, TNF, JNK,
--     Periostin, Cav3.2-pruritus subset.
--
--   * New 'EffectClass' constructors for allergic / autoimmune phenotypes.
--
--   * New 'AllergicReaction' and 'ClinicalTrial' records mirroring the
--     two new SQL tables.
--
--   * Pre-baked 'ConditionPanel' values for allergic asthma, atopic
--     dermatitis, mast-cell disorder, autoimmune inflammation, IBD,
--     multiple sclerosis, rheumatoid arthritis.
--
-- Design rule of thumb: every entity added here corresponds to at least
-- one cited row in @seed_v2.sql@. \"No data\" cases are represented via
-- the existing @evidence_gaps@ table — they do NOT get an ADT
-- constructor with fabricated values.
module TerpeneV2
  ( -- * Re-exported v1 surface
    module Terpene
    -- * Extended receptors (histamine / autoimmune axis)
  , ReceptorV2 (..)
    -- * Extended effects
  , EffectClassV2 (..)
    -- * New record types
  , AllergicReaction (..)
  , ReactionType    (..)
  , TriggerForm     (..)
  , Regulatory      (..)
  , ClinicalTrial   (..)
  , TrialDesign     (..)
    -- * Condition panels — v2
  , allergicAsthmaPanel
  , atopicDermatitisPanel
  , mastCellPanel
  , autoimmuneInflammationPanel
  , colitisPanel
  , multipleSclerosisPanel
  , rheumatoidArthritisPanel
    -- * Mast-cell scoring helpers
  , mastCellStabilizerScore
  , th2CytokineHits
  , steroidSparingCandidates
  ) where

import           Terpene
import           Data.Aeson         (FromJSON, ToJSON)
import           Data.Text          (Text)
import           GHC.Generics       (Generic)

-- ---------------------------------------------------------------------------
-- Extended Receptor enum — v2 histamine / autoimmune axis
-- ---------------------------------------------------------------------------

-- | Closed extension of the v1 'Receptor' enum. Every constructor maps
-- to a row in the @receptors@ table inserted by @seed_v2.sql@. Add new
-- targets here when seed data lands.
data ReceptorV2
  -- Histamine receptors
  = H1 | H2 | H3 | H4
  -- Mast cell pathway nodes
  | FceRI                  -- ^ High-affinity IgE receptor
  | MRGPRX2                -- ^ Mas-related GPCR X2 — pseudo-allergic
  | BetaHexosaminidase     -- ^ Degranulation readout
  | Tryptase
  | CaV3_2_Pruritus        -- ^ DRG-itch fibre subset of Cav3.2
  -- JAK / STAT
  | JAK1 | JAK2 | JAK3
  | STAT3 | STAT6
  -- T-cell master TFs
  | FoxP3                  -- ^ Treg lineage master TF
  | RORgammaT              -- ^ Th17 master TF
  -- Cytokine axes (interaction proxies)
  | IL4R | IL5 | IL13 | IL17A | IL33 | TSLP | IgE | Periostin
  -- Inflammasome
  | NLRP3 | CASP1 | IL1B
  -- Lipid mediators
  | LOX5 | LTB4 | PGE2
  -- Adiponectin
  | AdipoR1 | AdipoR2
  -- Th1 / balance
  | IFNgamma | TNF
  -- Kinases (extra)
  | JNK
  deriving stock   (Eq, Ord, Show, Read, Generic, Enum, Bounded)
  deriving anyclass (ToJSON, FromJSON)

-- ---------------------------------------------------------------------------
-- Extended EffectClass — allergic / autoimmune phenotypes
-- ---------------------------------------------------------------------------

data EffectClassV2
  = Antiallergic
  | MastCellStabilizing
  | Antipruritic
  | AntiAsthmatic
  | AntiAtopic
  | Immunomodulatory
  | SteroidSparing
  | ExacerbationReduction
  | SymptomScoreImprovement
  | Hypolipidemic
  deriving stock   (Eq, Show, Generic, Enum, Bounded)
  deriving anyclass (ToJSON, FromJSON)

-- ---------------------------------------------------------------------------
-- Allergic reactions — type-I / type-IV hypersensitivity
-- ---------------------------------------------------------------------------

data ReactionType
  = TypeI_IgE              -- ^ Mast cell / IgE crosslinking
  | TypeIV_Contact         -- ^ Delayed-type T cell contact dermatitis
  | Irritant
  | OxidationProduct
  deriving stock   (Eq, Show, Generic)
  deriving anyclass (ToJSON, FromJSON)

data TriggerForm
  = Neat
  | OxidizedAir
  | Hydroperoxide
  | PhotoIsomer
  deriving stock   (Eq, Show, Generic)
  deriving anyclass (ToJSON, FromJSON)

data Regulatory
  = EUMandatoryAllergen    -- ^ EU 26 fragrance allergen list
  | IFRARestricted
  | GRAS
  deriving stock   (Eq, Show, Generic)
  deriving anyclass (ToJSON, FromJSON)

data AllergicReaction = AllergicReaction
  { arTerpene     :: Text
  , arType        :: ReactionType
  , arTrigger     :: TriggerForm
  , arPopulation  :: Text
  , arRatePct     :: Maybe Double          -- patch-test positivity %
  , arNTested     :: Maybe Int
  , arRegulatory  :: Regulatory
  , arThreshold   :: Text
  , arNotes       :: Text
  , arRef         :: Reference
  } deriving stock   (Eq, Show, Generic)
    deriving anyclass (ToJSON, FromJSON)

-- ---------------------------------------------------------------------------
-- Clinical trials — human evidence
-- ---------------------------------------------------------------------------

data TrialDesign
  = RCTDoubleBlind
  | RCT
  | OpenLabel
  | CaseSeries
  deriving stock   (Eq, Show, Generic)
  deriving anyclass (ToJSON, FromJSON)

data ClinicalTrial = ClinicalTrial
  { ctTerpene    :: Text
  , ctDesign     :: TrialDesign
  , ctIndication :: Text
  , ctNSubjects  :: Int
  , ctDose       :: Text
  , ctDuration   :: Text
  , ctOutcome    :: Text
  , ctSummary    :: Text
  , ctPValue     :: Maybe Double
  , ctNCT        :: Maybe Text
  , ctRef        :: Reference
  } deriving stock   (Eq, Show, Generic)
    deriving anyclass (ToJSON, FromJSON)

-- ---------------------------------------------------------------------------
-- v2 Condition Panels
-- ---------------------------------------------------------------------------
-- These mirror v1's chronicPainPanel/neuroinflammationPanel, but parametrise
-- the target list over 'ReceptorV2' so we can score against the extended
-- enum. Helper type alias keeps the signature identical.

data ConditionPanelV2 = ConditionPanelV2
  { cpv2Condition :: Text
  , cpv2Targets   :: [(ReceptorV2, Int, Text)]
  } deriving stock   (Eq, Show, Generic)
    deriving anyclass (ToJSON, FromJSON)

allergicAsthmaPanel :: ConditionPanelV2
allergicAsthmaPanel = ConditionPanelV2
  { cpv2Condition = "allergic_asthma"
  , cpv2Targets   =
      [ (IL4R, 1, "Th2 driver; IL-4/IL-13 → IgE class switching")
      , (IL5,  1, "Eosinophil maturation & recruitment")
      , (IL13, 1, "Mucus, AHR, goblet cell hyperplasia")
      , (IgE,  1, "FcεRI crosslinking on mast cells")
      , (LOX5, 2, "LTB4/LTD4 bronchoconstriction")
      , (TSLP, 2, "Alarmin priming Th2 polarisation")
      , (FceRI,2, "Direct mast cell receptor")
      ]
  }

atopicDermatitisPanel :: ConditionPanelV2
atopicDermatitisPanel = ConditionPanelV2
  { cpv2Condition = "atopic_dermatitis"
  , cpv2Targets   =
      [ (IL4R, 1, "Anti-IL-4/13 biologics (dupilumab) — pathway target")
      , (IL13, 1, "Itch and barrier disruption")
      , (JAK1, 1, "Abrocitinib drug class")
      , (STAT6,2, "IL-4/13 downstream signaling")
      , (TSLP, 2, "Epithelial alarmin")
      , (CaV3_2_Pruritus, 2, "Bisabolol & camphene anti-itch")
      ]
  }

mastCellPanel :: ConditionPanelV2
mastCellPanel = ConditionPanelV2
  { cpv2Condition = "mast_cell_disorder"
  , cpv2Targets   =
      [ (FceRI,             1, "IgE-mediated activation")
      , (MRGPRX2,            1, "Pseudo-allergic non-IgE activation")
      , (BetaHexosaminidase, 1, "Degranulation readout")
      , (H1,                 1, "Histamine downstream effects")
      , (H4,                 2, "Mast cell chemotaxis, IL-31 axis")
      , (CaV3_2_Pruritus,    2, "Itch transduction in DRG")
      , (AdipoR1,            3, "BCP/Nrf2/HO-1 stabilisation route")
      ]
  }

autoimmuneInflammationPanel :: ConditionPanelV2
autoimmuneInflammationPanel = ConditionPanelV2
  { cpv2Condition = "autoimmune_inflammation"
  , cpv2Targets   =
      [ (NLRP3,    1, "Inflammasome blockade — IL-1β/IL-18 ↓")
      , (STAT3,    1, "Th17 / IL-6 axis")
      , (RORgammaT,1, "Th17 lineage")
      , (FoxP3,    1, "Treg lineage — disease remission")
      , (IL17A,    1, "Effector cytokine")
      , (JAK1,     2, "Pan-JAK suppression")
      , (TNF,      2, "Anti-TNF biologic axis")
      ]
  }

colitisPanel :: ConditionPanelV2
colitisPanel = ConditionPanelV2
  { cpv2Condition = "colitis_IBD"
  , cpv2Targets   =
      [ (NLRP3, 1, "Mucosal IL-1β/IL-18")
      , (STAT3, 1, "Th17 / IL-22 axis")
      , (IL17A, 1, "Mucosal Th17 inflammation")
      , (TNF,   1, "Anti-TNF target")
      ]
  }

multipleSclerosisPanel :: ConditionPanelV2
multipleSclerosisPanel = ConditionPanelV2
  { cpv2Condition = "multiple_sclerosis"
  , cpv2Targets   =
      [ (RORgammaT, 1, "Th17 lineage in EAE")
      , (FoxP3,     1, "Treg expansion = remission")
      , (IL17A,     1, "Effector cytokine")
      ]
  }

rheumatoidArthritisPanel :: ConditionPanelV2
rheumatoidArthritisPanel = ConditionPanelV2
  { cpv2Condition = "rheumatoid_arthritis"
  , cpv2Targets   =
      [ (JAK1, 1, "Tofacitinib drug class")
      , (JAK2, 1, "Tofacitinib drug class")
      , (STAT3,1, "Th17 axis")
      , (IL17A,1, "Pannus / destruction driver")
      , (TNF,  1, "Anti-TNF biologic axis")
      ]
  }

-- ---------------------------------------------------------------------------
-- Lightweight scoring helpers
-- ---------------------------------------------------------------------------
-- Because v1's 'Interaction' uses the v1 'Receptor', these scorers operate
-- over a polymorphic predicate so callers using JSON-decoded data can
-- supply their own Receptor → Bool match. This keeps v1 ADTs untouched.

-- | Count how many of a terpene's interactions hit any of a "mast cell
-- stabiliser" target set: FcεRI, β-Hex, MRGPRX2, Cav3.2 (itch), Tryptase.
-- Caller supplies the receptor name string (since v1 'Interaction' uses
-- the closed v1 enum).
mastCellStabilizerScore :: [Text] -> Int
mastCellStabilizerScore = length . filter (`elem` mcTargets)
  where mcTargets = ["fceri","bhex","mrgprx2","cav32_pruritus","tryptase"]

-- | Coverage of the four canonical Th2 cytokine / IgE axes.
th2CytokineHits :: [Text] -> Int
th2CytokineHits = length . filter (`elem` th2Targets)
  where th2Targets = ["il4r","il5","il13","ige"]

-- | A terpene is a "steroid-sparing" candidate iff it has either a human
-- RCT OR a rodent OVA-asthma study with IL-5 or IgE suppression.
-- The predicate operates on (tier, effect, condition) triples coming
-- from JSON-decoded rows.
steroidSparingCandidates
  :: [(Text, Text, Text)]      -- ^ (tier, effect, condition)
  -> Bool
steroidSparingCandidates rows =
     any (\(t,_,_) -> t == "H") rows
  || any (\(t,e,c) ->
            t == "R"
         && (e == "anti_asthmatic" || e == "mast_cell_stabilizing")
         && c == "allergic_asthma") rows
