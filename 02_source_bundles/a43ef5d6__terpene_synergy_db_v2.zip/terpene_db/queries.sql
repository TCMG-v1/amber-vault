-- ============================================================================
-- TERPENE SYNERGY DATABASE — Query Cookbook for Drug Design
-- ============================================================================
-- Usage:   sqlite3 terpenes.db < queries.sql
-- Or open: sqlite3 -header -column terpenes.db   then paste a block
-- ============================================================================

-- ---------------------------------------------------------------------------
-- Q1. Chronic-pain target panel: rank terpenes by # of prioritised hits
-- ---------------------------------------------------------------------------
.print '\n--- Q1: Terpenes ranked by chronic-pain target coverage ---'
SELECT
    t.name                                       AS terpene,
    COUNT(DISTINCT ct.receptor_id)               AS panel_hits,
    GROUP_CONCAT(DISTINCT ct.receptor_id)        AS receptors_hit,
    SUM(CASE WHEN ct.priority = 1 THEN 1 ELSE 0 END) AS primary_hits
FROM terpenes t
JOIN interactions i ON i.terpene_id = t.id
JOIN condition_targets ct
  ON ct.receptor_id = i.receptor_id
 AND ct.condition  = 'chronic_pain'
WHERE i.confidence IN ('strong','moderate')
GROUP BY t.id
ORDER BY primary_hits DESC, panel_hits DESC;

-- ---------------------------------------------------------------------------
-- Q2. Neuroinflammation: ranked target coverage
-- ---------------------------------------------------------------------------
.print '\n--- Q2: Terpenes ranked by neuroinflammation target coverage ---'
SELECT
    t.name                                       AS terpene,
    COUNT(DISTINCT ct.receptor_id)               AS panel_hits,
    GROUP_CONCAT(DISTINCT ct.receptor_id)        AS receptors_hit,
    SUM(CASE WHEN ct.priority = 1 THEN 1 ELSE 0 END) AS primary_hits
FROM terpenes t
JOIN interactions i ON i.terpene_id = t.id
JOIN condition_targets ct
  ON ct.receptor_id = i.receptor_id
 AND ct.condition  = 'neuroinflammation'
WHERE i.confidence IN ('strong','moderate')
GROUP BY t.id
ORDER BY primary_hits DESC, panel_hits DESC;

-- ---------------------------------------------------------------------------
-- Q3. Receptor coverage matrix (terpene x receptor) for visualisation
-- ---------------------------------------------------------------------------
.print '\n--- Q3: Coverage matrix (best confidence per pair) ---'
SELECT
    i.terpene_id,
    i.receptor_id,
    i.action,
    i.confidence,
    i.tier
FROM interactions i
ORDER BY i.terpene_id, i.confidence DESC;

-- ---------------------------------------------------------------------------
-- Q4. Best lead terpene for each receptor (rank by confidence + tier)
-- ---------------------------------------------------------------------------
.print '\n--- Q4: Best terpene per target ---'
WITH ranked AS (
  SELECT i.*,
         CASE i.confidence
            WHEN 'strong' THEN 4
            WHEN 'moderate' THEN 3
            WHEN 'weak' THEN 2
            WHEN 'contested' THEN 1
            ELSE 0 END
         + CASE i.tier WHEN 'H' THEN 3 WHEN 'R' THEN 2 WHEN 'IV' THEN 1 ELSE 0 END
         AS score,
         ROW_NUMBER() OVER (PARTITION BY i.receptor_id
                            ORDER BY
                              CASE i.confidence
                                WHEN 'strong' THEN 4 WHEN 'moderate' THEN 3
                                WHEN 'weak' THEN 2 WHEN 'contested' THEN 1
                                ELSE 0 END DESC,
                              CASE i.tier
                                WHEN 'H' THEN 3 WHEN 'R' THEN 2
                                WHEN 'IV' THEN 1 ELSE 0 END DESC) AS rk
  FROM interactions i
)
SELECT receptor_id, terpene_id, action, confidence, tier, score
FROM ranked WHERE rk = 1
ORDER BY receptor_id;

-- ---------------------------------------------------------------------------
-- Q5. Effective doses for chronic pain (R + H evidence only)
-- ---------------------------------------------------------------------------
.print '\n--- Q5: Analgesic doses for chronic / neuropathic pain ---'
SELECT
    e.terpene_id,
    e.condition,
    e.model,
    e.species,
    e.dose_value || ' ' || e.dose_unit AS dose,
    e.route, e.sex, e.tier,
    e.outcome,
    e.url
FROM effects e
WHERE e.effect IN ('analgesic','opioid_sparing')
  AND e.tier IN ('R','H')
ORDER BY e.terpene_id, e.dose_value;

-- ---------------------------------------------------------------------------
-- Q6. Synergy partners by terpene (for combination design)
-- ---------------------------------------------------------------------------
.print '\n--- Q6: Synergy partners summary ---'
SELECT
    s.terpene_id, s.partner, s.partner_class, s.interaction_type,
    s.confidence, s.tier,
    substr(s.mechanism, 1, 80) AS mechanism,
    s.url
FROM synergy s
WHERE s.interaction_type NOT IN ('no_interaction')
ORDER BY s.terpene_id, s.confidence DESC;

-- ---------------------------------------------------------------------------
-- Q7. Complementary-pair finder: two terpenes that hit DIFFERENT
--     primary targets in the same condition panel
-- ---------------------------------------------------------------------------
.print '\n--- Q7: Complementary terpene pairs for chronic pain ---'
WITH pain_hits AS (
  SELECT DISTINCT i.terpene_id, ct.receptor_id
  FROM interactions i
  JOIN condition_targets ct
    ON ct.receptor_id = i.receptor_id AND ct.condition = 'chronic_pain'
  WHERE i.confidence IN ('strong','moderate')
    AND ct.priority = 1
)
SELECT a.terpene_id AS terpene_a,
       b.terpene_id AS terpene_b,
       a.receptor_id AS a_hits,
       b.receptor_id AS b_hits
FROM pain_hits a
JOIN pain_hits b
  ON a.terpene_id < b.terpene_id
 AND a.receptor_id <> b.receptor_id
ORDER BY terpene_a, terpene_b;

-- ---------------------------------------------------------------------------
-- Q8. PK red flags — terpenes with missing / weak PK data
-- ---------------------------------------------------------------------------
.print '\n--- Q8: PK availability per terpene ---'
SELECT
    t.id,
    t.name,
    COUNT(pk.id)                             AS pk_records,
    GROUP_CONCAT(DISTINCT pk.species)        AS species,
    GROUP_CONCAT(DISTINCT pk.route)          AS routes
FROM terpenes t
LEFT JOIN pharmacokinetics pk ON pk.terpene_id = t.id
GROUP BY t.id ORDER BY pk_records ASC;

-- ---------------------------------------------------------------------------
-- Q9. Safety dashboard
-- ---------------------------------------------------------------------------
.print '\n--- Q9: Safety summary (contact allergy + LD50) ---'
SELECT
    s.terpene_id,
    s.category,
    s.value || COALESCE(' '||s.unit,'') AS measurement,
    s.severity,
    s.description,
    s.url
FROM safety s
WHERE s.category IN ('LD50','contact_allergy','carcinogen','occupational')
ORDER BY s.terpene_id, s.category;

-- ---------------------------------------------------------------------------
-- Q10. THC entourage panel: which terpenes synergise with THC + how?
-- ---------------------------------------------------------------------------
.print '\n--- Q10: THC entourage candidates ---'
SELECT
    s.terpene_id,
    s.interaction_type,
    s.mechanism,
    s.quantitative_result,
    s.confidence,
    s.tier,
    s.url
FROM synergy s
WHERE s.partner = 'THC'
ORDER BY
  CASE s.confidence
    WHEN 'strong' THEN 1 WHEN 'moderate' THEN 2
    WHEN 'weak' THEN 3 WHEN 'contested' THEN 4 ELSE 5 END;

-- ---------------------------------------------------------------------------
-- Q11. Opioid-sparing leads (rodent + human evidence)
-- ---------------------------------------------------------------------------
.print '\n--- Q11: Opioid-sparing leads ---'
SELECT s.terpene_id, s.partner, s.quantitative_result, s.tier, s.url
FROM synergy s
WHERE s.interaction_type = 'opioid_sparing'
   OR s.partner = 'morphine'
ORDER BY s.confidence DESC;

-- ---------------------------------------------------------------------------
-- Q12. Evidence-gap dashboard: where to invest research
-- ---------------------------------------------------------------------------
.print '\n--- Q12: Open evidence gaps ---'
SELECT
    COALESCE(eg.terpene_id,'(any)') AS terpene,
    COALESCE(eg.receptor_id,'(any)') AS receptor,
    eg.severity,
    eg.description
FROM evidence_gaps eg
ORDER BY
  CASE eg.severity WHEN 'blocker' THEN 1
                   WHEN 'weak_evidence' THEN 2
                   WHEN 'hypothesis_only' THEN 3 ELSE 4 END;
