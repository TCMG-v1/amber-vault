-- ============================================================================
-- TERPENE SYNERGY DATABASE v2 — Query Cookbook
-- Histamine / Mast Cell / Autoimmune / Anti-Inflammatory Focus
-- ============================================================================
-- Run as:  sqlite3 -header -column terpenes.db < queries_v2.sql
-- Counterpart to queries.sql (which covers pain/anxiety/neuro-inflammation).
-- ============================================================================

.headers on
.mode column

-- ============================================================================
-- Q1. Mast cell stabilizers — ranked by mechanism specificity
-- ============================================================================
SELECT 'Q1. MAST CELL STABILIZERS — ranked' AS heading;
SELECT
    i.terpene_id,
    GROUP_CONCAT(DISTINCT i.receptor_id) AS targets,
    GROUP_CONCAT(DISTINCT i.tier)        AS tiers,
    COUNT(DISTINCT i.receptor_id)        AS n_targets,
    GROUP_CONCAT(DISTINCT i.confidence)  AS confidence
FROM interactions i
WHERE i.receptor_id IN ('fceri','bhex','mrgprx2','cav32_pruritus','tryptase')
GROUP BY i.terpene_id
ORDER BY n_targets DESC, i.terpene_id;

-- ============================================================================
-- Q2. Th2 cytokine coverage (IL-4 / IL-5 / IL-13 / IgE) per terpene
-- ============================================================================
SELECT 'Q2. Th2 / IgE COVERAGE' AS heading;
SELECT
    terpene_id,
    SUM(receptor_id='il4r') AS hits_IL4,
    SUM(receptor_id='il5')  AS hits_IL5,
    SUM(receptor_id='il13') AS hits_IL13,
    SUM(receptor_id='ige')  AS hits_IgE,
    GROUP_CONCAT(DISTINCT tier) AS tiers
FROM interactions
WHERE receptor_id IN ('il4r','il5','il13','ige')
GROUP BY terpene_id
ORDER BY (SUM(receptor_id IN ('il4r','il5','il13','ige'))) DESC;

-- ============================================================================
-- Q3. NLRP3 inflammasome inhibitors (gout, colitis, NASH leverage)
-- ============================================================================
SELECT 'Q3. NLRP3 INFLAMMASOME INHIBITORS' AS heading;
SELECT terpene_id, action, tier, confidence, notes, url
FROM interactions
WHERE receptor_id = 'nlrp3' AND action = 'inhibitor'
ORDER BY tier DESC, confidence DESC;

-- ============================================================================
-- Q4. JAK / STAT modulators (drug-design overlap with tofacitinib class)
-- ============================================================================
SELECT 'Q4. JAK/STAT TERPENES' AS heading;
SELECT terpene_id, receptor_id, action, tier, confidence, notes
FROM interactions
WHERE receptor_id IN ('jak1','jak2','jak3','stat3','stat6')
ORDER BY terpene_id, receptor_id;

-- ============================================================================
-- Q5. Complementary mast-cell PAIRS — terpenes whose mast-cell mechanisms
--      DO NOT overlap (good for combination design)
-- ============================================================================
SELECT 'Q5. COMPLEMENTARY MAST-CELL PAIRS' AS heading;
WITH targets AS (
  SELECT terpene_id, GROUP_CONCAT(DISTINCT receptor_id) AS r
  FROM interactions
  WHERE receptor_id IN ('fceri','bhex','mrgprx2','cav32_pruritus','h1','h4','adipor1','adipor2','nrf2')
  GROUP BY terpene_id
)
SELECT a.terpene_id || ' + ' || b.terpene_id AS pair,
       a.r AS targets_a,
       b.r AS targets_b
FROM targets a, targets b
WHERE a.terpene_id < b.terpene_id
  AND INSTR(a.r,b.r)=0 AND INSTR(b.r,a.r)=0;

-- ============================================================================
-- Q6. Best terpene per allergic / autoimmune condition (ranked)
-- ============================================================================
SELECT 'Q6. CONDITION → TOP TERPENES' AS heading;
SELECT
    c.condition,
    i.terpene_id,
    COUNT(DISTINCT i.receptor_id) AS targets_hit,
    GROUP_CONCAT(DISTINCT i.tier)  AS tiers
FROM condition_targets c
JOIN interactions i ON i.receptor_id = c.receptor_id
WHERE c.condition IN (
    'allergic_asthma','mast_cell_disorder','atopic_dermatitis',
    'allergic_rhinitis','colitis_IBD','rheumatoid_arthritis',
    'multiple_sclerosis','psoriasis','COPD'
)
GROUP BY c.condition, i.terpene_id
HAVING targets_hit >= 1
ORDER BY c.condition, targets_hit DESC, i.terpene_id;

-- ============================================================================
-- Q7. Human-RCT-backed terpenes (separate signal vs hypothesis)
-- ============================================================================
SELECT 'Q7. HUMAN RCT EVIDENCE' AS heading;
SELECT terpene_id, design, indication, n_subjects, dose, duration,
       result_summary, p_value, url
FROM clinical_trials
ORDER BY n_subjects DESC;

-- ============================================================================
-- Q8. Allergy WARNING list — EU-mandatory allergens & oxidation risks
-- ============================================================================
SELECT 'Q8. ALLERGY RISK PROFILE' AS heading;
SELECT terpene_id, reaction_type, trigger_form, rate_pct, regulatory, notes
FROM allergic_reactions
ORDER BY (regulatory='EU_mandatory_allergen') DESC, rate_pct DESC NULLS LAST;

-- ============================================================================
-- Q9. Cannabinoid synergy compatible with histamine focus
-- ============================================================================
SELECT 'Q9. CB-SYNERGY (HISTAMINE-RELEVANT)' AS heading;
SELECT terpene_id, partner, interaction_type, mechanism, confidence, tier
FROM synergy
WHERE terpene_id IN ('humulene','bisabolol','geraniol','cineole','phytol','bcp','nerolidol','linalool')
ORDER BY (interaction_type='synergistic') DESC,
         (interaction_type='additive') DESC,
         terpene_id;

-- ============================================================================
-- Q10. Universal data gaps for histamine-receptor binding (open research)
-- ============================================================================
SELECT 'Q10. HISTAMINE-RECEPTOR DATA GAPS' AS heading;
SELECT terpene_id, receptor_id, description, severity
FROM evidence_gaps
WHERE receptor_id IN ('h1','h2','h3','h4','jak1','jak2','jak3','tslp','foxp3','rorgt','mrgprx2')
ORDER BY severity, terpene_id;

-- ============================================================================
-- Q11. Total target breadth — autoimmune-relevant axes
-- ============================================================================
SELECT 'Q11. AUTOIMMUNE BREADTH SCORE' AS heading;
SELECT
    terpene_id,
    COUNT(DISTINCT receptor_id) AS unique_autoimmune_targets,
    GROUP_CONCAT(DISTINCT receptor_id) AS axes
FROM interactions
WHERE receptor_id IN (
    'nfkb','nlrp3','jak1','jak2','jak3','stat3','stat6','foxp3','rorgt',
    'il4r','il5','il13','il17a','il33','tslp','ige','tnf','cox2','lox5','ppar_gamma'
)
GROUP BY terpene_id
ORDER BY unique_autoimmune_targets DESC;

-- ============================================================================
-- Q12. "Steroid-sparing" candidates — terpenes with clinical evidence OR
--       strong rodent IL-5 / IgE suppression
-- ============================================================================
SELECT 'Q12. STEROID-SPARING CANDIDATES' AS heading;
SELECT DISTINCT e.terpene_id, e.effect, e.condition, e.dose_value, e.dose_unit,
       e.tier, e.outcome, e.url
FROM effects e
WHERE e.effect IN ('steroid_sparing','anti_asthmatic','mast_cell_stabilizing')
   OR (e.condition='allergic_asthma' AND e.tier IN ('H','R'))
ORDER BY (e.tier='H') DESC, e.terpene_id;
