# Terpene Pharmacology: Rigorous Reference Compendium

*Five primary terpenes: Linalool · Limonene · Myrcene · α/β-Pinene · β-Caryophyllene*

Compiled from primary literature, 2018–2025 preferred. Evidence tiers: **IV** = in vitro, **R** = rodent/animal, **H** = human clinical.

---

## Contents
1. [Linalool](#1-linalool)
2. [Limonene](#2-limonene)
3. [Myrcene](#3-myrcene)
4. [α-Pinene / β-Pinene](#4-α-pinene--β-pinene)
5. [β-Caryophyllene (BCP)](#5-β-caryophyllene-bcp)
6. [Cross-Terpene Summary Tables](#6-cross-terpene-summary-tables)

---

## 1. LINALOOL

### 1.1 Molecular Identity

| Property | Value |
|---|---|
| IUPAC name | (3S)-3,7-dimethylocta-1,6-dien-3-ol (S-enantiomer predominates in lavender) |
| CAS# | 78-70-6 (racemic); 126-91-0 (R); 126-90-9 (S) |
| SMILES | CC(=CCC[C@@](C)(O)C=C)C (S-linalool) |
| Molecular formula | C₁₀H₁₈O |
| MW | 154.25 g/mol |
| Type | Acyclic monoterpenol |
| Boiling point | 198–199°C (at 760 mmHg) |
| logP | 2.97 (calculated); ~3.0 reported |
| Water solubility | ~1.6 mg/mL (poor) |
| Natural sources | Lavender (*Lavandula angustifolia*), coriander, cannabis sativa |

> Sources: [Frontiers in Chemistry 2015 – structure-odor relationships linalool](https://pmc.ncbi.nlm.nih.gov/articles/PMC4594031/); [PubChem CID 6549](https://pubchem.ncbi.nlm.nih.gov/compound/Linalool)

### 1.2 Biological Targets

| Target | Effect | Value | Tier | Reference |
|---|---|---|---|---|
| GABA-A (α1β2γ2) | Positive allosteric modulator (PAM) | ~1.6-fold potentiation of GABAergic currents at 2 mM with EC10–30 GABA (10 µM) | IV | [Kessler et al. 2014 → reviewed in Frontiers Chem 2017](https://www.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2017.00046/full) |
| GABA-A (α1β2γ2) | PAM — metabolite 8-oxolinalool | 1.66-fold at comparable concentration; hydroxylation at C8 reduces activity | IV | [Kamatou & Viljoen, Frontiers Chem 2017](https://www.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2017.00046/full) |
| Adenosine A2A receptor | Agonist (indirect/functional) | Antinociception blocked by A2A antagonist istradefylline 3.2 mg/kg; A2A CRISPR knockdown abolishes spinal effect | R | [LaVigne et al. 2023 biorXiv / PMC11511650 2025](https://pmc.ncbi.nlm.nih.gov/articles/PMC11511650/) |
| Adenosine A1 and A2A | Both involved in linalool antinociception | A1 and A2A antagonists each partially reverse effect | R | [de Sousa et al. 2006, *Life Sciences* doi:10.1016/j.lfs.2005.10.025] |
| Voltage-gated Na⁺ channels | Non-selective suppression | Not quantified (patch-clamp in olfactory neurons and Purkinje cells) | IV | [Narusuye et al. 2005, cited in Frontiers Chem 2017](https://www.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2017.00046/full) |
| Glutamate receptors (NMDA/AMPA) | Inhibitory | Not quantified (IC50 not established in electrophysiology studies) | IV | [Silva Brum et al. 2001; Ohkuma et al. 2002, cited ibid] |
| TRPV1 (weak) | Agonist/desensitizer | Low-concentration activity; weaker than myrcene | IV | [Jansen et al. 2019 PMC6768052](https://pmc.ncbi.nlm.nih.gov/articles/PMC6768052/) |
| 5-HT1A | Weak interaction proposed | No direct Ki published; serotonergic modulation inferred from behavioral studies | R | [Linck et al. 2010; reviewed in PMC3612440](https://pmc.ncbi.nlm.nih.gov/articles/PMC3612440/) |
| NF-κB / COX-2 / iNOS | Inhibition | Reduces LPS-induced IL-1β, IL-6, TNF-α; anti-arthritic in vitro/in vivo | IV/R | [Ahammed et al. 2025, Springer doi:10.1007/s00210-025-03984-5](https://link.springer.com/10.1007/s00210-025-03984-5) |

**Note on GABA-A PAM activity:** Quantification at 2 mM is a supra-physiological concentration. Physiologically relevant concentrations during inhalation in humans reach serum levels in single-digit ng/mL range (Russo 2011 estimate). Whether blood-level linalool achieves 2 mM at the GABA-A receptor is unknown.

### 1.3 Therapeutic Effects

| Effect | Model | Dose / Observation | Tier | Reference |
|---|---|---|---|---|
| Antinociceptive | Acetic acid writhing, hot plate, formalin (mice) | 50–200 mg/kg i.p.; comparable to low-dose morphine in some models | R | [de Sousa et al. 2010, *Pain* doi:10.1016/j.pain.2010.03.009](https://www.sciencedirect.com/science/article/pii/S1526590010003883) |
| Antinociceptive (terpene mixture) | Neuropathic pain (CIPN mice) | 200 mg/kg i.p. single terpene produces efficacy ~equal to morphine 10 mg/kg | R | [LaVigne et al. 2025 / PMC11511650](https://pmc.ncbi.nlm.nih.gov/articles/PMC11511650/) |
| Anxiolytic / Sedative | Light/dark, elevated plus maze, social interaction (mice) | Inhalation of linalool vapors (effective serum ~few ng/mL); NOT sedation via locomotor suppression | R | [Linck et al. 2010; reviewed in PMC3612440](https://pmc.ncbi.nlm.nih.gov/articles/PMC3612440/) |
| Anxiolytic (human) | 24 volunteers, experimental stress model | Inhalation → reduced blood pressure, heart rate, salivary cortisol | H | [Cited in PMC9886818, *Current Neuropharmacology* 2023](https://pmc.ncbi.nlm.nih.gov/articles/PMC9886818/) |
| Anxiolytic (human, lavender oil) | 83 prehypertensive subjects | Lavender EO (linalool-rich) inhalation → reduced cortisol, daytime BP | H | [PMC9886818](https://pmc.ncbi.nlm.nih.gov/articles/PMC9886818/) |
| Anti-inflammatory | Carrageenan paw edema, LPS macrophages | Reduces IL-1β, IL-6, TNF-α; COX-2 inhibition | IV/R | [Ahammed et al. 2025](https://link.springer.com/10.1007/s00210-025-03984-5) |
| Antioxidant | Various in vitro assays | DPPH IC50 varies by study; reduces MDA, increases SOD, catalase | IV | Multiple; reviewed in PMC9886818 |
| Anticonvulsant | Pentylenetetrazol, electroshock models (rodents) | Inhalation/i.p. effective at unspecified doses | R | [Reviewed in PMC3612440](https://pmc.ncbi.nlm.nih.gov/articles/PMC3612440/) |
| Neuroprotective | Neurodegeneration models; (-)-linalool promotes neuronal maturation | Regulates neuronal connectivity genes | IV/R | [PMC9886818](https://pmc.ncbi.nlm.nih.gov/articles/PMC9886818/) |
| Antimicrobial | Broad-spectrum (gram+, gram-, fungal) | MIC varies by organism; ~0.5–8 mg/mL range | IV | Multiple reviews |
| Gastroprotective | Ethanol-induced ulcer (rats) | Reduction in ulcer index at ≥50 mg/kg | R | [Reviewed; similar mechanism to limonene] |

### 1.4 Dose Ranges and Routes

| Route | Species | Dose | Effect |
|---|---|---|---|
| i.p. | Mouse | 50–200 mg/kg | Antinociceptive (writhing, CIPN models) |
| i.p. | Mouse | 100 mg/kg | Antinociceptive comparable to morphine 10 mg/kg (neuropathic) |
| Inhalation | Mouse | Vapor exposure (≈ng/mL serum) | Anxiolytic without sedation |
| Oral | Human | 80 mg (single dose, lavender EO capsule = Silexan) | Anxiolytic (clinically studied; Silexan 80 mg/day approved in Germany) |
| Oral | Human (PK study) | Not specified | Tmax ~1 h, Cmax 85.5 ± 42.6 ng/mL, t½ 3.9 ± 2.9 h, AUC 442 ± 243 h·ng/mL |
| Oral/inhalation | Rat/mouse | LD50 >5000 mg/kg (oral, rat) | GRAS (FEMA #2635) |

### 1.5 Pharmacokinetics

| Parameter | Value | Notes |
|---|---|---|
| Oral absorption | Rapid | Complete GI absorption reported |
| Tmax (oral, human) | ~1 h | [Wang et al. 2023, doTERRA/Univ Mississippi LC-MS/MS study](https://media.doterra.com/us/en/brochures/science-articles/linalool-oral-pharmacokinetics.pdf) |
| Cmax (oral, human) | 85.5 ± 42.6 ng/mL | Single oral dose (dose not specified in available abstract) |
| t½ (oral, human) | 3.9 ± 2.9 h | Wide individual variability |
| AUC (oral, human) | 442 ± 243 h·ng/mL | Detected up to 8 h post-dose |
| CL/F | 385 ± 287 L/h | Large volume of distribution |
| Vd/F | 1495 ± 898 L | Consistent with high lipophilicity (logP ~3) |
| BBB penetration | Presumed; CNS effects confirmed | No direct human CSF data; logP ~3 supports passive diffusion |
| CYP metabolism | CYP-mediated to 8-hydroxylinalool, 8-oxolinalool, 8-carboxylinalool | Oxidation at C8 is primary metabolic route |
| Plasma protein binding | Not quantified | Expected high due to lipophilicity |
| Oxidation products | Linalool oxide (in air) | Less biologically active at GABA-A vs. parent |

### 1.6 Safety

- **LD50** (oral, rat): >5,000 mg/kg — [FEMA GRAS #2635](https://www.femaflavor.org/fema-gras); GRAS by FDA
- **Contact allergy**: Autoxidation generates linalool hydroperoxides, which are potent contact allergens. In patch tests, oxidized linalool is significantly more sensitizing than non-oxidized material. Prevalence in fragrance-allergic patients ~7–10%. [PMC6040011](https://pmc.ncbi.nlm.nih.gov/articles/PMC6040011/)
- **NOAEL**: Not formally established for oral dosing in humans; 80 mg/day (Silexan) well-tolerated in clinical trials
- **Drug interactions**: CYP3A4 inhibitor potential at high concentrations (preclinical); clinical significance at physiological doses not established
- **Pregnancy**: Limited data; no definitive guidance; lavender EO contraindicated in high oral doses during pregnancy (precautionary)
- **Enantiomer differences**: (S)-(-)-linalool (lavender type) has stronger anxiolytic/antinociceptive profile than (R)-(+)-linalool in rodent models
- **Caffeine antagonism**: Caffeine and sclareol can offset sedative effects of linalool ([Islam et al. 2025](https://link.springer.com/10.1007/s00210-025-03915-4))

---

## 2. LIMONENE

### 2.1 Molecular Identity

| Property | Value |
|---|---|
| IUPAC name | (R)-(+)-1-methyl-4-(prop-1-en-2-yl)cyclohex-1-ene (d-limonene predominates in citrus) |
| CAS# | 5989-27-5 (R/d-); 5989-54-8 (S/l-) |
| SMILES | [C@@H]1(CC/C(=C/[H])/[H])(C(=C)C)CC1 → standard: C1CC(=CC1)C(C)=C and C1CCC(CC1)=C(C)C |
| Molecular formula | C₁₀H₁₆ |
| MW | 136.23 g/mol |
| Type | Monocyclic monoterpene |
| Boiling point | 176°C |
| logP | 4.57 (calculated) |
| Water solubility | ~0.01 mg/mL (poorly soluble) |
| Natural sources | Orange peel, lemon, cannabis |

> [PubChem CID 440917](https://pubchem.ncbi.nlm.nih.gov/compound/Limonene); [PMC6239267](https://pmc.ncbi.nlm.nih.gov/articles/PMC6239267/)

### 2.2 Biological Targets

| Target | Effect | Value | Tier | Reference |
|---|---|---|---|---|
| 5-HT1A | Activation inferred | No direct Ki; elevated DA and 5-HT levels in frontal cortex and hippocampus in rodents | R | [Russo 2011, Br J Pharmacol; reviewed in PMC6239267](https://pmc.ncbi.nlm.nih.gov/articles/PMC6239267/) |
| Spinal FOS expression | Antihyperalgesic via downregulation | Reduction of c-Fos immunoreactivity in spinal dorsal horn | R | Baseline CSV; Russo 2011 |
| NF-κB | Inhibition | Reduces NF-κB transcription; decreases IL-1β, IL-6, TNF-α, MPO | IV/R | [De Souza et al. 2019, PubMed 30668410](https://pubmed.ncbi.nlm.nih.gov/30668410/) |
| TRP channels (TRPV1/TRPA1) | Activation at high concentrations | Weak agonist; EC50 not precisely established for limonene | IV | Indirect; [Jansen et al. 2019](https://pmc.ncbi.nlm.nih.gov/articles/PMC6768052/) |
| AChE | Inhibition | Moderate IC50 (10–50 µg/mL range in vitro, species-dependent) | IV | [PMC7996600](https://pmc.ncbi.nlm.nih.gov/articles/PMC7996600/) |
| Adenosine A2A | Agonist-like functional activity | cAMP assay; in silico docking consistent with A2A agonism (common terpene mechanism) | IV/R | [LaVigne et al. 2025 PMC11511650](https://pmc.ncbi.nlm.nih.gov/articles/PMC11511650/) |
| COX-2 / iNOS | Inhibition | Reduces NO, PGE2 production in macrophages | IV | Multiple |
| CB1 receptor | Weak partial agonist | ~10–50% of THC efficacy in CB1 cAMP assay at 1–10 µM | IV | [Raz et al. 2023 Biochem Pharmacol doi:10.1016/j.bcp.2023.115548](https://www.sciencedirect.com/science/article/pii/S0006295223001399) |

### 2.3 Therapeutic Effects

| Effect | Model | Dose / Observation | Tier | Reference |
|---|---|---|---|---|
| Anxiolytic | Elevated plus maze, open field (mice) | 10 mg/kg i.p. effective; correlates with elevated DA/5-HT | R | [Russo 2011; reviewed PMC6239267](https://pmc.ncbi.nlm.nih.gov/articles/PMC6239267/) |
| Analgesic / Antihyperalgesic | Chronic musculoskeletal pain, carrageenan | Effective at 50–100 mg/kg oral in rodent models | R | Baseline CSV |
| Gastroprotective | Ethanol ulcer model (Wistar rats) | 50 mg/kg oral = lowest effective dose; 93% reduction in ulcer area; increases mucus, reduces MPO, TNF-α, IL-6, IL-1β | R | [De Souza et al. 2019 PubMed 30668410](https://pubmed.ncbi.nlm.nih.gov/30668410/) |
| Anti-inflammatory | Multiple models | 25–100 mg/kg oral; 50 mg/kg most studied | R | PMC12000914; De Souza 2019 |
| Antioxidant | In vitro; diabetic rats | Restores SOD, CAT, GPx, GSH; reduces MDA | IV/R | [PMC12000914](https://pmc.ncbi.nlm.nih.gov/articles/PMC12000914/) |
| Anticancer (human, Phase II) | Breast cancer, 43 women | 2 g/day × 2–6 weeks → 22% reduction in breast tumor HER2 expression; perillic acid metabolite may be active agent | H | [Crowell et al. 1994; Vigushin et al. 1998; reviewed PMC6239267] |
| Antimicrobial | Antibacterial, antifungal | Bacteriostatic at 20 mL/L; EC50 1.87 µg/mL against influenza strain H1N1 in vitro | IV | PMC12000914 |
| Bronchodilator / Antiasthmatic | Murine asthma model | Reduces airway inflammation; mechanism via COX-2/cytokine suppression | R | Reviewed; α-pinene more studied for this |
| Antidiabetic (metabolic) | Streptozotocin-diabetic rats | 50–200 mg/kg → antioxidant improvement, hypoglycaemic trend | R | PMC12000914 |
| Neuroprotective | Ischemia, cognitive models | Anti-neuroinflammatory; reduced neuronal apoptosis | R | Multiple |

### 2.4 Dose Ranges and Routes

| Route | Species | Dose | Effect |
|---|---|---|---|
| Oral | Rat/mouse | 25–100 mg/kg | Gastroprotection, anti-inflammatory, antinociceptive |
| Oral | Human | 1–2 g/day | Anticancer (Phase I/II clinical trials); well-tolerated |
| i.p. | Mouse | 10 mg/kg | Anxiolytic |
| Inhalation | Mouse | Vapor (ng/mL range) | Anxiolytic, antistress |

### 2.5 Pharmacokinetics

| Parameter | Value | Notes |
|---|---|---|
| Oral absorption | Rapid and complete from GI tract (human and animal) | [PMC12000914](https://pmc.ncbi.nlm.nih.gov/articles/PMC12000914/) |
| Primary metabolites | Perillic acid, dihydroperillic acid, limonene-1,2-diol, perillyl alcohol, carvone | Perillic acid is pharmacologically active |
| Tmax | Rapid (~1 h, inferred from rat data) | [PMID 9682146](https://pubmed.ncbi.nlm.nih.gov/9682146/) |
| t½ | ~1–2 h (limonene parent); perillic acid t½ longer (~12 h in human) | [Semanticscholar perillic acid human PK](https://www.semanticscholar.org/paper/Pharmacokinetics-of-perillic-acid-in-humans-after-a-Chow-Salazar/c092dbfb52bf79816059282ebcf7b97e5a962272) |
| CYP metabolism | CYP2C9, CYP3A4 (hydroxylation to perillyl alcohol, then perillic acid by CYP3A4) | [PMC6239267](https://pmc.ncbi.nlm.nih.gov/articles/PMC6239267/) |
| logP | 4.57 — highly lipophilic; distributes to adipose and lipid compartments | |
| BBB | Likely good penetration given logP and CNS behavioral effects confirmed | |
| Plasma protein binding | Not precisely quantified; high expected |
| Urinary excretion | Primarily as perillic acid and dihydroperillic acid glucuronides | |

### 2.6 Safety

- **LD50** (oral, rat): >5,000 mg/kg — GRAS FDA; FEMA #2633
- **Carcinogenicity**: Male F-344/N rat NTP 2-year study showed renal tubular tumors via α2μ-globulin mechanism, which is rat-specific and not extrapolatable to humans. FEMA Panel concluded no human carcinogenic risk. [FEMA GRAS paper](https://www.femaflavor.org/sites/default/files/15.%20GRAS%20Substances%20(3755-3774).pdf)
- **Contact dermatitis / allergy**: Autoxidation generates limonene-1,2-hydroperoxide and limonene-1,2-epoxide — major contact allergens. Patch-test positivity: ~1–2.5% of tested dermatitis patients (higher in industrial workers with skin exposure). [PMC6040011](https://pmc.ncbi.nlm.nih.gov/articles/PMC6040011/)
- **Drug interactions**: CYP3A4 substrate/mild inhibitor — theoretical interaction with CYP3A4-sensitive drugs at high oral doses; clinical data lacking
- **NOAEL**: 250 mg/kg/day rat oral in 13-week study (standard toxicology)
- **Human doses up to 2 g/day well-tolerated** in oncology trials

---

## 3. MYRCENE

### 3.1 Molecular Identity

| Property | Value |
|---|---|
| IUPAC name | (E)-7-methyl-3-methyleneoct-1,6-diene (β-myrcene) |
| CAS# | 123-35-3 |
| SMILES | C=CC(=C)CCC=C(C)C |
| Molecular formula | C₁₀H₁₆ |
| MW | 136.23 g/mol |
| Type | Acyclic monoterpene |
| Boiling point | 167°C |
| logP | 4.3 (calculated) |
| Water solubility | Poorly soluble (~0.01 mg/mL) |
| Natural sources | Cannabis (1–65% of terpene fraction), hops (*Humulus lupulus*), bay leaves, mango |

> [PubChem CID 31253](https://pubchem.ncbi.nlm.nih.gov/compound/Myrcene); [Australian Industrial Chemicals Eval 2022](https://www.industrialchemicals.gov.au/sites/default/files/2022-05/EVA00048%20-%20Evaluation%20statement%20-%2030%20May%202022.pdf)

### 3.2 Biological Targets

| Target | Effect | Value | Tier | Reference |
|---|---|---|---|---|
| TRPV1 | Agonist/activator | Dominant among terpenes in TRPV1-dependent Ca²⁺ flux at ~1–10 µM; triggers downstream desensitization | IV | [Jansen et al. 2019 PMC6768052](https://pmc.ncbi.nlm.nih.gov/articles/PMC6768052/) |
| CB1 (indirect) | Enhances endocannabinoid tone | Does NOT displace CP 55,940 from CB1 at 10 µM (no direct binding); enhances 2-AG/AEA activity; CB1 antagonist SR141716A blocks analgesic effects | IV/R | [LaVigne et al. 2025 PMC12353019](https://pmc.ncbi.nlm.nih.gov/articles/PMC12353019/) |
| CB1 (direct, functional) | Weak partial agonist | ~10–50% of THC efficacy in cAMP assay at 1–10 µM | IV | [Raz et al. 2023 doi:10.1016/j.bcp.2023.115548](https://www.sciencedirect.com/science/article/pii/S0006295223001399) |
| Opioid receptors (mu/delta) | Indirect — blocked by naloxone in some models | Opioid antagonists partially reverse analgesia; myrcene may stimulate endogenous opioid release | R | [Reviewed in fundacion-canna.es; NIH grant R01-AT010762](https://grantome.com/grant/NIH/R01-AT010762-01) |
| GABA-A | Allosteric modulation (proposed) | Not quantified; behavioral evidence of sedative/allosteric activity in early studies | R | Russo 2011 review |
| Adenosine A2A | Agonist-like (in vivo) | A2A antagonist istradefylline 3.2 mg/kg blocks antinociception in CIPN mice | R | [LaVigne et al. 2025 PMC11511650](https://pmc.ncbi.nlm.nih.gov/articles/PMC11511650/) |
| NF-κB / COX-2 / TNF-α | Inhibition | Reduces LPS-induced cytokines; reduces carrageenan edema | IV/R | Multiple |
| α2-Adrenoceptor | Proposed activation (Rao et al.) | Contested; may explain some analgesic effects, but central mechanism more likely | R | Reviewed in fundacion-canna.es |

**Key negative finding**: Patch-clamp recordings showed 1 µM myrcene had no effect on excitatory postsynaptic current (EPSC) amplitudes or depolarization-induced suppression of excitation (DSE). CP 55,940 binding was not displaced by 10 µM myrcene — ruling out direct orthosteric CB1 binding. [PMC12353019](https://pmc.ncbi.nlm.nih.gov/articles/PMC12353019/)

### 3.3 Therapeutic Effects

| Effect | Model | Dose / Observation | Tier | Reference |
|---|---|---|---|---|
| Antinociceptive (thermal) | Hot plate test (mice) | Effective at 1–5 mg/kg s.c. (inflammatory model) to 10–100 mg/kg i.p. (neuropathic); sex differences noted (females more sensitive) | R | [LaVigne et al. 2025 PMC12353019](https://pmc.ncbi.nlm.nih.gov/articles/PMC12353019/) |
| Anti-allodynic (neuropathic) | CCI mouse model (von Frey) | 1–200 mg/kg i.p. dose-dependent; minimum effective dose 10 mg/kg (F) / 100 mg/kg (M) | R | PMC12353019 |
| Anti-allodynic (arthritis) | von Frey in arthritic rats | 1–5 mg/kg s.c. effective | R | Reviewed in PMC12353019 |
| Anti-inflammatory | Carrageenan paw, LPS | Reduces IL-1β, IL-6, TNF-α; edema reduction | R | [Russo 2011; fundacion-canna.es review](https://www.fundacion-canna.es/en/anti-inflammatory-anti-nociceptive-properties-v-myrcene) |
| Sedative / "Couch-lock" | Locomotor activity assay | Does NOT alter locomotion or temperature at analgesic doses (10–200 mg/kg i.p.) in latest study; sedation reported at very high doses in older literature | R | **PMC12353019 (2025)** — disputed earlier claims |
| Antioxidant | In vitro assays | DPPH radical scavenging; reduces MDA | IV | Multiple |
| Antimicrobial | Various bacteria/fungi | MIC ~1–10 mg/mL (modest activity alone) | IV | Reviews |
| Opioid-sparing | Morphine combinations | 100 mg/kg myrcene + morphine 3.2 mg/kg → enhanced antinociception vs. either alone | R | [LaVigne biorXiv 2023 / PMC11511650](https://pmc.ncbi.nlm.nih.gov/articles/PMC11511650/) |

**The "couch-lock" myth**: The popular claim that myrcene causes the sedating "indica" effect is not supported by current evidence. The 2025 study by LaVigne et al. explicitly found that myrcene (1–200 mg/kg i.p.) **did not alter locomotion or body temperature** at analgesic doses. The indica/sativa terpene-determinism model lacks scientific validation. [PMC12353019](https://pmc.ncbi.nlm.nih.gov/articles/PMC12353019/)

### 3.4 Dose Ranges and Routes

| Route | Species | Dose | Effect |
|---|---|---|---|
| s.c. | Male rat | 1–5 mg/kg | Anti-inflammatory hyperalgesia |
| i.p. | Male mouse | ≥100 mg/kg | Mechanical anti-allodynia (CCI) |
| i.p. | Female mouse | ≥10 mg/kg | Mechanical anti-allodynia (CCI) |
| i.p. | Mouse | 200 mg/kg | Antinociception ≈ morphine 10 mg/kg |
| Oral | Human | Not established — no human clinical trial data |  |

### 3.5 Pharmacokinetics

| Parameter | Value | Notes |
|---|---|---|
| Oral absorption | Presumed moderate-good; GI absorption data limited | |
| logP | 4.3 — distributes to adipose/lipid compartments | |
| BBB | Expected (logP, CNS behavioral effects) | |
| CYP metabolism | CYP3A4 primary; likely epoxidation and hydroxylation | Limited human data |
| t½ | Not established in humans | |
| Plasma protein binding | Not quantified | High expected |
| LD50 | 7-methyl-3-methylene (myrcene) — oral rat LD50 ~1,600 mg/kg | [Australian NICNAS eval 2022](https://www.industrialchemicals.gov.au/sites/default/files/2022-05/EVA00048%20-%20Evaluation%20statement%20-%2030%20May%202022.pdf) |

### 3.6 Safety

- **LD50** (oral, rat): ~1,600–5,000 mg/kg (conflicting sources; FEMA GRAS #2762)
- **Genotoxicity**: Mixed results; some in vitro micronucleus assays positive at high concentrations; not confirmed as genotoxic in in vivo studies at food-contact levels
- **Embryotoxicity**: Some evidence of embryo-fetotoxicity at high doses in rats (300–600 mg/kg); [PMID 8474729](https://www.sciencedirect.com/science/article/abs/pii/027869159390175X) — not relevant at physiological terpene exposures
- **Drug interactions**: CB1 modulation (indirect) may potentiate THC and cannabinoids; opioid system interaction suggests monitoring with opioid medications
- **Contact sensitization**: Lower risk than limonene/linalool (no major oxidation-product allergy)

---

## 4. α-PINENE / β-PINENE

### 4.1 Molecular Identity

| Property | α-Pinene | β-Pinene |
|---|---|---|
| IUPAC | (1R,5R)-4,6,6-trimethylbicyclo[3.1.1]hept-3-ene | (1S,5S)-6,6-dimethyl-2-methylenebicyclo[3.1.1]heptane |
| CAS# | 80-56-8 (±); 7785-70-8 (1R,+) | 127-91-3 |
| SMILES (α) | [C@@H]1([C@@H]2CC1(C)C)CC/C2=C(\[H])C | Bicyclic structure |
| MW | 136.23 g/mol | 136.23 g/mol |
| Type | Bicyclic monoterpene | Bicyclic monoterpene |
| BP | 155°C | 163°C |
| logP | 4.44 (α); 4.04 (β) | |
| Sources | Pine resin, cannabis, rosemary, fir | Pine, cannabis, rosemary |

> [PubChem CID 6654 (α-pinene)](https://pubchem.ncbi.nlm.nih.gov/compound/alpha-Pinene); [PubChem CID 14896 (β-pinene)](https://pubchem.ncbi.nlm.nih.gov/compound/beta-Pinene)

**Key distinction**: α-Pinene has the double bond in the ring; β-pinene has an exocyclic methylene group. Both are bicyclic. α-Pinene is more abundant in cannabis and more pharmacologically studied. β-Pinene is the primary terpene in some pine/rosemary species.

### 4.2 Biological Targets

| Target | Effect | Value | Tier | Reference |
|---|---|---|---|---|
| AChE (AChEI) | Inhibition of acetylcholinesterase | IC50 α-pinene: ~0.67–2.9 mg/mL in some in vitro assays; potency lower than physostigmine but notable for a volatile terpene | IV | [PMC7996600](https://pmc.ncbi.nlm.nih.gov/articles/PMC7996600/) |
| GABA-A | Modulation (unclear direction) | Bicyclic structure noted for GABA-A activity; positive modulation documented for some bicyclic monoterpenes (myrtenol, verbenol); α-pinene direct data limited | IV | [Kessler 2014, cited in Frontiers Chem 2017](https://www.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2017.00046/full) |
| CB1 (functional) | Weak partial agonist | ~10–50% of THC cAMP efficacy at µM concentrations | IV | [Raz et al. 2023](https://www.sciencedirect.com/science/article/pii/S0006295223001399) |
| TRPV3 / TRPM8 | Proposed agonism | Menthol-type cooling axis for TRPM8; TRPV3 warm sensing; no Ki published for pinenes specifically | IV | [Russo 2011; reviewed] |
| Voltage-gated Na⁺ channels | Inhibition | Anticonvulsant mechanism proposed; no precise IC50 for pinene | IV | Multiple |
| NF-κB / COX-2 / TNF-α | Inhibition | Reduces LPS-induced cytokine production | IV/R | [PMC6269770](https://pmc.ncbi.nlm.nih.gov/articles/PMC6269770/) |
| Adenosine A2A | Functional agonist | A2A-mechanism shared with other monoterpenes in CIPN model | R | [PMC11511650](https://pmc.ncbi.nlm.nih.gov/articles/PMC11511650/) |

### 4.3 Therapeutic Effects

| Effect | Model | Dose / Observation | Tier | Reference |
|---|---|---|---|---|
| Anti-inflammatory / Analgesic | Carrageenan, acetic acid writhing | 10–50 mg/kg oral; effects lasting >48 h in mice | R | Baseline CSV; [PMC6269770](https://pmc.ncbi.nlm.nih.gov/articles/PMC6269770/) |
| Anticonvulsant | PTZ, electroshock (rodents) | Pinene essential oil preparations; specific dose for pure compound not well-defined | R | Russo 2011; reviewed |
| Bronchodilator / Antiasthmatic | Airway challenge models | α-Pinene: expectorant, bronchodilator at 10–50 mg/kg; inhibits bronchoconstriction | R/H | [Russo 2011; de Sá Silveira e Sá 2013](https://pmc.ncbi.nlm.nih.gov/articles/PMC6269770/) |
| Antimicrobial | Bacteria, fungi | MIC 0.5–8 mg/mL; stronger than β-pinene generally | IV | PMC6269770 |
| Antioxidant | DPPH, ABTS, lipid peroxidation | Moderate; less than linalool by most assays | IV | Multiple |
| Neuroprotective (AChEI) | In vitro neuronal models | AChE inhibition may reduce Aβ aggregation downstream | IV | PMC7996600 |
| Antinociceptive (terpene mixture) | CIPN + inflammatory pain (mice) | 200 mg/kg i.p.; ~equal efficacy to morphine 10 mg/kg | R | [PMC11511650](https://pmc.ncbi.nlm.nih.gov/articles/PMC11511650/) |
| Gastroprotective (β-pinene) | Ethanol/HCl gastric ulcer model | β-pinene in Citrus essential oil contributes gastroprotection via PGE2/mucus/NO | R | [doi:10.1016/j.cbi.2009.04.006, Citrus lemon EO] |

**β-Pinene specific**: Produces distinct pharmacological actions; gastroprotective mechanisms via nitric oxide / prostaglandin E2 pathways reported. More limited literature than α-pinene.

### 4.4 Dose Ranges and Routes

| Route | Species | Dose | Effect |
|---|---|---|---|
| Oral | Mouse | 10–50 mg/kg | Anti-inflammatory, analgesic |
| i.p. | Mouse | 200 mg/kg | Antinociceptive (terpene mix) |
| Inhalation | Human | 10–450 mg/m³ (occupational; pine resin processing) | See PK section |

### 4.5 Pharmacokinetics

| Parameter | α-Pinene (Human Inhalation) | Notes |
|---|---|---|
| Pulmonary uptake | ~60% at ≥225 mg/m³; linear with concentration | [Falk et al. 1990 / SJWEH 2004 doi](https://www.sjweh.fi/article/1771) |
| Blood elimination | **Triphasic**: α t½ 4.8 min, β t½ 38 min, γ t½ 695 min | Gamma phase suggests high-affinity adipose depot |
| Total blood clearance | ~1.1 L/h/kg | Consistent with high lipophilicity |
| Urinary excretion | <0.001% unchanged; ~8% as exhaled air unchanged | Primarily metabolized |
| Urinary metabolites | cis/trans-verbenol, myrtenol (CYP-mediated allylic oxidation) | [Eriksson & Levin 1996, cited in Toxicol Appl Pharmacol PMC] |
| logP | 4.44 — strong adipose accumulation | |
| BBB | Likely (logP, CNS effects); no direct CSF data | |
| Oral bioavailability | Not established; inhalation is primary route | |

**Metabolic toxicology note**: α-Pinene is an indoor air pollutant metabolized to carveol and related species; at occupational exposures, sensory irritation threshold ~10 mg/m³. [PMC9298155](https://pmc.ncbi.nlm.nih.gov/articles/PMC9298155/)

### 4.6 Safety

- **LD50** (oral, rat): α-pinene ~3,700 mg/kg; β-pinene ~4,700 mg/kg — GRAS (FEMA #2902, #2903)
- **Contact sensitization**: α-Pinene autooxidizes to form sensitizing allylic hydroperoxides (pinene hydroperoxides) and epoxides (α-pinene epoxide), though less frequent clinically than limonene. [PMC6040011](https://pmc.ncbi.nlm.nih.gov/articles/PMC6040011/)
- **NOAEL (inhalation)**: No acute lung function changes observed at 450 mg/m³ (20 min post-exposure); [SJWEH 2004](https://www.sjweh.fi/article/1771)
- **Drug interactions**: AChE inhibition may potentiate cholinergic drugs; mild CYP modulation possible
- **Occupational hazard**: Sensory irritation at >10 mg/m³ in volunteers

---

## 5. β-CARYOPHYLLENE (BCP)

### 5.1 Molecular Identity

| Property | Value |
|---|---|
| IUPAC name | (1R,9S,E)-4,11,11-trimethyl-8-methylenebicyclo[7.2.0]undec-4-ene |
| CAS# | 87-44-5 |
| SMILES | [C@@H]1(/C=C/CCC(=C)[C@@H]2CC(CC12)(C)C)C(=C)C → approximate |
| Molecular formula | C₁₅H₂₄ |
| MW | 204.35 g/mol |
| Type | **Bicyclic sesquiterpene** |
| Boiling point | 254–255°C |
| logP | 6.63 (calculated; highly lipophilic) |
| Water solubility | Very low (~0.0001 mg/mL) |
| Natural sources | Black pepper (*Piper nigrum*), cannabis, cloves, basil, copaiba balsam |
| FEMA status | GRAS #2252 |

> [PubChem CID 5281515](https://pubchem.ncbi.nlm.nih.gov/compound/beta-Caryophyllene); [Gertsch et al. 2008 PNAS](https://www.for926.uni-bonn.de/kunden/for926/content/e229/e709/e1294/2008-Gertsch-PNAS.pdf)

### 5.2 Biological Targets

| Target | Effect | Value | Tier | Reference |
|---|---|---|---|---|
| **CB2 receptor** | Full selective agonist | **Ki = 155 ± 4 nM** (CB2); no significant CB1 binding (Ki CB1 = 485 ± 36 nM) | IV | [Gertsch et al. 2008 PNAS doi:10.1073/pnas.0803601105](https://pubmed.ncbi.nlm.nih.gov/18574142/) |
| CB2 (functional) | Gi/cAMP; full agonist | EC50 ~1.9 ± 0.3 µM (cAMP assay); ~150-fold lower potency vs. WIN55,212-2 EC50 38 ± 5.7 nM | IV | [Gertsch et al. 2008](https://www.for926.uni-bonn.de/kunden/for926/content/e229/e709/e1294/2008-Gertsch-PNAS.pdf) |
| PPAR-α | Activation | Drives fatty acid oxidation enzyme transcription via PGC-1α; SIRT1 activation | IV/R | [Frontiers Pharmacol 2021](https://www.frontiersin.org/journals/pharmacology/articles/10.3389/fphar.2021.590201/full) |
| PPAR-γ | Activation | Modulates adipogenesis; controls cytokine overproduction; contributes to anti-inflammatory effects | IV/R | [PMC12565869](https://pmc.ncbi.nlm.nih.gov/articles/PMC12565869/); [Frontiers Pharmacol 2021](https://www.frontiersin.org/journals/pharmacology/articles/10.3389/fphar.2021.590201/full) |
| NF-κB | Inhibition | Inhibits LPS-induced phosphorylation of ERK1/2, JNK1/2 in macrophages (CB2-dependent) | IV | [Gertsch 2008; Frontiers Pharmacol 2021](https://www.frontiersin.org/journals/pharmacology/articles/10.3389/fphar.2021.590201/full) |
| TNF-α / IL-6 / IL-1β | Downregulation | Reduces cytokine storm mediators in multiple in vivo models | IV/R | PMC12565869; PMC10970213 |
| Adenosine A2A | Agonist-like (shared monoterpene mechanism) | A2A-blockade blunts antinociception in CIPN; BCP has additional CB2 component | R | [PMC11511650](https://pmc.ncbi.nlm.nih.gov/articles/PMC11511650/) |
| Mu-opioid | Indirect (opioid-sparing) | NIH-funded data suggest BCP + opioid synergy, mu-OR mediated in part | R | [NIH grant R01-AT010762](https://grantome.com/grant/NIH/R01-AT010762-01) |
| TRP channels | Not a primary target | No significant TRP activation reported | IV | [Jansen 2019](https://pmc.ncbi.nlm.nih.gov/articles/PMC6768052/) |
| Cav3.2 (T-type Ca²⁺) | Inhibition proposed | See secondary terpenes section; bisabolol and camphene more studied | R | Baseline CSV |

### 5.3 Therapeutic Effects

| Effect | Model | Dose / Observation | Tier | Reference |
|---|---|---|---|---|
| Anti-inflammatory (systemic) | Carrageenan (WT vs. CB2 KO mice) | **5 mg/kg oral** strongly reduces carrageenan-induced inflammation; absent in CB2-KO → proves CB2-dependence | R | [Gertsch et al. 2008 PNAS](https://pubmed.ncbi.nlm.nih.gov/18574142/) |
| Anti-inflammatory | LPS macrophage, multiple models | Reduces IL-6, TNF-α, IL-1β, NO; inhibits ERK1/2/JNK1/2 | IV | Frontiers Pharmacol 2021 |
| Analgesic (inflammatory) | CFA, carrageenan (rodents) | 5–50 mg/kg oral effective; intraplantar BCP also reduces local inflammation | R | [PMC12072555 2025](https://pmc.ncbi.nlm.nih.gov/articles/PMC12072555/) |
| Analgesic (neuropathic) | SNL, CCI models | 50 mg/kg oral; CB2-dependent reduction of allodynia/hyperalgesia | R | [Frontiers Neurosci 2020](https://www.frontiersin.org/journals/neuroscience/articles/10.3389/fnins.2020.00850/full); [PMID 30343038](https://pubmed.ncbi.nlm.nih.gov/30343038/) |
| Anxiolytic | EPM, OFT, MBT (mice) | 10–50 mg/kg i.p.; dose-dependent anxiolysis; 200 mg/kg also effective | R | [PMC10970213](https://pmc.ncbi.nlm.nih.gov/articles/PMC10970213/) |
| Antidepressant | FST, TST (mice) | CB2R + PPARγ mechanisms; BCP 30 mg/kg/day p.o. × 4 weeks reduced depression-like behavior | R | PMC10970213 |
| Neuroprotective | Neuroinflammation, Aβ models | Reduces neuroinflammation, oxidative stress; protective in Alzheimer's models | R | PMC10970213 |
| Gastroprotective | DSS-colitis model; peptic ulcer (human case reports) | 50–100 mg/kg oral (Viphyllin extract); improved dyspepsia/epigastric pain in human ulcer patients | R/H | PMC10970213 |
| Antioxidant | DPPH, ABTS; NRF2 activation | Activates NRF2/HO-1 pathway; reduces oxidative stress | IV/R | Multiple |
| Antimicrobial | Antibacterial, antifungal | MIC 0.5–4 mg/mL; more active in combination with antibiotics | IV | Multiple |
| Metabolic / Antiobesity | High-fat diet rodent models | Reduces adiposity, insulin resistance; PPAR-γ/CB2-mediated | R | PMC12565869 |

**Sex differences in pain**: Female mice show superior antinociceptive response to BCP in CCI model relative to males; sex-specific endocannabinoid system differences implicated. [Frontiers Neurosci 2020](https://www.frontiersin.org/journals/neuroscience/articles/10.3389/fnins.2020.00850/full)

### 5.4 Dose Ranges and Routes

| Route | Species | Dose | Effect |
|---|---|---|---|
| Oral | Mouse | 5 mg/kg | Anti-inflammatory (carrageenan, CB2-dependent) |
| Oral | Mouse/rat | 10–50 mg/kg | Analgesic, anxiolytic, neuroprotective |
| Oral | Rat | 30 mg/kg/day × 4 weeks | Antidepressant, metabolic |
| i.p. | Mouse | 10–200 mg/kg | Anxiolytic range |
| Intraplantar | Mouse | Local µg doses | Reduces local pain/inflammation |
| Oral | Human | Peptic ulcer patients (dose NR) | Improved dyspepsia symptoms |
| LD50 (oral) | Rat | >5,000 mg/kg | [Townsend Letter; Frontiers Pharmacol 2021] |
| LD50 (dermal) | Rabbit | >5,000 mg/kg | |
| Intratracheal (rat) | 12–48 mg/kg | Non-toxic to lungs | |

### 5.5 Pharmacokinetics

| Parameter | Value | Notes |
|---|---|---|
| Oral bioavailability | Low (pure BCP); significantly improved with formulation (SEDDS) | [PMC9104399](https://pmc.ncbi.nlm.nih.gov/articles/PMC9104399/) |
| Tmax (BCP neat oil) | ~3.07 h | Human healthy volunteers |
| Tmax (BCP-SEDDS) | ~1.43 h | Faster absorption with self-emulsifying drug delivery system |
| Cmax (BCP-SEDDS) | Significantly higher than neat oil | No gender differences in PK parameters |
| AUC improvement | SEDDS shows significantly higher AUC | PMC9104399 |
| t½ | Not precisely established in humans | |
| CYP metabolism | CYP3A4 primary; metabolized to β-caryophyllene oxide and related species | β-Caryophyllene oxide also bioactive |
| logP | 6.63 — very high lipophilicity; distributes to lipid compartments | |
| BBB | Expected (logP); CNS effects confirmed | |
| Plasma protein binding | High expected; not precisely quantified | |
| BCP/β-cyclodextrin complex | 2.6× increase in AUC₀₋₁₂ₕ vs. free BCP in rats | [PMID 23598076](https://pubmed.ncbi.nlm.nih.gov/23598076/) |

**Formulation note**: Because BCP has very high logP and poor aqueous solubility, oral bioavailability is bioformulation-dependent. SEDDS (self-emulsifying drug delivery systems) and β-cyclodextrin complexes significantly improve oral absorption.

### 5.6 Safety

- **LD50** (oral, rat): >5,000 mg/kg — GRAS (FEMA #2252); EU: approved as flavoring
- **Human safety**: No formal clinical trials for pure BCP in pain/anxiety; peptic ulcer improvement documented in limited human cohorts. BCP-SEDDS well-tolerated in human pharmacokinetic study.
- **Drug interactions**: CB2-mediated modulation of immune signaling; may interact with immunosuppressants. PPAR-γ activation → potential interaction with thiazolidinedione antidiabetics.
- **No CB1-mediated psychotropic effects**: Confirmed non-psychoactive at pharmacological doses
- **Oxidation**: β-Caryophyllene oxide is a metabolite/oxidation product; also bioactive but less characterized. Lower sensitization risk than oxygenated monoterpenes.

---

## 6. CROSS-TERPENE SUMMARY TABLES

### 6.1 Physicochemical Properties

| Terpene | Type | MW | logP | BP (°C) | Water Solubility | CAS# |
|---|---|---|---|---|---|---|
| Linalool | Acyclic monoterpenol | 154.25 | 2.97 | 198–199 | ~1.6 mg/mL | 78-70-6 |
| Limonene | Monocyclic monoterpene | 136.23 | 4.57 | 176 | ~0.01 mg/mL | 5989-27-5 |
| Myrcene | Acyclic monoterpene | 136.23 | 4.3 | 167 | ~0.01 mg/mL | 123-35-3 |
| α-Pinene | Bicyclic monoterpene | 136.23 | 4.44 | 155 | Poorly soluble | 80-56-8 |
| β-Pinene | Bicyclic monoterpene | 136.23 | 4.04 | 163 | Poorly soluble | 127-91-3 |
| β-Caryophyllene | Bicyclic sesquiterpene | 204.35 | 6.63 | 254–255 | ~0.0001 mg/mL | 87-44-5 |

### 6.2 Primary Biological Targets at a Glance

| Terpene | Primary Target(s) | Ki/EC50 (Key) | Tier |
|---|---|---|---|
| Linalool | GABA-A PAM, A2A agonist, VG Na⁺ block, NF-κB↓ | GABA-A: ~1.6× at 2 mM; no Ki established | IV/R |
| Limonene | 5-HT1A, A2A, NF-κB↓, AChE inhibitor | No direct Ki; functional EC50 estimated µM range | R |
| Myrcene | TRPV1 agonist, CB1 (indirect/functional), A2A, opioid (indirect) | CB1 cAMP: ~10–50% THC at µM | IV/R |
| α-Pinene | AChE inhibitor, A2A, GABA-A (weak), NF-κB↓ | AChE IC50 ~0.67–2.9 mg/mL | IV/R |
| β-Caryophyllene | CB2 full agonist, PPAR-α/γ, NF-κB↓ | CB2 Ki = **155 ± 4 nM** (EC50 ~1.9 µM functional) | IV/R/H |

### 6.3 Analgesic Dose Summary (Rodent)

| Terpene | Model | Min. Effective Dose | Route | Sex | Reference |
|---|---|---|---|---|---|
| Linalool | Writhing, neuropathic | 50–200 mg/kg | i.p. | M | de Sousa 2010; LaVigne 2025 |
| Limonene | Antihyperalgesic | 50–100 mg/kg | oral | M | Russo 2011 synthesis |
| Myrcene | Neuropathic (CCI) | 10 mg/kg (F) / 100 mg/kg (M) | i.p. | F>M | PMC12353019 |
| Myrcene | Inflammatory | 1–5 mg/kg | s.c. | M | Cited in PMC12353019 |
| α-Pinene | Inflammatory | ~10–50 mg/kg | oral | M | PMC6269770 |
| β-Caryophyllene | Inflammatory | **5 mg/kg** | oral | M | Gertsch 2008 PNAS |
| β-Caryophyllene | Neuropathic | 50 mg/kg | oral | M/F | Frontiers Neurosci 2020 |

### 6.4 Pharmacokinetic Comparison

| Terpene | Oral F% | Tmax | t½ | CYP | BBB |
|---|---|---|---|---|---|
| Linalool | High (presumed) | ~1 h (human) | 3.9 h (human oral) | CYP-mediated → 8-hydroxy/oxo metabolites | Yes (CNS effects) |
| Limonene | High | ~1 h (rat) | ~1–2 h (parent); ~12 h (perillic acid, human) | CYP2C9/3A4 → perillyl alcohol → perillic acid | Yes |
| Myrcene | Unknown | Unknown | Unknown | CYP3A4 (presumed) | Presumed |
| α-Pinene | Inhalation 60% (pulmonary) | Rapid | Triphasic (4.8/38/695 min) | CYP → verbenol, myrtenol | Presumed |
| β-Caryophyllene | Low (formulation-dependent) | 1.43–3.07 h (human) | Unknown | CYP3A4 → BCP oxide | Yes (CNS effects) |

### 6.5 Safety Comparison

| Terpene | LD50 (oral rat) | Contact Sensitization | Oxidation Products | GRAS Status |
|---|---|---|---|---|
| Linalool | >5,000 mg/kg | Low (hydroperoxides on aging) | Linalool oxide, linalool hydroperoxides | FEMA #2635 |
| Limonene | >5,000 mg/kg | **Moderate-high** (hydroperoxides) | Limonene-1,2-hydroperoxide, limonene-1,2-epoxide | FEMA #2633 |
| Myrcene | ~1,600–5,000 mg/kg | Low | Limited data | FEMA #2762 |
| α-Pinene | ~3,700 mg/kg | Low-moderate (hydroperoxides) | Pinene hydroperoxides, α-pinene epoxide | FEMA #2902 |
| β-Caryophyllene | >5,000 mg/kg | Very low | β-Caryophyllene oxide (bioactive) | FEMA #2252 |

---

## Notes on Evidence Quality and Known Gaps

1. **No established Ki/EC50 for limonene or myrcene at 5-HT1A receptor** — behavioral evidence only; mechanistic confirmation needed.
2. **Linalool GABA-A data** at 2 mM is supra-physiological; in vivo linalool concentrations at receptor likely in nM–µM range from oral/inhaled doses. Direct relevance of the PAM mechanism to anxiolytic effects at therapeutic doses remains unproven.
3. **Myrcene "couch-lock"** has no rigorous experimental support. The 2025 LaVigne et al. study (PMC12353019) explicitly tested and found NO locomotor or temperature effects at analgesic doses.
4. **Human clinical data** is almost entirely absent for individual terpenes in pain/anti-inflammatory contexts (exception: Silexan/linalool for anxiety, limonene in cancer Phase I/II, BCP in peptic ulcer case reports).
5. **BCP's CB2 Ki** (155 nM) is the most robust receptor-binding value in the field — established by radioligand displacement and confirmed across labs.
6. **α-Pinene AChE inhibition** is modest (mg/mL IC50 range) compared to pharmaceutical AChEIs (IC50 in nM range for donepezil) and unlikely to produce significant cholinergic effects at terpene exposure levels.
7. **Pharmacokinetics** are poorly characterized for myrcene specifically; no human PK study found.
8. **β-Pinene** is significantly understudied vs. α-pinene; most "pinene" effects in cannabis literature refer to α-pinene.

---

## Key References (Inline)

1. [Russo EB 2011 – Br J Pharmacol](https://pubmed.ncbi.nlm.nih.gov/21749363/) — Taming THC: potential cannabis synergy and phytocannabinoid-terpenoid entourage effects. PMID 21749363; PMCID PMC3165946
2. [Gertsch J et al. 2008 – PNAS](https://pubmed.ncbi.nlm.nih.gov/18574142/) — Beta-caryophyllene is a dietary cannabinoid. PMID 18574142; doi:10.1073/pnas.0803601105
3. [Jansen C et al. 2019 – Channels PMC6768052](https://pmc.ncbi.nlm.nih.gov/articles/PMC6768052/) — Myrcene and terpene regulation of TRPV1
4. [LaVigne JE et al. 2025 – PMC12353019](https://pmc.ncbi.nlm.nih.gov/articles/PMC12353019/) — Elucidating interplay between myrcene and cannabinoid systems in pain
5. [LaVigne JE et al. 2025 – PMC11511650](https://pmc.ncbi.nlm.nih.gov/articles/PMC11511650/) — Terpenes from Cannabis sativa Induce Antinociception via Adenosine A2A
6. [Raz N et al. 2023 – Biochem Pharmacol](https://www.sciencedirect.com/science/article/pii/S0006295223001399) — Selected cannabis terpenes synergize with THC to produce increased CB1 receptor activation; doi:10.1016/j.bcp.2023.115548
7. [Finlay DB et al. 2020 – Frontiers Pharmacol](https://www.frontiersin.org/journals/pharmacology/articles/10.3389/fphar.2020.00359/full) — Terpenoids From Cannabis Do Not Mediate an Entourage Effect by Acting at Cannabinoid Receptors; doi:10.3389/fphar.2020.00359
8. [Kessler A et al. 2017 – Frontiers Chem](https://www.frontiersin.org/journals/chemistry/articles/10.3389/fchem.2017.00046/full) — Metabolic Products of Linalool and Modulation of GABAA Receptors; doi:10.3389/fchem.2017.00046
9. [de Sousa DP et al. 2010 – ScienceDirect](https://www.sciencedirect.com/science/article/pii/S1526590010003883) — Antinociceptive effect of (-)-linalool
10. [Ahammed S et al. 2025 – Springer](https://link.springer.com/10.1007/s00210-025-03984-5) — Anti-arthritic potential of linalool; doi:10.1007/s00210-025-03984-5
11. [Islam MT et al. 2025 – Springer](https://link.springer.com/10.1007/s00210-025-03915-4) — Caffeine and sclareol offset linalool sedation; doi:10.1007/s00210-025-03915-4
12. [Wang YH et al. 2023 – Molecules (doTERRA/Univ Mississippi)](https://media.doterra.com/us/en/brochures/science-articles/linalool-oral-pharmacokinetics.pdf) — LC-MS/MS method for linalool oral PK in humans
13. [PMC9886818 – Curr Neuropharmacol 2023](https://pmc.ncbi.nlm.nih.gov/articles/PMC9886818/) — Linalool as a therapeutic and medicinal tool in depression and anxiety
14. [PMC3612440 – Koulivand et al. 2013](https://pmc.ncbi.nlm.nih.gov/articles/PMC3612440/) — Lavender and the nervous system
15. [PMC6239267 – Guimarães et al. 2018](https://pmc.ncbi.nlm.nih.gov/articles/PMC6239267/) — Biochemical significance of limonene and its metabolites
16. [PMC12000914 – IJND 2025](https://pmc.ncbi.nlm.nih.gov/articles/PMC12000914/) — From Citrus to Clinic: Limonene's journey
17. [De Souza MC et al. 2019 – PubMed 30668410](https://pubmed.ncbi.nlm.nih.gov/30668410/) — Gastroprotective effect of limonene; doi:10.1016/j.fct.2019.01.040
18. [PMC6269770 – de Sá Silveira e Sá 2013](https://pmc.ncbi.nlm.nih.gov/articles/PMC6269770/) — Anti-inflammatory activity of monoterpenes; doi:10.3390/molecules18011227
19. [SJWEH 2004 – Falk et al.](https://www.sjweh.fi/article/1771) — Uptake, distribution, elimination of alpha-pinene in man
20. [PMC9298155 – Xenobiotica 2022](https://pmc.ncbi.nlm.nih.gov/articles/PMC9298155/) — α-Pinene indoor air pollutant metabolism
21. [PMC7996600 – Biomolecules 2021](https://pmc.ncbi.nlm.nih.gov/articles/PMC7996600/) — Acetylcholinesterase inhibitory potential of terpenes
22. [Frontiers Pharmacol 2021 – Jha NK et al.](https://www.frontiersin.org/journals/pharmacology/articles/10.3389/fphar.2021.590201/full) — β-Caryophyllene: natural dietary CB2 receptor cannabinoid
23. [PMC10970213 – IJMS 2024](https://pmc.ncbi.nlm.nih.gov/articles/PMC10970213/) — Beta-caryophyllene: cannabinoid receptor type 2 review
24. [PMC12565869 – Metabolites 2025](https://pmc.ncbi.nlm.nih.gov/articles/PMC12565869/) — Effect of β-caryophyllene on PPAR-γ, NF-κB, CNR2
25. [PMC12072555 – IJMS 2025](https://pmc.ncbi.nlm.nih.gov/articles/PMC12072555/) — Intraplantar BCP alleviates pain and inflammation
26. [Frontiers Neurosci 2020 – PMC](https://www.frontiersin.org/journals/neuroscience/articles/10.3389/fnins.2020.00850/full) — CB2 agonist BCP in male and female neuropathic pain
27. [PMID 30343038 – 2019](https://pubmed.ncbi.nlm.nih.gov/30343038/) — BCP CB2 + PPAR-gamma, neuropathic pain
28. [PMC9104399 – Molecules 2022](https://pmc.ncbi.nlm.nih.gov/articles/PMC9104399/) — Enhanced oral bioavailability of β-caryophyllene (SEDDS)
29. [PMID 23598076 – 2013](https://pubmed.ncbi.nlm.nih.gov/23598076/) — BCP/β-cyclodextrin PK in rats
30. [PMC6040011 – Allergologie Select 2017](https://pmc.ncbi.nlm.nih.gov/articles/PMC6040011/) — Contact allergy to fragrances; oxidation products
31. [NIH Grant R01-AT010762](https://grantome.com/grant/NIH/R01-AT010762-01) — Analgesic and subjective effects of terpenes (myrcene, BCP opioid-sparing)
32. [Australian Industrial Chemicals Eval 2022 – Myrcene](https://www.industrialchemicals.gov.au/sites/default/files/2022-05/EVA00048%20-%20Evaluation%20statement%20-%2030%20May%202022.pdf)
33. [PMC11511650 – 2025](https://pmc.ncbi.nlm.nih.gov/articles/PMC11511650/) — Terpenes from Cannabis Induce Antinociception via A2A
34. [Russo EB & Marcu J 2017 – ethanrusso.org](http://ethanrusso.org/wp-content/uploads/2020/02/Russo-Marcu-Cannabis-Pharmacology-The-Usual-Suspects-and-a-Few-Promising-Leads-Adv-Pharmacol-2017-1.pdf) — Cannabis pharmacology: the usual suspects and promising leads
35. [Cannakeys 2024 – Raz 2023 summary](https://cannakeys.com/spotlights/terpenes-that-activate-cb1/) — Terpenes that activate CB1

---
*Compiled 2025. All values should be verified against primary sources before clinical application.*
