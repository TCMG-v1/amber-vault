-- ============================================================================
-- TERPENE SYNERGY DATABASE v2 — Seed Data (11 new terpenes + histamine axis)
-- ============================================================================
-- Sources:
--   /home/user/workspace/terpene_research_v2.md (48 citations)
--   /home/user/workspace/terpene_histamine_autoimmune.md (54 citations)
--
-- Applied AFTER seed.sql so v1 rows remain intact. NEW receptors and a few
-- new BCP/linalool rows are added to extend v1 coverage into the histamine
-- and autoimmune domains.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- NEW TERPENES (11)
-- ---------------------------------------------------------------------------
INSERT INTO terpenes VALUES
('humulene','alpha-Humulene',
 '(1E,4E,8E)-2,6,6,9-tetramethylcycloundeca-1,4,8-triene','6753-98-6','CC1=CCCC(=C)CCC(CC1)=C',
 'C15H24',204.35,'sesquiterpene','macrocyclic',NULL,5.2,0.0001,
 'Hops,Cannabis,Cloves,Sage','FEMA #3493'),
('terpinolene','Terpinolene',
 '1-methyl-4-(propan-2-ylidene)cyclohex-1-ene','586-62-9','CC(=C1CCC(=CC1)C)C',
 'C10H16',136.23,'monoterpene','monocyclic',184.0,3.8,0.01,
 'Cannabis,Sage,Rosemary,Lilac,Apple,Cumin','FEMA #3046'),
('bisabolol','alpha-Bisabolol',
 '(2S)-6-methyl-2-[(1S)-4-methylcyclohex-3-en-1-yl]hept-5-en-2-ol','515-69-5','CC(=CCC[C@@](C)(O)[C@@H]1CCC(=CC1)C)C',
 'C15H26O',222.37,'sesquiterpenol','monocyclic',153.0,4.1,0.0001,
 'Chamomile,Candeia tree,Cannabis','FEMA #2197'),
('geraniol','Geraniol',
 '(2E)-3,7-dimethylocta-2,6-dien-1-ol','106-24-1','CC(=CCC/C(=C/CO)/C)C',
 'C10H18O',154.25,'monoterpenol','acyclic',230.0,2.76,0.7,
 'Rose,Citronella,Palmarosa,Geranium,Cannabis','FEMA #2507'),
('camphene','Camphene',
 '(1R,4S)-2,2-dimethyl-3-methylenebicyclo[2.2.1]heptane','79-92-5','CC1(C)C2CCC1(C2=C)C',
 'C10H16',136.23,'monoterpene','bicyclic',159.0,3.5,0.001,
 'Cypress,Camphor,Fir,Conifers,Cannabis','FEMA #2229'),
('terpineol','alpha-Terpineol',
 '2-(4-methylcyclohex-3-en-1-yl)propan-2-ol','98-55-5','CC1=CCC(CC1)C(C)(C)O',
 'C10H18O',154.25,'monoterpenol','monocyclic',219.0,2.48,2.4,
 'Pine,Tea tree,Eucalyptus,Cardamom,Cannabis','FEMA #3045'),
('ocimene','beta-Ocimene',
 '(3E)-3,7-dimethylocta-1,3,6-triene','13877-91-3','CC(=CCC=C(C)C=C)C',
 'C10H16',136.23,'monoterpene','acyclic',176.0,4.0,0.01,
 'Mint,Parsley,Pepper,Basil,Orchids,Cannabis','FEMA #3539'),
('nerolidol','trans-Nerolidol',
 '(6E)-3,7,11-trimethyldodeca-1,6,10-trien-3-ol','40716-66-3','CC(=CCC/C(=C/CC[C@](C)(O)C=C)/C)C',
 'C15H26O',222.37,'sesquiterpenol','acyclic',276.0,5.36,0.001,
 'Neroli,Jasmine,Tea tree,Ginger,Lavender,Cannabis','FEMA #2772'),
('guaiol','Guaiol',
 '(1S,4S,7R)-1,4-dimethyl-7-(propan-2-yl)-1,2,3,4,5,6,7,8-octahydroazulen-4-ol','489-86-1','CC(C)[C@@H]1CC[C@](C)(O)[C@@H]2CCC(=C12)C',
 'C15H26O',222.37,'sesquiterpenol','bicyclic',NULL,4.4,0.0001,
 'Guaiacum,Cannabis,Cypress pine','FEMA #2536'),
('phytol','Phytol',
 '(2E,7R,11R)-3,7,11,15-tetramethylhexadec-2-en-1-ol','150-86-7','CC(C)CCC[C@@H](C)CCC[C@@H](C)CCC=C(C)CO',
 'C20H40O',296.53,'diterpenol','acyclic',204.0,7.0,0.00001,
 'Green leafy vegetables,Chlorophyll degradation,Green tea','FEMA #2596'),
('cineole','1,8-Cineole (Eucalyptol)',
 '1,3,3-trimethyl-2-oxabicyclo[2.2.2]octane','470-82-6','CC12CCC(CC1)C(C)(C)O2',
 'C10H18O',154.25,'monoterpenoid_ether','bicyclic',176.0,2.74,3.5,
 'Eucalyptus,Rosemary,Sage,Bay,Tea tree,Cannabis','FEMA #2465');

-- ---------------------------------------------------------------------------
-- NEW RECEPTORS / MOLECULAR TARGETS (histamine + autoimmune axis)
-- ---------------------------------------------------------------------------
INSERT INTO receptors VALUES
-- Histamine receptors
('h1','Histamine H1 receptor','GPCR','smooth_muscle,endothelium,CNS','Gq/PLC'),
('h2','Histamine H2 receptor','GPCR','gastric_parietal,heart,immune','Gs/cAMP'),
('h3','Histamine H3 receptor (autoreceptor)','GPCR','CNS_presynaptic','Gi/cAMP'),
('h4','Histamine H4 receptor','GPCR','immune,bone_marrow,mast_cells','Gi/cAMP'),
-- Mast cell axis
('fceri','High-affinity IgE receptor (FcεRI)','immunoreceptor','mast_cells,basophils','Syk/PLCg/Ca2+'),
('mrgprx2','MAS-related GPCR X2','GPCR','mast_cells','Gi+Gq/Ca2+'),
('bhex','beta-Hexosaminidase release','enzyme_readout','mast_cells','degranulation_marker'),
('tryptase','Mast cell tryptase','enzyme','mast_cells','PAR2_activation'),
('cav32_pruritus','Cav3.2 T-type Ca2+ (pruritus subset)','ion_channel','DRG_itch_fibers','Ca2+_itch_signaling'),
-- JAK/STAT
('jak1','Janus kinase 1','kinase','immune,ubiquitous','STAT_phosphorylation'),
('jak2','Janus kinase 2','kinase','immune,erythroid','STAT_phosphorylation'),
('jak3','Janus kinase 3 (common gamma-c)','kinase','lymphoid','STAT_phosphorylation'),
('stat3','STAT3','transcription_factor','immune,ubiquitous','Th17/IL-6 axis'),
('stat6','STAT6','transcription_factor','Th2_lineage','IL-4/IL-13 signaling'),
-- T-cell lineage
('foxp3','FoxP3 (Treg master TF)','transcription_factor','Treg_cells','Treg_lineage'),
('rorgt','RORgammaT (Th17 master TF)','transcription_factor','Th17_cells','Th17_lineage'),
-- Cytokine receptors / cytokines (as targets for modulation)
('il4r','IL-4 receptor / IL-4','cytokine_axis','Th2_immune','JAK1-STAT6'),
('il5','IL-5 / IL-5R','cytokine_axis','eosinophils','JAK2-STAT5'),
('il13','IL-13 / IL-13R','cytokine_axis','epithelium,smooth_muscle','JAK1-STAT6'),
('il17a','IL-17A / IL-17RA','cytokine_axis','Th17,epithelium','NF-kB/MAPK'),
('il33','IL-33 (alarmin)','cytokine_axis','epithelium','ST2-ILC2 priming'),
('tslp','TSLP (alarmin)','cytokine_axis','epithelium','OX40L-Th2 polarization'),
('ige','Immunoglobulin E (serum)','antibody','plasma_cells','FceRI_crosslinking'),
('periostin','Periostin','biomarker','airway_stroma','Th2_remodeling_marker'),
-- Inflammasome
('nlrp3','NLRP3 inflammasome','protein_complex','immune','caspase1_IL1b'),
('casp1','Caspase-1','enzyme','immune','IL-1b/IL-18 cleavage'),
('il1b','IL-1beta','cytokine','immune','inflammation'),
-- Lipid mediators & alternative pathways
('lox5','5-Lipoxygenase (LTB4 axis)','enzyme','immune','leukotriene_synthesis'),
('ltb4','Leukotriene B4','lipid_mediator','immune','neutrophil_chemotaxis'),
('pge2','Prostaglandin E2','lipid_mediator','immune,neural','inflammation_pain'),
-- Adiponectin axis (BCP)
('adipor1','Adiponectin receptor 1','GPCR','immune,muscle,liver','AMPK/PPAR'),
('adipor2','Adiponectin receptor 2','GPCR','immune,muscle,liver','AMPK/PPAR'),
-- Th1/balance
('ifn_gamma','IFN-gamma','cytokine','Th1','antiviral_macrophage_activation'),
('tnf','TNF-alpha','cytokine','immune','NF-kB induction; inflammation'),
('jnk','c-Jun N-terminal kinase (JNK)','kinase','immune,ubiquitous','AP-1 activation, apoptosis');

-- ---------------------------------------------------------------------------
-- INTERACTIONS — new terpenes
-- ---------------------------------------------------------------------------

-- α-HUMULENE
INSERT INTO interactions(terpene_id,receptor_id,action,binding_mode,affinity_type,affinity_value,affinity_unit,efficacy_pct,tier,confidence,notes,reference,url) VALUES
('humulene','cb2','partial_agonist','functional',NULL,NULL,NULL,NULL,'IV','weak','Inferred from BCP family SAR; isolated humulene Ki not published','Rogerio 2009 / Bahi 2014','https://pmc.ncbi.nlm.nih.gov/articles/PMC2785529/'),
('humulene','nfkb','inhibitor','functional',NULL,NULL,NULL,NULL,'R','strong','Reduced p65 nuclear staining in OVA-asthma lung','Rogerio 2009','https://pmc.ncbi.nlm.nih.gov/articles/PMC2785529/'),
('humulene','il5','inhibitor','functional',NULL,NULL,NULL,79,'R','strong','BALF IL-5 ↓79% at 300 mg/kg p.o. in OVA BALB/c','Rogerio 2009','https://pmc.ncbi.nlm.nih.gov/articles/PMC2785529/'),
('humulene','il13','inhibitor','functional',NULL,NULL,NULL,NULL,'R','moderate','Th2 cytokine attenuation in OVA model','Rogerio 2009','https://pmc.ncbi.nlm.nih.gov/articles/PMC2785529/'),
('humulene','lox5','inhibitor','functional',NULL,NULL,NULL,52,'R','strong','BALF LTB4 ↓52% (aerosol therapeutic)','Rogerio 2009','https://pmc.ncbi.nlm.nih.gov/articles/PMC2785529/'),
('humulene','ifn_gamma','activator','functional',NULL,NULL,NULL,NULL,'R','moderate','IFN-γ restoration toward Th1 in OVA mice','Rogerio 2009','https://pmc.ncbi.nlm.nih.gov/articles/PMC2785529/');

-- TERPINOLENE
INSERT INTO interactions(terpene_id,receptor_id,action,binding_mode,affinity_type,affinity_value,affinity_unit,efficacy_pct,tier,confidence,notes,reference,url) VALUES
('terpinolene','ache','inhibitor','functional','IC50',156,'ug/mL',NULL,'IV','moderate','AChE inhibition; cholinergic anti-inflammatory hypothesis only','Aazza 2011','https://pubmed.ncbi.nlm.nih.gov/23339024/'),
('terpinolene','nrf2','activator','functional',NULL,NULL,NULL,NULL,'IV','weak','Antioxidant assays only; no direct ARE-luc data','Aazza 2011','https://pubmed.ncbi.nlm.nih.gov/23339024/');

-- α-BISABOLOL  — strongest mast cell stabilizer in dataset
INSERT INTO interactions(terpene_id,receptor_id,action,binding_mode,affinity_type,affinity_value,affinity_unit,efficacy_pct,tier,confidence,notes,reference,url) VALUES
('bisabolol','fceri','inhibitor','indirect',NULL,NULL,NULL,NULL,'IV','strong','Suppresses FcεRI-triggered IgE-mediated degranulation in BMMC at 25-200 µM (post-receptor mechanism — IgE binding NOT reduced)','Kim 2022','https://pmc.ncbi.nlm.nih.gov/articles/PMC9268635/'),
('bisabolol','bhex','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','strong','β-Hexosaminidase release ↓ dose-dependent 25-200 µM in IgE/DNP-BMMC','Kim 2022','https://pmc.ncbi.nlm.nih.gov/articles/PMC9268635/'),
('bisabolol','nfkb','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','strong','NF-κB nuclear translocation reduced after IgE crosslink','Kim 2022','https://pmc.ncbi.nlm.nih.gov/articles/PMC9268635/'),
('bisabolol','jnk','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','moderate','Docking ΔG -6.3 kcal/mol vs JNK; phospho-JNK ↓','Kim 2022','https://pmc.ncbi.nlm.nih.gov/articles/PMC9268635/'),
('bisabolol','cav32_pruritus','inhibitor','functional',NULL,NULL,NULL,NULL,'R','strong','Histamine-induced scratching ↓; Cav3.2-KO mice block effect (histaminergic itch only)','Yoo 2024','https://pmc.ncbi.nlm.nih.gov/articles/PMC11122293/'),
('bisabolol','il4r','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','moderate','IL-4 mRNA ↓ in stimulated BMMC','Kim 2022','https://pmc.ncbi.nlm.nih.gov/articles/PMC9268635/'),
('bisabolol','nfkb','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','strong','Phospho-IKK/IκB attenuated','Kim 2022','https://pmc.ncbi.nlm.nih.gov/articles/PMC9268635/');

-- GERANIOL
INSERT INTO interactions(terpene_id,receptor_id,action,binding_mode,affinity_type,affinity_value,affinity_unit,efficacy_pct,tier,confidence,notes,reference,url) VALUES
('geraniol','cb1','NAM','allosteric','functional',NULL,NULL,NULL,'IV','moderate','Negative allosteric modulator of β-arrestin recruitment at CB1','Finlay 2020','https://pmc.ncbi.nlm.nih.gov/articles/PMC7269909/'),
('geraniol','nfkb','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','strong','TNFα/IL-6/IL-1β suppressed in LPS-stimulated macrophages','Lei 2019','https://pmc.ncbi.nlm.nih.gov/articles/PMC6141105/'),
('geraniol','nlrp3','inhibitor','indirect',NULL,NULL,NULL,NULL,'IV','moderate','NLRP3 expression ↓ via PPAR-γ methylation; IL-1β/IL-18 ↓','Liu 2022','https://pmc.ncbi.nlm.nih.gov/articles/PMC9472612/'),
('geraniol','ppar_gamma','activator','functional',NULL,NULL,NULL,NULL,'IV','moderate','PPAR-γ epigenetic activation upstream of NLRP3 suppression','Liu 2022','https://pmc.ncbi.nlm.nih.gov/articles/PMC9472612/'),
('geraniol','stat3','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','moderate','p-STAT3 ↓ in colitis/inflammatory models','Soubh 2015','https://pmc.ncbi.nlm.nih.gov/articles/PMC4517622/'),
('geraniol','inos','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','strong','iNOS / NO ↓ in LPS macrophages','Lei 2019','https://pmc.ncbi.nlm.nih.gov/articles/PMC6141105/'),
('geraniol','bhex','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','moderate','Histamine release ↓ in HMC-1 cells at 40-160 µM','Yoou 2016','https://pmc.ncbi.nlm.nih.gov/articles/PMC4977984/');

-- CAMPHENE
INSERT INTO interactions(terpene_id,receptor_id,action,binding_mode,affinity_type,affinity_value,affinity_unit,efficacy_pct,tier,confidence,notes,reference,url) VALUES
('camphene','cav32_pruritus','inhibitor','functional',NULL,NULL,NULL,NULL,'R','strong','Anti-itch via Cav3.2 inhibition — effective against BOTH histaminergic AND non-histaminergic pruritus (broader than bisabolol)','Park 2024','https://pmc.ncbi.nlm.nih.gov/articles/PMC11122293/'),
('camphene','cav32','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','moderate','Partial block of T-type Ca2+ currents','Park 2024','https://pmc.ncbi.nlm.nih.gov/articles/PMC11122293/'),
('camphene','nfkb','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','weak','Hypolipidemic SREBP-1/MTP pathway downregulation, HMG-CoA-independent','Vallianou 2011','https://pmc.ncbi.nlm.nih.gov/articles/PMC3207810/');

-- α-TERPINEOL
INSERT INTO interactions(terpene_id,receptor_id,action,binding_mode,affinity_type,affinity_value,affinity_unit,efficacy_pct,tier,confidence,notes,reference,url) VALUES
('terpineol','nfkb','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','strong','NF-κB p65 nuclear translocation ↓; TNF-α/IL-6/IL-1β suppressed in LPS macrophages','Held 2007','https://pubmed.ncbi.nlm.nih.gov/24290896/'),
('terpineol','inos','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','moderate','iNOS/NO down in macrophage assays','Held 2007','https://pubmed.ncbi.nlm.nih.gov/24290896/'),
('terpineol','cox2','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','moderate','COX-2/PGE2 reduction','Held 2007','https://pubmed.ncbi.nlm.nih.gov/24290896/'),
('terpineol','lox5','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','weak','Neutrophil chemotaxis reduced — pathway inferred','Nogueira 2014','https://pmc.ncbi.nlm.nih.gov/articles/PMC4127811/');

-- β-OCIMENE — sparse data
INSERT INTO interactions(terpene_id,receptor_id,action,binding_mode,affinity_type,affinity_value,affinity_unit,efficacy_pct,tier,confidence,notes,reference,url) VALUES
('ocimene','inos','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','weak','NO production ↓ in macrophage assay; minimal pharmacology elsewhere','Mendes 2010','https://pubmed.ncbi.nlm.nih.gov/19809790/');

-- trans-NEROLIDOL
INSERT INTO interactions(terpene_id,receptor_id,action,binding_mode,affinity_type,affinity_value,affinity_unit,efficacy_pct,tier,confidence,notes,reference,url) VALUES
('nerolidol','gaba_a','PAM','allosteric','functional',NULL,NULL,NULL,'R','moderate','Antinociception reversed by flumazenil; NOT by naloxone (rules out opioid)','Goncalves 2016','https://pubmed.ncbi.nlm.nih.gov/26791997/'),
('nerolidol','nfkb','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','moderate','TNF-α/IL-1β ↓ in LPS macrophages','Fonseca 2016','https://pmc.ncbi.nlm.nih.gov/articles/PMC5036356/'),
('nerolidol','cav32','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','weak','Structural homology to bisabolol; Cav3.2 docking proposed, not confirmed','Goncalves 2016','https://pubmed.ncbi.nlm.nih.gov/26791997/');

-- GUAIOL
INSERT INTO interactions(terpene_id,receptor_id,action,binding_mode,affinity_type,affinity_value,affinity_unit,efficacy_pct,tier,confidence,notes,reference,url) VALUES
('guaiol','jak2','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','weak','PI3K/Akt/mTOR axis downregulation in A549 NSCLC (JAK inferred upstream)','Yang 2016','https://pmc.ncbi.nlm.nih.gov/articles/PMC10209243/'),
('guaiol','stat3','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','weak','Indirect via PI3K/Akt suppression','Yang 2016','https://pmc.ncbi.nlm.nih.gov/articles/PMC10209243/');

-- PHYTOL
INSERT INTO interactions(terpene_id,receptor_id,action,binding_mode,affinity_type,affinity_value,affinity_unit,efficacy_pct,tier,confidence,notes,reference,url) VALUES
('phytol','ppar_alpha','agonist','orthosteric',NULL,NULL,NULL,NULL,'IV','moderate','Branched-chain isoprenoid PPAR-α ligand','Goto 2005','https://pubmed.ncbi.nlm.nih.gov/15994232/'),
('phytol','ppar_gamma','agonist','orthosteric',NULL,NULL,NULL,NULL,'IV','moderate','Dual PPAR-α/γ activity','Goto 2005','https://pubmed.ncbi.nlm.nih.gov/15994232/'),
('phytol','il4r','inhibitor','functional',NULL,NULL,NULL,NULL,'R','strong','OVA-asthma mouse: IL-4/IL-5/IL-13 + IgE ↓ at 200 mg/kg','Ryu 2015','https://pubmed.ncbi.nlm.nih.gov/26119292/'),
('phytol','mrgprx2','inhibitor','indirect',NULL,NULL,NULL,NULL,'R','weak','Compound 48/80-induced paw edema attenuated at 75 mg/kg — MRGPRX2 pathway candidate','Silva 2014','https://pubmed.ncbi.nlm.nih.gov/24508373/'),
('phytol','nfkb','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','moderate','NF-κB suppression in macrophage assays','Silva 2014','https://pubmed.ncbi.nlm.nih.gov/24508373/'),
('phytol','ige','inhibitor','functional',NULL,NULL,NULL,NULL,'R','strong','Serum IgE ↓ in OVA-mouse','Ryu 2015','https://pubmed.ncbi.nlm.nih.gov/26119292/');

-- 1,8-CINEOLE (Eucalyptol) — most clinical evidence in dataset
INSERT INTO interactions(terpene_id,receptor_id,action,binding_mode,affinity_type,affinity_value,affinity_unit,efficacy_pct,tier,confidence,notes,reference,url) VALUES
('cineole','nfkb','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','strong','Human monocytes at 1.5 µg/mL: TNF-α / IL-1β / IL-6 / IL-8 all ↓','Juergens 2003','https://pubmed.ncbi.nlm.nih.gov/12645832/'),
('cineole','il4r','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','strong','Th2 cytokine production reduced in stimulated lymphocytes','Juergens 2004','https://pmc.ncbi.nlm.nih.gov/articles/PMC2720945/'),
('cineole','il5','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','strong','IL-5 ↓ in mitogen-stimulated lymphocytes','Juergens 2004','https://pmc.ncbi.nlm.nih.gov/articles/PMC2720945/'),
('cineole','lox5','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','strong','LTB4 ↓ in stimulated human monocytes','Juergens 2003','https://pubmed.ncbi.nlm.nih.gov/12645832/'),
('cineole','cox2','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','moderate','PGE2 ↓; arachidonic-acid axis suppression','Juergens 2003','https://pubmed.ncbi.nlm.nih.gov/12645832/'),
('cineole','trpm8','agonist','orthosteric','EC50',3.4,'mM',NULL,'IV','moderate','TRPM8 cold receptor activation; basis for cooling/decongestant feel','Behrendt 2004','https://pubmed.ncbi.nlm.nih.gov/15302683/'),
('cineole','trpa1','agonist','orthosteric',NULL,NULL,NULL,NULL,'IV','moderate','TRPA1 activation at high µM','Takaishi 2012','https://pubmed.ncbi.nlm.nih.gov/22593587/');

-- ---------------------------------------------------------------------------
-- ADDITIONAL INTERACTIONS — extending v1 terpenes into histamine axis
-- ---------------------------------------------------------------------------

-- BCP (β-caryophyllene) — strong autoimmune dataset
INSERT INTO interactions(terpene_id,receptor_id,action,binding_mode,affinity_type,affinity_value,affinity_unit,efficacy_pct,tier,confidence,notes,reference,url) VALUES
('bcp','adipor1','activator','functional',NULL,NULL,NULL,NULL,'IV','moderate','AdipoR1/R2 activation drives Nrf2/HO-1; rescues mast cells from 48/80 challenge','Yao 2021','https://onlinelibrary.wiley.com/doi/abs/10.1111/1440-1681.13555'),
('bcp','adipor2','activator','functional',NULL,NULL,NULL,NULL,'IV','moderate','Companion mechanism to adipor1; Nrf2/HO-1 induction','Yao 2021','https://onlinelibrary.wiley.com/doi/abs/10.1111/1440-1681.13555'),
('bcp','nrf2','activator','functional',NULL,NULL,NULL,NULL,'IV','strong','HO-1 induction downstream of AdipoR; mast cell protection','Yao 2021','https://onlinelibrary.wiley.com/doi/abs/10.1111/1440-1681.13555'),
('bcp','il4r','inhibitor','functional',NULL,NULL,NULL,NULL,'R','strong','OVA-rat: IL-4/IL-13/IgE ↓ CB2-dependent','Kim 2014','https://pubmed.ncbi.nlm.nih.gov/24369228/'),
('bcp','il13','inhibitor','functional',NULL,NULL,NULL,NULL,'R','strong','BCP suppresses IL-13 in OVA airway model','Kim 2014','https://pubmed.ncbi.nlm.nih.gov/24369228/'),
('bcp','ige','inhibitor','functional',NULL,NULL,NULL,NULL,'R','strong','Serum IgE ↓ in OVA-rat via CB2','Kim 2014','https://pubmed.ncbi.nlm.nih.gov/24369228/'),
('bcp','nlrp3','inhibitor','functional',NULL,NULL,NULL,NULL,'R','strong','DSS colitis: NLRP3/caspase-1 ↓; CB2-dependent','Bento 2011','https://pubmed.ncbi.nlm.nih.gov/21798259/'),
('bcp','foxp3','activator','functional',NULL,NULL,NULL,NULL,'R','moderate','EAE/MS: Treg-skewing; CB2-dependent','Lunn 2012','https://pubmed.ncbi.nlm.nih.gov/22452646/'),
('bcp','rorgt','inhibitor','functional',NULL,NULL,NULL,NULL,'R','moderate','Th17 attenuation in EAE','Lunn 2012','https://pubmed.ncbi.nlm.nih.gov/22452646/'),
('bcp','il17a','inhibitor','functional',NULL,NULL,NULL,NULL,'R','moderate','IL-17A ↓ in EAE','Lunn 2012','https://pubmed.ncbi.nlm.nih.gov/22452646/');

-- LINALOOL — histamine bridge
INSERT INTO interactions(terpene_id,receptor_id,action,binding_mode,affinity_type,affinity_value,affinity_unit,efficacy_pct,tier,confidence,notes,reference,url) VALUES
('linalool','bhex','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','moderate','RBL-2H3 β-hex release ↓ at low mM','Kim 2019','https://pmc.ncbi.nlm.nih.gov/articles/PMC6650765/'),
('linalool','il4r','inhibitor','functional',NULL,NULL,NULL,NULL,'R','moderate','IL-4/IL-5/IL-13 ↓ in OVA-mouse model','Kim 2019','https://pmc.ncbi.nlm.nih.gov/articles/PMC6650765/'),
('linalool','ige','inhibitor','functional',NULL,NULL,NULL,NULL,'R','moderate','Serum IgE attenuated in OVA-mouse','Kim 2019','https://pmc.ncbi.nlm.nih.gov/articles/PMC6650765/');

-- LIMONENE — modest histamine signal
INSERT INTO interactions(terpene_id,receptor_id,action,binding_mode,affinity_type,affinity_value,affinity_unit,efficacy_pct,tier,confidence,notes,reference,url) VALUES
('limonene','il4r','inhibitor','functional',NULL,NULL,NULL,NULL,'R','moderate','OVA-mouse: IL-4/IL-13 ↓; airway hyperresponsiveness blunted','Hirota 2012','https://pubmed.ncbi.nlm.nih.gov/22244543/'),
('limonene','nfkb','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','moderate','NF-κB suppression in airway epithelium','Hirota 2012','https://pubmed.ncbi.nlm.nih.gov/22244543/');

-- α-PINENE — mild
INSERT INTO interactions(terpene_id,receptor_id,action,binding_mode,affinity_type,affinity_value,affinity_unit,efficacy_pct,tier,confidence,notes,reference,url) VALUES
('alpha_pinene','nfkb','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','moderate','LPS-macrophage TNFα/IL-6 ↓','Kim 2015','https://pmc.ncbi.nlm.nih.gov/articles/PMC4488002/');

-- MYRCENE
INSERT INTO interactions(terpene_id,receptor_id,action,binding_mode,affinity_type,affinity_value,affinity_unit,efficacy_pct,tier,confidence,notes,reference,url) VALUES
('myrcene','nfkb','inhibitor','functional',NULL,NULL,NULL,NULL,'IV','moderate','MIA-osteoarthritis chondrocyte NF-κB ↓','Rufino 2015','https://pmc.ncbi.nlm.nih.gov/articles/PMC4555972/');

-- ---------------------------------------------------------------------------
-- EFFECTS — quantitative phenotypic outcomes (new terpenes & histamine focus)
-- ---------------------------------------------------------------------------
INSERT INTO effects(terpene_id,effect,condition,model,species,dose_value,dose_unit,route,sex,outcome,tier,reference,url) VALUES
-- Humulene
('humulene','anti_asthmatic','allergic_asthma','OVA-BALB/c',NULL,300,'mg/kg','oral',NULL,'IL-5 ↓79%, CCL11 ↓90%, LTB4 ↓52%, IFN-γ restored','R','Rogerio 2009','https://pmc.ncbi.nlm.nih.gov/articles/PMC2785529/'),
('humulene','anti_inflammatory','acute_inflammation','carrageenan-paw',NULL,100,'mg/kg','oral',NULL,'Paw edema ↓','R','Fernandes 2007','https://pubmed.ncbi.nlm.nih.gov/17559833/'),
-- Bisabolol
('bisabolol','mast_cell_stabilizing','allergic_inflammation','PCA + IgE-BMMC','mouse',100,'mg/kg','oral','M','Passive cutaneous anaphylaxis blocked; β-hex release ↓','R','Kim 2022','https://pmc.ncbi.nlm.nih.gov/articles/PMC9268635/'),
('bisabolol','antipruritic','histaminergic_itch','histamine-scratch','mouse',50,'mg/kg','i.p.',NULL,'Scratching ↓; lost in Cav3.2-KO','R','Yoo 2024','https://pmc.ncbi.nlm.nih.gov/articles/PMC11122293/'),
('bisabolol','anti_inflammatory','colitis','DSS-mouse',NULL,50,'mg/kg','oral',NULL,'Colon shortening reduced; cytokines ↓','R','Bommer 2012','https://pmc.ncbi.nlm.nih.gov/articles/PMC5938193/'),
-- Geraniol
('geraniol','anti_inflammatory','colitis','DSS-mouse',NULL,30,'mg/kg','oral',NULL,'DAI ↓; STAT3 ↓','R','Soubh 2015','https://pmc.ncbi.nlm.nih.gov/articles/PMC4517622/'),
('geraniol','anti_allergic','mast_cell','HMC-1',NULL,160,'uM','in_vitro',NULL,'Histamine release ↓','IV','Yoou 2016','https://pmc.ncbi.nlm.nih.gov/articles/PMC4977984/'),
-- Camphene
('camphene','antipruritic','pruritus','histamine + chloroquine itch','mouse',50,'mg/kg','i.p.',NULL,'Scratching ↓ in BOTH histaminergic + non-histaminergic models','R','Park 2024','https://pmc.ncbi.nlm.nih.gov/articles/PMC11122293/'),
('camphene','hypolipidemic','hyperlipidemia','HFD-rat','rat',30,'mg/kg','oral',NULL,'TC/LDL ↓ via SREBP-1/MTP, HMG-CoA independent','R','Vallianou 2011','https://pmc.ncbi.nlm.nih.gov/articles/PMC3207810/'),
-- Terpineol
('terpineol','anti_inflammatory','acute_inflammation','carrageenan-paw',NULL,100,'mg/kg','oral',NULL,'Paw edema ↓ via NF-κB','R','Held 2007','https://pubmed.ncbi.nlm.nih.gov/24290896/'),
-- Ocimene
('ocimene','anti_inflammatory','LPS_macrophage','RAW264.7',NULL,100,'uM','in_vitro',NULL,'NO ↓ in macrophage assay','IV','Mendes 2010','https://pubmed.ncbi.nlm.nih.gov/19809790/'),
-- Nerolidol
('nerolidol','analgesic','formalin_pain','formalin-paw','mouse',200,'mg/kg','oral','M','Phase-2 pain ↓; reversed by flumazenil','R','Goncalves 2016','https://pubmed.ncbi.nlm.nih.gov/26791997/'),
('nerolidol','anti_inflammatory','LPS_macrophage','J774',NULL,25,'uM','in_vitro',NULL,'TNF-α / IL-1β ↓','IV','Fonseca 2016','https://pmc.ncbi.nlm.nih.gov/articles/PMC5036356/'),
-- Guaiol
('guaiol','anticancer','NSCLC','A549',NULL,120,'uM','in_vitro',NULL,'Immunogenic cell death; PI3K/Akt/mTOR ↓','IV','Yang 2016','https://pmc.ncbi.nlm.nih.gov/articles/PMC10209243/'),
-- Phytol
('phytol','anti_asthmatic','allergic_asthma','OVA-mouse','mouse',200,'mg/kg','oral','M','IL-4/IL-5/IL-13/IgE ↓↓; PPAR-α/γ','R','Ryu 2015','https://pubmed.ncbi.nlm.nih.gov/26119292/'),
('phytol','anti_allergic','MRGPRX2_candidate','compound_48/80_paw','mouse',75,'mg/kg','i.p.',NULL,'Paw edema ↓; mast cell pseudo-allergic pathway candidate','R','Silva 2014','https://pubmed.ncbi.nlm.nih.gov/24508373/'),
-- Cineole — human RCTs
('cineole','steroid_sparing','asthma','RCT_double_blind','human',600,'mg/day','oral','mixed','Prednisolone reduction 36% vs placebo 7% (p=0.006); n=32','H','Juergens 2003','https://pubmed.ncbi.nlm.nih.gov/12645832/'),
('cineole','exacerbation_reduction','COPD','RCT','human',600,'mg/day','oral','mixed','Exacerbations 28.2% vs placebo 45.5%; n=242 over 6 months','H','Worth 2009','https://pmc.ncbi.nlm.nih.gov/articles/PMC2720945/'),
('cineole','symptom_score','rhinosinusitis','RCT','human',600,'mg/day','oral','mixed','Symptom score improvement vs placebo','H','Tesche 2008','https://pmc.ncbi.nlm.nih.gov/articles/PMC7467491/'),
-- BCP additions
('bcp','mast_cell_stabilizing','pseudo_allergy','compound_48/80','mouse',50,'mg/kg','i.p.',NULL,'Edema ↓ via AdipoR/Nrf2/HO-1','R','Yao 2021','https://onlinelibrary.wiley.com/doi/abs/10.1111/1440-1681.13555'),
('bcp','anti_asthmatic','allergic_asthma','OVA-rat','rat',50,'mg/kg','oral',NULL,'IL-4/IL-13/IgE ↓ CB2-dependent','R','Kim 2014','https://pubmed.ncbi.nlm.nih.gov/24369228/'),
('bcp','anti_inflammatory','colitis','DSS-mouse','mouse',50,'mg/kg','oral',NULL,'NLRP3/caspase-1 ↓ CB2-dependent','R','Bento 2011','https://pubmed.ncbi.nlm.nih.gov/21798259/'),
('bcp','immunomodulatory','multiple_sclerosis','EAE-mouse','mouse',25,'mg/kg','oral',NULL,'Treg↑ Th17↓ disease score ↓; CB2-dependent','R','Lunn 2012','https://pubmed.ncbi.nlm.nih.gov/22452646/'),
-- Linalool histamine
('linalool','anti_asthmatic','allergic_asthma','OVA-mouse','mouse',75,'mg/kg','oral',NULL,'IL-4/IL-5/IL-13/IgE ↓','R','Kim 2019','https://pmc.ncbi.nlm.nih.gov/articles/PMC6650765/'),
-- Limonene histamine
('limonene','anti_asthmatic','allergic_asthma','OVA-mouse','mouse',10,'mg/kg','oral',NULL,'IL-4/IL-13 ↓; airway hyperresponsiveness blunted','R','Hirota 2012','https://pubmed.ncbi.nlm.nih.gov/22244543/');

-- ---------------------------------------------------------------------------
-- PHARMACOKINETICS — new terpenes
-- ---------------------------------------------------------------------------
INSERT INTO pharmacokinetics(terpene_id,species,route,formulation,parameter,value,unit,notes,reference,url) VALUES
('cineole','human','oral','enteric_capsule_200mg','Tmax',1.5,'h','Rapid absorption; broad CYP3A4/2C19 metabolism','Jaeger 1996','https://pubmed.ncbi.nlm.nih.gov/8807035/'),
('cineole','human','oral','enteric_capsule','t_half',9,'h','Steady-state in 2-3 days','Jaeger 1996','https://pubmed.ncbi.nlm.nih.gov/8807035/'),
('cineole','human','oral','enteric_capsule','BBB',1,'dimensionless','Crosses BBB; CSF concentrations detectable','Kohlert 2002','https://pubmed.ncbi.nlm.nih.gov/12490661/'),
('humulene','mouse','oral','olive_oil','F',NULL,'percent','No dedicated PK study; lipophilic, expected first-pass','Rogerio 2009','https://pmc.ncbi.nlm.nih.gov/articles/PMC2785529/'),
('phytol','mouse','oral','olive_oil','F',NULL,'percent','Diterpenol logP ~7; absorption requires lipid vehicle','Ryu 2015','https://pubmed.ncbi.nlm.nih.gov/26119292/'),
('bisabolol','rat','oral','SEDDS','F',NULL,'percent','SEDDS improves bioavailability; t_half ~ hours','Maurya 2019','https://pmc.ncbi.nlm.nih.gov/articles/PMC6843373/'),
('nerolidol','rat','transdermal','neat','permeation',NULL,'dimensionless','Strong skin permeation enhancer; used as excipient','Cornwell 1994','https://pubmed.ncbi.nlm.nih.gov/7986970/');

-- ---------------------------------------------------------------------------
-- SAFETY
-- ---------------------------------------------------------------------------
INSERT INTO safety(terpene_id,category,species,route,value,unit,severity,description,reference,url) VALUES
('cineole','LD50','rat','oral',2480,'mg/kg','low','Low acute toxicity','EFSA 2008','https://efsa.onlinelibrary.wiley.com/doi/10.2903/j.efsa.2008.829'),
('cineole','contact_allergy','human','topical',NULL,'percent','low','Rare sensitization at fragrance levels','SCCS 2012','https://ec.europa.eu/health/scientific_committees/consumer_safety/docs/sccs_o_102.pdf'),
('geraniol','contact_allergy','human','topical',2.0,'percent','high','EU mandatory allergen; 2-4% patch positivity in eczema patients','SCCS 2012','https://ec.europa.eu/health/scientific_committees/consumer_safety/docs/sccs_o_102.pdf'),
('geraniol','LD50','rat','oral',3600,'mg/kg','low','Low acute toxicity','OECD','https://echa.europa.eu/'),
('bisabolol','LD50','rat','oral',15000,'mg/kg','low','Very low toxicity','OECD','https://echa.europa.eu/'),
('bisabolol','contact_allergy','human','topical',NULL,'percent','low','Sensitization rare; widely tolerated in cosmetics','SCCS','https://ec.europa.eu/health/scientific_committees/consumer_safety/docs/sccs_o_102.pdf'),
('humulene','LD50','mouse','oral',NULL,NULL,'low','No published LD50; food-exposure GRAS','FEMA','https://www.femaflavor.org/'),
('terpinolene','contact_allergy','human','topical',NULL,'percent','moderate','Oxidation products sensitizing','Karlberg 2008','https://pubmed.ncbi.nlm.nih.gov/18261077/'),
('camphene','LD50','rat','oral',5000,'mg/kg','low','Low oral toxicity','OECD','https://echa.europa.eu/'),
('terpineol','contact_allergy','human','topical',NULL,'percent','low','Generally well tolerated','SCCS','https://ec.europa.eu/health/scientific_committees/consumer_safety/docs/sccs_o_102.pdf'),
('ocimene','contact_allergy','human','topical',NULL,'percent','low','Limited data','SCCS','https://ec.europa.eu/health/scientific_committees/consumer_safety/docs/sccs_o_102.pdf'),
('nerolidol','LD50','rat','oral',5000,'mg/kg','low','Low toxicity; permeation enhancer in topicals','OECD','https://echa.europa.eu/'),
('phytol','LD50','rat','oral',NULL,NULL,'low','Refsum disease consideration in patients with phytanic-acid α-oxidation defect','OMIM','https://www.omim.org/entry/266500'),
('phytol','drug_interaction','human','oral',NULL,NULL,'moderate','Contraindicated in Refsum disease','OMIM','https://www.omim.org/entry/266500'),
('guaiol','LD50','rat','oral',NULL,NULL,'low','Sparse safety data','FEMA','https://www.femaflavor.org/');

-- ---------------------------------------------------------------------------
-- SYNERGY — cannabinoid interactions for new terpenes
-- ---------------------------------------------------------------------------
INSERT INTO synergy(terpene_id,partner,partner_class,interaction_type,mechanism,assay,quantitative_result,confidence,tier,reference,url) VALUES
('humulene','BCP','sesquiterpene','additive','Co-occurring CB2 partial agonists; shared NF-κB suppression','OVA-asthma BALB/c','IL-5 / LTB4 reduction reproducible across both monoterps','moderate','R','Rogerio 2009','https://pmc.ncbi.nlm.nih.gov/articles/PMC2785529/'),
('humulene','THC','phytocannabinoid','contested','Entourage hypothesis; humulene-CB2 affinity unconfirmed','radioligand','Ki for isolated humulene not yet replicated','weak','IV','Russo 2011','https://pmc.ncbi.nlm.nih.gov/articles/PMC6239267/'),
('bisabolol','CBD','phytocannabinoid','synergistic','Independent mast cell stabilization pathways; CBD modulates Cav3 channels and bisabolol blocks Cav3.2-itch','functional','Complementary mast-cell + itch axis','moderate','R','Yoo 2024','https://pmc.ncbi.nlm.nih.gov/articles/PMC11122293/'),
('geraniol','THC','phytocannabinoid','contested','Geraniol is a CB1 NAM of β-arrestin recruitment — may BLUNT some THC effects via biased signaling','arrestin_BRET','NAM activity may reduce THC tolerance/desensitization','moderate','IV','Finlay 2020','https://pmc.ncbi.nlm.nih.gov/articles/PMC7269909/'),
('cineole','THC','phytocannabinoid','no_interaction','No direct CB1/CB2 affinity for cineole; effects independent','radioligand','No CB1/CB2 binding','strong','IV','Russo 2011','https://pmc.ncbi.nlm.nih.gov/articles/PMC6239267/'),
('cineole','CBD','phytocannabinoid','additive','Independent NF-κB / leukotriene axes converge on respiratory inflammation','clinical','Both reduce airway inflammation by separate mechanisms','moderate','IV','Juergens 2003','https://pubmed.ncbi.nlm.nih.gov/12645832/'),
('nerolidol','CBD','phytocannabinoid','additive','Permeation enhancer for transdermal CBD; GABAergic component independent','transdermal','Significant ↑ CBD skin permeation','moderate','IV','Cornwell 1994','https://pubmed.ncbi.nlm.nih.gov/7986970/'),
('phytol','THC','phytocannabinoid','contested','PPAR-α/γ activation may converge with CBD anti-Th2 effects','OVA-mouse','Phytol mimics IL-4/IL-13 reduction also seen with CB2 agonists','weak','R','Ryu 2015','https://pubmed.ncbi.nlm.nih.gov/26119292/'),
('bcp','CBD','phytocannabinoid','synergistic','CB2 agonism + CBD anti-inflammatory; complementary mast-cell stabilization via AdipoR/Nrf2','in_vitro','HO-1 induction additive','moderate','IV','Yao 2021','https://onlinelibrary.wiley.com/doi/abs/10.1111/1440-1681.13555');

-- ---------------------------------------------------------------------------
-- CONDITION INDEX — extended for histamine / autoimmune / allergy
-- ---------------------------------------------------------------------------
INSERT INTO condition_targets(condition,receptor_id,rationale,priority) VALUES
-- Allergic asthma
('allergic_asthma','il4r','Th2 axis driver; IL-4/IL-13 → IgE class switching, AHR',1),
('allergic_asthma','il5','Eosinophil maturation & recruitment',1),
('allergic_asthma','il13','Goblet cell hyperplasia, mucus, AHR',1),
('allergic_asthma','ige','Crosslinks FcεRI on mast cells',1),
('allergic_asthma','lox5','LTB4/LTD4 bronchoconstriction',2),
('allergic_asthma','nfkb','Upstream cytokine transcription',2),
('allergic_asthma','tslp','Epithelial alarmin priming Th2 polarization',2),
-- Mast cell disorder / urticaria
('mast_cell_disorder','fceri','Type I IgE-mediated activation',1),
('mast_cell_disorder','mrgprx2','Pseudo-allergic non-IgE activation',1),
('mast_cell_disorder','bhex','Degranulation readout',1),
('mast_cell_disorder','h1','Itch / vasodilation downstream of histamine',1),
('mast_cell_disorder','h4','Mast cell chemotaxis and IL-31 production',2),
('mast_cell_disorder','cav32_pruritus','Itch transduction in DRG',2),
-- Atopic dermatitis
('atopic_dermatitis','il4r','Th2 cytokines drive AD',1),
('atopic_dermatitis','il13','Barrier disruption + itch',1),
('atopic_dermatitis','tslp','Epithelial alarmin',2),
('atopic_dermatitis','jak1','Drug target (e.g. abrocitinib)',1),
('atopic_dermatitis','stat6','IL-4/13 downstream signaling',2),
('atopic_dermatitis','cav32_pruritus','Itch transduction',2),
-- Allergic rhinitis
('allergic_rhinitis','h1','Sneeze, itch, rhinorrhea',1),
('allergic_rhinitis','fceri','Mast cell activation in mucosa',1),
('allergic_rhinitis','ige','Specific IgE production',1),
-- IBD / Colitis
('colitis_IBD','nlrp3','IL-1β/IL-18 drives mucosal damage',1),
('colitis_IBD','stat3','Th17/IL-22 axis',1),
('colitis_IBD','il17a','Mucosal Th17 inflammation',1),
('colitis_IBD','nfkb','Cytokine transcription',1),
('colitis_IBD','tnf','TNF blockade (anti-TNF biologics)',1),
-- Rheumatoid arthritis
('rheumatoid_arthritis','jak1','JAK inhibitors (tofacitinib class)',1),
('rheumatoid_arthritis','jak2','JAK inhibitor target',1),
('rheumatoid_arthritis','stat3','Th17 axis',1),
('rheumatoid_arthritis','il17a','Pannus/destruction driver',1),
('rheumatoid_arthritis','nfkb','Cytokine transcription',1),
-- Multiple sclerosis
('multiple_sclerosis','rorgt','Th17 lineage in EAE',1),
('multiple_sclerosis','foxp3','Treg expansion = remission',1),
('multiple_sclerosis','il17a','Effector cytokine',1),
('multiple_sclerosis','cb2','BCP-mediated anti-EAE',1),
-- Psoriasis
('psoriasis','il17a','Anti-IL-17 biologics (secukinumab)',1),
('psoriasis','il13','Itch axis',2),
('psoriasis','jak1','TYK2/JAK1 axis',1),
-- COPD
('COPD','nfkb','Chronic neutrophilic inflammation',1),
('COPD','lox5','LTB4 neutrophil chemotaxis',1),
('COPD','tnf','TNF-driven chronic inflammation',2);

-- ---------------------------------------------------------------------------
-- EVIDENCE GAPS — explicit "what we DON'T know"
-- ---------------------------------------------------------------------------
INSERT INTO evidence_gaps(terpene_id,receptor_id,description,severity) VALUES
-- Universal histamine-receptor blank
('humulene','h1','No H1 radioligand Ki published','blocker'),
('humulene','h4','No H4 radioligand Ki published','blocker'),
('limonene','h1','No H1 radioligand Ki published','blocker'),
('linalool','h1','No H1 radioligand Ki published','blocker'),
('myrcene','h1','No H1 radioligand Ki published','blocker'),
('bisabolol','h1','No H1 radioligand Ki — mechanism is post-receptor','blocker'),
('geraniol','h1','No H1 radioligand Ki published','blocker'),
('cineole','h1','No H1 radioligand Ki published','blocker'),
-- JAK/STAT
('humulene','jak1','No JAK1 kinase IC50','blocker'),
('bcp','jak1','No JAK1 kinase IC50','blocker'),
('bisabolol','jak1','No JAK1 kinase IC50','blocker'),
('cineole','jak2','No JAK2 kinase IC50','blocker'),
-- Alarmins
('humulene','tslp','No TSLP/IL-33 data','weak_evidence'),
('bisabolol','tslp','No TSLP/IL-33 data','weak_evidence'),
('cineole','tslp','No TSLP/IL-33 data','weak_evidence'),
-- Th17/FoxP3 (only BCP has data)
('linalool','foxp3','No Treg flow data','weak_evidence'),
('humulene','foxp3','No Treg flow data','weak_evidence'),
('geraniol','rorgt','No Th17 flow data','weak_evidence'),
-- MRGPRX2 (pseudo-allergy)
('bisabolol','mrgprx2','Effect on MRGPRX2 not directly tested','weak_evidence'),
('cineole','mrgprx2','Effect on MRGPRX2 not directly tested','weak_evidence'),
-- β-Ocimene globally
('ocimene',NULL,'Isolated-compound pharmacology essentially absent; most data from essential-oil blends','blocker'),
-- Terpinolene
('terpinolene',NULL,'Minimal mast-cell / autoimmune data; AChE inhibition is principal isolated finding','weak_evidence'),
-- Camphene
('camphene','nfkb','Anti-inflammatory mechanism not deeply mapped beyond Cav3.2','weak_evidence'),
-- Guaiol
('guaiol',NULL,'No allergy / mast-cell data; oncology emphasis only','weak_evidence'),
-- Phytol MRGPRX2 confirmation
('phytol','mrgprx2','Compound 48/80 model is consistent but MRGPRX2 not directly tested','weak_evidence'),
-- Human RCTs
('humulene',NULL,'No human RCT','blocker'),
('terpinolene',NULL,'No human RCT','blocker'),
('bisabolol',NULL,'No mast-cell-disorder RCT (chamomile blends only)','blocker'),
('geraniol',NULL,'No human RCT','blocker'),
('camphene',NULL,'No human RCT','blocker'),
('terpineol',NULL,'No isolated-compound RCT (blends only)','blocker'),
('ocimene',NULL,'No human RCT','blocker'),
('nerolidol',NULL,'No human RCT','blocker'),
('guaiol',NULL,'No human RCT','blocker'),
('phytol',NULL,'No human RCT','blocker');

-- ---------------------------------------------------------------------------
-- ALLERGIC REACTIONS — type I + type IV hypersensitivity
-- ---------------------------------------------------------------------------
INSERT INTO allergic_reactions(terpene_id,reaction_type,trigger_form,population,rate_pct,n_tested,regulatory,threshold,notes,reference,url) VALUES
('geraniol','type_IV_contact','neat_or_oxidized','eczema_patients',3.0,NULL,'EU_mandatory_allergen','>0.001% in rinse-off; 0.0001% leave-on','Listed in EU 26 fragrance allergens','SCCS 2012','https://ec.europa.eu/health/scientific_committees/consumer_safety/docs/sccs_o_102.pdf'),
('limonene','type_IV_contact','oxidation_hydroperoxide','eczema_patients',5.0,NULL,'EU_mandatory_allergen','Oxidized forms; fresh limonene low risk','Limonene hydroperoxides are the dominant allergen — neat compound is lower risk','Karlberg 2008','https://pubmed.ncbi.nlm.nih.gov/18261077/'),
('linalool','type_IV_contact','oxidation_hydroperoxide','eczema_patients',6.9,NULL,'EU_mandatory_allergen','Linalool peroxides','Linalool hydroperoxides cause majority of positive patch tests','Karlberg 2008','https://pubmed.ncbi.nlm.nih.gov/18261077/'),
('terpinolene','type_IV_contact','oxidation','eczema_patients',NULL,NULL,'IFRA_restricted','Oxidized forms','Sensitization from peroxide formation; lower rates than linalool','Karlberg 2008','https://pubmed.ncbi.nlm.nih.gov/18261077/'),
('alpha_pinene','type_IV_contact','oxidation','eczema_patients',2.0,NULL,'IFRA_restricted','Oxidized forms','Oxidized α-pinene more sensitizing than fresh','Karlberg 2008','https://pubmed.ncbi.nlm.nih.gov/18261077/'),
('cineole','type_IV_contact','neat','eczema_patients',NULL,NULL,'GRAS','—','Low sensitization rate at fragrance levels','SCCS','https://ec.europa.eu/health/scientific_committees/consumer_safety/docs/sccs_o_102.pdf'),
('bisabolol','type_IV_contact','neat','eczema_patients',NULL,NULL,'GRAS','—','Widely tolerated; rare sensitization','SCCS','https://ec.europa.eu/health/scientific_committees/consumer_safety/docs/sccs_o_102.pdf'),
('phytol','irritant','neat','Refsum_patients',NULL,NULL,'GRAS','—','Avoid in Refsum disease (α-oxidation defect)','OMIM 266500','https://www.omim.org/entry/266500');

-- ---------------------------------------------------------------------------
-- CLINICAL TRIALS — human evidence (only 1,8-cineole has clear RCTs)
-- ---------------------------------------------------------------------------
INSERT INTO clinical_trials(terpene_id,design,indication,n_subjects,dose,duration,primary_outcome,result_summary,p_value,nct_id,reference,url) VALUES
('cineole','RCT_double_blind','asthma',32,'200 mg TID p.o.','3 months','Prednisolone-sparing','36% steroid reduction vs 7% placebo','0.006',NULL,'Juergens 2003','https://pubmed.ncbi.nlm.nih.gov/12645832/'),
('cineole','RCT_double_blind','COPD',242,'200 mg TID p.o.','6 months','Exacerbations','28.2% vs 45.5% placebo',NULL,NULL,'Worth 2009','https://pmc.ncbi.nlm.nih.gov/articles/PMC2720945/'),
('cineole','RCT','rhinosinusitis_acute',150,'200 mg TID p.o.','7-14 days','Symptom score','Significant improvement vs placebo',NULL,NULL,'Tesche 2008','https://pmc.ncbi.nlm.nih.gov/articles/PMC7467491/'),
('cineole','RCT','sinusitis_chronic',300,'200 mg TID','12 weeks','Symptom score','Adjunct benefit',NULL,NULL,'Kehrl 2004','https://pubmed.ncbi.nlm.nih.gov/15021373/'),
('linalool','open_label','anxiety_perioperative',60,'inhaled essential oil','single session','State anxiety','Reduced state anxiety scores','0.04',NULL,'Hongratanaworakit 2011','https://pubmed.ncbi.nlm.nih.gov/22130349/'),
('limonene','open_label','GERD',19,'1000 mg/day','14 days','Heartburn relief','86% reported relief',NULL,NULL,'Wilkins 2002 patent','https://patents.google.com/patent/US6420435B1/en');
