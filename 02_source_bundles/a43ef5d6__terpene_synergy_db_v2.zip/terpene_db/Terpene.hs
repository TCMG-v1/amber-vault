{-# LANGUAGE DeriveGeneric        #-}
{-# LANGUAGE DerivingStrategies   #-}
{-# LANGUAGE OverloadedStrings    #-}
{-# LANGUAGE StrictData           #-}
{-# LANGUAGE LambdaCase           #-}

-- |
-- Module      : Terpene
-- Description : Typed ADTs for the terpene synergy database.
--
-- A small, total schema-as-types module. Each constructor mirrors a
-- table in @terpenes.db@ / @terpenes.json@. The module is deliberately
-- record-heavy: every field is named so that lens / optics generation
-- (e.g. via @generic-lens@ or @makeLenses@) is a one-liner downstream.
--
-- Design philosophy:
--   * Closed enums for receptor families, evidence tiers, confidence
--     levels and pharmacological actions — wrong values are unrepresent-
--     able.
--   * Numeric measurements carry their unit alongside the magnitude.
--   * Citations are first-class values: a 'Reference' is a short
--     human-readable handle plus a URL.
--
-- The intended use is twofold:
--   1. Decode @terpenes.json@ into a @[TerpeneRecord]@ and reason
--      programmatically (drug design queries, scoring functions).
--   2. Build new compounds *in code* by composing 'Interaction',
--      'Synergy' and 'Effect' values without touching SQL.
module Terpene where

import           Data.Aeson         (FromJSON, ToJSON)
import           Data.Text          (Text)
import           GHC.Generics       (Generic)

-- ---------------------------------------------------------------------------
-- Evidence and confidence
-- ---------------------------------------------------------------------------

-- | Evidence tier. Ordered: in vitro < rodent < human.
data Tier = InVitro | Rodent | Human
  deriving stock   (Eq, Ord, Show, Read, Generic, Enum, Bounded)
  deriving anyclass (ToJSON, FromJSON)

-- | Subjective confidence the field assigns to a finding.
data Confidence
  = Strong
  | Moderate
  | Weak
  | Contested
  | Rejected
  deriving stock   (Eq, Ord, Show, Read, Generic, Enum, Bounded)
  deriving anyclass (ToJSON, FromJSON)

-- ---------------------------------------------------------------------------
-- Receptors / targets
-- ---------------------------------------------------------------------------

data ReceptorFamily
  = GPCR
  | IonChannel
  | NuclearReceptor
  | Enzyme
  | TranscriptionFactor
  deriving stock (Eq, Show, Generic)
  deriving anyclass (ToJSON, FromJSON)

-- | Closed set of receptors/targets covered by the seed data. Extend by
-- adding constructors here; this preserves exhaustiveness checks in any
-- pattern matches downstream.
data Receptor
  = CB1 | CB2
  | A2A | A1
  | GABA_A
  | TRPV1 | TRPA1 | TRPM8
  | HT1A
  | PPAR_alpha | PPAR_gamma
  | MuOpioid
  | NaV | CaV3_2
  | AChE
  | NFkB | COX2 | iNOS | NRF2
  | Alpha2Adrenergic
  deriving stock   (Eq, Ord, Show, Read, Generic, Enum, Bounded)
  deriving anyclass (ToJSON, FromJSON)

-- ---------------------------------------------------------------------------
-- Pharmacological actions and binding
-- ---------------------------------------------------------------------------

data Action
  = FullAgonist
  | PartialAgonist
  | Antagonist
  | PAM        -- positive allosteric modulator
  | NAM        -- negative allosteric modulator
  | Inhibitor
  | Activator
  | Inducer
  | IndirectModulator
  | NoInteraction
  deriving stock   (Eq, Show, Generic)
  deriving anyclass (ToJSON, FromJSON)

data BindingMode
  = Orthosteric
  | Allosteric
  | Indirect
  | Functional
  deriving stock   (Eq, Show, Generic)
  deriving anyclass (ToJSON, FromJSON)

-- | A measurement of affinity. Units are made explicit at the type
-- level so 'nM' and 'µM' can't be silently mixed.
data Affinity
  = Ki   { magnitude :: Double, unit :: Unit }
  | EC50 { magnitude :: Double, unit :: Unit }
  | IC50 { magnitude :: Double, unit :: Unit }
  | Kd   { magnitude :: Double, unit :: Unit }
  | FunctionalOnly
  deriving stock   (Eq, Show, Generic)
  deriving anyclass (ToJSON, FromJSON)

data Unit
  = NM | UM | MM | MgPerMl | UgPerMl | FoldChange Double
  deriving stock   (Eq, Show, Generic)
  deriving anyclass (ToJSON, FromJSON)

-- ---------------------------------------------------------------------------
-- Citations
-- ---------------------------------------------------------------------------

data Reference = Reference
  { refLabel :: Text         -- ^ e.g. "Gertsch 2008 PNAS"
  , refUrl   :: Text         -- ^ DOI / PMC / PubMed URL
  } deriving stock   (Eq, Show, Generic)
    deriving anyclass (ToJSON, FromJSON)

-- ---------------------------------------------------------------------------
-- Terpene identity
-- ---------------------------------------------------------------------------

data TerpeneClass = Monoterpene | Monoterpenol | Sesquiterpene
  deriving stock   (Eq, Show, Generic)
  deriving anyclass (ToJSON, FromJSON)

data Structure = Acyclic | Monocyclic | Bicyclic
  deriving stock   (Eq, Show, Generic)
  deriving anyclass (ToJSON, FromJSON)

data Terpene = Terpene
  { terpeneId     :: Text
  , commonName    :: Text
  , iupac         :: Text
  , cas           :: Text
  , smiles        :: Text
  , formula       :: Text
  , molWeight     :: Double   -- g/mol
  , klass         :: TerpeneClass
  , structure     :: Structure
  , boilingPointC :: Double
  , logP          :: Double
  , waterSolMgMl  :: Double
  , sources       :: [Text]
  , femaGras      :: Text
  } deriving stock   (Eq, Show, Generic)
    deriving anyclass (ToJSON, FromJSON)

-- ---------------------------------------------------------------------------
-- Interactions, effects, PK, safety, synergy
-- ---------------------------------------------------------------------------

data Interaction = Interaction
  { iTerpene     :: Text
  , iReceptor    :: Receptor
  , iAction      :: Action
  , iBindingMode :: BindingMode
  , iAffinity    :: Affinity
  , iEfficacyPct :: Maybe Double  -- vs. reference agonist
  , iTier        :: Tier
  , iConfidence  :: Confidence
  , iNotes       :: Text
  , iRef         :: Reference
  } deriving stock   (Eq, Show, Generic)
    deriving anyclass (ToJSON, FromJSON)

data Route
  = Oral | IP | SC | IV | Inhalation | Intraplantar | Topical | Sublingual
  deriving stock   (Eq, Show, Generic)
  deriving anyclass (ToJSON, FromJSON)

data Sex = Male | Female | Mixed
  deriving stock   (Eq, Show, Generic)
  deriving anyclass (ToJSON, FromJSON)

data EffectClass
  = Analgesic | AntiInflammatory | Anxiolytic | Antidepressant
  | Antioxidant | Anticonvulsant | Neuroprotective | Antimicrobial
  | Gastroprotective | Bronchodilator | Antiobesity | Antidiabetic
  | Anticancer | NoSedation | OpioidSparing | MemoryProtective
  deriving stock   (Eq, Show, Generic)
  deriving anyclass (ToJSON, FromJSON)

data Effect = Effect
  { eTerpene   :: Text
  , eEffect    :: EffectClass
  , eCondition :: Text         -- canonical condition slug
  , eModel     :: Text         -- assay/animal model
  , eSpecies   :: Text
  , eDose      :: Maybe Double
  , eDoseUnit  :: Maybe Text   -- "mg/kg", "mg", ...
  , eRoute     :: Maybe Route
  , eSex       :: Maybe Sex
  , eOutcome   :: Text
  , eTier      :: Tier
  , eRef       :: Reference
  } deriving stock   (Eq, Show, Generic)
    deriving anyclass (ToJSON, FromJSON)

data PKParam
  = OralF | Tmax | Cmax | THalf | AUC | Vd | CL | BBB | PulmonaryUptake
  deriving stock   (Eq, Show, Generic)
  deriving anyclass (ToJSON, FromJSON)

data Pharmacokinetics = Pharmacokinetics
  { pkTerpene     :: Text
  , pkSpecies     :: Text
  , pkRoute       :: Route
  , pkFormulation :: Text   -- "neat","SEDDS","beta-cyclodextrin","EO_capsule"
  , pkParameter   :: PKParam
  , pkValue       :: Double
  , pkUnit        :: Text
  , pkNotes       :: Text
  , pkRef         :: Reference
  } deriving stock   (Eq, Show, Generic)
    deriving anyclass (ToJSON, FromJSON)

data SynergyKind
  = Synergistic
  | Additive
  | Antagonistic
  | NoInteractionS
  | OpioidSparingS
  | MemoryProtectiveS
  | Antianxiogenic
  | ContestedS
  deriving stock   (Eq, Show, Generic)
  deriving anyclass (ToJSON, FromJSON)

data Partner
  = THC | CBD | TwoAG | AEA | Morphine | WIN55212 | CP_55940 | Other Text
  deriving stock   (Eq, Show, Generic)
  deriving anyclass (ToJSON, FromJSON)

data Synergy = Synergy
  { syTerpene     :: Text
  , syPartner     :: Partner
  , syKind        :: SynergyKind
  , syMechanism   :: Text
  , syAssay       :: Text
  , syQuantResult :: Text
  , syConfidence  :: Confidence
  , syTier        :: Tier
  , syRef         :: Reference
  } deriving stock   (Eq, Show, Generic)
    deriving anyclass (ToJSON, FromJSON)

-- ---------------------------------------------------------------------------
-- The canonical record per terpene
-- ---------------------------------------------------------------------------

data TerpeneRecord = TerpeneRecord
  { rIdentity         :: Terpene
  , rInteractions     :: [Interaction]
  , rEffects          :: [Effect]
  , rPharmacokinetics :: [Pharmacokinetics]
  , rSynergy          :: [Synergy]
  } deriving stock   (Eq, Show, Generic)
    deriving anyclass (ToJSON, FromJSON)

-- ---------------------------------------------------------------------------
-- Drug-design queries
-- ---------------------------------------------------------------------------

-- | A condition mapped to its prioritised target panel.
data ConditionPanel = ConditionPanel
  { cpCondition :: Text
  , cpTargets   :: [(Receptor, Int, Text)]   -- (target, priority, rationale)
  } deriving stock   (Eq, Show, Generic)
    deriving anyclass (ToJSON, FromJSON)

-- | Score a terpene against a condition panel by counting how many of
-- its high-confidence interactions hit prioritised targets. A toy
-- starter for more sophisticated scoring (Bayesian, network-pharmacology
-- weighting, etc.).
scoreTerpene :: ConditionPanel -> [Interaction] -> Int
scoreTerpene panel ix =
  let targets = map (\(r,_,_) -> r) (cpTargets panel)
      strong  = filter (\i -> iConfidence i `elem` [Strong, Moderate]) ix
  in length (filter (\i -> iReceptor i `elem` targets) strong)

-- | Convenience: turn an interaction list into a "fingerprint" — the
-- set of receptors hit with at least Moderate confidence. Two compounds
-- with overlapping fingerprints are candidates for additive design;
-- two with disjoint fingerprints that converge on the same condition
-- panel are candidates for synergistic design.
fingerprint :: [Interaction] -> [Receptor]
fingerprint = map iReceptor
            . filter (\i -> iConfidence i `elem` [Strong, Moderate])

-- | Detect candidate entourage pairs: two terpenes whose receptor
-- fingerprints intersect with the panel but do NOT overlap each
-- other — i.e. they cover complementary mechanisms for the same
-- condition.
complementaryPair
  :: ConditionPanel
  -> (Text, [Interaction])
  -> (Text, [Interaction])
  -> Bool
complementaryPair panel (_, ax) (_, bx) =
  let targets = map (\(r,_,_) -> r) (cpTargets panel)
      fpA     = filter (`elem` targets) (fingerprint ax)
      fpB     = filter (`elem` targets) (fingerprint bx)
  in not (null fpA) && not (null fpB)
     && null (filter (`elem` fpB) fpA)

-- ---------------------------------------------------------------------------
-- A couple of pre-baked condition panels matching the seed DB
-- ---------------------------------------------------------------------------

chronicPainPanel :: ConditionPanel
chronicPainPanel = ConditionPanel
  { cpCondition = "chronic_pain"
  , cpTargets   =
      [ (A2A,      1, "Spinal A2A is convergent terpene analgesic mechanism")
      , (CB2,      1, "BCP-validated peripheral immune analgesia")
      , (CB1,      2, "THC + terpene partial agonism for central analgesia")
      , (TRPV1,    2, "Myrcene activation/desensitization paradigm")
      , (MuOpioid, 2, "Indirect engagement enables opioid-sparing combos")
      , (CaV3_2,   3, "Camphene/bisabolol T-type Ca block")
      ]
  }

neuroinflammationPanel :: ConditionPanel
neuroinflammationPanel = ConditionPanel
  { cpCondition = "neuroinflammation"
  , cpTargets   =
      [ (CB2,        1, "BCP CB2-dependent cytokine suppression")
      , (NFkB,       1, "Master inflammatory TF; all 5 terpenes inhibit")
      , (PPAR_gamma, 1, "BCP-PPARg axis modulates microglial polarisation")
      , (NRF2,       2, "BCP NRF2/HO-1 antioxidant defense")
      , (COX2,       2, "Downstream prostaglandin reduction")
      , (iNOS,       2, "NO production reduction")
      ]
  }
