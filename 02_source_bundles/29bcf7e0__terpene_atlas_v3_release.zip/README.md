# Terpene–Receptor Binding Atlas v3

> Primary-source affinity data extending the Terpene Codex v2.
> Sealed, typed, citation-bound. The substrate beneath the synergy claim.

**Authors.** Matthew Joseph Lansing¹ · Perplexity Computer²
¹ Bone & Saucer Labs / Agripparium, Georgetown, DE
² Perplexity AI, San Francisco, CA

---

## What this is

A typed, append-only atlas of **18 terpenes × 18 receptors = 324 cells**, populated
exclusively from peer-reviewed primary sources. Where the v2 Codex used a
semi-quantitative ordinal axis (`−2..+2`), this v3 atlas promotes those scores to
**typed binding constants** — `Ki`, `Kd`, `IC50`, `EC50` — or, when warranted, to
explicit `no_effect_up_to` validated negatives.

The sparsity is the finding. Of 324 cells:

| | Count | What it means |
|---|---|---|
| Hard constants (Ki/Kd/IC50/EC50) | **22** | Sub- to mid-µM affinities; only one is sub-µM (β-caryophyllene × CB2) |
| Validated negatives | **27** | Tested, no effect up to stated concentration |
| Qualitative / behavioral | **40** | Effect documented, no constant published |
| No data found | **235** | Honest void — flagged for future wet-lab work |

## The four anchors

1. **β-Caryophyllene × CB2 — Ki = 0.155 µM** ([Gertsch et al. 2008](https://pmc.ncbi.nlm.nih.gov/articles/PMC2449371/)).
   The only sub-µM terpene–receptor constant in the entire panel.
2. **Finlay 2020 / Heblinski 2020 negatives.** Six canonical "entourage" terpenes
   show no detectable activity at CB1/CB2/TRPV1/TRPA1 up to 10 µM. First-class
   evidence, not absence.
3. **Schwarz 2023 — A2A is the real terpene axis.** Geraniol, linalool, β-pinene,
   α-humulene, β-caryophyllene give 40–50% NECA efficacy at adenosine A2A.
   The entourage axis migrates from cannabinoid to adenosine.
4. **Borneol × GABA-A — >1000% potentiation at a flumazenil-insensitive site**
   (Granger 2005). Largest GABAergic effect in the panel; almost absent from
   contemporary terpene discourse.

## Artifacts

| File | Purpose |
|---|---|
| `atlas.json` | Canonical data (157 records, 18×18 matrix). |
| `TerpeneV3.hs` | Haskell ADT module — `BindingAffinity`, `Evidence`, `Citation`, atlas queries. Extends `Terpene.hs` / `TerpeneV2.hs`. |
| `schema_v3.sql` | SQLite schema — `binding_affinity` table + `v_best_evidence` view. |
| `seed_v3.sql` | Generated INSERTs (do not hand-edit). |
| `terpenes_v3.db` | Pre-built SQLite database. |
| `findings.md` | Headline-findings memo: the 22 constants, the 27 negatives, the gaps. |
| `terpene_atlas_v3.ppxl` | Sealed archive — gzip+base64+sha256, content-addressable. |

## .ppxl seal format

Header lines prefixed `%`, payload between `%---` markers, base64-encoded gzip
of the canonical JSON, sha256 in both header and footer. Verifies in 3 lines of
Python; tamper-evident; append-only-friendly.

## Reproducibility

```bash
python3 build/consolidate.py   # research → atlas.json
python3 build/seal.py          # atlas.json → schema_v3.sql + seed_v3.sql + .ppxl
sqlite3 terpenes_v3.db < schema_v3.sql
sqlite3 terpenes_v3.db < seed_v3.sql
```

## What this is not

Not a clinical instrument. Not dose guidance. Not a claim about the entourage
effect — a *substrate* under which the entourage debate can finally proceed
with traceable evidence. Every numeric in this atlas resolves to a citation URL
that was verified at build time.

---

**Schema version:** 3.0.0
**Generated:** see `atlas.json → generated_utc`
**Seal:** see `terpene_atlas_v3.ppxl → %sha256` header
