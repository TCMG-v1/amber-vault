-- ============================================================================
-- schema_v3.sql — Terpene Codex, schema version 3.0.0
-- ----------------------------------------------------------------------------
-- Extends schema_v2.sql with the binding_affinity table: typed, citation-
-- sealed receptor pharmacology. The v2 ordinal axis (-2..+2) remains as the
-- editorial summary; this table is the underlying primary-source layer.
-- ============================================================================

CREATE TABLE IF NOT EXISTS binding_affinity (
    record_id          TEXT PRIMARY KEY,
    terpene_id         TEXT NOT NULL REFERENCES terpenes(terpene_id),
    receptor           TEXT NOT NULL,
    assay_type         TEXT,    -- radioligand_binding | functional_camp | calcium_flux | patch_clamp | GTP_gamma_S | enzyme_inhibition | behavioral_in_vivo | other
    metric             TEXT NOT NULL CHECK (metric IN (
                         'Ki','Kd','IC50','EC50',
                         'percent_potentiation','percent_efficacy',
                         'no_effect_up_to','qualitative','no_data_found'
                       )),
    value_uM           REAL,    -- always micromolar; NULL for qualitative/null
    effect_direction   TEXT,    -- agonist|partial_agonist|antagonist|positive_allosteric_modulator|negative_allosteric_modulator|inhibitor|no_effect|modulator_unclear
    species_or_system  TEXT,
    confidence         TEXT,    -- high|medium|low
    citation_authors   TEXT,
    citation_year      INTEGER,
    citation_doi_pmid  TEXT,
    citation_url       TEXT,
    citation_quote     TEXT
);

CREATE INDEX IF NOT EXISTS idx_aff_terpene  ON binding_affinity(terpene_id);
CREATE INDEX IF NOT EXISTS idx_aff_receptor ON binding_affinity(receptor);
CREATE INDEX IF NOT EXISTS idx_aff_metric   ON binding_affinity(metric);

-- View: best evidence per (terpene, receptor) cell.
CREATE VIEW IF NOT EXISTS v_best_evidence AS
WITH ranked AS (
  SELECT
    terpene_id, receptor, record_id, metric, value_uM, effect_direction,
    citation_authors, citation_year, citation_url,
    CASE metric
      WHEN 'Ki'   THEN 4 WHEN 'Kd' THEN 4 WHEN 'IC50' THEN 4 WHEN 'EC50' THEN 4
      WHEN 'percent_potentiation' THEN 3 WHEN 'percent_efficacy' THEN 3
      WHEN 'no_effect_up_to' THEN 2
      WHEN 'qualitative' THEN 1
      ELSE 0
    END AS strength
  FROM binding_affinity
  WHERE metric <> 'no_data_found'
)
SELECT * FROM ranked r1
WHERE strength = (SELECT MAX(strength) FROM ranked r2
                  WHERE r2.terpene_id = r1.terpene_id AND r2.receptor = r1.receptor);
