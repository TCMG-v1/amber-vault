# Atlas — Headline Findings Memo

Generated: 2026-06-10T19:27:43.264456Z
Schema: v3.0.0

## Coverage
- Total cells: **324** (18 terpenes × 18 receptors)
- Cells with citation-bound evidence: **82** (25.3%)
- Quantitative constants (Ki/Kd/IC50/EC50): **22**
- Validated negatives (no-effect-up-to): **27**
- Qualitative / behavioral-only: **40**

## The four anchor findings

1. **β-caryophyllene × CB2, Ki = 0.155 µM (Gertsch 2008)** — the only sub-µM terpene constant in the entire panel. Validated by CB2-null mouse pharmacology. The Finlay 2020 partial displacement at 10 µM is *consistent* with this Ki, not contradictory.

2. **Finlay et al. 2020 negatives** — β-myrcene, linalool, limonene, α-/β-pinene, β-caryophyllene show *no detectable activity* at CB1, CB2, hTRPV1, hTRPA1 up to 10 µM. These are not absences of pharmacology; they are first-class evidence that the canonical 'entourage' terpenes do not act through the cannabinoid axis at physiologically plausible concentrations.

3. **Schwarz et al. 2023 — adenosine A2A is the real terpene axis.** Geraniol, linalool, β-pinene, α-humulene, and β-caryophyllene give 40–50% NECA efficacy at 100 µM on hA2A. The entourage story migrates from CB to A2A.

4. **Borneol × GABA-A, >1000% potentiation, EC50 ≈ 248 µM, flumazenil-insensitive (Granger 2005)** — the largest GABAergic effect in the panel and almost entirely absent from current terpene discourse. Acts at a non-benzodiazepine allosteric site.

## Surprises documented in the data

- **Eucalyptol × TRPM8 — human–mouse inversion.** EC50 = 120 µM at hTRPM8 (Fürst 2017) vs 7.7 mM at mouse (Behrendt 2004). Therapeutic doses reach the human EC50; rodent studies cannot.
- **Linalool × NMDA is essentially inert** at any plausible tissue concentration (IC50 ~2,970 µM, Brum 2001) — the glutamatergic story in many reviews collapses on inspection.
- **α-Pinene × AChE** is potency-equivalent to eucalyptol (~630 vs 670 µM, Perry 2000) yet absent from the Alzheimer-adjacent terpene literature.

## Gaps the atlas explicitly names

- **5-HT2A** — zero terpene records meet the schema criteria. A clean panel here would be high-impact.
- **TRPV3, TRPA1** — sparse across all 18 terpenes despite mechanistic relevance.
- **β-ocimene, guaiol, camphene** — near-total voids across the entire receptor panel.
- **CYP2D6** interactions undocumented for most monoterpenes; drug-interaction implications unaddressed.

## The 22 quantitative constants

| Terpene | Receptor | Metric | Value (µM) | Direction | Citation |
|---|---|---|---|---|---|
| eucalyptol | TRPM8 | EC50 | 0.1204 | agonist | [Fürst et al. 2017](https://pmc.ncbi.nlm.nih.gov/articles/PMC5387001/) |
| beta_caryophyllene | CB2 | Ki | 0.155 | agonist | [Gertsch et al. 2008](https://pmc.ncbi.nlm.nih.gov/articles/PMC2449371/) |
| linalool | GABA_A | EC50 | 10.8 | positive_allosteric_modulator | [Kessler et al. 2014](https://pmc.ncbi.nlm.nih.gov/articles/PMC4384808/) |
| nerolidol | CYP3A4 | Ki | 32.5 | inhibitor | [Václavíková et al. 2019](https://pubmed.ncbi.nlm.nih.gov/31755290/) |
| nerolidol | CYP3A4 | IC50 | 50.5 | inhibitor | [Špičáková et al. 2017](https://pmc.ncbi.nlm.nih.gov/articles/PMC6154719/) |
| alpha_terpineol | GABA_A | EC50 | 88 | positive_allosteric_modulator | [Che Has et al. 2014](https://www.alliedacademies.org/articles/the-inhibitory-activity-of-nutmeg-essential-oil-on-gabaa-122s-receptors.pdf) |
| borneol | TRPA1 | IC50 | 200.0 | antagonist | [Takaishi et al. 2013](https://pmc.ncbi.nlm.nih.gov/articles/PMC3889502/) |
| borneol | GABA_A | EC50 | 248 | positive_allosteric_modulator | [Granger et al. 2005](https://pubmed.ncbi.nlm.nih.gov/15763546/) |
| linalool | TRPA1 | IC50 | 300.0 | antagonist | [Hashimoto et al. 2023](https://pmc.ncbi.nlm.nih.gov/articles/PMC10123348/) |
| d_limonene | AChE | IC50 | 390.2 | inhibitor | [Nguyen Thi Thu Huong et al. 2022](https://pmc.ncbi.nlm.nih.gov/articles/PMC9610647/) |
| alpha_pinene | AChE | IC50 | 400 | inhibitor | [Miyazawa & Yamafuji 2005](https://pubs.acs.org/doi/abs/10.1021/jf040019b) |
| beta_caryophyllene | AChE | IC50 | 436 | inhibitor | [Nguyen Thi Thu Huong et al. 2022](https://pmc.ncbi.nlm.nih.gov/articles/PMC9610647/) |
| beta_pinene | AChE | IC50 | 524.5 | inhibitor | [Nguyen Thi Thu Huong et al. 2022](https://pmc.ncbi.nlm.nih.gov/articles/PMC9610647/) |
| alpha_pinene | AChE | IC50 | 630 | inhibitor | [Perry et al. 2000](https://pubmed.ncbi.nlm.nih.gov/10933142/) |
| eucalyptol | AChE | IC50 | 670 | inhibitor | [Perry et al. 2000](https://pubmed.ncbi.nlm.nih.gov/10933142/) |
| alpha_humulene | AChE | IC50 | 785.3 | inhibitor | [Nguyen Thi Thu Huong et al. 2022](https://pmc.ncbi.nlm.nih.gov/articles/PMC9610647/) |
| alpha_terpineol | AChE | IC50 | 1300 | inhibitor | [Savelev et al. 2009](https://pubmed.ncbi.nlm.nih.gov/19358605/) |
| linalool | NMDA | IC50 | 2970 | antagonist | [Brum et al. 2001](https://pubmed.ncbi.nlm.nih.gov/11507735/) |
| eucalyptol | TRPA1 | IC50 | 3430.0 | antagonist | [Takaishi et al. 2013](https://pmc.ncbi.nlm.nih.gov/articles/PMC3889502/) |
| eucalyptol | AChE | IC50 | 6000 | inhibitor | [Dorofeev et al. 2008](https://pubmed.ncbi.nlm.nih.gov/18321657/) |
| eucalyptol | TRPM8 | EC50 | 7700.0 | agonist | [Behrendt et al. 2004](https://pubmed.ncbi.nlm.nih.gov/15310428/) |
| alpha_terpineol | AChE | IC50 | 8440 | inhibitor | [Savelev et al. 2009](https://pubmed.ncbi.nlm.nih.gov/19358605/) |

## The 27 validated negatives

| Terpene | Receptor | Tested up to (µM) | Citation |
|---|---|---|---|
| alpha_pinene | CB1 | 10.0 | [Finlay et al. 2020](https://pmc.ncbi.nlm.nih.gov/articles/PMC7109307/) |
| alpha_pinene | CB2 | 10.0 | [Finlay et al. 2020](https://pmc.ncbi.nlm.nih.gov/articles/PMC7109307/) |
| alpha_pinene | TRPA1 | 10.0 | [Heblinski et al. 2020](https://pubmed.ncbi.nlm.nih.gov/33376801/) |
| alpha_pinene | TRPV1 | 10.0 | [Heblinski et al. 2020](https://pubmed.ncbi.nlm.nih.gov/33376801/) |
| beta_caryophyllene | CB1 | 10.0 | [Finlay et al. 2020](https://pmc.ncbi.nlm.nih.gov/articles/PMC7109307/) |
| beta_caryophyllene | CB2 | 10.0 | [Finlay et al. 2020](https://pmc.ncbi.nlm.nih.gov/articles/PMC7109307/) |
| beta_caryophyllene | TRPA1 | 10.0 | [Heblinski et al. 2020](https://pubmed.ncbi.nlm.nih.gov/33376801/) |
| beta_caryophyllene | TRPV1 | 10.0 | [Heblinski et al. 2020](https://pubmed.ncbi.nlm.nih.gov/33376801/) |
| beta_myrcene | CB1 | 10.0 | [Finlay et al. 2020](https://pmc.ncbi.nlm.nih.gov/articles/PMC7109307/) |
| beta_myrcene | CB2 | 10.0 | [Finlay et al. 2020](https://pmc.ncbi.nlm.nih.gov/articles/PMC7109307/) |
| beta_myrcene | TRPA1 | 10.0 | [Heblinski et al. 2020](https://pubmed.ncbi.nlm.nih.gov/33376801/) |
| beta_pinene | CB1 | 10.0 | [Finlay et al. 2020](https://pmc.ncbi.nlm.nih.gov/articles/PMC7109307/) |
| beta_pinene | CB2 | 10.0 | [Finlay et al. 2020](https://pmc.ncbi.nlm.nih.gov/articles/PMC7109307/) |
| beta_pinene | TRPA1 | 10.0 | [Heblinski et al. 2020](https://pubmed.ncbi.nlm.nih.gov/33376801/) |
| beta_pinene | TRPV1 | 10.0 | [Heblinski et al. 2020](https://pubmed.ncbi.nlm.nih.gov/33376801/) |
| d_limonene | CB1 | 10.0 | [Finlay et al. 2020](https://pmc.ncbi.nlm.nih.gov/articles/PMC7109307/) |
| d_limonene | CB2 | 10.0 | [Finlay et al. 2020](https://pmc.ncbi.nlm.nih.gov/articles/PMC7109307/) |
| d_limonene | TRPV1 | 10.0 | [Heblinski et al. 2020](https://pubmed.ncbi.nlm.nih.gov/33376801/) |
| eucalyptol | TRPV1 | 5000.0 | [Ohkawara et al. 2012](https://pmc.ncbi.nlm.nih.gov/articles/PMC3567430/) |
| geraniol | AChE | None | [Perry et al. 2000](https://pubmed.ncbi.nlm.nih.gov/10933142/) |
| geraniol | AChE | None | [Perry et al. 2000](https://pubmed.ncbi.nlm.nih.gov/10933142/) |
| linalool | 5HT1A | None | [Harada et al. 2018](https://www.frontiersin.org/journals/behavioral-neuroscience/articles/10.3389/fnbeh.2018.00241/full) |
| linalool | AChE | None | [Perry et al. 2000](https://pubmed.ncbi.nlm.nih.gov/10933142/) |
| linalool | CB1 | 10.0 | [Finlay et al. 2020](https://pmc.ncbi.nlm.nih.gov/articles/PMC7109307/) |
| linalool | CB2 | 10.0 | [Finlay et al. 2020](https://pmc.ncbi.nlm.nih.gov/articles/PMC7109307/) |
| linalool | TRPV1 | 1.0 | [Hashimoto et al. 2023](https://pmc.ncbi.nlm.nih.gov/articles/PMC10123348/) |
| nerolidol | CYP2D6 | 100.0 | [Špičáková et al. 2017](https://pmc.ncbi.nlm.nih.gov/articles/PMC6154719/) |