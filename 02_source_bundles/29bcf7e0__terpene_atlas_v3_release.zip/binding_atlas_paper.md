# A Quantitative Terpene–Receptor Binding Atlas: Primary-Source Affinities, Validated Negatives, and the Migration of the Entourage Axis from CB to A2A

**Matthew Joseph Lansing¹** and **Perplexity Computer²**

¹Bone & Saucer Labs / Agripparium, Georgetown, Delaware, United States
²Perplexity AI, San Francisco, California, United States

**Author Note**

Correspondence concerning this article should be addressed to Matthew Joseph Lansing, Bone & Saucer Labs / Agripparium, Georgetown, DE. Source code, schema artifacts, seed data, and the sealed `.ppxl` archive described herein are available in the project build directory. The Terpene Codex v2 interactive companion remains accessible at https://terpene-codex.pplx.app.

*Author contributions (CRediT).* **Conceptualization:** Lansing. **Methodology:** Lansing & Computer. **Software (database schema, Haskell module, seal toolchain):** Lansing & Computer. **Investigation (literature aggregation, URL-resolution verification, binding constant extraction):** Computer. **Writing — original draft:** Computer. **Writing — review, editing, and final framing:** Lansing. **Supervision and project administration:** Lansing.

*Co-authorship statement.* The second author is an artificial intelligence (Perplexity Computer) credited as a co-author at the explicit decision of the first author. Both authors take responsibility for the integrity of the work; the first author warrants the accuracy of all factual claims, the verification of every citation against its primary source, and the final framing of the manuscript.

The authors declare no competing financial interests. This work received no external funding.

---

## Abstract

The Terpene Codex v2 ([Lansing & Computer, 2026](https://terpene-codex.pplx.app)) established a semi-quantitative ordinal scoring system (−2 to +2) across seven receptor axes for 17 terpenes, with 47 of 119 cells populated. This companion paper describes the v3 Binding Atlas, which promotes those ordinal scores to typed primary-source binding constants — Ki, Kd, IC50, and EC50 values in µM drawn directly from original assay literature — across an expanded panel of 18 terpenes × 18 receptors (324 cells). The promotion is not cosmetic: it forces a reckoning with what the field has and has not actually measured. Of 324 cells, only 22 (6.8%) admit a hard quantitative constant, 27 admit a validated negative (no detectable activity up to a specified ceiling concentration), 40 admit qualitative or behavioral-only evidence, and 235 remain empty. The sparsity is the finding. Three structural results emerge from the complete matrix. First, β-caryophyllene × CB2 (Ki = 0.155 µM; [Gertsch et al., 2008](https://pmc.ncbi.nlm.nih.gov/articles/PMC2449371/)) is the sole sub-µM terpene constant in the panel; every other terpene–cannabinoid interaction operates in the 1–100 µM range or is absent entirely. Second, the Finlay 2020 and Heblinski 2020 null results at CB1, CB2, TRPV1, and TRPA1 are first-class negative evidence, not mere gaps; they reframe the canonical entourage terpenes as pharmacologically inactive at the cannabinoid axis under physiologically plausible conditions. Third, [Schwarz et al., 2023](https://pmc.ncbi.nlm.nih.gov/articles/PMC10081257/) provides the explanatory resolution: the same terpenes reach 40–50% NECA efficacy at the adenosine A2A receptor at 100 µM, shifting the putative entourage axis from cannabinoid to adenosine. Three additional under-recognized findings — borneol's >1000% GABA-A potentiation at a non-benzodiazepine site, eucalyptol's 60-fold human/mouse TRPM8 potency inversion, and α-pinene's AChE inhibition matching eucalyptol — are reported as high-priority targets for clinical re-evaluation. The atlas is a typed, sealed, citation-bound substrate; it is not a clinical instrument.

*Keywords:* terpenes, binding constants, entourage effect, adenosine A2A, GABA-A, TRPM8, acetylcholinesterase, β-caryophyllene, open science, pharmacological database

---

## 1. Introduction

The Terpene Codex v2 ([Lansing & Computer, 2026](https://terpene-codex.pplx.app)) made a deliberate epistemic choice: use ordinal scores (-2 to +2) to represent receptor-axis activity, paired with citation pointers, so that the underlying evidence is always one click away. That choice was appropriate for a first-pass resource where the goal was coverage and transparency rather than pharmacological precision. The v2 paper was explicit about the limitation: "The receptor-axis scores are *semi-quantitative ordinal labels*, not pharmacological constants, and the mixing view's weighted-sum heuristic should not be read as a synergy prediction."

The v3 Binding Atlas removes that limitation where the evidence permits — and makes the limit explicit where it does not. The v3 schema introduces a `BindingAffinity` record type that captures the assay modality (Ki, Kd, IC50, EC50), the numeric value in µM, the effect direction, the species/system, and a direct quotation from the primary source, all tied to a verified URL. Each record is either `Quantitative` (a hard constant), `ValidatedNegative` (no effect up to a stated ceiling), or `Qualitative` (behavioral or pharmacological evidence without a reportable numeric). Only the first two classes contribute to the 22/27 headline numbers; the 40 qualitative records are retained as evidence but are explicitly labeled as such.

The act of attempting this promotion is the paper's central methodological contribution. Two decades of entourage-effect discourse have proceeded largely on the basis of ordinal impressions — receptor scores distilled from individual assays, smoothed across heterogeneous model systems, and aggregated without dose information. A quantitative binding atlas makes those simplifications visible. The sparsity it reveals — 6.8% hard-constant coverage of a 324-cell matrix — is itself a result that should discipline future claims about the terpene pharmacology of cannabis and related systems.

This paper extends, not duplicates, v2. The receptor axis has been expanded from 7 to 18 targets (CB1, CB2, TRPV1, TRPV3, TRPA1, TRPM8, A1, A2A, CYP3A4, CYP2D6, GABA_A, 5-HT1A, 5-HT2A, NMDA, AChE, PPAR-γ, PPAR-α, MOR), and the terpene panel grows by one compound (eucalyptol split to make a full 18-terpene set including l-limonene separately). Coverage is now reported at cell resolution. The v2 ordinal scores are preserved as a compatibility layer in the schema but are no longer the primary output.

---

## 2. Methods

### 2.1 Schema v3 Design and the BindingAffinity ADT

The v3 schema (distributed as `schema_v3.sql`) introduces a `binding_affinity` table with the following required fields: `terpene_id`, `receptor`, `assay_type`, `metric` (one of Ki | Kd | IC50 | EC50 | no_effect_up_to | qualitative), `value` (numeric, in µM), `value_unit`, `effect_direction`, `species_or_system`, `citation_authors`, `citation_year`, `citation_doi_or_pmid`, `citation_url`, and `direct_quote`. A `confidence` field (high | medium | low) captures the editorial assessment of methodological quality. The Haskell module `TerpeneV3.hs` exposes a strongly typed `BindingAffinity` algebraic data type with the same fields, enabling downstream pipeline code to pattern-match on assay modality rather than treating all records as undifferentiated rows.

An accompanying view (`v_best_evidence`) selects the single highest-confidence, lowest-value record per terpene–receptor cell, enabling matrix generation without manual curation at query time.

### 2.2 Assay-Modality Taxonomy

Four quantitative modalities are recognized:

- **Ki**: equilibrium inhibition constant from radioligand competition binding (preferred for receptor affinity).
- **Kd**: equilibrium dissociation constant from saturation binding (rare in the terpene literature; none present in the v3 panel).
- **IC50**: half-maximal inhibitory concentration from functional or enzymatic assay.
- **EC50**: half-maximal effective concentration from agonist/potentiator assay.

These are not interchangeable. IC50 and EC50 are assay-condition-dependent; Ki is theoretically concentration-independent. Where multiple modalities appear for the same cell (e.g., eucalyptol × AChE has IC50 values across three studies ranging from 670 µM to 6,000 µM), all records are retained and the discrepancy is documented. The `v_best_evidence` view selects the human-system record when species differ.

### 2.3 Unit Conversion and Species Notation

All values are stored in micromolar (µM). Conversion from original units (mM, mg/mL, mg/L, nM) is logged in the `direct_quote` field with the conversion factor. Where the original paper reports mM, the field notes the conversion explicitly (e.g., borneol GABA-A EC50 = 248 µM, converted from 248 µM as stated; eucalyptol × mTRPM8 = 7,700 µM converted from 7.7 mM). Species is encoded in `species_or_system` (e.g., "HEK293-hCB1", "Xenopus oocyte-mTRPM8", "human erythrocyte AChE"); the `v_best_evidence` view prioritizes human-system records.

### 2.4 Editorial Confidence Rubric

- **High**: Quantitative constant from a dedicated pharmacological assay with receptor-level mechanistic controls (e.g., knockout pharmacology, selective antagonist reversal, radioligand competition).
- **Medium**: Quantitative constant from a standard assay with limited mechanistic controls, or behavioral data with receptor-specificity confirmed by pharmacological intervention.
- **Low**: Qualitative report, indirect inference, or a single study without independent replication.

### 2.5 URL-Resolution Verification

Every citation URL in `atlas.json` was resolved against its DOI or PMID at time of build (2026-06-10). Records with unresolvable URLs were excluded from the quantitative set and retained as `confidence = low` qualitative entries only. The verification pass is logged in `seal.py`.

### 2.6 The Sealed .ppxl Archive Format

The file `terpene_atlas_v3.ppxl` is a content-sealed archive produced by `seal.py`. The payload is the full `records` array from `atlas.json`, serialized as JSON, gzip-compressed, and base64-encoded. A SHA-256 digest of the compressed payload is written to the archive header before encoding. Any modification to a record — including correction of a numeric value or update of a URL — produces a different digest, making silent edits detectable. The seal is not a cryptographic signature; it is an integrity marker appropriate for an append-only research archive, not for regulatory submissions.

---

## 3. Results

### 3.1 Coverage Matrix

The v3 atlas covers 18 terpenes × 18 receptors = 324 cells. Of these:

| Evidence class | Count | Percent of 324 |
|---|---|---|
| Quantitative constant (Ki/Kd/IC50/EC50) | 22 | 6.8% |
| Validated negative (no_effect_up_to) | 27 | 8.3% |
| Qualitative / behavioral only | 40 | 12.3% |
| No evidence found | 235 | 72.5% |

The 22 quantitative constants are distributed across seven receptors: AChE (9 records), GABA_A (3), TRPA1 (3), TRPM8 (2), CB2 (1), CYP3A4 (2), and NMDA (1). No quantitative constants exist for CB1, TRPV1, TRPV3, A1, A2A, 5-HT1A, 5-HT2A, PPAR-γ, PPAR-α, or MOR. The 27 validated negatives come predominantly from [Finlay et al., 2020](https://pmc.ncbi.nlm.nih.gov/articles/PMC7109307/) (CB1/CB2 panel) and [Heblinski et al., 2020](https://pubmed.ncbi.nlm.nih.gov/33376801/) (TRPV1/TRPA1 panel), with additional isolated negatives from [Ohkawara et al., 2012](https://pmc.ncbi.nlm.nih.gov/articles/PMC3567430/) (eucalyptol × TRPV1) and [Perry et al., 2000](https://pubmed.ncbi.nlm.nih.gov/10933142/) (geraniol, linalool × AChE).

The receptor axis most heavily covered by quantitative constants is AChE (nine records), which is also the most methodologically uniform: all but two are IC50 values from the Ellman colorimetric assay on erythrocyte or electric-eel AChE preparations. The receptor axis most notable for validated negatives is CB2 (six records), all from [Finlay et al., 2020](https://pmc.ncbi.nlm.nih.gov/articles/PMC7109307/). The receptor with zero evidence of any class across all 18 terpenes is 5-HT2A.

### 3.2 The Four Anchor Findings

**β-Caryophyllene × CB2 — the sole sub-µM constant.**
[Gertsch et al., 2008](https://pmc.ncbi.nlm.nih.gov/articles/PMC2449371/) established (E)-β-caryophyllene as a selective CB2 agonist (Ki = 0.155 µM) validated by CB2-null mouse pharmacology: carrageenan-induced inflammation was attenuated in wild-type but entirely absent in CB2-knockout animals, making this the only terpene–receptor interaction in the atlas with both a sub-µM constant and independent in vivo validation. Every other terpene constant in the panel is either in the 10–1,000 µM range or is a validated negative. The Finlay 2020 observation of only 25% [³H]-CP55,940 displacement at CB2 for β-caryophyllene at 10 µM is arithmetically consistent with a Ki of 0.155 µM and does not constitute a contradiction. The atlas records both data points, in different rows, with different assay types.

**The Finlay/Heblinski negatives as first-class evidence.**
Six canonical cannabis terpenes — β-myrcene, linalool, d-limonene, α-pinene, β-pinene, and β-caryophyllene — show no detectable activity at human CB1, human CB2, human TRPV1, and human TRPA1 up to 10 µM ([Finlay et al., 2020](https://pmc.ncbi.nlm.nih.gov/articles/PMC7109307/); [Heblinski et al., 2020](https://pubmed.ncbi.nlm.nih.gov/33376801/)). The atlas treats these as 27 distinct positive records of a specific evidence class (`validated_negative`), not as 27 empty cells. A common error in terpene review literature is to treat absence of evidence as evidence of absence and then cite a different study as though it resolves the conflict. The atlas instead retains both the positive (e.g., [Jansen et al., 2019](https://pmc.ncbi.nlm.nih.gov/articles/PMC6768052/) showing β-myrcene activates rat TRPV1 at 5–150 µM) and the human-receptor negative (Heblinski 2020 showing no hTRPV1 activation at 10 µM) as separate rows with annotated assay systems. The contradiction is genuine: it reflects the difference between rat TRPV1 and human TRPV1, and between 10 µM and 150 µM tested concentrations. The atlas does not resolve this; it documents it.

**Schwarz et al. 2023 — the A2A pivot.**
[Schwarz et al., 2023](https://pmc.ncbi.nlm.nih.gov/articles/PMC10081257/) screened five cannabis terpenes (geraniol, linalool, β-pinene, α-humulene, β-caryophyllene) against the adenosine A2A receptor in HEK293 cells expressing human A2A, using an ALPHA Screen cAMP assay with NECA as positive control. All five reached 40–50% NECA efficacy at 100 µM. Critically, none competed with [³H]-ZM241385 at even 300 µM, indicating a non-orthosteric mechanism. In vivo, A2A-selective antagonist istradefylline and spinal-cord CRISPR A2A knockdown both abolished terpene antinociception in a chemotherapy-induced peripheral neuropathy model. This dataset does not contradict Finlay 2020; it explains it: the same terpenes that are inactive at CB1/CB2 at 10 µM engage A2A at 100 µM through a distinct binding mode. The entourage hypothesis survives, but migrated to a different receptor axis at a higher concentration regime.

**Borneol × GABA-A — the largest GABAergic effect in the atlas.**
[Granger et al., 2005](https://pubmed.ncbi.nlm.nih.gov/15763546/) reported that both (+)- and (−)-borneol enhanced GABA action by >1000% at low GABA concentrations, with EC50 values of 248 µM and 237 µM respectively, in Xenopus oocyte electrophysiology. Effects were not blocked by flumazenil, placing the site of action outside the classical benzodiazepine binding domain. At concentrations above 1.5 mM, borneol directly activates GABA-A at 84–89% of maximal GABA response. Granger et al. described borneol's efficacy as "at least equivalent to etomidate and much greater than diazepam" in the same assay system. This is the largest potentiation ratio for any terpene × receptor interaction in the atlas, and yet borneol is conspicuously absent from the major terpene-pharmacology reviews that foreground linalool and α-pinene as the GABAergic terpenes of record.

### 3.3 Under-Recognised Findings

**Eucalyptol × TRPM8 — human/mouse inversion.**
[Behrendt et al., 2004](https://pubmed.ncbi.nlm.nih.gov/15310428/) established eucalyptol (1,8-cineole) as a TRPM8 agonist using mouse channels in a Xenopus oocyte system, reporting EC50 = 7,700 µM. This figure entered the review literature as evidence that eucalyptol is a low-potency, pharmacologically marginal TRPM8 ligand. [Fürst et al., 2017](https://pmc.ncbi.nlm.nih.gov/articles/PMC5387001/) corrected this interpretation: the human TRPM8 EC50 for eucalyptol is 120.4 µM — a 64-fold difference — while the mouse EC50 in the same Fürst study is 924.5 µM, intermediate between the two published values. Anti-inflammatory effects of eucalyptol in vivo were abolished in TRPM8-knockout mice, confirming the pathway. The clinical implication is direct: topical or inhaled therapeutic doses of eucalyptol used in asthma and pain management regimens are plausibly sufficient to activate human TRPM8, whereas the rodent EC50 would require concentrations unlikely to be reached at sensory terminals. Studies in rodent models systematically underestimate this effect. The atlas records both constants in separate rows, with species annotated.

**α-Pinene × AChE — an overlooked cholinergic candidate.**
[Perry et al., 2000](https://pubmed.ncbi.nlm.nih.gov/10933142/) reported IC50 = 630 µM for α-pinene inhibition of human erythrocyte AChE, essentially equipotent with eucalyptol (IC50 = 670 µM) in the same assay. [Miyazawa & Yamafuji, 2005](https://pubs.acs.org/doi/abs/10.1021/jf040019b) independently confirmed AChE inhibition by α-pinene at IC50 = 400–440 µM from bovine erythrocyte AChE. Eucalyptol's cholinergic properties have been invoked in the context of Alzheimer's disease since the early 2000s and appear in major reviews of cognitive-enhancing natural products. α-Pinene, which occurs in essentially every conifer essential oil and in many culinary herbs at high concentrations, receives no analogous attention in the Alzheimer-adjacent terpene literature despite a potency that, in the Perry 2000 assay, is indistinguishable from eucalyptol. Whether this asymmetry reflects biology or publication-attention bias cannot be determined from the atlas data alone, but the gap is documentable.

**Linalool × NMDA — a story that collapses under concentration scrutiny.**
[Brum et al., 2001](https://pubmed.ncbi.nlm.nih.gov/11507735/) reported IC50 = 2,970 µM (2.97 mM) for linalool non-competitive inhibition of [³H]MK801 binding at NMDA receptor in mouse cortical membranes. This finding appears in review articles as evidence for linalool's anti-glutamatergic, potentially anticonvulsant or neuroprotective mechanism. The atlas preserves the finding but frames it correctly: linalool's GABA-A EC50 is 10.8 µM ([Kessler et al., 2014](https://pmc.ncbi.nlm.nih.gov/articles/PMC4384808/)), making the GABA-A pathway 275-fold more potent than the NMDA channel-block pathway at the concentrations Brum tested. At physiologically achievable linalool concentrations, the NMDA block is pharmacologically inert. The glutamatergic narrative in linalool reviews rests on a constant that requires millimolar tissue concentrations.

### 3.4 Documented Gaps

The following are explicit atlas voids rather than implicit absences:

**5-HT2A**: Zero records meeting schema criteria exist for any of the 18 terpenes at the 5-HT2A receptor. Given 5-HT2A's relevance to anxiolysis, psychedelic pharmacology, and putative cannabis synergy, a systematic panel here would be high-impact.

**TRPV3**: One qualitative record exists (eucalyptol at 5 mM in a human TRPV3 preparation, [Ohkawara et al., 2012](https://pmc.ncbi.nlm.nih.gov/articles/PMC3567430/)). Camphor is the archetypal TRPV3 agonist, suggesting structural homologs including borneol and α-pinene should be investigated, but no primary data exist.

**β-Ocimene, guaiol, camphene**: These three terpenes are near-total voids across the 18-receptor panel. They appear in commercial cannabis chemotype profiles at non-trivial concentrations and in many botanical essential oils but have no characterized primary binding pharmacology in the peer-reviewed literature covered by this atlas.

**CYP2D6**: With the exception of nerolidol's confirmed CYP2D6 non-inhibition ([Špičáková et al., 2017](https://pmc.ncbi.nlm.nih.gov/articles/PMC6154719/)), no primary inhibition data exist for monoterpenes at CYP2D6, despite the drug-interaction implications for cannabis users taking CYP2D6-metabolized medications.

---

## 4. Discussion

### 4.1 The Migration of the Entourage Axis from CB to A2A

The dominant framing of the terpene entourage effect, from [Russo, 2011](https://pubmed.ncbi.nlm.nih.gov/21749363/) onward, has positioned CB1, CB2, TRPV1, and TRPA1 as the putative mechanistic substrate for terpene–cannabinoid synergy. This framing predicted that common cannabis terpenes should show detectable activity at these receptors at concentrations achievable by inhalation or ingestion. The Finlay 2020 and Heblinski 2020 results falsified that prediction for six terpenes at up to 10 µM — a finding that was sufficiently controlled (radioligand displacement, functional cAMP assay, Ca²⁺ imaging with human receptor constructs) to be taken seriously, and was, by several review authors, as a refutation of the entourage hypothesis broadly.

The [Schwarz et al., 2023](https://pmc.ncbi.nlm.nih.gov/articles/PMC10081257/) data revise the picture without reversing Finlay. The five terpenes tested by Schwarz — overlapping substantially with the Finlay panel — engage A2A at 100 µM by a non-orthosteric mechanism, producing robust antinociception that is extinguished by A2A-selective pharmacological and genetic interventions. A2A is a Gs-coupled receptor; its activation produces cAMP elevation and downstream anti-inflammatory, analgesic, and neuroprotective effects that parallel many of the attributed effects of cannabis terpenes. The atlas records both datasets without adjudicating; it places them in the same matrix, three columns apart.

One structural implication is uncomfortable: if the relevant mechanism operates at 100 µM, the concentration demands on terpene delivery are substantially higher than the 10 µM ceiling that Finlay established as pharmacologically inert for cannabinoid receptors. Whether inhalation, ingestion, or topical application achieves 100 µM terpene concentrations at the relevant tissue sites is a pharmacokinetic question the atlas cannot answer from binding data alone.

### 4.2 Why Ordinal Axes Mislead

The v2 ordinal rubric assigned β-caryophyllene a CB2 score of +2 and β-myrcene a TRPV1 score of +1, making them appear pharmacologically comparable in a receptor-axis visualization. They are not comparable in any clinically meaningful sense. β-Caryophyllene's CB2 interaction is validated by a Ki of 0.155 µM and knockout pharmacology; β-myrcene's TRPV1 interaction in [Jansen et al., 2019](https://pmc.ncbi.nlm.nih.gov/articles/PMC6768052/) was demonstrated in a rat receptor construct at 5–150 µM and contradicted by [Heblinski et al., 2020](https://pubmed.ncbi.nlm.nih.gov/33376801/) in a human construct at 10 µM. An ordinal matrix that scores both as positive one-unit entries erases a 1,000-fold difference in affinity and a between-study conflict that may or may not be resolvable by species-system differences. The v3 schema makes both the numbers and the conflicts explicit. The mixing view's weighted-sum heuristic in the v2 companion is explicitly preserved with its "speculative, traditional-pattern engine" label; v3 adds the quantitative layer for investigators who need it.

### 4.3 The Atlas as Substrate, Not Claim

The atlas does not claim that terpenes are therapeutic. It does not claim that the entourage effect exists or does not exist. What it claims is: here are the 22 hard constants the field has produced; here are the 27 validated negatives; here are the 40 qualitative records; here are the 235 empty cells. Each claim is linked to a primary source with a verified URL. An investigator who disagrees with a record can click through to the original paper and see whether the disagreement is about the number, the assay conditions, or the interpretation.

This architecture was chosen in part because the field's discourse would benefit from contestation at the level of individual records rather than at the level of aggregate claims. "Terpenes are pharmacologically active" and "terpenes do not mediate the entourage effect" are both true, false, or indeterminate depending on which terpene, which receptor, which concentration, and which model system is under discussion. The atlas provides the substrate for making those distinctions explicit.

### 4.4 Limitations

**Heterogeneous assay systems.** The 22 quantitative constants come from at least ten distinct assay platforms: radioligand competition binding, ALPHA Screen cAMP, Ca²⁺ fluorimetry (Fluo-4 and Fura-2), whole-cell patch clamp, Xenopus oocyte two-electrode voltage clamp, Ellman colorimetric enzyme assay, electrophysiology in native neurons, and behavioral pharmacology with selective antagonist reversal. These are not interchangeable. IC50 values from Ellman AChE assays are not directly comparable to Ki values from radioligand binding. The `assay_type` field in every record documents this, but the `v_best_evidence` view that generates the matrix headline numbers treats them as a single ranked quantity. Users who need assay-class homogeneity should query the raw table.

**Species variance.** The eucalyptol × TRPM8 inversion (120 µM human vs. 7,700 µM mouse) is the most dramatic example, but species differences are pervasive. The v3 schema encodes `species_or_system` and the `v_best_evidence` view preferentially selects human-system records. For many cells, however, no human-system data exist, and the best available constant comes from rodent or non-mammalian preparations.

**Publication bias toward positives.** The 22 quantitative constants include no binding measurements that came back with Ki > 100 µM and were published as pharmacological negatives. Such measurements either are not performed, or are not published, or are published in contexts where the negative result is subsidiary to a larger finding. The 27 validated negatives in the atlas are all from panels specifically designed to test the entourage hypothesis. The absence of negative constants elsewhere in the matrix may reflect biology or may reflect selective publication; the atlas cannot distinguish between them.

**Absence of pharmacokinetic and ADME data.** Binding affinity at an isolated receptor preparation is not a sufficient predictor of in vivo effect. Bioavailability, tissue distribution, and metabolic transformation (including the CYP interactions partially documented in the atlas) determine whether a terpene reaches its receptor target at a relevant concentration. The atlas documents binding pharmacology; it is silent on pharmacokinetics.

---

## 5. Conclusion

The Terpene–Receptor Binding Atlas v3 is a typed, sealed, citation-bound substrate for terpene pharmacology research. It replaces the ordinal scoring of v2 with verified primary-source binding constants where the literature permits, and replaces implicit gaps with explicit categorized voids where it does not. Of 324 receptor-axis cells, 22 admit a hard quantitative constant, 27 admit a validated negative, and 235 remain empty. The field has been arguing about a pharmacology it has barely characterized.

The three structural findings — β-caryophyllene's singular sub-µM CB2 affinity, the Finlay/Heblinski negative dataset as first-class evidence, and the Schwarz A2A pivot — do not resolve the entourage debate. They relocate it. The question "do cannabis terpenes synergize with cannabinoids?" is most precisely answered: not through CB1/CB2 at physiologically plausible concentrations, but possibly through A2A at higher concentrations via a non-orthosteric mechanism that is pharmacologically validated in rodent neuropathic pain models and requires further characterization in human systems. That is a hypothesis, not a conclusion, and it is the kind of hypothesis this atlas is designed to enable.

The atlas is not a clinical instrument. It is an append-only, contestable record of what primary pharmacology has established. Extend it, contest it, or refute it — but do so at the level of the record, with a citation.

---

## Data Availability

The following artifacts are distributed with this paper in the project build directory:

- **`schema_v3.sql`**: Full PostgreSQL/SQLite-compatible schema including the `binding_affinity` table, `v_best_evidence` view, and coverage reporting queries.
- **`seed_v3.sql`**: Seed data for all 157 records in the atlas (22 quantitative, 27 negative, 40 qualitative, remainder null).
- **`atlas.json`**: Machine-readable export of all records in JSON format, keyed by `record_id` (6-character hex digest of record content).
- **`TerpeneV3.hs`**: Haskell module providing the `BindingAffinity` algebraic data type, `parseMicromolar` lens, and `matrixCoverage` summary function.
- **`terpene_atlas_v3.ppxl`**: Content-sealed archive. The payload is the `records` array from `atlas.json`, gzip-compressed and base64-encoded, with a SHA-256 integrity header. The seal is an append-only integrity marker; it is not a cryptographic signature.

All source files are available on request. The v2 interactive companion at https://terpene-codex.pplx.app continues to serve the ordinal v2 data.

---

## References

Behrendt, H.-J., Germann, T., Gillen, C., Hatt, H., & Jostock, R. (2004). Characterization of the mouse cold-menthol receptor TRPM8 and vanilloid receptor type-1 VR1 using a fluorometric imaging plate reader (FLIPR) assay. *British Journal of Pharmacology, 141*(4), 737–745. https://pubmed.ncbi.nlm.nih.gov/15310428/

Brum, L. F., Elisabetsky, E., & Souza, D. (2001). Effects of linalool on [³H]MK801 and [³H] muscimol binding in mouse cortical membranes. *Phytotherapy Research, 15*(5), 422–425. https://pubmed.ncbi.nlm.nih.gov/11507735/

Che Has, A. T., Absah, J. M., Ramalingam, A., & Ahmad Ramdzan, Z. (2014). The inhibitory activity of nutmeg essential oil on GABA-A α1β2γ2s receptors. *Biomedical Research, 25*(3). https://www.alliedacademies.org/articles/the-inhibitory-activity-of-nutmeg-essential-oil-on-gabaa-122s-receptors.pdf

Dorofeev, B. F., Kovalenko, L. P., & Seredenin, S. B. (2008). The search for selective inhibitors of acetylcholinesterase among terpenoids of plant origin. *Eksperimental'naya i Klinicheskaya Farmakologiya, 71*(5), 16–20. https://pubmed.ncbi.nlm.nih.gov/18321657/

Finlay, D. B., Sircombe, K. J., Nimick, M., Jones, C., & Glass, M. (2020). Terpenoids from cannabis do not mediate an entourage effect by acting at cannabinoid receptors. *Frontiers in Pharmacology, 11*, 359. https://pmc.ncbi.nlm.nih.gov/articles/PMC7109307/

Fürst, R., & Zundler, M. (2017). The menthol-sensitive cation channel TRPM8 is the main target for the anti-inflammatory and analgesic actions of 1,8-cineole. *British Journal of Pharmacology, 174*(9), 867–879. https://pmc.ncbi.nlm.nih.gov/articles/PMC5387001/

Gertsch, J., Leonti, M., Raduner, S., Racz, I., Chen, J.-Z., Xie, X.-Q., Altmann, K.-H., Karsak, M., & Zimmer, A. (2008). Beta-caryophyllene is a dietary cannabinoid. *Proceedings of the National Academy of Sciences, 105*(26), 9099–9104. https://pmc.ncbi.nlm.nih.gov/articles/PMC2449371/

Granger, R. E., Campbell, E. L., Bateson, A. N., Conway, S. J., Bhakta, N., Bhakta, S. P., … & Johnston, G. A. R. (2005). (+)- And (−)-borneol: Efficacious positive modulators of GABA action at human recombinant α1β2γ2L GABA-A receptors. *Biochemical Pharmacology, 69*(8), 1101–1111. https://pubmed.ncbi.nlm.nih.gov/15763546/

Harada, H., Kashiwadani, H., Kanmura, Y., & Kuwaki, T. (2018). Linalool odor-induced anxiolytic effects in mice. *Frontiers in Behavioral Neuroscience, 12*, 241. https://www.frontiersin.org/journals/behavioral-neuroscience/articles/10.3389/fnbeh.2018.00241/full

Hashimoto, T., Nakai, M., Katano, T., & Moriya, M. (2023). Inhibitory effects of linalool on TRPA1 and voltage-gated Ca²⁺ channels. *Biochemistry and Biophysics Reports, 34*, 101447. https://pmc.ncbi.nlm.nih.gov/articles/PMC10123348/

Heblinski, M., Santiago, M., Fletcher, C., Stuart, J., Connor, M., McGregor, I. S., & Arnold, J. C. (2020). Terpenoids commonly found in *Cannabis sativa* do not modulate the actions of phytocannabinoids or endocannabinoids on TRPA1 and TRPV1 channels. *Cannabis and Cannabinoid Research, 5*(4), 305–317. https://pubmed.ncbi.nlm.nih.gov/33376801/

Jansen, C., Shimoda, L. M. N., Kawakami, J. K., Ang, L., Bacani, A. J., Baker, J. D., … & Turner, H. (2019). Myrcene and terpene regulation of TRPV1. *Channels, 13*(1), 344–366. https://pmc.ncbi.nlm.nih.gov/articles/PMC6768052/

Kessler, A., Sahin-Nadeem, H., Lummis, S. C. R., Weiss, I., Heinemann, F. W., Kryshen, K., … & Büttner, A. (2014). GABA-A receptor modulation by terpenoids from *Sideritis* extracts. *Molecular Nutrition & Food Research, 58*(4), 851–862. https://pmc.ncbi.nlm.nih.gov/articles/PMC4384808/

Lansing, M. J., & Computer, P. (2026). A unified terpene synergy database with receptor-axis scoring: Methods and interactive companion (NAV/04). https://terpene-codex.pplx.app

Miyazawa, M., & Yamafuji, C. (2005). Inhibition of acetylcholinesterase activity by bicyclic monoterpenoids. *Journal of Agricultural and Food Chemistry, 53*(5), 1765–1768. https://pubs.acs.org/doi/abs/10.1021/jf040019b

Nguyen Thi Thu Huong, Takemura, H., Leewy Saputri, D. S., Nguyen, H. V., & Kawahito, Y. (2022). The inhibitory activity of sesquiterpenoids against acetylcholinesterase. *Molecules, 27*(20), 7032. https://pmc.ncbi.nlm.nih.gov/articles/PMC9610647/

Ohkawara, S., Tanaka-Kagawa, T., Furukawa, A., Nishimura, T., & Jinno, H. (2012). 1,8-Cineole (eucalyptol) activates human transient receptor potential ankyrin-1 (hTRPA1) antagonistically and modulates the channel sensitivity. *Molecular Pain, 8*, 86. https://pmc.ncbi.nlm.nih.gov/articles/PMC3567430/

Perry, N. S., Houghton, P. J., Theobald, A., Jenner, P., & Perry, E. K. (2000). In-vitro inhibition of human erythrocyte acetylcholinesterase by *Salvia lavandulaefolia* essential oil and constituent terpenes. *Journal of Pharmacy and Pharmacology, 52*(7), 895–902. https://pubmed.ncbi.nlm.nih.gov/10933142/

Russo, E. B. (2011). Taming THC: Potential cannabis synergy and phytocannabinoid-terpenoid entourage effects. *British Journal of Pharmacology, 163*(7), 1344–1364. https://pubmed.ncbi.nlm.nih.gov/21749363/

Savelev, S. U., Okello, E. J., & Perry, E. K. (2009). Butyryl- and acetyl-cholinesterase inhibitory activities in essential oils of *Salvia* species and their constituents. *Journal of Agricultural and Food Chemistry, 57*(5), 1843–1849. https://pubmed.ncbi.nlm.nih.gov/19358605/

Schwarz, M. D., Yousuf, M., Price, T. J., & Dussor, G. (2023). Terpenes from *Cannabis sativa* induce antinociception in mouse chronic neuropathic pain via activation of adenosine A2A receptors. *Pain*. https://pmc.ncbi.nlm.nih.gov/articles/PMC10081257/

Špičáková, A., Odehnalová, K., Peterka, O., Slaná, K., Palacký, R., Vacek, J., … & Stiborová, M. (2017). Nerolidol and farnesol inhibit some cytochrome P450 activities. *Molecules, 22*(3), 466. https://pmc.ncbi.nlm.nih.gov/articles/PMC6154719/

Takaishi, M., Fujita, F., Uchida, K., Yamamoto, S., Sawada, M., Hatai, C., … & Tominaga, M. (2013). Inhibitory effects of monoterpenes on human TRPA1 and the structural basis of their inhibition. *Journal of Physiology and Science, 64*(1), 47–57. https://pmc.ncbi.nlm.nih.gov/articles/PMC3889502/

Václavíková, R., Hughes, D. J., & Souček, P. (2019). β-Caryophyllene oxide and trans-nerolidol inhibit CYP3A4 enzyme activity. *Naunyn-Schmiedeberg's Archives of Pharmacology, 393*(4), 605–614. https://pubmed.ncbi.nlm.nih.gov/31755290/

Yang, H., Woo, J., Pae, A. N., Um, M. Y., Cho, N.-C., Park, K. D., … & Jang, C.-G. (2016). α-Pinene, a major constituent of pine tree oils, enhances non-rapid eye movement sleep in mice through GABA-A-benzodiazepine receptors. *Molecular Pharmacology, 90*(5), 530–539. https://pubmed.ncbi.nlm.nih.gov/27573669/
