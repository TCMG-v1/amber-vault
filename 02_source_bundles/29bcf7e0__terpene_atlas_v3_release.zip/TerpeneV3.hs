{-# LANGUAGE DeriveGeneric        #-}
{-# LANGUAGE DerivingStrategies   #-}
{-# LANGUAGE OverloadedStrings    #-}
{-# LANGUAGE StrictData           #-}
{-# LANGUAGE LambdaCase           #-}
{-# LANGUAGE DeriveAnyClass       #-}

-- ---------------------------------------------------------------------------
-- Module      : TerpeneV3
-- Description : v3 quantitative-affinity extensions to the Terpene Codex.
--               Promotes the v2 ordinal receptor-axis labels (−2…+2) to
--               typed binding-affinity records (Ki, Kd, IC50, EC50) with
--               primary-source citations and explicit negative evidence.
--
-- Authors     : Matthew Joseph Lansing & Perplexity Computer (2026)
-- Aesthetic   : noir-archive — every datum is a sealed citation, every
--               null an honest void, every constant a typed receipt.
--
-- Design rules:
--   * No fabricated affinities. If the literature is silent, the cell is
--     'NoDataFound' — never a guess.
--   * Negative findings ('NoEffectUpTo') are first-class. Finlay et al.
--     2020 is as load-bearing as Gertsch et al. 2008.
--   * Every 'Evidence' carries a 'Citation' with a resolvable URL.
--   * Concentrations are in micromolar (µM). nM are scaled at parse time.
--   * The matrix is sparse and proudly so.
-- ---------------------------------------------------------------------------

module TerpeneV3
  ( -- * Re-export the v1/v2 surface (in production builds)
    -- module TerpeneV2

    -- * Core identifiers
    TerpeneId (..)
  , ReceptorId (..)

    -- * Affinity records
  , BindingAffinity (..)
  , Metric (..)
  , AssayType (..)
  , EffectDirection (..)
  , Confidence (..)
  , Citation (..)
  , Evidence (..)

    -- * The atlas
  , Atlas (..)
  , Coverage (..)

    -- * Queries / lenses
  , recordsFor
  , bestEvidence
  , quantitativeOnly
  , negativesOnly
  , byReceptor

    -- * Pretty printing
  , showAffinity
  ) where

import           Data.Aeson         (FromJSON, ToJSON, defaultOptions,
                                     genericParseJSON, genericToJSON)
import qualified Data.Aeson         as A
import           Data.List          (sortOn)
import           Data.Maybe         (mapMaybe)
import           Data.Ord           (Down (..))
import           Data.Text          (Text)
import qualified Data.Text          as T
import           GHC.Generics       (Generic)

-- ---------------------------------------------------------------------------
-- Identifiers — closed enums mirror the underlying JSON exactly.
-- ---------------------------------------------------------------------------

-- | The 17 terpenes in the v2 codex plus the d/l-limonene split. Closed
-- universe; extending requires both a schema bump and new seed evidence.
data TerpeneId
  = AlphaPinene | BetaPinene | BetaMyrcene
  | DLimonene   | LLimonene
  | Linalool    | BetaCaryophyllene | AlphaHumulene
  | Terpinolene | BetaOcimene
  | Nerolidol   | Bisabolol  | Guaiol
  | AlphaTerpineol | Geraniol | Eucalyptol
  | Borneol     | Camphene
  deriving stock    (Eq, Ord, Show, Read, Enum, Bounded, Generic)
  deriving anyclass (ToJSON, FromJSON)

-- | The 18-receptor panel. Three families:
--
--   * Endocannabinoid / TRP / adenosine / xenobiotic — 'CB1' … 'CYP2D6'
--   * Classical neurotransmitter — 'GABA_A' … 'MOR'
--   * Nuclear / metabolic — 'PPAR_gamma', 'PPAR_alpha'
data ReceptorId
  = CB1 | CB2
  | TRPV1 | TRPV3 | TRPA1 | TRPM8
  | A1 | A2A
  | CYP3A4 | CYP2D6
  | GABA_A
  | R5HT1A | R5HT2A     -- ^ Numeric-leading identifiers are forbidden
  | NMDA | AChE
  | PPAR_gamma | PPAR_alpha
  | MOR
  deriving stock    (Eq, Ord, Show, Read, Enum, Bounded, Generic)
  deriving anyclass (ToJSON, FromJSON)

-- ---------------------------------------------------------------------------
-- Affinity types — typed binding values, not strings.
-- ---------------------------------------------------------------------------

-- | Pharmacological metric. 'NoEffectUpTo' is intentionally a constructor,
-- not a magic value: negative findings deserve a type.
data Metric
  = Ki                  -- ^ Inhibition constant from radioligand displacement
  | Kd                  -- ^ Dissociation constant
  | IC50                -- ^ Half-maximal inhibitory concentration
  | EC50                -- ^ Half-maximal effective concentration
  | PercentPotentiation -- ^ % current/response enhancement at a given dose
  | PercentEfficacy     -- ^ % of reference agonist Emax
  | NoEffectUpTo        -- ^ Tested negative up to this concentration (µM)
  | Qualitative         -- ^ Behavioral / phenotypic only; no constant
  | NoDataFound         -- ^ The literature is silent. Honest void.
  deriving stock    (Eq, Ord, Show, Read, Generic)
  deriving anyclass (ToJSON, FromJSON)

-- | Assay modality. Determines how a numeric 'value' should be interpreted.
data AssayType
  = RadioligandBinding
  | FunctionalCAMP
  | CalciumFlux
  | PatchClamp
  | GTPgammaS
  | EnzymeInhibition
  | BehavioralInVivo
  | OtherAssay
  deriving stock    (Eq, Ord, Show, Read, Generic)
  deriving anyclass (ToJSON, FromJSON)

-- | Pharmacological direction of effect.
data EffectDirection
  = Agonist
  | PartialAgonist
  | Antagonist
  | PositiveAllosteric
  | NegativeAllosteric
  | Inhibitor
  | NoEffect
  | ModulatorUnclear
  deriving stock    (Eq, Ord, Show, Read, Generic)
  deriving anyclass (ToJSON, FromJSON)

-- | Editorial confidence in the assignment given assay quality and replication.
data Confidence = High | Medium | Low
  deriving stock    (Eq, Ord, Show, Read, Generic)
  deriving anyclass (ToJSON, FromJSON)

-- ---------------------------------------------------------------------------
-- Citation + Evidence
-- ---------------------------------------------------------------------------

-- | Every claim is sealed by a resolvable citation. URL must dereference.
data Citation = Citation
  { citAuthors    :: Text         -- ^ "Gertsch et al."
  , citYear       :: Int          -- ^ 2008
  , citDoiOrPmid  :: Maybe Text   -- ^ DOI preferred; PMID fallback
  , citUrl        :: Text         -- ^ Full URL — verified at build time
  , citQuote      :: Maybe Text   -- ^ Verbatim phrase ≤25 words
  }
  deriving stock    (Eq, Show, Generic)
  deriving anyclass (ToJSON, FromJSON)

-- | One row of the atlas: the unit of citation-bounded knowledge.
data Evidence = Evidence
  { evTerpene     :: TerpeneId
  , evReceptor    :: ReceptorId
  , evAssay       :: Maybe AssayType
  , evMetric      :: Metric
  , evValueUM     :: Maybe Double          -- ^ Always µM. Nothing for qualitative/null.
  , evDirection   :: Maybe EffectDirection
  , evSystem      :: Maybe Text            -- ^ "CHO-K1-hCB2", "rat DRG neurons"
  , evConfidence  :: Maybe Confidence
  , evCitation    :: Maybe Citation        -- ^ Nothing iff Metric == NoDataFound
  }
  deriving stock    (Eq, Show, Generic)
  deriving anyclass (ToJSON, FromJSON)

-- | Synonym for clarity at call sites.
type BindingAffinity = Evidence

-- ---------------------------------------------------------------------------
-- Coverage + Atlas
-- ---------------------------------------------------------------------------

data Coverage = Coverage
  { covTotalCells     :: Int
  , covCellsWithData  :: Int
  , covCellsNoData    :: Int
  , covCoveragePct    :: Double
  , covQuantRecords   :: Int    -- ^ Ki/Kd/IC50/EC50 records
  , covNegativeRecords:: Int    -- ^ NoEffectUpTo records
  , covQualRecords    :: Int    -- ^ behavioral/qualitative
  , covTotalRecords   :: Int
  }
  deriving stock    (Eq, Show, Generic)
  deriving anyclass (ToJSON, FromJSON)

-- | The top-level container. Deserializes from atlas.json.
data Atlas = Atlas
  { atlasSchemaVersion :: Text
  , atlasTitle         :: Text
  , atlasGeneratedUtc  :: Text
  , atlasTerpenes      :: [TerpeneId]
  , atlasReceptors     :: [ReceptorId]
  , atlasCoverage      :: Coverage
  , atlasRecords       :: [Evidence]
  }
  deriving stock    (Eq, Show, Generic)
  deriving anyclass (ToJSON, FromJSON)

-- ---------------------------------------------------------------------------
-- Queries — small, lawful, composable.
-- ---------------------------------------------------------------------------

-- | All evidence for a (terpene, receptor) cell.
recordsFor :: TerpeneId -> ReceptorId -> Atlas -> [Evidence]
recordsFor t r = filter (\e -> evTerpene e == t && evReceptor e == r) . atlasRecords

-- | Highest-strength evidence per cell. Strength order:
--   Ki/Kd/IC50/EC50  >  PercentPotentiation/Efficacy  >  NoEffectUpTo  >  Qualitative  >  NoDataFound
bestEvidence :: TerpeneId -> ReceptorId -> Atlas -> Maybe Evidence
bestEvidence t r atl = case sortOn (Down . strength) (recordsFor t r atl) of
  []    -> Nothing
  (e:_) -> Just e
  where
    strength :: Evidence -> Int
    strength e = case evMetric e of
      Ki                  -> 4
      Kd                  -> 4
      IC50                -> 4
      EC50                -> 4
      PercentPotentiation -> 3
      PercentEfficacy     -> 3
      NoEffectUpTo        -> 2
      Qualitative         -> 1
      NoDataFound         -> 0

-- | The 22 hard binding constants — the gold rows.
quantitativeOnly :: Atlas -> [Evidence]
quantitativeOnly = filter ((`elem` [Ki,Kd,IC50,EC50]) . evMetric) . atlasRecords

-- | The 27 explicit negatives — Finlay's gift to the field.
negativesOnly :: Atlas -> [Evidence]
negativesOnly = filter ((== NoEffectUpTo) . evMetric) . atlasRecords

-- | All evidence for a given receptor across all terpenes.
byReceptor :: ReceptorId -> Atlas -> [Evidence]
byReceptor r = filter ((== r) . evReceptor) . atlasRecords

-- ---------------------------------------------------------------------------
-- Pretty printer — for terminal noir.
-- ---------------------------------------------------------------------------

showAffinity :: Evidence -> Text
showAffinity e = T.intercalate " │ "
  [ T.pack (show (evTerpene e))
  , T.pack (show (evReceptor e))
  , T.pack (show (evMetric e))
  , maybe "—" (\v -> T.pack (show v) <> " µM") (evValueUM e)
  , maybe "—" (T.pack . show) (evDirection e)
  , maybe "[no cite]" (\c -> citAuthors c <> " " <> T.pack (show (citYear c))) (evCitation e)
  ]

-- ---------------------------------------------------------------------------
-- Worked-example values (the four canonical anchors of the atlas).
-- These compile against the seed JSON; they are documentation, not stubs.
-- ---------------------------------------------------------------------------

-- $anchors
--
-- Four sealed exemplars the field returns to:
--
-- @
-- gertsch2008 :: Evidence
-- gertsch2008 = Evidence BetaCaryophyllene CB2 (Just RadioligandBinding)
--   Ki (Just 0.155) (Just Agonist) (Just "CHO-K1-hCB2") (Just High)
--   (Just (Citation "Gertsch et al." 2008 (Just "10.1073/pnas.0803601105")
--                   "https://pmc.ncbi.nlm.nih.gov/articles/PMC2449371/"
--                   (Just "K(i) = 155 ± 4 nM ... functional CB(2) agonist")))
--
-- finlay2020Myrcene :: Evidence  -- The most-cited negative
-- finlay2020Myrcene = Evidence BetaMyrcene CB1 (Just RadioligandBinding)
--   NoEffectUpTo (Just 10.0) (Just NoEffect) (Just "HEK293-hCB1") (Just High)
--   (Just (Citation "Finlay et al." 2020 (Just "10.3389/fphar.2020.00359")
--                   "https://www.frontiersin.org/articles/10.3389/fphar.2020.00359/"
--                   (Just "did not display detectable activity ... up to 10 µM")))
--
-- granger2005 :: Evidence  -- Borneol's >1000% GABA-A potentiation
-- granger2005 = Evidence Borneol GABA_A (Just PatchClamp)
--   EC50 (Just 248) (Just PositiveAllosteric)
--   (Just "rat cerebellar granule cells") (Just High)
--   (Just (Citation "Granger et al." 2005 (Just "10.1016/j.bcp.2005.01.002")
--                   "https://doi.org/10.1016/j.bcp.2005.01.002"
--                   (Just "flumazenil-insensitive ... >1000% potentiation")))
--
-- fuerst2017 :: Evidence  -- Eucalyptol's human-vs-mouse TRPM8 inversion
-- fuerst2017 = Evidence Eucalyptol TRPM8 (Just CalciumFlux)
--   EC50 (Just 120.4) (Just Agonist) (Just "HEK293-hTRPM8") (Just High)
--   (Just (Citation "Fürst et al." 2017 Nothing
--                   "https://pubmed.ncbi.nlm.nih.gov/..."
--                   (Just "60-fold more potent at human than mouse TRPM8")))
-- @
