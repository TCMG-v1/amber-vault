import { lexemeData } from "@/data/lexemes";
import { useBlend } from "@/lib/blend-context";
import { TERPENE_BY_ID } from "@/lib/score";
import { SectionLabel } from "@/components/archive-bits";
import { Plus, Check } from "lucide-react";

interface Card {
  id: string;
  headword: string;
  ipa: string;
  morphemes: string[];
  etymon: string;
  first_attested: string;
  semantic_drift: string;
  cognates: string[];
  haskell: string;
  seal: string;
}

export default function Codex() {
  const { addTerpene, has } = useBlend();
  const cards = lexemeData.cards as unknown as Card[];

  return (
    <div className="p-4 md:p-6">
      <header className="mb-5">
        <h1 className="font-serif text-2xl font-semibold text-foreground tracking-tight">
          The Codex · Lexeme Cards
        </h1>
        <p className="text-xs text-muted-foreground font-serif italic mt-0.5">
          {lexemeData.philological_seal} · compiled {lexemeData.compiled}. Click a card to cross-reference into the Mixing Board.
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 2xl:grid-cols-3 gap-4">
        {cards.map((c) => {
          const inBlend = has(c.id);
          const terp = TERPENE_BY_ID[c.id];
          return (
            <article
              key={c.id}
              className="border border-border bg-card flex flex-col"
              data-testid={`lexeme-${c.id}`}
            >
              {/* head */}
              <div className="flex items-start justify-between px-3 py-2 border-b border-border archive-grain">
                <div className="min-w-0">
                  <h2 className="font-serif text-xl text-foreground leading-tight">{c.headword}</h2>
                  <p className="font-mono text-[13px] text-primary mt-0.5">{c.ipa}</p>
                </div>
                <button
                  onClick={() => addTerpene(c.id)}
                  className={`shrink-0 border px-1.5 py-1 ${inBlend ? "border-primary/50 text-primary" : "border-border text-muted-foreground hover:text-foreground"}`}
                  aria-label={`Add ${c.headword} to blend`}
                  data-testid={`button-codex-add-${c.id}`}
                >
                  {inBlend ? <Check className="h-3.5 w-3.5" /> : <Plus className="h-3.5 w-3.5" />}
                </button>
              </div>

              <div className="px-3 py-2.5 space-y-2.5 flex-1">
                {/* morphemes breadcrumb */}
                <div className="flex items-center gap-1 flex-wrap">
                  {c.morphemes.map((m, i) => (
                    <span key={i} className="flex items-center gap-1">
                      <span className="font-mono text-[11px] text-foreground/80">{m}</span>
                      {i < c.morphemes.length - 1 && <span className="text-muted-foreground text-[10px]">›</span>}
                    </span>
                  ))}
                </div>

                {/* etymon — emphasis via color/weight, not italics */}
                <div>
                  <p className="nav-label mb-0.5">ETYMON</p>
                  <p className="font-serif text-[12.5px] text-foreground/80 leading-snug">{c.etymon}</p>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <p className="nav-label mb-0.5">FIRST ATTESTED</p>
                    <p className="font-mono text-[11px] text-foreground/75">{c.first_attested}</p>
                  </div>
                  {terp && (
                    <div>
                      <p className="nav-label mb-0.5">CLASS</p>
                      <p className="font-mono text-[11px] text-foreground/75">{terp.identity.class}</p>
                    </div>
                  )}
                </div>

                <div>
                  <p className="nav-label mb-0.5">SEMANTIC DRIFT</p>
                  <p className="font-serif text-[12px] text-muted-foreground leading-snug">{c.semantic_drift}</p>
                </div>

                {/* cognates as mono pills */}
                <div>
                  <p className="nav-label mb-1">COGNATES</p>
                  <div className="flex flex-wrap gap-1">
                    {c.cognates.map((g, i) => (
                      <span key={i} className="font-mono text-[10px] border border-border px-1.5 py-0.5 text-foreground/80 bg-secondary/30">
                        {g}
                      </span>
                    ))}
                  </div>
                </div>

                {/* haskell snippet */}
                <pre className="bg-background border border-border p-2 overflow-x-auto font-mono text-[10px] leading-relaxed text-foreground/85">
{c.haskell}
                </pre>
              </div>

              {/* sealed line */}
              <div className="px-3 py-1.5 border-t border-border bg-secondary/20 flex items-center gap-2">
                <span className="seal-red text-[10px]">●</span>
                <p className="font-mono text-[10px] text-muted-foreground truncate">{c.seal}</p>
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
