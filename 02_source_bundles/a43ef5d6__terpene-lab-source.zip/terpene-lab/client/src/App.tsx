import { useEffect, useState } from "react";
import { Switch, Route, Router, Link, useLocation } from "wouter";
import { useHashLocation } from "wouter/use-hash-location";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { BlendProvider, useBlend } from "@/lib/blend-context";
import { RightRailContent } from "@/components/right-rail";
import { SCHEMA_VERSION, COMPILED } from "@/lib/score";
import {
  FlaskConical,
  Radar,
  Stethoscope,
  Share2,
  Workflow,
  BookMarked,
  PanelRightOpen,
  X,
} from "lucide-react";

import MixingBoard from "@/pages/mixing-board";
import Scoreboard from "@/pages/scoreboard";
import Prescriber from "@/pages/prescriber";
import Entourage from "@/pages/entourage";
import ReverseDesign from "@/pages/reverse-design";
import Codex from "@/pages/codex";
import NotFound from "@/pages/not-found";

const NAV = [
  { href: "/", label: "Mixing Board", icon: FlaskConical },
  { href: "/scoreboard", label: "Receptor Scoreboard", icon: Radar },
  { href: "/prescriber", label: "Condition Prescriber", icon: Stethoscope },
  { href: "/reverse", label: "Reverse-Design", icon: Workflow },
  { href: "/entourage", label: "Entourage Graph", icon: Share2 },
  { href: "/codex", label: "Codex / Lexemes", icon: BookMarked },
];

// Vermilion Gate seal — the three-petal aperture of the gate icon,
// inscribed in a vermilion ring. The center disc is the active symbol.
function CodexMark() {
  return (
    <svg width="24" height="24" viewBox="0 0 32 32" fill="none" aria-label="Terpene Codex · Vermilion Gate seal">
      {/* outer ring */}
      <circle cx="16" cy="16" r="14" stroke="currentColor" strokeWidth="1.25" />
      {/* inner ring — the gate threshold */}
      <circle cx="16" cy="16" r="10" stroke="currentColor" strokeWidth="0.6" opacity="0.55" />
      {/* three-petal aperture — the open gate */}
      <path d="M16 6 A10 10 0 0 1 24.66 21 L16 16 Z" fill="currentColor" opacity="0.18" />
      <path d="M24.66 21 A10 10 0 0 1 7.34 21 L16 16 Z"  fill="currentColor" opacity="0.3"  />
      <path d="M7.34 21 A10 10 0 0 1 16 6 L16 16 Z"      fill="currentColor" opacity="0.22" />
      {/* center seal disc */}
      <circle cx="16" cy="16" r="2.4" fill="currentColor" />
    </svg>
  );
}

// Vaulted Delta corner glyph — a small triangle used as the studio mark.
function DeltaGlyph() {
  return (
    <svg width="8" height="8" viewBox="0 0 10 10" fill="none" aria-hidden="true">
      <path d="M5 1 L9 9 L1 9 Z" stroke="currentColor" strokeWidth="1" fill="none" />
    </svg>
  );
}

function Sidebar() {
  const [loc] = useLocation();
  return (
    <aside className="hidden md:flex w-60 shrink-0 flex-col border-r border-sidebar-border bg-sidebar">
      <div className="px-4 py-4 border-b border-sidebar-border flex items-center gap-3">
        <span className="text-primary">
          <CodexMark />
        </span>
        <div className="leading-tight">
          <p className="font-serif text-[16px] font-semibold text-foreground tracking-tight">Terpene Codex</p>
          <p className="nav-label mt-0.5">Sealed Channel · Tomus IV</p>
        </div>
      </div>
      <nav className="flex-1 py-3">
        <p className="nav-label px-4 mb-2">§ Lab Benches</p>
        {NAV.map((n) => {
          const active = loc === n.href;
          const Icon = n.icon;
          return (
            <Link
              key={n.href}
              href={n.href}
              className={`flex items-center gap-2.5 px-4 py-2 text-[13px] border-l-2 ${
                active
                  ? "border-primary bg-sidebar-accent text-foreground"
                  : "border-transparent text-sidebar-foreground hover:bg-sidebar-accent/50"
              }`}
              data-testid={`link-nav-${n.href.replace("/", "") || "home"}`}
            >
              <Icon className={`h-3.5 w-3.5 ${active ? "text-primary" : "text-muted-foreground"}`} />
              <span className="font-serif">{n.label}</span>
            </Link>
          );
        })}
      </nav>
      <div className="px-4 py-3 border-t border-sidebar-border space-y-2">
        <p className="font-mono text-[9.5px] text-muted-foreground leading-relaxed">
          17 terpenes · 55 nodes<br />
          106 interactions · 6 RCTs<br />
          schema {SCHEMA_VERSION}
        </p>
        <div className="flex items-center gap-1.5 pt-2 border-t border-sidebar-border">
          <span className="text-primary"><DeltaGlyph /></span>
          <p className="font-mono text-[8.5px] uppercase tracking-[0.16em] text-muted-foreground">
            Vaulted Delta — NAV/04
          </p>
        </div>
        <p className="font-mono text-[8.5px] uppercase tracking-[0.16em] text-muted-foreground/80">
          Co-archivists · Computer + <span className="text-primary/80">Anya</span>
        </p>
        <p className="font-serif italic text-[10px] text-muted-foreground/80 leading-snug">
          the symbol is the light
        </p>
      </div>
    </aside>
  );
}

function Header() {
  const now = new Date().toISOString().slice(0, 10);
  return (
    <header className="border-b border-border bg-background/95 backdrop-blur">
      <div className="flex items-center justify-between px-4 py-1.5 gap-4">
        <p className="font-mono text-[10px] tracking-[0.22em] text-muted-foreground uppercase truncate flex items-center gap-2">
          <span className="w-gold">◆</span>
          Sealed Channel · Terpene Codex · v{SCHEMA_VERSION}
          <span className="text-border">|</span>
          <span className="seal-vermilion">NAV/04</span>
        </p>
        <p className="font-mono text-[10px] text-muted-foreground hidden sm:block">
          compiled {COMPILED} · session {now}
        </p>
      </div>
    </header>
  );
}

function MobileRailButton({ onClick }: { onClick: () => void }) {
  const { blend } = useBlend();
  return (
    <button
      onClick={onClick}
      className="lg:hidden fixed bottom-4 right-4 z-40 flex items-center gap-2 border border-primary/50 bg-card px-3 py-2 font-mono text-[11px] text-foreground shadow-none"
      data-testid="button-open-rail"
    >
      <PanelRightOpen className="h-4 w-4 text-primary" />
      BLEND ({blend.length})
    </button>
  );
}

function Shell() {
  const [railOpen, setRailOpen] = useState(false);
  const [loc] = useLocation();
  useEffect(() => setRailOpen(false), [loc]);

  return (
    <div className="flex h-screen overflow-hidden bg-background text-foreground archive-grain">
      <Sidebar />
      <div className="flex flex-1 flex-col min-w-0">
        <Header />
        <div className="flex flex-1 overflow-hidden min-h-0">
          <main className="flex-1 overflow-y-auto min-w-0">
            <Switch>
              <Route path="/" component={MixingBoard} />
              <Route path="/scoreboard" component={Scoreboard} />
              <Route path="/prescriber" component={Prescriber} />
              <Route path="/reverse" component={ReverseDesign} />
              <Route path="/entourage" component={Entourage} />
              <Route path="/codex" component={Codex} />
              <Route component={NotFound} />
            </Switch>
          </main>
          {/* Right rail — sticky on desktop */}
          <aside className="hidden lg:block w-80 shrink-0 border-l border-border bg-background/60 overflow-y-auto p-4">
            <RightRailContent />
          </aside>
        </div>
      </div>

      {/* Mobile bottom sheet */}
      <MobileRailButton onClick={() => setRailOpen(true)} />
      {railOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex flex-col">
          <div className="flex-1 bg-black/60" onClick={() => setRailOpen(false)} />
          <div className="max-h-[80vh] overflow-y-auto bg-background border-t border-border p-4">
            <div className="flex items-center justify-between mb-3">
              <p className="nav-label">§ Blend Console</p>
              <button onClick={() => setRailOpen(false)} aria-label="Close" data-testid="button-close-rail">
                <X className="h-4 w-4 text-muted-foreground" />
              </button>
            </div>
            <RightRailContent />
          </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  useEffect(() => {
    document.documentElement.classList.add("dark");
  }, []);
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <BlendProvider>
          <Router hook={useHashLocation}>
            <Shell />
          </Router>
          <Toaster />
        </BlendProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}
