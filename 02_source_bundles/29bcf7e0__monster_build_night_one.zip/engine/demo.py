#!/usr/bin/env python3
# ─────────────────────────────────────────────────────────────────────────────
# demo.py  —  Vaulted Engine Micro-Loop Smoke Test
# Sim-CCG Hybrid Engine — Python mirror of the Haskell core
#
# Authors : Matthew Joseph Lansing (Vaulted Delta / BNS Labs)
#           Perplexity Computer
# IP      : BNS 100% — Vaulted Delta CCG Standard umbrella
#
# "Proof that the loop runs.  Not a game.  Not yet."
# ─────────────────────────────────────────────────────────────────────────────

from __future__ import annotations

import hashlib
import json
import os
import random
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from enum import Enum, auto
from typing import Dict, List, Optional, Tuple, Any


# ─── Enumerations ─────────────────────────────────────────────────────────────

class CardKind(str, Enum):
    UNIT     = "Unit"
    POLICY   = "Policy"
    EVENT    = "Event"
    TERRAIN  = "Terrain"
    TECH     = "Tech"


class TerrainType(str, Enum):
    PLAINS     = "Plains"
    FOREST     = "Forest"
    MOUNTAIN   = "Mountain"
    WATER      = "Water"
    RUIN       = "Ruin"
    SETTLEMENT = "Settlement"


class DurationType(str, Enum):
    INSTANT   = "Instant"
    TURNS     = "Turns"
    PERMANENT = "Permanent"


class StatusKind(str, Enum):
    STUNNED  = "Stunned"
    SHIELDED = "Shielded"
    ROOTED   = "Rooted"


# ─── Value types ──────────────────────────────────────────────────────────────

@dataclass
class Resource:
    gold:      int = 0
    influence: int = 0
    energy:    int = 0
    materiel:  int = 0

    def __add__(self, other: "Resource") -> "Resource":
        return Resource(
            gold      = self.gold      + other.gold,
            influence = self.influence + other.influence,
            energy    = self.energy    + other.energy,
            materiel  = self.materiel  + other.materiel,
        )

    def __sub__(self, other: "Resource") -> "Resource":
        return Resource(
            gold      = self.gold      - other.gold,
            influence = self.influence - other.influence,
            energy    = self.energy    - other.energy,
            materiel  = self.materiel  - other.materiel,
        )

    def can_afford(self, cost: "Resource") -> bool:
        return (self.gold      >= cost.gold and
                self.influence >= cost.influence and
                self.energy    >= cost.energy and
                self.materiel  >= cost.materiel)


@dataclass
class Hex:
    q: int
    r: int

    def __hash__(self):
        return hash((self.q, self.r))

    def __eq__(self, other):
        return isinstance(other, Hex) and self.q == other.q and self.r == other.r

    def neighbors(self) -> List["Hex"]:
        return [
            Hex(self.q+1, self.r),
            Hex(self.q-1, self.r),
            Hex(self.q,   self.r+1),
            Hex(self.q,   self.r-1),
            Hex(self.q+1, self.r-1),
            Hex(self.q-1, self.r+1),
        ]

    def adjacent_to(self, other: "Hex") -> bool:
        return other in self.neighbors()


@dataclass
class Duration:
    kind:  DurationType
    turns: int = 0   # only meaningful when kind == TURNS


@dataclass
class Mutation:
    kind:     str         # matches Haskell ADT constructor names
    payload:  Dict[str, Any] = field(default_factory=dict)


@dataclass
class Effect:
    on_play:  List[Mutation] = field(default_factory=list)
    on_tick:  List[Mutation] = field(default_factory=list)
    duration: Duration = field(default_factory=lambda: Duration(DurationType.INSTANT))


@dataclass
class Card:
    card_id: str
    name:    str
    kind:    CardKind
    cost:    Resource
    effect:  Effect


@dataclass
class UnitStatus:
    kind:  StatusKind
    value: int = 0   # shield points or turns remaining


@dataclass
class Unit:
    uid:      str
    owner:    str   # player id
    hp:       int
    atk:      int
    position: Hex
    status:   List[UnitStatus] = field(default_factory=list)


@dataclass
class Tile:
    hex:      Hex
    terrain:  TerrainType
    occupant: Optional[str] = None   # UnitId or None


@dataclass
class QueuedEvent:
    event_id:    str
    fire_on_turn: int
    mutations:   List[Mutation] = field(default_factory=list)


@dataclass
class Player:
    pid:       str
    hand:      List[Card]     = field(default_factory=list)
    deck:      List[Card]     = field(default_factory=list)
    discard:   List[Card]     = field(default_factory=list)
    resources: Resource       = field(default_factory=Resource)
    units:     Dict[str, Unit] = field(default_factory=dict)
    traits:    List[str]      = field(default_factory=list)


@dataclass
class WorldState:
    turn:        int
    players:     Dict[str, Player]
    board:       Dict[str, Tile]       # key = "q,r"
    event_queue: List[QueuedEvent]     = field(default_factory=list)
    rng_seed:    int                   = 42


# ─── Inline splitmix-style RNG ────────────────────────────────────────────────

def rng_step(s: int) -> Tuple[int, int]:
    """SplitMix64 step.  Returns (output, new_state)."""
    MASK64 = 0xFFFFFFFFFFFFFFFF
    s = (s + 0x9e3779b97f4a7c15) & MASK64
    z = s
    z = ((z ^ (z >> 30)) * 0xbf58476d1ce4e5b9) & MASK64
    z = ((z ^ (z >> 27)) * 0x94d049bb133111eb) & MASK64
    z = (z ^ (z >> 31)) & MASK64
    return z, s


def rng_shuffle(lst: list, seed: int) -> Tuple[list, int]:
    """Fisher-Yates using splitmix64."""
    arr = list(lst)
    n = len(arr)
    for i in range(n - 1, 0, -1):
        w, seed = rng_step(seed)
        j = w % (i + 1)
        arr[i], arr[j] = arr[j], arr[i]
    return arr, seed


# ─── drawN ────────────────────────────────────────────────────────────────────

HAND_CAP = 5

def draw_n(n: int, player: Player, rng_seed: int) -> Tuple[Player, List[Card], int]:
    """Draw up to n cards; reshuffle discard into deck if needed.
    Returns (updated_player, drawn_cards, new_seed)."""
    drawn = []
    seed  = rng_seed
    for _ in range(n):
        if not player.deck and not player.discard:
            break
        if not player.deck:
            player.deck, seed = rng_shuffle(player.discard, seed)
            player.discard = []
        card = player.deck.pop(0)
        player.hand.append(card)
        drawn.append(card)
    return player, drawn, seed


# ─── playCard ─────────────────────────────────────────────────────────────────

def play_card(card_id: str, player: Player, ws: WorldState) -> Tuple[bool, str, WorldState]:
    """Attempt to play a card.  Returns (ok, error_msg, updated_ws)."""
    card = next((c for c in player.hand if c.card_id == card_id), None)
    if card is None:
        return False, "NotInHand", ws

    if not player.resources.can_afford(card.cost):
        return False, "InsufficientResource", ws

    # Deduct cost, move to discard
    player.resources = player.resources - card.cost
    player.hand = [c for c in player.hand if c.card_id != card_id]
    player.discard.append(card)
    ws.players[player.pid] = player

    # Apply on_play mutations
    for mut in card.effect.on_play:
        ws = apply_mutation(ws, mut, player.pid)

    return True, "", ws


# ─── Mutation application ─────────────────────────────────────────────────────

def apply_mutation(ws: WorldState, mut: Mutation, acting_pid: str) -> WorldState:
    k = mut.kind

    if k == "GainResource":
        res = Resource(**mut.payload)
        p   = ws.players[acting_pid]
        p.resources = p.resources + res

    elif k == "DamageUnit":
        uid  = mut.payload["uid"]
        dmg  = mut.payload["dmg"]
        for p in ws.players.values():
            if uid in p.units:
                p.units[uid].hp -= dmg

    elif k == "DrawCards":
        n   = mut.payload["n"]
        p   = ws.players[acting_pid]
        p, _, ws.rng_seed = draw_n(n, p, ws.rng_seed)
        ws.players[acting_pid] = p

    elif k == "ChangeTerrain":
        hex_key  = mut.payload["hex"]
        new_type = TerrainType(mut.payload["terrain"])
        if hex_key in ws.board:
            ws.board[hex_key].terrain = new_type

    elif k == "TriggerEvent":
        eid = mut.payload["event_id"]
        ws.event_queue.append(QueuedEvent(eid, ws.turn + 1, []))

    return ws


# ─── economyTick ─────────────────────────────────────────────────────────────

def economy_tick(player: Player, board: Dict[str, Tile]) -> Player:
    """Apply passive resource generation."""
    gain = Resource()

    # Settlements owned by this player
    for tile in board.values():
        if tile.terrain == TerrainType.SETTLEMENT and tile.occupant in player.units:
            gain = gain + Resource(gold=2, influence=1)

    # Forest hexes adjacent to any of this player's units
    unit_hexes = {u.position for u in player.units.values()}
    adjacent_forest_seen = set()
    for uh in unit_hexes:
        for nb in uh.neighbors():
            key = f"{nb.q},{nb.r}"
            if key not in adjacent_forest_seen and key in board:
                if board[key].terrain == TerrainType.FOREST:
                    gain = gain + Resource(materiel=1)
                    adjacent_forest_seen.add(key)

    # Ruins occupied by this player
    for tile in board.values():
        if tile.terrain == TerrainType.RUIN and tile.occupant in player.units:
            gain = gain + Resource(energy=1)

    player.resources = player.resources + gain
    return player


# ─── Combat resolver ─────────────────────────────────────────────────────────

def terrain_defense_bonus(terrain: TerrainType) -> int:
    return {TerrainType.FOREST: 1, TerrainType.MOUNTAIN: 2}.get(terrain, 0)

def terrain_attack_penalty(terrain: TerrainType) -> int:
    return 1 if terrain == TerrainType.WATER else 0


def resolve_combat(att_hex: Hex, def_hex: Hex, ws: WorldState) -> WorldState:
    if not att_hex.adjacent_to(def_hex):
        return ws

    att_key = f"{att_hex.q},{att_hex.r}"
    def_key = f"{def_hex.q},{def_hex.r}"
    att_tile = ws.board.get(att_key)
    def_tile = ws.board.get(def_key)
    if not att_tile or not def_tile:
        return ws
    if not att_tile.occupant or not def_tile.occupant:
        return ws

    # Locate units
    att_unit = def_unit = None
    att_owner = def_owner = None
    for p in ws.players.values():
        if att_tile.occupant in p.units:
            att_unit  = p.units[att_tile.occupant]
            att_owner = p.pid
        if def_tile.occupant in p.units:
            def_unit  = p.units[def_tile.occupant]
            def_owner = p.pid

    if not att_unit or not def_unit:
        return ws

    att_terrain = att_tile.terrain
    def_terrain = def_tile.terrain

    att_dmg = max(0, att_unit.atk
                  - terrain_attack_penalty(att_terrain)
                  - terrain_defense_bonus(def_terrain))
    def_dmg = max(0, def_unit.atk
                  - terrain_attack_penalty(def_terrain)
                  - terrain_defense_bonus(att_terrain))

    att_unit.hp -= def_dmg
    def_unit.hp -= att_dmg

    att_dead = att_unit.hp <= 0
    def_dead = def_unit.hp <= 0

    if att_dead:
        if att_owner:
            del ws.players[att_owner].units[att_tile.occupant]
        att_tile.occupant = None

    if def_dead:
        if def_owner:
            del ws.players[def_owner].units[def_tile.occupant]
        def_tile.occupant = None
        # Advance attacker if it survived
        if not att_dead and att_owner:
            att_uid = att_unit.uid
            att_unit.position = def_hex
            def_tile.occupant = att_uid
            att_tile.occupant = None

    return ws


# ─── Tick ─────────────────────────────────────────────────────────────────────

BASE_INCOME = Resource(gold=1)


def tick(ws: WorldState) -> WorldState:
    """Advance world by one turn."""
    # 1. Resolve queued events
    fire = [qe for qe in ws.event_queue if qe.fire_on_turn <= ws.turn]
    keep = [qe for qe in ws.event_queue if qe.fire_on_turn > ws.turn]
    ws.event_queue = keep
    for qe in fire:
        for mut in qe.mutations:
            for pid in ws.players:
                ws = apply_mutation(ws, mut, pid)

    # 2. Draw phase
    for pid, player in ws.players.items():
        needed = max(0, HAND_CAP - len(player.hand))
        player, _, ws.rng_seed = draw_n(needed, player, ws.rng_seed)
        ws.players[pid] = player

    # 3. Base income
    for player in ws.players.values():
        player.resources = player.resources + BASE_INCOME

    # 4. Economy tick (passive generation)
    for pid, player in ws.players.items():
        ws.players[pid] = economy_tick(player, ws.board)

    # 5. onTick mutations from active discard effects
    for pid, player in ws.players.items():
        for card in player.discard:
            eff = card.effect
            if eff.duration.kind in (DurationType.TURNS, DurationType.PERMANENT):
                if eff.duration.kind == DurationType.TURNS and eff.duration.turns <= 0:
                    continue
                for mut in eff.on_tick:
                    ws = apply_mutation(ws, mut, pid)
        # Decrement Turns durations
        for card in player.discard:
            if card.effect.duration.kind == DurationType.TURNS:
                card.effect.duration.turns = max(0, card.effect.duration.turns - 1)

    # 6. Increment turn counter
    ws.turn += 1
    return ws


# ─── World factory ───────────────────────────────────────────────────────────

def make_starter_deck(player_id: str) -> List[Card]:
    """Build a small starter deck for smoke testing."""
    cards = []
    for i in range(8):
        cards.append(Card(
            card_id = f"{player_id}_gold_{i}",
            name    = "Gold Mine",
            kind    = CardKind.POLICY,
            cost    = Resource(gold=0),
            effect  = Effect(
                on_play  = [Mutation("GainResource", {"gold": 3})],
                on_tick  = [],
                duration = Duration(DurationType.INSTANT),
            )
        ))
    for i in range(4):
        cards.append(Card(
            card_id = f"{player_id}_unit_{i}",
            name    = "Scout",
            kind    = CardKind.UNIT,
            cost    = Resource(gold=2),
            effect  = Effect(
                on_play  = [Mutation("GainResource", {"gold": 0, "influence": 1, "energy": 0, "materiel": 0})],
                on_tick  = [Mutation("GainResource", {"gold": 0, "influence": 0, "energy": 0, "materiel": 1})],
                duration = Duration(DurationType.TURNS, 3),
            )
        ))
    for i in range(4):
        cards.append(Card(
            card_id = f"{player_id}_draw_{i}",
            name    = "Intel Sweep",
            kind    = CardKind.EVENT,
            cost    = Resource(influence=1),
            effect  = Effect(
                on_play  = [Mutation("DrawCards", {"n": 2})],
                on_tick  = [],
                duration = Duration(DurationType.INSTANT),
            )
        ))
    return cards


def make_board() -> Dict[str, Tile]:
    """Build a small 5x5-ish test board."""
    board: Dict[str, Tile] = {}
    terrain_map = {
        (0, 0): TerrainType.SETTLEMENT,
        (1, 0): TerrainType.PLAINS,
        (2, 0): TerrainType.FOREST,
        (3, 0): TerrainType.MOUNTAIN,
        (4, 0): TerrainType.WATER,
        (0, 1): TerrainType.RUIN,
        (1, 1): TerrainType.PLAINS,
        (2, 1): TerrainType.PLAINS,
        (3, 1): TerrainType.FOREST,
        (4, 1): TerrainType.PLAINS,
        (0, 2): TerrainType.PLAINS,
        (1, 2): TerrainType.SETTLEMENT,
        (2, 2): TerrainType.PLAINS,
        (3, 2): TerrainType.RUIN,
        (4, 2): TerrainType.MOUNTAIN,
    }
    for (q, r), t in terrain_map.items():
        key = f"{q},{r}"
        board[key] = Tile(Hex(q, r), t)
    return board


def make_world() -> WorldState:
    p1_deck = make_starter_deck("alice")
    p2_deck = make_starter_deck("bob")

    p1 = Player(
        pid       = "alice",
        deck      = p1_deck,
        resources = Resource(gold=3),
        units     = {
            "alice_u1": Unit("alice_u1", "alice", hp=10, atk=3, position=Hex(0, 0))
        },
    )
    p2 = Player(
        pid       = "bob",
        deck      = p2_deck,
        resources = Resource(gold=3),
        units     = {
            "bob_u1": Unit("bob_u1", "bob", hp=8, atk=4, position=Hex(4, 2))
        },
    )

    board = make_board()
    # Place units on their starting tiles
    board["0,0"].occupant = "alice_u1"
    board["4,2"].occupant = "bob_u1"

    return WorldState(
        turn    = 1,
        players = {"alice": p1, "bob": p2},
        board   = board,
        rng_seed = 0xDEADBEEF_CAFEF00D,
    )


# ─── JSON serialization helpers ───────────────────────────────────────────────

class EngineEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (Resource, Hex, Duration, Mutation, Effect,
                             Card, Unit, Tile, QueuedEvent, Player,
                             UnitStatus, WorldState)):
            d = {}
            for k, v in obj.__dict__.items():
                d[k] = v
            return d
        if isinstance(obj, (CardKind, TerrainType, DurationType, StatusKind)):
            return obj.value
        return super().default(obj)


def world_to_dict(ws: WorldState) -> dict:
    return json.loads(json.dumps(ws, cls=EngineEncoder))


# ─── Turn summary printer ────────────────────────────────────────────────────

def print_turn_summary(ws: WorldState):
    print(f"  Turn {ws.turn:>2} |", end="")
    for pid, p in ws.players.items():
        res = p.resources
        print(f"  {pid}: hand={len(p.hand)} deck={len(p.deck)} "
              f"res=G{res.gold}/I{res.influence}/E{res.energy}/M{res.materiel} "
              f"units={len(p.units)}", end="")
    print()


# ─── Main simulation ─────────────────────────────────────────────────────────

def run_simulation():
    print("-- ─────────────────────────────────────────────────────── --")
    print("-- Vaulted Engine Micro-Loop  |  10-turn smoke test        --")
    print("-- ─────────────────────────────────────────────────────── --")

    ws = make_world()
    print_turn_summary(ws)

    for _ in range(10):
        ws = tick(ws)
        # Attempt a card play for each player (first affordable card in hand)
        for pid, player in ws.players.items():
            for card in list(player.hand):
                ok, err, ws = play_card(card.card_id, ws.players[pid], ws)
                if ok:
                    break   # one play per turn per player for demo

        print_turn_summary(ws)

    print("-- ─────────────────────────────────────────────────────── --")

    # Snapshot
    snapshot = {
        "version":    "0.1.0-micro",
        "captured_at": datetime.now(timezone.utc).isoformat(),
        "world":       world_to_dict(ws),
    }
    snap_path = os.path.join(os.path.dirname(__file__), "demo_snapshot.json")
    snap_json = json.dumps(snapshot, indent=2)
    with open(snap_path, "w") as f:
        f.write(snap_json)

    sha = hashlib.sha256(snap_json.encode()).hexdigest()
    print(f"Sim ran 10 turns. Final snapshot sha256: {sha}")
    return sha


if __name__ == "__main__":
    run_simulation()
