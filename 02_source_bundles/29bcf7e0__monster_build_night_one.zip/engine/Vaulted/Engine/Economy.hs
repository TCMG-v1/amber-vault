-- ─────────────────────────────────────────────────────────────────────────────
-- Vaulted.Engine.Economy
-- Sim-CCG Hybrid Engine — passive economy tick
--
-- Authors : Matthew Joseph Lansing (Vaulted Delta / BNS Labs)
--           Perplexity Computer
-- IP      : BNS 100% — Vaulted Delta CCG Standard umbrella
--
-- "The economy is the world breathing.  It does not stop breathing
--  because the player forgot to build a settlement."
-- ─────────────────────────────────────────────────────────────────────────────
{-# LANGUAGE DerivingStrategies #-}
{-# LANGUAGE StrictData         #-}

module Vaulted.Engine.Economy
  ( economyTick
  , settlementIncome
  , forestMaterielBonus
  , ruinEnergyBonus
  ) where

import Data.List         (nub)
import Data.Map.Strict   (Map)
import qualified Data.Map.Strict as Map
import Data.Maybe        (mapMaybe)

import Vaulted.Engine.Core
import Vaulted.Engine.Combat (hexNeighbors)

-- ─── Income constants ────────────────────────────────────────────────────────

-- | Per-turn income for each owned Settlement.
settlementIncome :: Resource
settlementIncome = mempty { gold = 2, influence = 1 }

-- | Per-turn materiel for each Forest hex adjacent to one of the player's units.
forestMaterielBonus :: Resource
forestMaterielBonus = mempty { materiel = 1 }

-- | Per-turn energy for each Ruin hex currently occupied by the player.
ruinEnergyBonus :: Resource
ruinEnergyBonus = mempty { energy = 1 }

-- ─── economyTick ─────────────────────────────────────────────────────────────

-- | Apply all passive resource generation for a player, given the current board.
--
--   Settlement rule  : tile.terrain == Settlement AND tile.occupant.owner == player
--   Forest rule      : tile.terrain == Forest AND tile is adjacent to at least
--                      one of the player's units
--   Ruin rule        : tile.terrain == Ruin AND tile.occupant.owner == player
economyTick :: Map Hex Tile -> Player -> Player
economyTick board' p =
  let gain = settlementsGain board' p
           <> forestsGain    board' p
           <> ruinsGain      board' p
  in  p { resources = resources p <> gain }

-- ─── Settlement income ───────────────────────────────────────────────────────

settlementsGain :: Map Hex Tile -> Player -> Resource
settlementsGain board' p =
  let myUnitIds = Map.keysSet (units p)
      ownedSettlements =
        [ ()
        | tile <- Map.elems board'
        , terrain tile == Settlement
        , Just uid' <- [occupant tile]
        , Map.member uid' (units p)
        ]
  in  mconcat (map (const settlementIncome) ownedSettlements)

-- ─── Forest materiel ─────────────────────────────────────────────────────────

forestsGain :: Map Hex Tile -> Player -> Resource
forestsGain board' p =
  let unitHexes = map position (Map.elems (units p))
      -- all hexes adjacent to any of this player's units
      adjacentHexes = nub (concatMap hexNeighbors unitHexes)
      forestAdjacent =
        [ ()
        | h <- adjacentHexes
        , Just tile <- [Map.lookup h board']
        , terrain tile == Forest
        ]
  in  mconcat (map (const forestMaterielBonus) forestAdjacent)

-- ─── Ruin energy ─────────────────────────────────────────────────────────────

ruinsGain :: Map Hex Tile -> Player -> Resource
ruinsGain board' p =
  let ownedRuins =
        [ ()
        | tile <- Map.elems board'
        , terrain tile == Ruin
        , Just uid' <- [occupant tile]
        , Map.member uid' (units p)
        ]
  in  mconcat (map (const ruinEnergyBonus) ownedRuins)

-- ─────────────────────────────────────────────────────────────────────────────
-- end Economy.hs
-- ─────────────────────────────────────────────────────────────────────────────
