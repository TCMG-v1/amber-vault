-- ─────────────────────────────────────────────────────────────────────────────
-- Vaulted.Engine.Tick
-- Sim-CCG Hybrid Engine — turn ticker
--
-- Authors : Matthew Joseph Lansing (Vaulted Delta / BNS Labs)
--           Perplexity Computer
-- IP      : BNS 100% — Vaulted Delta CCG Standard umbrella
--
-- "The world does not wait for the player to feel ready."
-- ─────────────────────────────────────────────────────────────────────────────
{-# LANGUAGE DeriveAnyClass     #-}
{-# LANGUAGE DerivingStrategies #-}
{-# LANGUAGE StrictData         #-}
{-# LANGUAGE OverloadedStrings  #-}
{-# LANGUAGE TupleSections      #-}

module Vaulted.Engine.Tick
  ( tick
  , handCap
    -- * Inline RNG (splitmix-style, no external dep)
  , RngState (..)
  , rngStep
  , rngFromSeed
  ) where

import Data.List            (foldl')
import Data.Map.Strict      (Map)
import qualified Data.Map.Strict as Map
import Data.Word            (Word64)

import Vaulted.Engine.Core

-- ─── Inline splitmix-style RNG ───────────────────────────────────────────────
-- A minimal SplitMix64 implementation.  No external library required.
-- Source pattern: Guy Steele et al., "Fast splittable pseudorandom number
-- generators" (OOPSLA 2014).

newtype RngState = RngState { unRng :: Word64 }
  deriving stock (Eq, Show)

rngFromSeed :: Word64 -> RngState
rngFromSeed = RngState

-- | Advance the state and return a pseudo-random Word64.
rngStep :: RngState -> (Word64, RngState)
rngStep (RngState s) =
  let s'  = s + 0x9e3779b97f4a7c15
      z0  = (s' `xor` (s' `shiftR` 30)) * 0xbf58476d1ce4e5b9
      z1  = (z0 `xor` (z0 `shiftR` 27)) * 0x94d049bb133111eb
      out = z1 `xor` (z1 `shiftR` 31)
  in  (out, RngState s')
  where
    xor    = Data.Bits.xor
    shiftR = Data.Bits.shiftR

-- ─── Constants ───────────────────────────────────────────────────────────────

-- | Maximum cards a player may hold at end of draw phase.
handCap :: Int
handCap = 5

-- | Passive per-turn base resources every player receives.
baseTurnIncome :: Resource
baseTurnIncome = Resource { gold = 1, influence = 0, energy = 0, materiel = 0 }

-- ─── Tick pipeline ───────────────────────────────────────────────────────────

-- | Advance the world by exactly one turn.  Pure and deterministic given
--   the current rngSeed.
--
-- Pipeline:
--   1. resolve queued events whose fireOnTurn <= current turn
--   2. each player draws up to handCap
--   3. apply per-turn base resource income
--   4. apply onTick mutations from permanent / timed active effects
--      (active effects are cards in discard pile with duration > Instant)
--   5. decrement Turns durations; expire exhausted effects
--   6. increment turn counter
tick :: WorldState -> WorldState
tick ws0 =
  let ws1 = resolveQueue    ws0
      ws2 = drawPhase       ws1
      ws3 = incomePhase     ws2
      ws4 = onTickPhase     ws3
      ws5 = ws4 { turn = turn ws4 + 1 }
  in  ws5

-- ─── Step 1: resolve queued events ───────────────────────────────────────────

resolveQueue :: WorldState -> WorldState
resolveQueue ws =
  let currentTurn = turn ws
      (fire, keep) = span (\qe -> fireOnTurn qe <= currentTurn) (eventQueue ws)
      ws'          = ws { eventQueue = keep }
  in  foldl' applyQueuedEvent ws' fire

applyQueuedEvent :: WorldState -> QueuedEvent -> WorldState
applyQueuedEvent ws qe =
  foldl' applyMutation ws (mutations qe)

-- ─── Step 2: draw phase ───────────────────────────────────────────────────────

drawPhase :: WorldState -> WorldState
drawPhase ws =
  let rng0     = rngFromSeed (rngSeed ws)
      (ps, rng1) = Map.foldlWithKey' (drawForPlayer ws) (Map.empty, rng0) (players ws)
  in  ws { players = ps, rngSeed = unRng rng1 }

drawForPlayer
  :: WorldState
  -> (Map PlayerId Player, RngState)
  -> PlayerId
  -> Player
  -> (Map PlayerId Player, RngState)
drawForPlayer _ws (acc, rng) pid' p =
  let needed           = max 0 (handCap - length (hand p))
      (p', rng')       = drawCards needed p rng
  in  (Map.insert pid' p' acc, rng')

-- | Draw n cards for a player, reshuffling discard into deck if necessary.
drawCards :: Int -> Player -> RngState -> (Player, RngState)
drawCards 0 p rng = (p, rng)
drawCards n p rng
  | null (deck p) && null (discard p) = (p, rng)
  | null (deck p) =
      -- reshuffle: move discard into deck (shuffle via RNG)
      let (shuffled, rng') = shuffleList (discard p) rng
          p'               = p { deck = shuffled, discard = [] }
      in  drawCards n p' rng'
  | otherwise =
      let (c : rest) = deck p
          p'         = p { deck = rest, hand = hand p ++ [c] }
      in  drawCards (n - 1) p' rng

-- | Fisher-Yates shuffle using the inline RNG.
shuffleList :: [a] -> RngState -> ([a], RngState)
shuffleList [] rng = ([], rng)
shuffleList xs rng =
  let arr             = zip [0..] xs
      (arr', rng')    = foldl' swapStep (arr, rng) [length xs - 1, length xs - 2 .. 1]
  in  (map snd arr', rng')
  where
    swapStep (arr, r) i =
      let (w, r')  = rngStep r
          j        = fromIntegral w `mod` (i + 1)
          vi       = snd (arr !! i)
          vj       = snd (arr !! j)
          arr'     = map (\(k, v) -> if k == i then (k, vj) else if k == j then (k, vi) else (k, v)) arr
      in  (arr', r')

-- ─── Step 3: income phase ─────────────────────────────────────────────────────

incomePhase :: WorldState -> WorldState
incomePhase ws =
  ws { players = Map.map addIncome (players ws) }
  where
    addIncome p = p { resources = resources p <> baseTurnIncome }

-- ─── Step 4: onTick mutations ─────────────────────────────────────────────────

-- | Apply onTick mutations from active effects.
-- Active effects are tracked on cards currently in the discard pile
-- whose effect duration is NOT Instant (they were placed there by playCard
-- and retain their onTick for as long as duration > 0).
-- For this slice, we scan each player's discard for non-Instant effects.
onTickPhase :: WorldState -> WorldState
onTickPhase ws =
  Map.foldl' tickPlayerEffects ws (players ws)

tickPlayerEffects :: WorldState -> Player -> WorldState
tickPlayerEffects ws p =
  let activeCards   = filter (isActive . effect) (discard p)
      allMutations  = concatMap (onTick . effect) activeCards
      ws'           = foldl' applyMutation ws allMutations
      -- decrement durations
      updatedDiscard = map decrementDuration (discard p)
      pid'          = pid p
  in  ws' { players = Map.adjust (\pl -> pl { discard = updatedDiscard }) pid' (players ws') }

isActive :: Effect -> Bool
isActive eff = case duration eff of
  Instant  -> False
  Turns 0  -> False
  _        -> True

decrementDuration :: Card -> Card
decrementDuration c =
  let eff = effect c
  in  c { effect = eff { duration = stepDuration (duration eff) } }

stepDuration :: Duration -> Duration
stepDuration (Turns n) | n > 0 = Turns (n - 1)
stepDuration other              = other

-- ─── Mutation application ─────────────────────────────────────────────────────

-- | Apply a single Mutation to the WorldState.
applyMutation :: WorldState -> Mutation -> WorldState
applyMutation ws mut = case mut of

  GainResource res ->
    -- GainResource broadcasts to all players in this base implementation.
    -- Override per-player targeting in the Deck layer.
    ws { players = Map.map (\p -> p { resources = resources p <> res }) (players ws) }

  DamageUnit uid' dmg ->
    ws { players = Map.map (damageUnitInPlayer uid' dmg) (players ws) }

  SpawnUnit tmpl hex' ->
    -- Spawn assigns the first player as owner in base impl;
    -- Deck.playCard should call a targeted variant.
    case Map.lookupMin (players ws) of
      Nothing       -> ws
      Just (pid', _) -> spawnUnitForPlayer ws pid' tmpl hex'

  ChangeTerrain hex' tt ->
    let board' = Map.adjust (\t -> t { terrain = tt }) hex' (board ws)
    in  ws { board = board' }

  DrawCards n ->
    let rng0 = rngFromSeed (rngSeed ws)
        (ps', rng1) = Map.mapAccum (\r p -> let (p', r') = drawCards n p r in (r', p')) rng0 (players ws)
    in  ws { players = ps', rngSeed = unRng rng1 }

  DiscardCards n ->
    ws { players = Map.map (discardFromHand n) (players ws) }

  TriggerEvent eid ->
    -- Enqueue the event to fire next turn; mutations are empty until
    -- an event registry wires them.
    let qe = QueuedEvent { qEventId = eid, fireOnTurn = turn ws + 1, mutations = [] }
    in  ws { eventQueue = eventQueue ws ++ [qe] }

-- ─── Helpers ─────────────────────────────────────────────────────────────────

damageUnitInPlayer :: UnitId -> Int -> Player -> Player
damageUnitInPlayer uid' dmg p =
  p { units = Map.adjust (\u -> u { hp = hp u - dmg }) uid' (units p) }

spawnUnitForPlayer :: WorldState -> PlayerId -> UnitTemplate -> Hex -> WorldState
spawnUnitForPlayer ws pid' tmpl hex' =
  let uid' = UnitId (templateName tmpl)  -- simplistic; real impl should uuid
      u    = Unit
               { uid      = uid'
               , owner    = pid'
               , hp       = baseHp tmpl
               , atk      = baseAtk tmpl
               , position = hex'
               , status   = []
               }
  in  ws { players = Map.adjust (\p -> p { units = Map.insert uid' u (units p) }) pid' (players ws) }

discardFromHand :: Int -> Player -> Player
discardFromHand n p =
  let (toDiscard, keep) = splitAt n (hand p)
  in  p { hand = keep, discard = discard p ++ toDiscard }

-- ─────────────────────────────────────────────────────────────────────────────
-- end Tick.hs
-- ─────────────────────────────────────────────────────────────────────────────
