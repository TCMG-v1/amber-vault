-- ─────────────────────────────────────────────────────────────────────────────
-- Vaulted.Engine.Snapshot
-- Sim-CCG Hybrid Engine — JSON state codec + .ppxl/4 capsule bridge
--
-- Authors : Matthew Joseph Lansing (Vaulted Delta / BNS Labs)
--           Perplexity Computer
-- IP      : BNS 100% — Vaulted Delta CCG Standard umbrella
--
-- "The snapshot is the ghost.  The capsule is the tomb.
--  Both are necessary.  Neither is the game."
-- ─────────────────────────────────────────────────────────────────────────────
{-# LANGUAGE DeriveAnyClass     #-}
{-# LANGUAGE DeriveGeneric      #-}
{-# LANGUAGE DerivingStrategies #-}
{-# LANGUAGE StrictData         #-}
{-# LANGUAGE OverloadedStrings  #-}

module Vaulted.Engine.Snapshot
  ( Snapshot (..)
  , snapshot
    -- * Re-exported for callers
  , module Data.Aeson
  ) where

import Data.Aeson           (ToJSON, FromJSON, toJSON, fromJSON, encode, decode,
                              genericToJSON, genericParseJSON,
                              defaultOptions, fieldLabelModifier)
import Data.Time.Clock      (UTCTime, getCurrentTime)
import Data.Text            (Text)
import GHC.Generics         (Generic)

import Vaulted.Engine.Core

-- ─── Snapshot wrapper ────────────────────────────────────────────────────────

data Snapshot = Snapshot
  { version    :: Text         -- ^ engine semver, e.g. "0.1.0-micro"
  , capturedAt :: UTCTime      -- ^ wall-clock seal time
  , world      :: WorldState
  } deriving stock    (Eq, Show, Generic)
    deriving anyclass (ToJSON, FromJSON)

-- ─── ToJSON / FromJSON derivations for Core types ────────────────────────────
--
-- NOTE: All Core types need Generic + ToJSON/FromJSON instances to drive the
--       Aeson derivation.  Add `deriving (Generic)` to each type in Core.hs
--       and extend this orphan block, or use standalone deriving.  This module
--       hosts the instance declarations to keep Core.hs free of Aeson imports.

deriving instance Generic PlayerId
deriving instance ToJSON  PlayerId;  deriving instance FromJSON PlayerId

deriving instance Generic CardId
deriving instance ToJSON  CardId;    deriving instance FromJSON CardId

deriving instance Generic UnitId
deriving instance ToJSON  UnitId;    deriving instance FromJSON UnitId

deriving instance Generic EventId
deriving instance ToJSON  EventId;   deriving instance FromJSON EventId

deriving instance Generic Resource
deriving instance ToJSON  Resource;  deriving instance FromJSON Resource

deriving instance Generic CardKind
deriving instance ToJSON  CardKind;  deriving instance FromJSON CardKind

deriving instance Generic Duration
deriving instance ToJSON  Duration;  deriving instance FromJSON Duration

deriving instance Generic Effect
deriving instance ToJSON  Effect;    deriving instance FromJSON Effect

deriving instance Generic UnitTemplate
deriving instance ToJSON  UnitTemplate; deriving instance FromJSON UnitTemplate

deriving instance Generic Mutation
deriving instance ToJSON  Mutation;  deriving instance FromJSON Mutation

deriving instance Generic Hex
deriving instance ToJSON  Hex;       deriving instance FromJSON Hex

deriving instance Generic TerrainType
deriving instance ToJSON  TerrainType; deriving instance FromJSON TerrainType

deriving instance Generic Status
deriving instance ToJSON  Status;    deriving instance FromJSON Status

deriving instance Generic Trait
deriving instance ToJSON  Trait;     deriving instance FromJSON Trait

deriving instance Generic Card
deriving instance ToJSON  Card;      deriving instance FromJSON Card

deriving instance Generic Unit
deriving instance ToJSON  Unit;      deriving instance FromJSON Unit

deriving instance Generic Tile
deriving instance ToJSON  Tile;      deriving instance FromJSON Tile

deriving instance Generic QueuedEvent
deriving instance ToJSON  QueuedEvent; deriving instance FromJSON QueuedEvent

deriving instance Generic Player
deriving instance ToJSON  Player;    deriving instance FromJSON Player

deriving instance Generic WorldState
deriving instance ToJSON  WorldState; deriving instance FromJSON WorldState

-- ─── snapshot :: IO ──────────────────────────────────────────────────────────

-- | Capture the current world as a timestamped Snapshot.
snapshot :: WorldState -> IO Snapshot
snapshot ws = do
  t <- getCurrentTime
  pure Snapshot
    { version    = "0.1.0-micro"
    , capturedAt = t
    , world      = ws
    }

-- ─── .ppxl/4 capsule bridge ──────────────────────────────────────────────────
--
-- To seal a Snapshot as a .ppxl/4 capsule, call:
--
--   import qualified Ppxl.V4 as V4
--
--   sealSnapshot :: Snapshot -> IO V4.CapsuleId
--   sealSnapshot snap = do
--     let payload = encode snap          -- ByteString (lazy JSON)
--     V4.seal V4.SealConfig
--       { V4.namespace  = "vaulted.engine"
--       , V4.schemaVer  = "4"
--       , V4.payload    = payload
--       , V4.tags       = [ "turn:" <> show (turn (world snap))
--                         , "engine:sim-ccg"
--                         , "project:vaulted-delta"
--                         ]
--       }
--
-- V4.seal returns a CapsuleId (a content-addressed hash reference) that
-- the .ppxl/4 protocol uses for deduplication, retrieval, and audit trails.
-- The parallel slice (Slice 4) owns the Ppxl.V4 module.  Wire this dependency
-- once that slice is merged.
--
-- For offline use, encode and write:
--
--   import qualified Data.ByteString.Lazy as BSL
--   BSL.writeFile "engine/demo_snapshot.json" (encode snap)
--
-- ─────────────────────────────────────────────────────────────────────────────
-- end Snapshot.hs
-- ─────────────────────────────────────────────────────────────────────────────
