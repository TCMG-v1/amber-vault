-- ─────────────────────────────────────────────────────────────────────────────
-- Vaulted.Engine.Deck
-- Sim-CCG Hybrid Engine — deck-state engine
--
-- Authors : Matthew Joseph Lansing (Vaulted Delta / BNS Labs)
--           Perplexity Computer
-- IP      : BNS 100% — Vaulted Delta CCG Standard umbrella
--
-- "The deck is the strategy.  The hand is the moment."
-- ─────────────────────────────────────────────────────────────────────────────
{-# LANGUAGE DerivingStrategies #-}
{-# LANGUAGE StrictData         #-}
{-# LANGUAGE OverloadedStrings  #-}

module Vaulted.Engine.Deck
  ( drawN
  , playCard
  , PlayError (..)
  ) where

import Data.List         (find)
import Data.Map.Strict   (Map)
import qualified Data.Map.Strict as Map
import Data.Text         (Text)

import Vaulted.Engine.Core
import Vaulted.Engine.Tick (shuffleList, rngFromSeed, rngStep)

-- ─── Play errors ─────────────────────────────────────────────────────────────

data PlayError
  = NotInHand
  | InsufficientResource Resource   -- ^ how much short
  | IllegalTarget Text
  deriving stock (Eq, Show)

-- ─── drawN ───────────────────────────────────────────────────────────────────

-- | Draw up to N cards for a player, reshuffling discard into deck when
--   the deck is exhausted.  Returns the updated Player and the drawn cards.
--   Uses the WorldState's rngSeed for any shuffle; the seed is NOT updated
--   here — Tick.drawPhase owns that responsibility when calling drawN in bulk.
--
--   If N exceeds available cards (deck + discard), draw as many as possible.
drawN :: Int -> Player -> (Player, [Card])
drawN n p0 = go n p0 []
  where
    go 0 p acc = (p, reverse acc)
    go k p acc
      | null (deck p) && null (discard p) = (p, reverse acc)
      | null (deck p) =
          -- reshuffle — deterministic via pid hash as a stand-in seed
          let seed       = pidSeed (pid p)
              rng        = rngFromSeed seed
              (shuffled, _) = shuffleList (discard p) rng
              p'         = p { deck = shuffled, discard = [] }
          in  go k p' acc
      | otherwise =
          let (c : rest) = deck p
              p'         = p { deck = rest, hand = hand p ++ [c] }
          in  go (k - 1) p' (c : acc)

-- | Derive a deterministic seed from PlayerId (avoids threading RngState
--   through this pure function; Tick owns the canonical seed).
pidSeed :: PlayerId -> Word64
pidSeed (PlayerId t) =
  foldl (\acc c -> acc * 31 + fromIntegral (fromEnum c)) 0 (show t)

-- ─── playCard ────────────────────────────────────────────────────────────────

-- | Attempt to play a card for the given player.
--
--   Steps:
--   1. Verify card is in the player's hand.
--   2. Verify the player can pay the cost.
--   3. Deduct cost and move card to discard.
--   4. Apply onPlay mutations to the WorldState.
--   5. Return updated WorldState.
playCard :: CardId -> Player -> WorldState -> Either PlayError WorldState
playCard cid player ws = do
  -- 1. find card in hand
  c <- case find (\x -> cardId x == cid) (hand player) of
         Nothing -> Left NotInHand
         Just x  -> Right x

  -- 2. check cost
  let cost'   = cost c
      res     = resources player
      deficit = resourceDeficit res cost'
  if not (zeroOrPositive deficit)
    then Left (InsufficientResource deficit)
    else do
      -- 3. deduct & move card
      let player1 = player
            { hand      = filter (\x -> cardId x /= cid) (hand player)
            , discard   = discard player ++ [c]
            , resources = resources player `subResource` cost'
            }
          pid'     = pid player
          ws1      = ws { players = Map.insert pid' player1 (players ws) }

      -- 4. apply onPlay mutations
      let ws2 = foldr (flip applyMutationForPlayer pid') ws1 (onPlay (effect c))
      Right ws2

-- ─── Resource arithmetic ─────────────────────────────────────────────────────

-- | Subtract `cost` from `available`.  Negative fields = shortfall.
resourceDeficit :: Resource -> Resource -> Resource
resourceDeficit avail cost' = Resource
  { gold      = gold      avail - gold      cost'
  , influence = influence avail - influence cost'
  , energy    = energy    avail - energy    cost'
  , materiel  = materiel  avail - materiel  cost'
  }

subResource :: Resource -> Resource -> Resource
subResource a b = Resource
  { gold      = gold      a - gold      b
  , influence = influence a - influence b
  , energy    = energy    a - energy    b
  , materiel  = materiel  a - materiel  b
  }

zeroOrPositive :: Resource -> Bool
zeroOrPositive r =
  gold r >= 0 && influence r >= 0 && energy r >= 0 && materiel r >= 0

-- ─── Targeted mutation application ──────────────────────────────────────────

-- | Apply a mutation on behalf of a specific player (the card's owner).
--   GainResource and DrawCards are directed to that player only.
applyMutationForPlayer :: WorldState -> Mutation -> PlayerId -> WorldState
applyMutationForPlayer ws mut pid' = case mut of

  GainResource res ->
    ws { players = Map.adjust (\p -> p { resources = resources p <> res }) pid' (players ws) }

  DrawCards n ->
    let rng = rngFromSeed (rngSeed ws)
    in  case Map.lookup pid' (players ws) of
          Nothing -> ws
          Just p  ->
            let (p', _) = drawN n p
            in  ws { players = Map.insert pid' p' (players ws) }

  DiscardCards n ->
    ws { players = Map.adjust discardTop (players ws) }
    where
      discardTop p =
        let (toDiscard, keep) = splitAt n (hand p)
        in  p { hand = keep, discard = discard p ++ toDiscard }

  -- All other mutations fall through to world-level application
  other ->
    applyWorldMutation ws other

-- | World-level fallback for mutations without a player target.
applyWorldMutation :: WorldState -> Mutation -> WorldState
applyWorldMutation ws mut = case mut of

  DamageUnit uid' dmg ->
    ws { players = Map.map (\p -> p { units = Map.adjust (\u -> u { hp = hp u - dmg }) uid' (units p) }) (players ws) }

  SpawnUnit tmpl hex' ->
    case Map.lookupMin (players ws) of
      Nothing        -> ws
      Just (pid', _) ->
        let uid'  = UnitId (templateName tmpl)
            u     = Unit uid' pid' (baseHp tmpl) (baseAtk tmpl) hex' []
            board' = Map.adjust (\t -> t { occupant = Just uid' }) hex' (board ws)
        in  ws
              { players = Map.adjust (\p -> p { units = Map.insert uid' u (units p) }) pid' (players ws)
              , board   = board'
              }

  ChangeTerrain hex' tt ->
    ws { board = Map.adjust (\t -> t { terrain = tt }) hex' (board ws) }

  TriggerEvent eid ->
    let qe = QueuedEvent eid (turn ws + 1) []
    in  ws { eventQueue = eventQueue ws ++ [qe] }

  _ -> ws

-- ─────────────────────────────────────────────────────────────────────────────
-- end Deck.hs
-- ─────────────────────────────────────────────────────────────────────────────
