-- ─────────────────────────────────────────────────────────────────────────────
-- Vaulted.Engine.Core
-- Sim-CCG Hybrid Engine — foundational types
--
-- Authors : Matthew Joseph Lansing (Vaulted Delta / BNS Labs)
--           Perplexity Computer
-- IP      : BNS 100% — Vaulted Delta CCG Standard umbrella
-- License : Proprietary / BNS
--
-- "Every game is a simulation of choices someone else designed.
--  Here we design the choices."
-- ─────────────────────────────────────────────────────────────────────────────
{-# LANGUAGE DeriveAnyClass     #-}
{-# LANGUAGE DerivingStrategies #-}
{-# LANGUAGE StrictData         #-}
{-# LANGUAGE OverloadedStrings  #-}

module Vaulted.Engine.Core
  ( -- * Identity
    PlayerId (..)
  , CardId   (..)
  , UnitId   (..)
  , EventId  (..)
    -- * Cards
  , Card     (..)
  , CardKind (..)
    -- * Resources
  , Resource (..)
    -- * Effects & Mutations
  , Effect   (..)
  , Mutation (..)
  , Duration (..)
    -- * World
  , WorldState (..)
  , Player     (..)
  , Hex        (..)
  , Tile       (..)
  , TerrainType (..)
  , Unit        (..)
  , UnitTemplate (..)
  , QueuedEvent  (..)
  , Status       (..)
  , Trait        (..)
  ) where

import Data.Map.Strict (Map)
import Data.Text       (Text)
import Data.Word       (Word64)

-- ─── Identity wrappers ───────────────────────────────────────────────────────

newtype PlayerId = PlayerId Text
  deriving stock   (Eq, Ord, Show)
  deriving newtype (Semigroup, Monoid)

newtype CardId = CardId Text
  deriving stock   (Eq, Ord, Show)

newtype UnitId = UnitId Text
  deriving stock   (Eq, Ord, Show)

newtype EventId = EventId Text
  deriving stock   (Eq, Ord, Show)

-- ─── Card model ──────────────────────────────────────────────────────────────

data Card = Card
  { cardId :: CardId
  , name   :: Text
  , kind   :: CardKind
  , cost   :: Resource
  , effect :: Effect
  } deriving stock (Eq, Show)

data CardKind
  = Unit
  | Policy
  | Event
  | Terrain
  | Tech
  deriving stock (Eq, Ord, Show, Enum, Bounded)

-- ─── Resource ────────────────────────────────────────────────────────────────

-- | Four-axis economy.  Designed so that (mempty) is the zero resource
--   and (<>) combines additively.  Subtraction is done externally to keep
--   this type lawful.
data Resource = Resource
  { gold      :: Int
  , influence :: Int
  , energy    :: Int
  , materiel  :: Int
  } deriving stock (Eq, Ord, Show)

instance Semigroup Resource where
  a <> b = Resource
    { gold      = gold      a + gold      b
    , influence = influence a + influence b
    , energy    = energy    a + energy    b
    , materiel  = materiel  a + materiel  b
    }

instance Monoid Resource where
  mempty = Resource 0 0 0 0

-- ─── Effects & Mutations ─────────────────────────────────────────────────────

-- | An Effect packages the full lifecycle of a played card.
data Effect = Effect
  { onPlay  :: [Mutation]   -- ^ Fires once when the card is played
  , onTick  :: [Mutation]   -- ^ Fires each turn while the effect is active
  , duration :: Duration
  } deriving stock (Eq, Show)

-- | Atomic state-change primitives.  The engine resolves these in order.
data Mutation
  = GainResource   Resource
  | DamageUnit     UnitId Int
  | SpawnUnit      UnitTemplate Hex
  | ChangeTerrain  Hex TerrainType
  | DrawCards      Int
  | DiscardCards   Int
  | TriggerEvent   EventId
  deriving stock (Eq, Show)

data Duration
  = Instant
  | Turns Int
  | Permanent
  deriving stock (Eq, Ord, Show)

-- ─── World ───────────────────────────────────────────────────────────────────

data WorldState = WorldState
  { turn       :: Int
  , players    :: Map PlayerId Player
  , board      :: Map Hex Tile
  , eventQueue :: [QueuedEvent]
  , rngSeed    :: Word64
  } deriving stock (Eq, Show)

data Player = Player
  { pid       :: PlayerId
  , hand      :: [Card]
  , deck      :: [Card]
  , discard   :: [Card]
  , resources :: Resource
  , units     :: Map UnitId Unit
  , traits    :: [Trait]
  } deriving stock (Eq, Show)

-- | Axial hex coordinates (q, r).  s = -q - r is implied.
data Hex = Hex Int Int
  deriving stock (Eq, Ord, Show)

data Tile = Tile
  { hex      :: Hex
  , terrain  :: TerrainType
  , occupant :: Maybe UnitId
  } deriving stock (Eq, Show)

data TerrainType
  = Plains
  | Forest
  | Mountain
  | Water
  | Ruin
  | Settlement
  deriving stock (Eq, Ord, Show, Enum, Bounded)

data Unit = Unit
  { uid      :: UnitId
  , owner    :: PlayerId
  , hp       :: Int
  , atk      :: Int
  , position :: Hex
  , status   :: [Status]
  } deriving stock (Eq, Show)

-- ─── Small supporting types ───────────────────────────────────────────────────

-- | Minimal template to spawn a new unit.
data UnitTemplate = UnitTemplate
  { templateName :: Text
  , baseHp       :: Int
  , baseAtk      :: Int
  } deriving stock (Eq, Show)

-- | An event waiting to fire in a future turn.
data QueuedEvent = QueuedEvent
  { qEventId   :: EventId
  , fireOnTurn :: Int
  , mutations  :: [Mutation]
  } deriving stock (Eq, Show)

-- | Unit status effects (expandable).
data Status
  = Stunned
  | Shielded Int   -- ^ remaining shield points
  | Rooted   Int   -- ^ turns remaining
  deriving stock (Eq, Show)

-- | Player-level persistent traits (expandable).
data Trait
  = ExpandedSupply    -- ^ hand cap +1
  | LogisticsExpert   -- ^ materiel generation +1
  | ShadowNetwork     -- ^ influence costs reduced by 1
  deriving stock (Eq, Ord, Show, Enum, Bounded)

-- ─────────────────────────────────────────────────────────────────────────────
-- end Core.hs
-- ─────────────────────────────────────────────────────────────────────────────
