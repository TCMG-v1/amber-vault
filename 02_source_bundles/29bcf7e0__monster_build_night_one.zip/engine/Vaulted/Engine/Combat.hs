-- ─────────────────────────────────────────────────────────────────────────────
-- Vaulted.Engine.Combat
-- Sim-CCG Hybrid Engine — combat resolver
--
-- Authors : Matthew Joseph Lansing (Vaulted Delta / BNS Labs)
--           Perplexity Computer
-- IP      : BNS 100% — Vaulted Delta CCG Standard umbrella
--
-- "Terrain is not scenery.  It is a variable."
-- ─────────────────────────────────────────────────────────────────────────────
{-# LANGUAGE DerivingStrategies #-}
{-# LANGUAGE StrictData         #-}

module Vaulted.Engine.Combat
  ( resolveCombat
  , terrainDefenseBonus
  , terrainAttackPenalty
  , hexAdjacent
  ) where

import Data.Map.Strict (Map)
import qualified Data.Map.Strict as Map
import Data.Maybe      (fromMaybe, mapMaybe)

import Vaulted.Engine.Core

-- ─── Terrain modifiers ───────────────────────────────────────────────────────

-- | Bonus added to *defender's* effective HP (i.e., damage reduction).
--   Forest = +1, Mountain = +2, all others = 0.
terrainDefenseBonus :: TerrainType -> Int
terrainDefenseBonus Forest   = 1
terrainDefenseBonus Mountain = 2
terrainDefenseBonus _        = 0

-- | Penalty subtracted from *attacker's* effective ATK.
--   Water = -1 (fighting from water is a disadvantage).
terrainAttackPenalty :: TerrainType -> Int
terrainAttackPenalty Water = 1
terrainAttackPenalty _     = 0

-- ─── Adjacency ───────────────────────────────────────────────────────────────

-- | Axial hex neighbors (the six directions in a flat-top grid).
hexNeighbors :: Hex -> [Hex]
hexNeighbors (Hex q r) =
  [ Hex (q+1)  r
  , Hex (q-1)  r
  , Hex  q    (r+1)
  , Hex  q    (r-1)
  , Hex (q+1) (r-1)
  , Hex (q-1) (r+1)
  ]

-- | True iff the two hexes are adjacent (distance == 1).
hexAdjacent :: Hex -> Hex -> Bool
hexAdjacent a b = b `elem` hexNeighbors a

-- ─── Combat resolution ───────────────────────────────────────────────────────

-- | Resolve combat between the unit on `attackerHex` and the unit on
--   `defenderHex`.  Returns an updated WorldState.
--
--   Rules:
--   1. Look up units on each hex.
--   2. Compute effective damage in both directions simultaneously.
--      effectiveDmg = max 0 (atk - terrainAttackPenalty(attTerrain)
--                            - terrainDefenseBonus(defTerrain))
--   3. Apply damage; remove units with hp <= 0.
--   4. If attacker survived and defender died, move attacker into defender's hex.
resolveCombat :: Hex -> Hex -> WorldState -> WorldState
resolveCombat attackerHex defenderHex ws
  | not (hexAdjacent attackerHex defenderHex) = ws   -- must be adjacent
  | otherwise =
      let board'    = board ws
          attTile   = Map.lookup attackerHex board'
          defTile   = Map.lookup defenderHex board'
          attUnitId = attTile >>= occupant
          defUnitId = defTile >>= occupant
      in case (attUnitId, defUnitId) of
           (Nothing, _)  -> ws   -- no attacker
           (_, Nothing)  -> ws   -- no defender
           (Just aId, Just dId) ->
             resolveUnits aId dId attackerHex defenderHex ws

-- | Core resolution once both UnitIds are confirmed present.
resolveUnits
  :: UnitId -> UnitId
  -> Hex -> Hex
  -> WorldState -> WorldState
resolveUnits aId dId aHex dHex ws =
  let board'    = board ws
      attTerrain = maybe Plains terrain (Map.lookup aHex board')
      defTerrain = maybe Plains terrain (Map.lookup dHex board')

      -- Locate units across all players
      allUnits  = concatMap (Map.toList . units) (Map.elems (players ws))
      aUnit     = lookup aId allUnits
      dUnit     = lookup dId allUnits

  in case (aUnit, dUnit) of
       (Nothing, _) -> ws
       (_, Nothing) -> ws
       (Just att, Just def) ->
         let atkDmg = max 0 ( atk att
                             - terrainAttackPenalty attTerrain
                             - terrainDefenseBonus  defTerrain )
             defDmg = max 0 ( atk def
                             - terrainAttackPenalty defTerrain
                             - terrainDefenseBonus  attTerrain )

             att'  = att { hp = hp att - defDmg }
             def'  = def { hp = hp def - atkDmg }

             ws1   = updateUnit aId att' ws
             ws2   = updateUnit dId def' ws1

             attDead = hp att' <= 0
             defDead = hp def' <= 0

             ws3 = if attDead then removeUnit aId aHex ws2 else ws2
             ws4 = if defDead then removeUnit dId dHex ws3 else ws3

             -- advance attacker into vacated hex if it survived and defender died
             ws5 = if not attDead && defDead
                     then moveUnit aId aHex dHex ws4
                     else ws4
         in  ws5

-- ─── Unit helpers ────────────────────────────────────────────────────────────

-- | Update a unit across all players.
updateUnit :: UnitId -> Unit -> WorldState -> WorldState
updateUnit uid' u ws =
  ws { players = Map.map updateInPlayer (players ws) }
  where
    updateInPlayer p =
      if Map.member uid' (units p)
        then p { units = Map.insert uid' u (units p) }
        else p

-- | Remove a dead unit and clear its tile occupant.
removeUnit :: UnitId -> Hex -> WorldState -> WorldState
removeUnit uid' hex' ws =
  let ws1 = ws { players = Map.map removeFromPlayer (players ws) }
      ws2 = ws1 { board = Map.adjust (\t -> t { occupant = Nothing }) hex' (board ws1) }
  in  ws2
  where
    removeFromPlayer p = p { units = Map.delete uid' (units p) }

-- | Move a surviving unit into a new hex, updating both tile occupancies.
moveUnit :: UnitId -> Hex -> Hex -> WorldState -> WorldState
moveUnit uid' fromHex toHex ws =
  let clearFrom = Map.adjust (\t -> t { occupant = Nothing }) fromHex
      setTo     = Map.adjust (\t -> t { occupant = Just uid' }) toHex
      board'    = setTo . clearFrom $ board ws
      ws1       = ws { board = board' }
      ws2       = ws1 { players = Map.map (updateUnitPos uid' toHex) (players ws1) }
  in  ws2

updateUnitPos :: UnitId -> Hex -> Player -> Player
updateUnitPos uid' hex' p =
  p { units = Map.adjust (\u -> u { position = hex' }) uid' (units p) }

-- ─────────────────────────────────────────────────────────────────────────────
-- end Combat.hs
-- ─────────────────────────────────────────────────────────────────────────────
