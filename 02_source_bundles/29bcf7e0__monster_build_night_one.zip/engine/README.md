# Vaulted Engine — Sim-CCG Hybrid Micro-Loop

**Authors:** Matthew Joseph Lansing (Vaulted Delta / BNS Labs) + Perplexity Computer  
**IP:** BNS 100% — Vaulted Delta CCG Standard umbrella  
**Slice:** 2 of 3 (core engine loop)  
**Version:** 0.1.0-micro

---

## What this is, what this isn't

This is the **micro-loop** — the load-bearing core that proves the sim-CCG hybrid
runs end-to-end.  It is not a game.  There are no win conditions, no menus, no
assets.  What exists here is the minimal set of pure functions and types needed
to answer one question: can a turn-based world state, a card hand, and a hex
grid mutate each other in a closed loop?

The answer is yes.  The demo ran 10 turns.

These mechanics are designed to be **reusable across all Vaulted Delta / Cauldron
Works titles**.  The CCG layer (deck, draw, play, discard) is wired to the sim
layer (world state, hex board, economy) through the `Mutation` ADT.  Any card
in any future title that emits a `Mutation` will compose with this engine
without modification.  That is the point.

---

## Architecture

```
                       ┌─────────────────────────────┐
                       │        WorldState             │
                       │  turn / players / board       │
                       │  eventQueue / rngSeed         │
                       └────────────┬────────────────-─┘
                                    │
               ┌────────────────────┼────────────────────┐
               │                    │                    │
               ▼                    ▼                    ▼
     ┌─────────────────┐  ┌──────────────────┐  ┌────────────────┐
     │   Tick.hs        │  │   Deck.hs         │  │  Economy.hs    │
     │  tick :: WS→WS   │  │  drawN            │  │  economyTick   │
     │  resolveQueue    │  │  playCard         │  │  settlement    │
     │  drawPhase       │  │  PlayError        │  │  forest mat.   │
     │  incomePhase     │  │  applyMutation    │  │  ruin energy   │
     │  onTickPhase     │  │  (player-scoped)  │  └────────────────┘
     │  rngStep / RNG   │  └──────────────────┘
     └─────────────────┘
               │
               ▼
     ┌─────────────────┐        ┌──────────────────┐
     │  Combat.hs       │        │  Snapshot.hs      │
     │  resolveCombat   │        │  Snapshot ADT     │
     │  terrainBonus    │        │  snapshot :: IO   │
     │  hexAdjacent     │        │  ToJSON/FromJSON  │
     └─────────────────┘        │  .ppxl/4 bridge   │
               │                └──────────────────┘
               ▼                          │
     ┌─────────────────┐                  ▼
     │   Core.hs        │        ┌──────────────────┐
     │   All ADTs        │        │  Ppxl.V4 (Slice 4)│
     │   Resource        │        │  seal / retrieve  │
     │   Mutation        │        │  content-addr.    │
     │   WorldState      │        │  capsule protocol │
     └─────────────────┘        └──────────────────┘

  demo.py — Python mirror of the full stack
  Runs the 10-turn smoke test.  No Haskell toolchain required tonight.
```

---

## Module guide

### -- Core.hs

All ADTs live here.  One file, zero business logic.  The design rule is:
if a type change breaks two or more modules, the type belongs in Core.

`Resource` is the engine's economic primitive.  It is a `Semigroup` and
`Monoid` over pointwise addition so that income sources compose with `<>` and
the zero resource is `mempty`.  Subtraction is kept out of the class hierarchy
on purpose — negative balances have semantics that vary by context, so callers
make that call.

`Mutation` is the bridge between the CCG layer and the sim layer.  A card's
`Effect` is a bundle of `[Mutation]`; the engine resolves them in sequence.
Every future card mechanic — in any title — is a new `Mutation` constructor.

---

### -- Tick.hs

The ticker is a pure function `WorldState -> WorldState`.  Determinism is
non-negotiable: given the same seed and the same state, every client on every
device produces the same next state.  This is what makes the engine
network-safe and replay-safe without a server.

The inline RNG is a minimal SplitMix64 — the same algorithm that ships in
GHC's `splitmix` package, inlined to avoid a dependency during early
development.  When the cabal project matures, replace the inline struct with
`import System.Random.SplitMix` and the signatures stay identical.

The draw phase pulls each player up to `handCap` (5), reshuffling discard
into deck when the draw pile empties.  The `onTickPhase` scans each player's
discard pile for cards whose duration is not `Instant` — those are "active
effects" and fire their `onTick` mutations each turn until their `Turns n`
counter expires or a `Permanent` effect is manually removed.

---

### -- Combat.hs

Combat is simultaneous: both units compute their outgoing damage before either
takes it.  This mirrors the Vaulted Delta CCG Standard's resolution order
(declare, modify, resolve) and avoids first-strike edge cases at the engine
level.  Titles that want first-strike should implement it as a card `Mutation`
or `Status`, not by reordering the resolver.

Terrain modifiers are pure lookups exported as `terrainDefenseBonus` and
`terrainAttackPenalty`.  They are separate functions so that AI, UI preview,
and tooltip layers can call them independently without running a full combat
simulation.

---

### -- Deck.hs

`playCard` returns `Either PlayError WorldState`.  The `PlayError` ADT is the
entire failure surface: `NotInHand`, `InsufficientResource`, `IllegalTarget`.
Rule enforcement (targeting validity, zone legality, timing windows) belongs
upstream — Deck only checks presence and cost.  This keeps the Deck module
suitable for any CCG title that adopts the Vaulted Delta CCG Standard without
carrying game-specific rule logic.

`drawN` is intentionally stateless about the world RNG — it takes a seed as an
argument and returns a new one.  Tick.drawPhase owns the canonical seed update;
Deck owns the shuffle algorithm.  The separation prevents accidental RNG
coupling between draw resolution and other sources of randomness.

---

### -- Economy.hs

Economy is a player-scoped tick applied once per world turn after base income.
The three income sources — Settlement ownership, Forest adjacency, Ruin
occupation — represent the sim game's territorial incentive structure.
Expanding your footprint pays materiel and energy; controlling key hexes pays
gold and influence.  This is the Oregon Trail × Civ design signal: land is
not decoration.

The `economyTick` function takes a `Map Hex Tile` (the board) and a `Player`
and returns an updated `Player`.  It is pure.  The caller (Tick.incomePhase)
threads the board through; Economy never touches WorldState directly.  This
makes Economy trivially portable to any title with a hex board.

---

### -- Snapshot.hs

Snapshots are versioned, timestamped `WorldState` wrappers with full
`ToJSON`/`FromJSON` derivation via `DeriveAnyClass`.  The serialization
strategy is intentionally boring: flat Aeson generics, no custom encoding,
human-readable JSON.  Debug builds should read like a game save file.

Snapshots are designed to be **sealed under .ppxl/4** — the parallel Slice 4
capsule protocol.  The comment block in `Snapshot.hs` shows the exact call
signature:

```haskell
V4.seal V4.SealConfig
  { V4.namespace = "vaulted.engine"
  , V4.payload   = encode snap
  , V4.tags      = ["turn:N", "engine:sim-ccg"]
  }
```

The `.ppxl/4` protocol provides content-addressed storage, deduplication, and
audit trails.  Once Slice 4 is merged, wire `Ppxl.V4` as a cabal dependency
and the bridge activates.  Until then, `encode snap` writes standard JSON.

---

## Running the smoke test

```bash
cd engine
python3 demo.py
```

No Haskell toolchain required for the smoke test.  `demo.py` is a full Python
mirror of the engine that runs a 10-turn simulation with 2 players, prints
turn-by-turn state summaries, and writes `demo_snapshot.json` with a sha256
hash.

To compile the Haskell modules once the cabal project is wired:

```bash
cabal build vaulted-engine
```

Required packages: `containers`, `text`, `aeson`, `time`, `bytestring`.
The inline RNG replaces `splitmix` during this slice; swap it at will.

---

## CCG Standard note

The `Mutation` ADT, `Effect` lifecycle (`onPlay` / `onTick` / `duration`),
and `PlayError` surface are the three points the Vaulted Delta CCG Standard
specifies as engine contracts.  Any future title — BtB Arena 2, Cauldron
Works dungeon crawl, World Builder's event system — that implements these
three contracts will be plug-compatible with this engine core without
modification.  Cards are data.  The engine is infrastructure.

---

*"The archive does not judge the turn.  It records it."*

---
<!-- end README.md -->
