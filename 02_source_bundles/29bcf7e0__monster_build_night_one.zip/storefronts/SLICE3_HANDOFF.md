# Slice 3 — Dual Storefront Shell + Operator Dashboard · Handoff

## Deploy (preview only — not published)
- Project path: `/home/user/workspace/monster_build/storefronts`
- Entry point: `index.html`
- Site name: `Cauldron Works × Vaulted Delta`
- Preview URL: https://www.perplexity.ai/computer/a/cauldron-works-x-vaulted-delta-dneQe.RmTYmPMV58qOeGPQ
- Routes (single SPA, hash router): `#/` landing · `#/cauldron` · `#/vaulted` · `#/cauldron/product/<sku>` · `#/vaulted/product/<sku>` · `#/cauldron/about` · `#/vaulted/about` · `#/terms/<sku>` · `#/dashboard`

> Parent must call `deploy_website` itself with the same args to surface the component in main chat.

## 12 Product SKUs (store · RWA)
| SKU | Store | RWA | Kind | Registry |
|---|---|---|---|---|
| cw-base-sealed-lattice | cauldron | no | game | — |
| cw-sealed-pack-physical | cauldron | YES | asset_pack (physical_card) | solana |
| cw-expansion-ashfall | cauldron | no | asset_pack | — |
| cw-ost-the-binding | cauldron | no | ost | — |
| cw-artbook-sealed | cauldron | YES | art_book (physical_art) | stellar |
| cw-founders-badge | cauldron | no | license | — |
| vd-ccg-standard-spec | vaulted | no | spec | — |
| vd-engine-indie-annual | vaulted | no | license | — |
| vd-engine-studio-pertitle | vaulted | no | license | — |
| vd-certified-build | vaulted | no | tooling | — |
| vd-cards-as-data-toolkit | vaulted | no | asset_pack | — |
| vd-first-100-charter | vaulted | YES | license (license_seat) | xrp |

2 RWA-backed per store (4 total): cw-sealed-pack-physical, cw-artbook-sealed, vd-first-100-charter — plus founders badge is a license_seat asset class but not backed.

## 7 Release-History Entries (newest first on dashboard)
1. 2026-06-10T23:45Z · dashboard/0.1.0 · STORE · "Publishing dashboard online" · STAGED
2. 2026-06-10T23:44:30Z · vaulted/0.1.0 · STORE · "Vaulted Delta storefront shell" · STAGED
3. 2026-06-10T23:44Z · cauldron/0.1.0 · STORE · "Cauldron Works storefront shell" · STAGED
4. 2026-06-10T23:43Z · engine/microloop-0.1.0 · ENGINE · "Sim-CCG micro-loop online" · STAGED
5. 2026-06-10T23:42Z · ppxl/4.0.0 · SPEC · "Protocol generalized — sealed capsules formalized" · STAGED · prev → f652ab6b…
6. 2026-06-10T19:41Z · terpene-codex/3.0.0 · CAPSULE · "Terpene Binding Atlas v3 sealed" · LIVE (genesis, digest f652ab6b…)
7. 2026-04-30T00:00Z · foundation/launch · STORE · "Bell to Bell Foundation — four-property launch" · LIVE

## Architecture decisions
Built as a **single static SPA** (vanilla HTML/CSS/JS, no framework, no build step) with hash-based routing — chosen because the sandbox serves one opaque entry URL and blocks separate secret paths, and because a single deployable was the explicit requirement ("two front-doors, shared infrastructure"). Both stores, the landing gate, and the operator dashboard live in one `index.html` + `app.js`; the store identity (palette accent, nav, copy) swaps via a body class driven by the route. The shared product schema lives in `products.json` and the dashboard state in `dashboard.json`, so both stores and the dashboard read from the same load-bearing data — RWA hooks, rails, and capsule IDs are all data-driven, not hardcoded in markup. Covers are procedurally generated SVGs (per-kind motifs) so there are no placeholder/hallucinated image URLs. Fonts: Instrument Serif (display) + Inter (body) + JetBrains Mono (digests/labels), matching the shadow-synthetic-noir family.

## Dashboard chain-viewer wiring
The Capsule Chain panel reads the `capsules` array from `dashboard.json`, sorts by `sealed_iso`, and renders each as a node box (label + truncated digest) joined by `→` arrows following the `prev` linkage already encoded in the data. The three integrity indicators below it read straight from `dashboard.json.chain_status` (`valid`, `digests_verified/digests_total`, `signer_keys_rotated`, `schema_active`) — flip `valid` to false or change the verified count and the green dot/text update with no code change. The release timeline and product table read from `dashboard.json.history` and `products.json` respectively. To plug real values: edit `dashboard.json` only.

## Pay-button UX notes
Each product renders pay buttons ONLY for rails with `enabled:true`. Click opens a modal: rail-colored header (Solana purple-gradient, Stellar navy, XRP teal, Binance gold), a deterministic faux-QR mosaic (visual placeholder), stub address, XRP destination-tag/memo when `memo_required`, a "coming soon — rail preview" tag, and an email interest field. NOTE: sandbox blocks localStorage, so interest capture is **in-memory** (`INTEREST[]` array) — task asked for localStorage but that crashes sandboxed iframes; swap to a backend POST for real capture.

## What Matt will want to wire next
1. **Real wallet/merchant identifiers** — replace `STUB_ADDR` in app.js and the `rails.*.address` / `binance_pay.merchant_id` "stub" values in products.json with live Solana USDC, Stellar, XRP addresses and the real Binance Pay merchant ID.
2. **Real .ppxl/4 capsule digests + explorer links** — the digests in dashboard.json are plausible-but-fabricated sha256s; wire to the actual capsule registry and point the "view on explorer" links (currently generic Solana/Stellar/XRP explorer bases) at real registry entries.
3. **Persistent interest capture + auth wall** — move email capture to a backend endpoint (sandbox blocks localStorage); gate `/dashboard` behind real BNS operator auth; consider websocket/SSE for live deploy-log + chain-verify updates instead of static JSON.
