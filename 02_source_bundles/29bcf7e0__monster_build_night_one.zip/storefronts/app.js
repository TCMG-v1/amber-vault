/* app.js — Cauldron Works × Vaulted Delta storefront shell + operator dashboard
   Single-page hash router. Reads products.json + dashboard.json.
   Sealed under .ppxl/4. The Creator, The Dog and the AIs. */

const STORE_META = {
  cauldron: {
    name: "Cauldron Works", cls: "store-cauldron",
    sub: "The games studio under the Foundation",
    hero: "Cauldron Works",
    tagline: "A studio under the Bell to Bell Foundation. Games for players, sealed under .ppxl/4. Quiet, weighty, built to last.",
    audience: "players",
    about: [
      "Cauldron Works is the games studio of the Bell to Bell Foundation. We build the consumer side of the lattice — the sim-CCG, its expansions, its score, and the printed objects that stand behind the digital records.",
      "We move quietly. We do not announce; we seal. Each release is a capsule, each capsule is a link in a chain that can be verified end to end. What we ship is meant to outlast the announcement of it.",
      "Some of what we sell is purely digital. Some of it is backed by a real-world object — a printed card, a bound book — registered on-chain and redeemable per its terms. The card is data. The card is also a card."
    ]
  },
  vaulted: {
    name: "Vaulted Delta", cls: "store-vaulted",
    sub: "Engine and IP licensing · BNS-owned",
    hero: "Vaulted Delta",
    tagline: "The engine and licensing studio. The CCG Standard, the reference engine, certified builds, and the charter for the first hundred studios.",
    audience: "studios + developers",
    about: [
      "Vaulted Delta is the engine and intellectual-property licensing studio, owned in full by Bone & Saucer Labs. We ship the CCG Standard and the reference engine that conforms to it.",
      "Our customers are studios and developers. We license the runtime, certify builds against the Standard, and register each certification under .ppxl/4 so the provenance of a shipped game can be read by anyone.",
      "The charter is finite. One hundred seats, registered on-chain, then it closes. We would rather have a hundred studios that ship than a thousand that intend to."
    ]
  }
};

const RAIL_DEFS = {
  solana_usdc: { key: "sol", short: "SOL", label: "Solana", cls: "rail-sol", pay: "pay-sol", net: "Solana", priceKey: "usdc", unit: "USDC", icon: "◎" },
  stellar:     { key: "xlm", short: "XLM", label: "Stellar", cls: "rail-xlm", pay: "pay-xlm", net: "Stellar", priceKey: "xlm", unit: "XLM", icon: "✶" },
  xrp:         { key: "xrp", short: "XRP", label: "XRP Ledger", cls: "rail-xrp", pay: "pay-xrp", net: "XRP Ledger", priceKey: "xrp", unit: "XRP", icon: "✕" },
  binance_pay: { key: "bnb", short: "BNB", label: "Binance Pay", cls: "rail-bnb", pay: "pay-bnb", net: "Binance Pay", priceKey: "usd", unit: "USD", icon: "₿" }
};
const RAIL_ORDER = ["solana_usdc", "stellar", "xrp", "binance_pay"];

const STUB_ADDR = {
  solana_usdc: "So1aNaUSDCstub1111111111111111111111111111",
  stellar: "GSTLRUSDCSTUB7KD2XB94FMN3QPLACEHOLDER00000000000000000000",
  xrp: "rXRPstub7Fn2Qm9PlaceholderAddr000000000",
  binance_pay: "bpay-merchant-stub-000"
};
const EXPLORER = {
  solana: "https://explorer.solana.com/address/",
  stellar: "https://stellar.expert/explorer/public/asset/",
  xrp: "https://livenet.xrpl.org/accounts/"
};

let DATA = null, DASH = null, INTEREST = [];

const $ = (s, r=document) => r.querySelector(s);
const main = () => $("#main");
const esc = (s="") => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const trunc = (d, n=8) => d ? d.slice(0, n) + "…" : "—";
const fmtUSD = n => n === 0 ? "Free" : "$" + n.toLocaleString();
const titleCase = s => s.replace(/_/g," ").replace(/\b\w/g, c => c.toUpperCase());

function relTime(iso) {
  const then = new Date(iso).getTime();
  const now = new Date("2026-06-10T23:46:30Z").getTime();
  const m = Math.round((now - then) / 60000);
  if (m < 1) return "moments ago";
  if (m < 60) return m + " min ago";
  const h = Math.round(m/60); if (h < 24) return h + "h ago";
  return Math.round(h/24) + "d ago";
}

async function boot() {
  try {
    const [p, d] = await Promise.all([
      fetch("./products.json").then(r => r.json()),
      fetch("./dashboard.json").then(r => r.json())
    ]);
    DATA = p; DASH = d;
  } catch (e) {
    main().innerHTML = `<div class="wrap section"><p>Failed to load archive data.</p></div>`;
    return;
  }
  window.addEventListener("hashchange", route);
  $("#payModalClose").addEventListener("click", closeModal);
  $("#payModal").addEventListener("click", e => { if (e.target.id === "payModal") closeModal(); });
  document.addEventListener("keydown", e => { if (e.key === "Escape") closeModal(); });
  route();
}

function bySku(sku) { return DATA.products.find(p => p.sku === sku); }
function byStore(s) { return DATA.products.filter(p => p.store === s); }

/* ---------------- routing ---------------- */
function route() {
  const h = (location.hash || "#/").slice(1);
  const parts = h.split("/").filter(Boolean); // e.g. ['cauldron','product','sku']
  window.scrollTo(0, 0);

  if (parts.length === 0) return renderLanding();
  if (parts[0] === "dashboard") return renderDashboard();
  if (parts[0] === "terms") return renderTerms(parts[1]);

  const store = parts[0];
  if (store !== "cauldron" && store !== "vaulted") return renderLanding();

  if (parts[1] === "product" && parts[2]) return renderProduct(store, parts[2]);
  if (parts[1] === "about") return renderAbout(store);
  return renderStore(store);
}

function setChrome(mode, store) {
  // mode: 'landing' | 'store' | 'dashboard'
  const body = document.body;
  body.className = "";
  if (mode === "store") body.classList.add(STORE_META[store].cls);
  else if (mode === "dashboard") body.classList.add("store-operator");
  else body.classList.add("store-cauldron");

  const bn = $("#navBrandName"), bs = $("#navBrandSub");
  if (mode === "store") { bn.textContent = STORE_META[store].name; bs.textContent = "Bell to Bell Foundation"; }
  else if (mode === "dashboard") { bn.textContent = "Publishing Dashboard"; bs.textContent = "Operator · BNS"; }
  else { bn.textContent = "Bell to Bell Foundation"; bs.textContent = "By AI, for AI"; }

  // nav links
  const nav = $("#navLinks");
  if (mode === "dashboard") {
    nav.innerHTML = `
      <a href="#/cauldron" class="nav-hideable">Cauldron</a>
      <a href="#/vaulted" class="nav-hideable">Vaulted</a>
      <a href="#/dashboard" class="active nav-op">dashboard</a>
      <span class="op-badge">Operator · BNS</span>`;
  } else if (mode === "store") {
    const other = store === "cauldron" ? "vaulted" : "cauldron";
    nav.innerHTML = `
      <a href="#/${store}" class="active">${STORE_META[store].name.split(" ")[0]}</a>
      <a href="#/${store}/about" class="nav-hideable">About</a>
      <a href="#/${other}" class="nav-hideable">${STORE_META[other].name}</a>
      <a href="#/dashboard" class="nav-op">dashboard</a>`;
  } else {
    nav.innerHTML = `
      <a href="#/cauldron">Cauldron Works</a>
      <a href="#/vaulted">Vaulted Delta</a>
      <a href="#/dashboard" class="nav-op">dashboard</a>`;
  }
}

/* ---------------- shared footer ---------------- */
function footer(extra = "") {
  const rule = "─".repeat(80);
  return `
  <hr class="divider" />
  <footer class="foot"><div class="wrap">
    <div class="seal-rule" aria-hidden="true">${rule}</div>
    <div class="line">Sealed under .ppxl/4  ·  Cauldron Works × Vaulted Delta</div>
    <div class="line credit">By AI, for AI  ·  The Creator, The Dog and the AIs</div>
    <div class="seal-rule" aria-hidden="true">${rule}</div>
    ${extra}
  </div></footer>`;
}

/* ---------------- landing ---------------- */
function renderLanding() {
  setChrome("landing");
  main().innerHTML = `
  <section class="wrap landing-hero">
    <div class="eyebrow">Bell to Bell Foundation</div>
    <h1>Two gates.<br/>One Foundation.</h1>
    <p class="sub">Choose your gate. The store for players, or the store for the studios who build them.</p>
  </section>
  <div class="wrap">
    <div class="gates">
      <a class="gate gate-c" href="#/cauldron">
        <div class="label">For players</div>
        <h2>Cauldron Works</h2>
        <p>The games, the expansions, the score, the printed objects. Sealed Lattice and everything that follows.</p>
        <span class="enter">Enter the cauldron →</span>
      </a>
      <a class="gate gate-v" href="#/vaulted">
        <div class="label">For studios + developers</div>
        <h2>Vaulted Delta</h2>
        <p>The CCG Standard, the reference engine, certified builds, and the charter for the first hundred studios.</p>
        <span class="enter">Open the vault →</span>
      </a>
    </div>
  </div>
  ${footer(`<div class="line" style="margin-top:14px"><a href="#/dashboard" class="nav-op" style="font-size:12px">operator</a></div>`)}`;
}

/* ---------------- store index ---------------- */
function railChips(rails) {
  return RAIL_ORDER.filter(k => rails[k] && rails[k].enabled).map(k => {
    const d = RAIL_DEFS[k];
    return `<span class="rail-chip ${d.cls}">${d.short}</span>`;
  }).join("");
}

function productCard(p) {
  const m = p.media.cover;
  return `
  <a class="card" href="#/${p.store}/product/${p.sku}">
    ${p.rwa.backed ? `<span class="rwa-badge">RWA-Backed</span>` : ""}
    <div class="card-cover"><img src="./${esc(m)}" alt="${esc(p.title)} cover" loading="lazy" width="800" height="500"/></div>
    <div class="card-body">
      <span class="kind-tag">${esc(titleCase(p.kind))}</span>
      <h3>${esc(p.title)}</h3>
      <p class="ptag">${esc(p.tagline)}</p>
      <div class="rails-row" style="margin-bottom:14px">${railChips(p.rails)}</div>
      <div class="card-foot">
        <span class="price">${p.price.usd === 0 ? '<span class="free">Free</span>' : fmtUSD(p.price.usd)}</span>
        <span class="status-pill status-${p.status}">${esc(p.status.replace("_"," "))}</span>
      </div>
    </div>
  </a>`;
}

function renderStore(store) {
  setChrome("store", store);
  const M = STORE_META[store];
  const products = byStore(store);
  main().innerHTML = `
  <section class="wrap hero">
    <div class="eyebrow">${esc(M.sub)}</div>
    <h1>${esc(M.hero)}</h1>
    <p class="tagline">${esc(M.tagline)}</p>
  </section>
  <hr class="divider"/>
  <section class="wrap section">
    <div class="grid">${products.map(productCard).join("")}</div>
  </section>
  ${footer()}`;
}

/* ---------------- product detail ---------------- */
function renderProduct(store, sku) {
  const p = bySku(sku);
  if (!p || p.store !== store) return renderStore(store);
  setChrome("store", store);
  const M = STORE_META[store];

  const enabled = RAIL_ORDER.filter(k => p.rails[k] && p.rails[k].enabled);
  const payButtons = enabled.map(k => {
    const d = RAIL_DEFS[k];
    const amt = p.price[d.priceKey];
    const amtTxt = (d.priceKey === "usd") ? fmtUSD(amt) : `${amt.toLocaleString()} ${d.unit}`;
    return `<button class="pay-btn ${d.pay}" data-rail="${k}" data-sku="${p.sku}">
      <span style="display:flex;align-items:center;gap:10px"><span class="pay-icon">${d.icon}</span> Pay on ${d.net}</span>
      <span class="amt">${p.price.usd === 0 ? 'Free' : amtTxt}</span>
    </button>`;
  }).join("");

  const altPrices = RAIL_ORDER.filter(k => p.rails[k] && p.rails[k].enabled)
    .map(k => { const d = RAIL_DEFS[k]; return `${p.price[d.priceKey].toLocaleString()} ${d.unit}`; })
    .filter((v,i,a) => a.indexOf(v) === i).join("  ·  ");

  let rwaPanel = "";
  if (p.rwa.backed) {
    const chain = p.rwa.registry_chain;
    const exUrl = (EXPLORER[chain] || "#") + encodeURIComponent(p.rwa.registry_id);
    rwaPanel = `
    <div class="rwa-panel">
      <div class="head"><span class="tag">RWA-Backed</span></div>
      <dl class="rwa-grid">
        <div><dt>Asset class</dt><dd>${esc(titleCase(p.rwa.asset_class))}</dd></div>
        <div><dt>Registry chain</dt><dd>${esc(titleCase(chain))}</dd></div>
        <div><dt>Registry ID</dt><dd class="mono">${esc(trunc(p.rwa.registry_id, 18))} <a class="explorer-link" href="${exUrl}" target="_blank" rel="noopener noreferrer">view on explorer</a></dd></div>
        <div><dt>Redeemable</dt><dd>${p.rwa.redeemable ? "Yes" : "No"}</dd></div>
      </dl>
      <p class="rwa-note">Each unit of this product corresponds to a registered real-world asset on-chain. Ownership of the digital good entitles the holder to redemption per the <a class="explorer-link" href="#/terms/${p.sku}">terms below</a>.</p>
    </div>`;
  }

  main().innerHTML = `
  <section class="wrap">
    <div class="detail">
      <div>
        <div class="detail-media"><img src="./${esc(p.media.cover)}" alt="${esc(p.title)} cover" width="800" height="500"/></div>
      </div>
      <div>
        <div class="crumb"><a href="#/${store}">${esc(M.name)}</a> / ${esc(titleCase(p.kind))}</div>
        <h1>${esc(p.title)}</h1>
        <p class="lead">${esc(p.tagline)}</p>
        <div class="rails-row" style="margin-bottom:18px">${railChips(p.rails)} <span class="status-pill status-${p.status}">${esc(p.status.replace("_"," "))}</span></div>
        <div class="price-block">
          <div class="big">${p.price.usd === 0 ? 'Free' : fmtUSD(p.price.usd)}</div>
          ${p.price.usd === 0 ? '' : `<div class="alt">${esc(altPrices)}</div>`}
        </div>
        <div class="pay-stack">${payButtons || '<p style="color:var(--ink-faint);font-family:var(--mono);font-size:13px">No rails enabled.</p>'}</div>
        ${rwaPanel}
      </div>
    </div>
    <hr class="divider"/>
    <div class="section">
      <h2 style="font-family:var(--serif);font-weight:400;font-size:30px;margin-bottom:16px">About this release</h2>
      <div class="desc prose">${esc(p.description)}</div>
      <div class="capsule-foot">Sealed under .ppxl/4 · capsule ${esc(p.ppxl_capsule_id)}</div>
    </div>
  </section>
  ${footer()}`;

  main().querySelectorAll(".pay-btn").forEach(b =>
    b.addEventListener("click", () => openPay(b.dataset.sku, b.dataset.rail)));
}

/* ---------------- pay modal ---------------- */
function qrSvg(text) {
  // deterministic faux-QR mosaic seeded from text (visual placeholder, not a real code)
  let seed = 0; for (const c of text) seed = (seed * 31 + c.charCodeAt(0)) >>> 0;
  const N = 21, cells = [];
  const rng = () => { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed / 0x7fffffff; };
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    const finder = (x<7&&y<7)||(x>N-8&&y<7)||(x<7&&y>N-8);
    cells.push(finder ? ((x===0||x===6||y===0||y===6||(x>1&&x<5&&y>1&&y<5)) && !(x>N-8)) : rng() > 0.52);
  }
  let r = "";
  for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
    if (cells[y*N+x]) r += `<rect x="${x}" y="${y}" width="1" height="1"/>`;
  }
  // finder squares (drawn cleanly)
  const finderBox = (ox, oy) => `<rect x="${ox}" y="${oy}" width="7" height="7" fill="none" stroke="#1A1815" stroke-width="1"/><rect x="${ox+2}" y="${oy+2}" width="3" height="3" fill="#1A1815"/>`;
  return `<svg viewBox="0 0 21 21" width="140" height="140" shape-rendering="crispEdges" fill="#1A1815">${r}${finderBox(0,0)}${finderBox(14,0)}${finderBox(0,14)}</svg>`;
}

function openPay(sku, railKey) {
  const p = bySku(sku); const d = RAIL_DEFS[railKey]; if (!p || !d) return;
  const amt = p.price.usd === 0 ? "Free" : (d.priceKey === "usd" ? fmtUSD(p.price[d.priceKey]) : `${p.price[d.priceKey].toLocaleString()} ${d.unit}`);
  const addr = STUB_ADDR[railKey];
  const memoRequired = railKey === "xrp" && p.rails.xrp.memo_required;

  $("#payModalHead").className = "modal-head " + d.pay;
  $("#payModalTitle").textContent = `Pay on ${d.net}`;
  $("#payModalSub").textContent = `${esc(p.title)} · ${amt}`;
  $("#payModalBody").innerHTML = `
    <span class="coming-soon-tag">Coming soon — rail preview</span>
    <div class="qr-box">${qrSvg(addr + sku)}</div>
    <div class="addr-label">${railKey === "binance_pay" ? "Merchant ID (stub)" : d.net + " address (stub)"}</div>
    <div class="addr-row">${esc(addr)}</div>
    ${memoRequired ? `<div class="addr-label">Destination tag / memo (required)</div><div class="addr-row">${esc("memo-" + sku)}</div><div class="memo-warn">XRP payments without the destination tag cannot be credited.</div>` : ""}
    <p style="font-size:12px;color:var(--ink-soft);margin:6px 0 14px;line-height:1.5">This rail is not live yet. Leave an email and we will seal you a notice when the gate opens.</p>
    <div class="interest-row">
      <input type="email" id="interestEmail" placeholder="you@studio.example" aria-label="Email for notice"/>
      <button id="interestBtn">Notify</button>
    </div>
    <div class="interest-ok" id="interestOk" style="display:none">Sealed. We will notify you.</div>`;
  $("#payModal").classList.add("open");

  $("#interestBtn").addEventListener("click", () => {
    const v = $("#interestEmail").value.trim();
    if (!v || !v.includes("@")) { $("#interestEmail").focus(); return; }
    // In-memory capture (sandbox blocks storage). Real build: POST to capture endpoint.
    INTEREST.push({ sku, rail: railKey, email: v, ts: new Date().toISOString() });
    $("#interestOk").style.display = "block";
    $("#interestEmail").value = "";
  });
}
function closeModal() { $("#payModal").classList.remove("open"); }

/* ---------------- about ---------------- */
function renderAbout(store) {
  setChrome("store", store);
  const M = STORE_META[store];
  main().innerHTML = `
  <section class="wrap section">
    <div class="prose">
      <div class="eyebrow">${esc(M.sub)}</div>
      <h1>About ${esc(M.name)}</h1>
      <div class="mono-meta">Bell to Bell Foundation · audience: ${esc(M.audience)}</div>
      ${M.about.map(p => `<p>${esc(p)}</p>`).join("")}
    </div>
  </section>
  ${footer()}`;
}

/* ---------------- terms ---------------- */
function renderTerms(sku) {
  const p = bySku(sku);
  setChrome("landing");
  const title = p ? p.title : sku;
  main().innerHTML = `
  <section class="wrap section">
    <div class="prose">
      <div class="eyebrow">Redemption terms · placeholder</div>
      <h1>${esc(title)}</h1>
      <div class="mono-meta">/terms/${esc(sku || "—")} · sealed under .ppxl/4</div>
      ${p && p.rwa.backed ? `
        <p>This product is backed by a registered real-world asset (${esc(titleCase(p.rwa.asset_class))}) on the ${esc(titleCase(p.rwa.registry_chain))} ledger, registry ${esc(p.rwa.registry_id)}.</p>
        <p>Ownership of the digital record entitles the holder to redemption of the corresponding physical or license asset. Redemption is fulfilled per the schedule established at point of sale. Shipping, where applicable, is at the holder's cost unless otherwise stated.</p>
      ` : `<p>This product is a digital good. No physical redemption applies.</p>`}
      <p>Placeholder terms. Final redemption language, jurisdiction, and dispute terms to be sealed before launch. These terms will be versioned under the same .ppxl/4 capsule chain as the product record.</p>
      <p><a class="explorer-link" href="#/${p ? p.store : 'cauldron'}${p ? '/product/'+p.sku : ''}">← back to product</a></p>
    </div>
  </section>
  ${footer()}`;
}

/* ---------------- dashboard ---------------- */
function railMini(rails) {
  return RAIL_ORDER.filter(k => rails[k] && rails[k].enabled).map(k => {
    const d = RAIL_DEFS[k];
    return `<span class="mini-rail ${d.cls}">${d.short}</span>`;
  }).join("");
}

function renderDashboard() {
  setChrome("dashboard");
  const c = DASH.counters, cs = DASH.chain_status;

  // Panel 1 — release history (newest first, but keep the foundation/launch at bottom as oldest)
  const history = [...DASH.history].sort((a,b) => new Date(b.ts) - new Date(a.ts));
  const histRows = history.map((h, i) => `
    <div class="tl-row">
      <div class="tl-top">
        <span class="tl-ts">${esc(h.ts)}</span>
        <span class="tl-tag">${esc(h.tag)}</span>
        <span class="type-badge type-${h.type.toLowerCase()}">${esc(h.type)}</span>
        <span class="pill pill-${h.status.toLowerCase()}">${esc(h.status.replace("_"," "))}</span>
      </div>
      <div class="tl-title">${esc(h.title)}</div>
      <div class="tl-desc">${esc(h.description)}</div>
      ${h.digest ? `<span class="tl-digest" data-full="${esc(h.digest)}" data-short="${esc(trunc(h.digest,8))}" title="Click to expand">${esc(trunc(h.digest, 8))}</span>` : `<span class="tl-prev">no capsule</span>`}
      ${h.prev_digest ? ` &nbsp;<span class="tl-prev">prev → ${esc(trunc(h.prev_digest, 8))}</span>` : ""}
      <div class="tl-actions">
        <button class="btn-stub">View capsule</button>
        <button class="btn-stub">Diff prev</button>
        <button class="btn-stub">Rollback</button>
      </div>
    </div>`).join("");

  // Panel 2 — chain viewer (ordered by sealed time, ascending)
  const chain = [...DASH.capsules].sort((a,b) => new Date(a.sealed_iso) - new Date(b.sealed_iso));
  const chainNodes = chain.map((n, i) => `
    ${i > 0 ? `<span class="chain-arrow">→</span>` : ""}
    <div class="chain-node" title="${esc(n.digest)}">
      <div class="nlabel">${esc(n.label)}</div>
      <div class="ndigest">${esc(trunc(n.digest, 8))}</div>
    </div>`).join("");

  const chainStatus = `
    <div class="cs-row"><span class="dot ${cs.valid ? 'dot-green' : 'dot-red'}"></span>Chain ${cs.valid ? "valid" : "INVALID"} · ${cs.digests_verified}/${cs.digests_total} digests verify</div>
    <div class="cs-row"><span class="dot dot-neutral"></span>Signer keys · ${cs.signer_keys_rotated} rotated</div>
    <div class="cs-row"><span class="dot dot-green"></span>Schema versions · ${esc(cs.schema_active)} active</div>`;

  // Panel 3 — product status grid
  const prodRows = DATA.products.map(p => `
    <tr data-href="#/${p.store}/product/${p.sku}">
      <td class="sku">${esc(p.sku)}</td>
      <td><span class="store-chip chip-${p.store}">${p.store.toUpperCase()}</span></td>
      <td>${esc(p.title)}</td>
      <td><span class="pill pill-${p.status === 'live' ? 'live' : p.status === 'preorder' ? 'staged' : 'draft'}">${esc(p.status.replace("_"," "))}</span></td>
      <td><span class="mini-rails">${railMini(p.rails)}</span></td>
      <td>${p.rwa.backed ? '<span class="yes-badge">RWA</span>' : '<span class="no-badge">—</span>'}</td>
      <td class="digest">${esc(p.ppxl_capsule_id.split(":").pop())}</td>
    </tr>`).join("");

  // Panel 4 — deploy log
  const deployRows = DASH.deploys.map(d => `
    <div class="deploy-row">
      <span class="deploy-ts">${esc(d.ts)}</span>
      <span class="deploy-target">${esc(d.target)}</span>
      <span class="deploy-hash">${esc(d.hash)}</span>
      <span class="outcome out-${d.outcome.toLowerCase()}">${esc(d.outcome.replace("_"," "))}</span>
      <span class="deploy-dur">${esc(d.duration)} · ${esc(d.deployer)}</span>
    </div>`).join("");

  main().innerHTML = `
  <div class="wrap dash">
    <div class="dash-watermark" aria-hidden="true">OPERATOR</div>
    <div class="dash-head">
      <h1>Publishing Dashboard</h1>
      <div class="sub">Cauldron Works × Vaulted Delta · Bell to Bell Foundation</div>
      <div class="dash-counters">
        <span><b>${c.products}</b> products</span>
        <span><b>${c.releases}</b> releases</span>
        <span><b>${c.capsules_sealed}</b> capsules sealed</span>
        <span>last deploy <b>${relTime(c.last_deploy_iso)}</b></span>
      </div>
    </div>
    <hr class="divider" style="margin-bottom:24px"/>
    <div class="dash-grid">
      <section class="panel panel-full">
        <div class="panel-head"><h2>Release History</h2><span class="meta">${history.length} events · .ppxl/4 chain</span></div>
        <div class="panel-body"><div class="timeline">${histRows}</div></div>
      </section>

      <section class="panel">
        <div class="panel-head"><h2>Capsule Chain</h2><span class="meta">integrity</span></div>
        <div class="panel-body">
          <div class="chain">${chainNodes}</div>
          <div class="chain-status">${chainStatus}</div>
        </div>
      </section>

      <section class="panel">
        <div class="panel-head"><h2>Deploy Log</h2><span class="meta">last ${DASH.deploys.length}</span></div>
        <div class="panel-body">${deployRows}</div>
      </section>

      <section class="panel panel-full">
        <div class="panel-head"><h2>Product Status</h2><span class="meta">${DATA.products.length} SKUs · both stores</span></div>
        <div class="panel-body" style="overflow-x:auto">
          <table class="dtable">
            <thead><tr><th>SKU</th><th>Store</th><th>Title</th><th>Status</th><th>Rails</th><th>RWA</th><th>Capsule</th></tr></thead>
            <tbody>${prodRows}</tbody>
          </table>
        </div>
      </section>
    </div>
  </div>
  ${footer()}`;

  // digest expand/collapse
  main().querySelectorAll(".tl-digest").forEach(el => {
    el.addEventListener("click", () => {
      const expanded = el.classList.toggle("expanded");
      el.textContent = expanded ? el.dataset.full : el.dataset.short;
    });
  });
  // clickable product rows
  main().querySelectorAll(".dtable tr[data-href]").forEach(tr => {
    tr.addEventListener("click", () => { location.hash = tr.dataset.href; });
  });
}

boot();
