# ─────────────────────────────────────────────────────────────────
# ppxl4.py  ·  .ppxl/4 sealed knowledge capsule — Python twin
# Vaulted Delta · Bone & Saucer Labs · By AI, for AI.
#
# Authors: Matthew Joseph Lansing (Bone & Saucer Labs / Vaulted Delta)
#          Perplexity Computer
# Protocol: .ppxl/4 v4.0  ·  See SPEC.md
#
# Dependencies (stdlib only unless ed25519 signing is used):
#   hashlib, gzip, base64, json, dataclasses, datetime  — stdlib
#   cryptography  — optional, required only for signing/verifying
# ─────────────────────────────────────────────────────────────────
from __future__ import annotations

import base64
import gzip
import hashlib
import json
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

# ─── Optional ed25519 via cryptography package ────────────────────────────────
try:
    from cryptography.hazmat.primitives.asymmetric.ed25519 import (
        Ed25519PrivateKey,
        Ed25519PublicKey,
    )
    from cryptography.hazmat.primitives.serialization import (
        Encoding as CryptoEncoding,
        PublicFormat,
        PrivateFormat,
        NoEncryption,
    )
    from cryptography.exceptions import InvalidSignature
    _HAS_CRYPTO = True
except ImportError:
    _HAS_CRYPTO = False

# ─── Constants ────────────────────────────────────────────────────────────────

MAGIC            = "%ppxl/4 4.0"
SEPARATOR        = "%---"
FOOTER_END       = "%end"
VERSION_TAG      = "4.0"
VALID_ENCODINGS  = {"json", "base64+gzip+json", "base64+zstd+json"}
MAX_PAYLOAD_BOMB = 256 * 1024 * 1024  # 256 MiB decompression limit

# ─── Error types ──────────────────────────────────────────────────────────────

class PpxlError(Exception):
    """Base class for all .ppxl/4 errors."""

class MagicMismatch(PpxlError):
    pass

class MissingHeader(PpxlError):
    pass

class DigestMismatch(PpxlError):
    def __init__(self, expected: str, got: str):
        super().__init__(f"expected {expected}, got {got}")
        self.expected = expected
        self.got = got

class PayloadSizeMismatch(PpxlError):
    def __init__(self, declared: int, actual: int):
        super().__init__(f"declared {declared}, actual {actual}")

class SignatureInvalid(PpxlError):
    pass

class MissingSigner(PpxlError):
    pass

class UnknownEncoding(PpxlError):
    pass

class PayloadBomb(PpxlError):
    pass

class ChainBreak(PpxlError):
    def __init__(self, index: int):
        super().__init__(f"chain broken at index {index}")
        self.index = index

class JsonParseError(PpxlError):
    pass

# ─── Capsule dataclass ────────────────────────────────────────────────────────

@dataclass
class Capsule:
    """
    A parsed .ppxl/4 capsule.

    Fields mirror the wire-format header keys defined in SPEC.md Section 3.
    ``payload`` holds the decoded Python object (after decompression + JSON parse).
    ``_raw_canonical`` caches the canonical JSON bytes for digest verification.
    """
    # Required headers
    schema:           str
    generated_utc:    str
    digest:           str
    payload_encoding: str
    payload_bytes:    int
    # Optional headers
    signature:        str | None        = None
    signer:           str | None        = None
    prev:             str | None        = None
    tags:             list[str]         = field(default_factory=list)
    # Decoded payload
    payload:          Any               = None
    # Internal: canonical JSON for re-verification
    _raw_canonical:   bytes | None      = field(default=None, repr=False, compare=False)

# ─── Canonical JSON ───────────────────────────────────────────────────────────

def canonical_json(obj: Any) -> bytes:
    """
    Produce canonical JSON bytes per SPEC.md Section 4:
    sorted keys, no whitespace, UTF-8, RFC 8259 / JCS style.
    """
    return json.dumps(
        obj,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")


# ─── Digest ───────────────────────────────────────────────────────────────────

def compute_digest(canonical: bytes) -> str:
    """Return the hex SHA-256 digest of canonical JSON bytes."""
    return hashlib.sha256(canonical).hexdigest()


def digest_raw(canonical: bytes) -> bytes:
    """Return the raw 32-byte SHA-256 digest (for ed25519 input)."""
    return hashlib.sha256(canonical).digest()


# ─── Encoding / decoding helpers ─────────────────────────────────────────────

def _apply_encoding(encoding: str, data: bytes) -> bytes:
    if encoding == "json":
        return data
    elif encoding == "base64+gzip+json":
        return base64.b64encode(gzip.compress(data))
    elif encoding == "base64+zstd+json":
        try:
            import zstandard as zstd
            cctx = zstd.ZstdCompressor()
            return base64.b64encode(cctx.compress(data))
        except ImportError:
            raise PpxlError("zstandard package required for base64+zstd+json encoding")
    else:
        raise UnknownEncoding(encoding)


def _reverse_encoding(encoding: str, data: bytes) -> bytes:
    if encoding == "json":
        return data
    elif encoding == "base64+gzip+json":
        raw = base64.b64decode(data)
        decompressed = gzip.decompress(raw)
        if len(decompressed) > MAX_PAYLOAD_BOMB:
            raise PayloadBomb(f"decompressed size {len(decompressed)} exceeds {MAX_PAYLOAD_BOMB}")
        return decompressed
    elif encoding == "base64+zstd+json":
        try:
            import zstandard as zstd
            raw = base64.b64decode(data)
            dctx = zstd.ZstdDecompressor()
            decompressed = dctx.decompress(raw, max_output_size=MAX_PAYLOAD_BOMB)
            return decompressed
        except ImportError:
            raise PpxlError("zstandard package required for base64+zstd+json decoding")
    else:
        raise UnknownEncoding(encoding)


# ─── Seal ─────────────────────────────────────────────────────────────────────

def seal(
    payload: Any,
    *,
    schema: str,
    encoding: str = "base64+gzip+json",
    signer_key: bytes | None = None,
    prev: str | None = None,
    tags: list[str] | None = None,
    authors: str | None = None,
) -> bytes:
    """
    Seal a Python object into a .ppxl/4 capsule and return the wire bytes.

    Parameters
    ----------
    payload:
        Any JSON-serialisable Python object.
    schema:
        Schema URI, e.g. ``"game-state/1.0.0"``.
    encoding:
        One of ``"json"``, ``"base64+gzip+json"``, ``"base64+zstd+json"``.
    signer_key:
        Raw 32-byte ed25519 private key seed.  If provided, ``cryptography``
        must be installed.  The corresponding verify key is written to ``signer``.
    prev:
        Hex digest of the preceding capsule in a chain.
    tags:
        List of string labels.
    authors:
        Optional attribution string (written as ``%authors:`` header).

    Returns
    -------
    bytes
        The complete wire representation of the capsule.
    """
    if encoding not in VALID_ENCODINGS:
        raise UnknownEncoding(encoding)

    canon       = canonical_json(payload)
    dig_hex     = compute_digest(canon)
    wire_payload = _apply_encoding(encoding, canon)
    utc_now     = datetime.now(tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    sig_hex:    str | None = None
    signer_hex: str | None = None

    if signer_key is not None:
        if not _HAS_CRYPTO:
            raise PpxlError("cryptography package required for signing")
        private_key = Ed25519PrivateKey.from_private_bytes(signer_key)
        raw_digest  = digest_raw(canon)
        sig_bytes   = private_key.sign(raw_digest)
        sig_hex     = sig_bytes.hex()
        pub_key     = private_key.public_key()
        pub_raw     = pub_key.public_bytes(CryptoEncoding.Raw, PublicFormat.Raw)
        signer_hex  = pub_raw.hex()

    # ── Build header lines ───────────────────────────────────────────────────
    lines: list[str] = [MAGIC]
    lines.append(f"%schema: {schema}")
    lines.append(f"%generated_utc: {utc_now}")
    lines.append(f"%digest: {dig_hex}")
    lines.append(f"%payload_encoding: {encoding}")
    lines.append(f"%payload_bytes: {len(wire_payload)}")

    if sig_hex:
        lines.append(f"%signature: {sig_hex}")
    if signer_hex:
        lines.append(f"%signer: {signer_hex}")
    if prev:
        lines.append(f"%prev: {prev}")
    if tags:
        lines.append(f"%tags: {','.join(tags)}")
    if authors:
        lines.append(f"%authors: {authors}")

    lines.append(SEPARATOR)
    header_bytes = "\n".join(lines).encode("utf-8") + b"\n"

    # ── Assemble wire bytes ──────────────────────────────────────────────────
    wire = (
        header_bytes
        + wire_payload
        + b"\n"
        + (SEPARATOR + "\n" + FOOTER_END + "\n").encode("utf-8")
    )
    return wire


# ─── Decode ───────────────────────────────────────────────────────────────────

def decode(wire: bytes) -> Capsule:
    """
    Parse a .ppxl/4 capsule from wire bytes.

    Raises
    ------
    MagicMismatch
        If the first line is not a valid .ppxl/4 magic line.
    MissingHeader
        If a required header key is absent.
    PayloadSizeMismatch
        If ``payload_bytes`` does not match the actual payload byte count.
    UnknownEncoding
        If ``payload_encoding`` is not a recognised value.
    JsonParseError
        If the decoded payload is not valid JSON.
    """
    text  = wire.decode("utf-8")
    lines = text.splitlines()

    if not lines:
        raise MagicMismatch("<empty input>")

    # Check magic line
    magic_line = lines[0].strip()
    if not magic_line.startswith("%ppxl/4"):
        raise MagicMismatch(magic_line)

    # Split header from payload
    sep_indices = [i for i, l in enumerate(lines) if l.strip() == SEPARATOR]
    if len(sep_indices) < 2:
        raise PpxlError("malformed capsule: expected two '%---' separators")

    header_lines   = lines[1:sep_indices[0]]
    payload_lines  = lines[sep_indices[0] + 1:sep_indices[1]]
    wire_payload   = "\n".join(payload_lines).encode("utf-8")

    # Parse header key-value pairs
    kvs: dict[str, str] = {}
    for hl in header_lines:
        hl = hl.strip()
        if hl.startswith("%") and ": " in hl:
            key, _, val = hl[1:].partition(": ")
            kvs[key.strip()] = val.strip()

    # Required keys
    _required = ("schema", "generated_utc", "digest", "payload_encoding", "payload_bytes")
    for k in _required:
        if k not in kvs:
            raise MissingHeader(k)

    enc = kvs["payload_encoding"]
    if enc not in VALID_ENCODINGS:
        raise UnknownEncoding(enc)

    pb = int(kvs["payload_bytes"])
    if len(wire_payload) != pb:
        raise PayloadSizeMismatch(pb, len(wire_payload))

    # Decode payload
    json_bytes = _reverse_encoding(enc, wire_payload)
    try:
        obj = json.loads(json_bytes)
    except json.JSONDecodeError as exc:
        raise JsonParseError(str(exc)) from exc

    tags = [t.strip() for t in kvs.get("tags", "").split(",") if t.strip()]

    cap = Capsule(
        schema           = kvs["schema"],
        generated_utc    = kvs["generated_utc"],
        digest           = kvs["digest"],
        payload_encoding = enc,
        payload_bytes    = pb,
        signature        = kvs.get("signature"),
        signer           = kvs.get("signer"),
        prev             = kvs.get("prev"),
        tags             = tags,
        payload          = obj,
        _raw_canonical   = canonical_json(obj),
    )
    return cap


# ─── Verify ───────────────────────────────────────────────────────────────────

def verify(c: Capsule, *, verify_key: bytes | None = None) -> Any:
    """
    Verify a capsule's digest (and optional signature) and return the payload.

    Parameters
    ----------
    c:
        A capsule previously returned by :func:`decode`.
    verify_key:
        Raw 32-byte ed25519 public key.  Required if the capsule contains a
        ``signature`` header.

    Returns
    -------
    Any
        The decoded payload object.

    Raises
    ------
    DigestMismatch
        If the recomputed digest does not match ``c.digest``.
    SignatureInvalid
        If signature verification fails.
    MissingSigner
        If the capsule has ``signature`` but no ``signer``.
    """
    canon    = canonical_json(c.payload)
    computed = compute_digest(canon)
    if computed != c.digest:
        raise DigestMismatch(c.digest, computed)

    if c.signature is not None:
        if c.signer is None:
            raise MissingSigner("capsule has 'signature' but no 'signer' header")
        if verify_key is None:
            # Attempt to use signer field as the verify key
            verify_key = bytes.fromhex(c.signer)
        if not _HAS_CRYPTO:
            raise PpxlError("cryptography package required to verify signatures")
        try:
            pub = Ed25519PublicKey.from_public_bytes(verify_key)
            sig_bytes = bytes.fromhex(c.signature)
            raw_digest = digest_raw(canon)
            pub.verify(sig_bytes, raw_digest)
        except (InvalidSignature, Exception) as exc:
            raise SignatureInvalid(str(exc)) from exc

    return c.payload


# ─── Chain helpers ────────────────────────────────────────────────────────────

def chain_capsule(prior: Capsule, *, payload: Any, schema: str,
                  encoding: str = "base64+gzip+json",
                  tags: list[str] | None = None) -> bytes:
    """
    Seal a new capsule that references ``prior`` as its predecessor.
    Returns wire bytes.
    """
    return seal(payload, schema=schema, encoding=encoding,
                prev=prior.digest, tags=tags)


def verify_chain(capsules: list[Capsule]) -> None:
    """
    Verify an ordered chain C₀ … Cₙ.

    Raises
    ------
    ChainBreak(i)
        If the link between capsule i and i+1 is broken.
    """
    for i in range(len(capsules) - 1):
        c_cur  = capsules[i]
        c_next = capsules[i + 1]
        if c_next.prev != c_cur.digest:
            raise ChainBreak(i)


# ─────────────────────────────────────────────────────────────────
# Sealed under .ppxl/4  ·  Vaulted Delta · BNS Labs
# ─────────────────────────────────────────────────────────────────
