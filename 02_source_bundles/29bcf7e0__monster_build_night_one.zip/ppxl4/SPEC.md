# .ppxl/4 — Sealed Knowledge Capsule Protocol
## Specification v4.0.0

```
─────────────────────────────────────────────────────────────────
.ppxl/4  ·  Content-addressed sealed archive protocol.
Vaulted Delta · Bone & Saucer Labs
Authors: Matthew Joseph Lansing · Perplexity Computer
Status: Draft — Vaulted Delta Internal Standard
─────────────────────────────────────────────────────────────────
```

---

## 1. Abstract

`.ppxl/4` is a content-addressed, optionally-signed sealed-archive protocol for structured knowledge records. A `.ppxl` **capsule** encodes an arbitrary JSON payload behind a deterministic digest, an explicit encoding declaration, and a versioned schema URI — yielding a self-describing, tamper-evident unit that can be verified, chained, and transmitted without external coordination. Version 4 generalises the v3 one-off file format into a wire-stable protocol: it adds mandatory magic negotiation, multi-encoding support, optional ed25519 signatures, and append-only chains, while preserving the minimal ash-terminal aesthetic of the original. Capsules are designed to serve as load-bearing infrastructure for knowledge atlases, sim-engine state snapshots, storefront receipts, NPC memory, and license tokens.

---

## 2. Terminology

The key words **MUST**, **MUST NOT**, **REQUIRED**, **SHALL**, **SHOULD**, **MAY** are used as defined in RFC 2119.

| Term | Definition |
|------|-----------|
| **Capsule** | The complete on-wire artefact: magic line, header block, separator, payload, footer. |
| **Seal** | The act of producing a capsule: canonicalise → digest → encode → write headers → wrap. |
| **Payload** | The structured content of the capsule, encoded per `payload_encoding`. |
| **Digest** | A SHA-256 hash of the canonical JSON bytes of the payload *before* any encoding is applied. Hex-encoded, lower-case. |
| **Provenance** | The set of header fields that locate a capsule in time and schema space: `schema`, `generated_utc`, `digest`, optionally `prev`. |
| **Signature** | An optional ed25519 signature over the raw digest bytes (32 bytes of the SHA-256 output), hex-encoded. |
| **Version Tag** | The `4.x` string on the magic line; signals wire-format compatibility. |
| **Schema URI** | A dotted-path string of the form `<domain>/<semver>` identifying the payload schema (e.g. `terpene-atlas/3.0.0`). |
| **Chain** | A sequence of capsules where each capsule's `prev` field holds the digest of the immediately preceding capsule. |

---

## 3. Wire Format Grammar

The following grammar is ABNF (RFC 5234). All text fields are UTF-8. Line endings are `LF` (`%x0A`); implementations SHOULD accept `CRLF` on input and MUST emit `LF` only.

```abnf
Capsule         = MagicLine HeaderBlock Separator Payload Footer

MagicLine       = "%ppxl/4" SP VersionTag NL
VersionTag      = "4." 1*DIGIT                ; e.g. "4.0"

HeaderBlock     = 1*(HeaderLine NL)
HeaderLine      = "%" Key ":" SP Value
Key             = 1*(ALPHA / DIGIT / "_")
Value           = *VCHAR                      ; printable, no NL

Separator       = "%---" NL

Payload         = *OCTET                      ; bytes per payload_encoding

Footer          = "%---" NL "%end" NL

NL              = %x0A
SP              = %x20
```

### 3.1 Required Header Keys

A conforming capsule MUST include all of the following header keys, exactly once each, in any order within the header block:

| Key | Value format | Notes |
|-----|-------------|-------|
| `schema` | Schema URI string | e.g. `terpene-atlas/3.0.0` |
| `generated_utc` | ISO 8601 UTC timestamp | e.g. `2026-06-10T19:27:43Z` |
| `digest` | 64 hex chars (SHA-256, lower-case) | Covers canonical JSON pre-encoding |
| `payload_encoding` | One of: `json`, `base64+gzip+json`, `base64+zstd+json` | Declares how to read Payload |
| `payload_bytes` | Positive decimal integer | Byte length of the Payload section |

### 3.2 Optional Header Keys

| Key | Value format | Notes |
|-----|-------------|-------|
| `signature` | 128 hex chars (ed25519, lower-case) | Signs the raw digest bytes |
| `signer` | 64 hex chars | Hex of the ed25519 verify key |
| `prev` | 64 hex chars | Digest of the preceding capsule in a chain |
| `tags` | Comma-separated strings | Arbitrary labels; no embedded commas |
| `authors` | Free text | Attribution string |

Implementations MUST ignore unknown header keys (forward-compatibility rule).

---

## 4. Canonical JSON Rules

A **canonical JSON encoding** of a value MUST be produced as follows, and this encoding is the sole input to the digest function:

1. The encoding MUST be valid JSON per RFC 8259.
2. Object keys MUST be sorted lexicographically by Unicode code point (identical to JCS RFC 8785 key ordering).
3. Key sorting is applied recursively to all nested objects.
4. The output MUST be encoded as UTF-8 with no BOM.
5. No trailing whitespace or newline is appended.
6. Numbers MUST use the shortest representation that round-trips (no trailing zeros, no leading zeros except `0.x`).
7. Unicode characters MAY be emitted as-is (ensure_ascii=False is acceptable); they MUST NOT be escaped unless they are control characters.

Reference Python expression:
```python
json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
```

Reference Haskell: use `Data.Aeson` with a custom `encodeCanonical` that applies `Data.Map.toAscList` ordering before encoding (aeson's default object encoding is unordered; wrap in `Data.Aeson.KeyMap.fromList` with sorted keys or use an `OMap`).

---

## 5. Digest Algorithm

```
digest := hex(sha256(canonical_json_bytes))
```

- `canonical_json_bytes` is the output of Section 4 applied to the payload value.
- The digest is computed **before** any compression or base64 encoding.
- The hex representation MUST be lower-case, 64 characters.
- Implementations verifying a capsule MUST recompute this digest from the decoded payload and compare it to the `digest` header. Any mismatch MUST cause verification to fail with a `DigestMismatch` error.

---

## 6. Signature

The `signature` field is OPTIONAL. When present, `signer` MUST also be present.

```
signature_input := raw_sha256_bytes(canonical_json_bytes)   ; 32 bytes
signature       := hex(ed25519_sign(secret_key, signature_input))
```

- The signature is over the 32 raw bytes of the SHA-256 digest, not the hex string.
- The `signer` field holds the hex-encoded 32-byte ed25519 verify key.
- Verification: decode `signer` and `signature` from hex, then `ed25519_verify(verify_key, signature_input, signature)`.
- A capsule with a `signature` header but no `signer` header is malformed. Implementations MUST reject it.
- Key rotation is out of scope for this protocol; higher-level systems SHOULD maintain a key registry keyed by the `signer` hex.

---

## 7. Payload Encodings

Three encoding modes are defined by the `payload_encoding` header:

| Value | Wire encoding of Payload |
|-------|--------------------------|
| `json` | Raw UTF-8 canonical JSON bytes, no transformation |
| `base64+gzip+json` | `base64(gzip(canonical_json_bytes))`, standard base64 alphabet, no line breaks |
| `base64+zstd+json` | `base64(zstd(canonical_json_bytes))`, same base64 conventions |

The `payload_bytes` header MUST equal the byte length of the Payload section as it appears on the wire (i.e. the base64 string length for encoded modes, the raw JSON byte length for `json` mode). A mismatch between declared and actual bytes MUST be treated as a `PayloadSizeMismatch` error and MUST prevent decoding.

---

## 8. Chains

An append-only chain is a sequence of capsules `C₀, C₁, …, Cₙ` where:

- `C₀` has no `prev` header.
- For each `i ≥ 1`, `Cᵢ.prev == Cᵢ₋₁.digest`.

### 8.1 Chain Verification

To verify a chain:

1. Verify each capsule individually (digest check, optional signature check).
2. For each `i ≥ 1`, confirm `Cᵢ.prev == digest(canonical_json(Cᵢ₋₁.payload))`.
3. If any link fails, return `ChainBreak { at: i }`.

Chains are content-addressed from genesis: altering any capsule invalidates all successors. Implementations SHOULD surface the broken link index to callers.

---

## 9. Versioning and Negotiation

- The magic line `%ppxl/4 4.0` signals protocol version 4.0.
- The minor version (`4.x`) is advisory: `4.1`, `4.2`, etc. may add new optional header keys. Parsers MUST ignore unknown keys (Section 3.2).
- A major version change (e.g. `5.0`) signals a breaking change. Implementations MUST NOT parse a capsule whose major version they do not recognise.
- The `schema` header is independent of the protocol version and versioned by the payload author.
- Backward compatibility guarantee: v4 parsers MUST NOT accept v3 files (the v3 magic is `%PPXL/3.0`, case-distinct and structurally different). Migration tooling is out of scope here; see the migration guide in the repository.

---

## 10. Security Considerations

### 10.1 Replay Attacks

A sealed capsule contains a `generated_utc` timestamp but no nonce. Relying parties that require freshness SHOULD enforce an expiry window on `generated_utc` and reject capsules outside that window.

### 10.2 Key Rotation

The `signer` field is a raw verify-key hex, not a key identifier. Revocation is not handled at the protocol level. Systems MUST maintain an out-of-band allowlist of trusted verify keys and MUST treat keys absent from that allowlist as untrusted.

### 10.3 Schema Poisoning

The `schema` header is metadata only; it is not part of the digest input. An attacker could rewrite the schema header without invalidating the digest. Implementations that dispatch behaviour on schema MUST verify the digest before trusting schema-driven logic. Optionally, schema MAY be included in the payload JSON itself to bring it under digest coverage.

### 10.4 Payload Bombs

Compressed payloads (`base64+gzip+json`, `base64+zstd+json`) may expand dramatically. Implementations MUST:

1. Check `payload_bytes` against a configurable maximum before beginning decompression.
2. Abort decompression if the output exceeds a configurable limit (RECOMMENDED: 256 MiB default).
3. Treat `payload_bytes` mismatch as a hard error before any decompression is attempted.

### 10.5 Digest Downgrade

Future versions MUST NOT introduce a weaker digest algorithm without a mandatory algorithm identifier in the header. SHA-256 is the sole algorithm in v4.0; an `algo` header key is reserved for future use.

---

## 11. Use Cases

`.ppxl/4` capsules are intended as durable, self-verifying containers wherever a JSON record must travel across trust boundaries:

- **Knowledge atlases** — The terpene-receptor-binding atlas (`terpene-atlas/3.0.0`) that motivated v3 continues to use the format; v4 adds chain support for incremental atlas updates.
- **Game-state snapshots** — A sim-engine serialises turn state as a capsule; successive turns form a chain. A crashed session can be replayed from the chain.
- **Storefront receipts** — A purchase event is sealed at the moment of transaction; the signature field ties it to the issuer key.
- **NPC memory** — Persistent NPC state between sessions is sealed and chain-linked; the NPC can verify its own history has not been tampered with.
- **License tokens** — A software license is a capsule signed by the issuer; the recipient verifies the signature without a network round-trip.

---

## Appendix A. Example Capsule (Annotated)

```
%ppxl/4 4.0
%schema: game-state/1.0.0
%generated_utc: 2026-06-10T20:00:00Z
%digest: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
%payload_encoding: base64+gzip+json
%payload_bytes: 312
%tags: turn-1,player-alice
%---
H4sI...base64-encoded-compressed-payload...
%---
%end
```

A signed variant adds:
```
%signature: <128 hex chars>
%signer: <64 hex chars>
```

---

## Appendix B. Error Taxonomy

| Error | Condition |
|-------|-----------|
| `MagicMismatch` | First line is not `%ppxl/4 4.x` |
| `MissingHeader(key)` | A required header key is absent |
| `DigestMismatch` | Recomputed digest does not match header |
| `PayloadSizeMismatch` | Actual payload bytes differ from `payload_bytes` |
| `SignatureInvalid` | Signature verification failed |
| `MissingSigner` | `signature` present but `signer` absent |
| `UnknownEncoding` | `payload_encoding` is not a recognised value |
| `ChainBreak(i)` | Chain link `i` does not reference the correct prior digest |
| `PayloadBomb` | Decompressed size exceeds configured limit |

---

*Sealed under .ppxl/4 — Vaulted Delta · Bone & Saucer Labs*
