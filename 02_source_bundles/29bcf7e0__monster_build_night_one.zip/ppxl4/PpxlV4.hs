-- ─────────────────────────────────────────────────────────────────
-- Ppxl.V4  ·  Sealed knowledge capsules, content-addressed.
-- Vaulted Delta · BNS Labs · By AI, for AI.
--
-- Authors: Matthew Joseph Lansing (Bone & Saucer Labs / Vaulted Delta)
--          Perplexity Computer
-- Protocol: .ppxl/4 v4.0  ·  See SPEC.md
-- ─────────────────────────────────────────────────────────────────
{-# LANGUAGE DeriveAnyClass     #-}
{-# LANGUAGE DerivingStrategies #-}
{-# LANGUAGE OverloadedStrings  #-}
{-# LANGUAGE StrictData         #-}

module Ppxl.V4
  ( -- * Core types
    Capsule(..)
  , Header(..)
  , Sealed(..)
  , Encoding(..)
  , Digest(..)
  , Sig(..)
  , KeyId(..)
  , VerifyError(..)
  , DecodeError(..)
    -- * Sealing & verification
  , seal
  , verify
    -- * Wire encoding / decoding
  , encode
  , decode
    -- * Chains
  , chain
  , verifyChain
    -- * Canonical JSON
  , canonicalJson
  ) where

-- ─── Imports ──────────────────────────────────────────────────────────────────

import           Codec.Compression.GZip          (compress)
import           Codec.Compression.Zstd          (compress, maxCLevel)
import qualified Codec.Compression.GZip          as GZip
import qualified Codec.Compression.Zstd          as Zstd
import           Control.DeepSeq                 (NFData)
import           Crypto.Error                    (CryptoFailable(..))
import qualified Crypto.Hash.SHA256              as SHA256
import qualified Crypto.PubKey.Ed25519           as Ed25519
import           Data.Aeson                      (FromJSON, ToJSON, Value)
import qualified Data.Aeson                      as Aeson
import qualified Data.Aeson.Encoding             as Encoding
import qualified Data.Aeson.Key                  as Key
import qualified Data.Aeson.KeyMap               as KeyMap
import           Data.ByteString                 (ByteString)
import qualified Data.ByteString                 as BS
import qualified Data.ByteString.Base16          as Base16
import qualified Data.ByteString.Base64          as Base64
import qualified Data.ByteString.Char8           as BC
import qualified Data.ByteString.Lazy            as LBS
import           Data.List                       (intercalate, sortOn)
import           Data.Maybe                      (catMaybes, mapMaybe)
import           Data.Text                       (Text)
import qualified Data.Text                       as T
import qualified Data.Text.Encoding              as TE
import           Data.Time                       (UTCTime, formatTime, defaultTimeLocale)
import           GHC.Generics                    (Generic)

-- ─── Newtypes ─────────────────────────────────────────────────────────────────

-- | SHA-256 digest of canonical JSON payload bytes (raw 32 bytes).
newtype Digest = Digest { unDigest :: ByteString }
  deriving stock    (Eq, Ord, Show, Generic)
  deriving anyclass (NFData)

-- | ed25519 signature (raw 64 bytes).
newtype Sig = Sig { unSig :: ByteString }
  deriving stock    (Eq, Show, Generic)
  deriving anyclass (NFData)

-- | Hex of an ed25519 verify key (raw 32 bytes → 64 hex chars).
newtype KeyId = KeyId { unKeyId :: Text }
  deriving stock    (Eq, Show, Generic)
  deriving anyclass (NFData)

-- ─── Encoding ─────────────────────────────────────────────────────────────────

data Encoding
  = JsonRaw         -- ^ Raw canonical JSON, no transformation.
  | Base64GzipJson  -- ^ base64(gzip(canonical_json)).
  | Base64ZstdJson  -- ^ base64(zstd(canonical_json)).
  deriving stock    (Eq, Show, Generic)
  deriving anyclass (NFData)

encodingLabel :: Encoding -> Text
encodingLabel JsonRaw        = "json"
encodingLabel Base64GzipJson = "base64+gzip+json"
encodingLabel Base64ZstdJson = "base64+zstd+json"

parseEncoding :: Text -> Either DecodeError Encoding
parseEncoding "json"             = Right JsonRaw
parseEncoding "base64+gzip+json" = Right Base64GzipJson
parseEncoding "base64+zstd+json" = Right Base64ZstdJson
parseEncoding t                  = Left (UnknownEncoding t)

-- ─── Header ───────────────────────────────────────────────────────────────────

data Header = Header
  { schema          :: !Text
  , generatedUtc    :: !UTCTime
  , digest          :: !Digest
  , payloadEncoding :: !Encoding
  , payloadBytes    :: !Int
  , signature       :: !(Maybe Sig)
  , signer          :: !(Maybe KeyId)
  , prev            :: !(Maybe Digest)
  , tags            :: ![Text]
  } deriving stock (Eq, Show, Generic)
    deriving anyclass (NFData)

-- ─── Capsule ──────────────────────────────────────────────────────────────────

-- | A capsule pairs a verified header with its decoded payload.
-- The type parameter @a@ is the Haskell type of the payload value.
data Capsule a = Capsule
  { hdr     :: !Header
  , payload :: !a
  } deriving stock (Eq, Show, Generic, Functor)
    deriving anyclass (NFData)

-- | Phantom-typed sealed capsule.  Construction is only possible via 'seal'
-- or 'decode' + 'verify'; the constructor is intentionally not exported.
newtype Sealed a = Sealed { unseal :: Capsule a }
  deriving stock (Eq, Show, Generic)
  deriving anyclass (NFData)

-- ─── Errors ───────────────────────────────────────────────────────────────────

data VerifyError
  = DigestMismatch   { expected :: Digest, got :: Digest }
  | SignatureInvalid
  | MissingSigner
  | ChainBreak       { atIndex :: Int }
  deriving stock (Eq, Show, Generic)
  deriving anyclass (NFData)

data DecodeError
  = MagicMismatch       Text
  | MissingHeader       Text
  | PayloadSizeMismatch { declaredBytes :: Int, actualBytes :: Int }
  | UnknownEncoding     Text
  | JsonParseError      Text
  | DecompressionError  Text
  | MalformedHeader     Text
  deriving stock (Eq, Show, Generic)
  deriving anyclass (NFData)

-- ─── Canonical JSON ───────────────────────────────────────────────────────────

-- | Produce canonical JSON bytes per .ppxl/4 Section 4:
-- sorted keys, no trailing whitespace, UTF-8, RFC 8259 / JCS key order.
--
-- Note: this does a best-effort sort of Aeson's KeyMap.  For full JCS
-- compliance at nested levels, the caller should ensure their 'ToJSON'
-- instance uses 'Data.Map.Strict.Map' (which aeson serialises in key order)
-- rather than unordered HashMap-backed objects.
canonicalJson :: ToJSON a => a -> ByteString
canonicalJson v =
  let val        = Aeson.toJSON v
      sorted     = sortValue val
      lazyBytes  = Aeson.encode sorted
  in LBS.toStrict lazyBytes
  where
    sortValue :: Value -> Value
    sortValue (Aeson.Object km) =
      let pairs   = sortOn fst (KeyMap.toList km)
          sorted' = KeyMap.fromList [(k, sortValue v') | (k, v') <- pairs]
      in Aeson.Object sorted'
    sortValue (Aeson.Array arr) = Aeson.Array (fmap sortValue arr)
    sortValue other             = other

-- ─── Digesting ────────────────────────────────────────────────────────────────

computeDigest :: ByteString -> Digest
computeDigest = Digest . SHA256.hash

hexDigest :: Digest -> Text
hexDigest (Digest bs) = TE.decodeUtf8 (Base16.encode bs)

parseDigest :: Text -> Either DecodeError Digest
parseDigest t =
  case Base16.decode (TE.encodeUtf8 t) of
    Left err -> Left (MalformedHeader ("digest hex decode: " <> T.pack err))
    Right bs -> Right (Digest bs)

-- ─── Wire encoding helpers ───────────────────────────────────────────────────

applyEncoding :: Encoding -> ByteString -> ByteString
applyEncoding JsonRaw        bs = bs
applyEncoding Base64GzipJson bs =
  Base64.encode . LBS.toStrict . GZip.compress . LBS.fromStrict $ bs
applyEncoding Base64ZstdJson bs =
  Base64.encode . Zstd.compress maxCLevel $ bs

reverseEncoding :: Encoding -> ByteString -> Either DecodeError ByteString
reverseEncoding JsonRaw        bs = Right bs
reverseEncoding Base64GzipJson bs =
  case Base64.decode bs of
    Left err -> Left (DecompressionError ("base64 decode: " <> T.pack err))
    Right raw ->
      Right . LBS.toStrict . GZip.decompress . LBS.fromStrict $ raw
reverseEncoding Base64ZstdJson bs =
  case Base64.decode bs of
    Left err -> Left (DecompressionError ("base64 decode: " <> T.pack err))
    Right raw ->
      case Zstd.decompress raw of
        Zstd.Skip         -> Left (DecompressionError "zstd: skip")
        Zstd.Error msg    -> Left (DecompressionError ("zstd: " <> T.pack msg))
        Zstd.Decompress d -> Right d

-- ─── Sealing ─────────────────────────────────────────────────────────────────

-- | Seal a value into a 'Sealed' capsule.
--
-- @
-- example :: IO ()
-- example = do
--   let terpene = object ["name" .= ("limonene" :: Text), "cas" .= ("5989-27-5" :: Text)]
--   s <- seal Base64GzipJson Nothing terpene
--   BS.putStr (encode s)
-- @
seal
  :: ToJSON a
  => Encoding
  -> Maybe (Ed25519.SecretKey, KeyId)  -- ^ Optional signing key + key id
  -> a
  -> IO (Sealed a)
seal enc mKey val = do
  now <- getCurrentTime  -- from Data.Time
  let canon   = canonicalJson val
      dig     = computeDigest canon
      encoded = applyEncoding enc canon
      mSig    = fmap (\(sk, _) -> Sig . BA.convert $ Ed25519.sign sk (unDigest dig)) mKey
      mKeyId  = fmap snd mKey
      h = Header
            { schema          = "unknown/1.0.0"  -- caller should override via lens
            , generatedUtc    = now
            , digest          = dig
            , payloadEncoding = enc
            , payloadBytes    = BS.length encoded
            , signature       = mSig
            , signer          = mKeyId
            , prev            = Nothing
            , tags            = []
            }
  pure (Sealed (Capsule { hdr = h, payload = val }))

-- ─── Verification ─────────────────────────────────────────────────────────────

-- | Verify a sealed capsule: recompute digest, optionally check signature.
-- Returns the decoded payload on success.
verify :: ToJSON a => Sealed a -> Either VerifyError a
verify (Sealed (Capsule { hdr = h, payload = val })) = do
  let canon    = canonicalJson val
      computed = computeDigest canon
  if computed /= digest h
    then Left (DigestMismatch (digest h) computed)
    else case (signature h, signer h) of
      (Nothing, _)              -> Right val
      (Just _,  Nothing)        -> Left MissingSigner
      (Just (Sig sigBytes), Just (KeyId kid)) ->
        case Base16.decode (TE.encodeUtf8 kid) of
          Left _    -> Left SignatureInvalid
          Right vkBytes ->
            case Ed25519.publicKey vkBytes of
              CryptoFailed _ -> Left SignatureInvalid
              CryptoPassed vk ->
                case Ed25519.signature sigBytes of
                  CryptoFailed _ -> Left SignatureInvalid
                  CryptoPassed sig ->
                    if Ed25519.verify vk (unDigest (digest h)) sig
                      then Right val
                      else Left SignatureInvalid

-- ─── Wire encoding ───────────────────────────────────────────────────────────

-- | Serialise a 'Sealed' capsule to wire bytes.
encode :: ToJSON a => Sealed a -> ByteString
encode (Sealed (Capsule { hdr = h, payload = val })) =
  let canon      = canonicalJson val
      wirePayload = applyEncoding (payloadEncoding h) canon
      ts          = T.pack $ formatTime defaultTimeLocale "%Y-%m-%dT%H:%M:%SZ" (generatedUtc h)
      required    =
        [ "%ppxl/4 4.0"
        , "%" <> "schema: "           <> T.unpack (schema h)
        , "%" <> "generated_utc: "    <> T.unpack ts
        , "%" <> "digest: "           <> T.unpack (hexDigest (digest h))
        , "%" <> "payload_encoding: " <> T.unpack (encodingLabel (payloadEncoding h))
        , "%" <> "payload_bytes: "    <> show (BS.length wirePayload)
        ]
      optional = catMaybes
        [ fmap (\(Sig s)  -> "%" <> "signature: " <> BC.unpack (Base16.encode s)) (signature h)
        , fmap (\(KeyId k) -> "%" <> "signer: "   <> T.unpack k) (signer h)
        , fmap (\d        -> "%" <> "prev: "      <> T.unpack (hexDigest d)) (prev h)
        , if null (tags h) then Nothing
          else Just ("%" <> "tags: " <> T.unpack (T.intercalate "," (tags h)))
        ]
      headerLines = required <> optional
      header      = BC.pack (unlines headerLines)
      sep         = "%---\n"
      footer      = "%---\n%end\n"
  in header <> BC.pack sep <> wirePayload <> BC.pack "\n" <> BC.pack footer

-- ─── Wire decoding ────────────────────────────────────────────────────────────

-- | Parse wire bytes into a 'Sealed Value' (payload is untyped 'Value').
-- Use 'verify' + 'Aeson.fromJSON' to recover a typed capsule.
decode :: ByteString -> Either DecodeError (Sealed Value)
decode raw = do
  let ls = BC.lines raw
  case ls of
    [] -> Left (MagicMismatch "<empty>")
    (magic:rest) -> do
      -- Check magic
      let magicT = TE.decodeUtf8 magic
      if not ("%" `T.isPrefixOf` magicT && "ppxl/4" `T.isInfixOf` magicT)
        then Left (MagicMismatch magicT)
        else do
          -- Split at first separator
          let (hdrLines, afterSep) = break (== "%---") (map TE.decodeUtf8 rest)
          hdr <- parseHeader hdrLines
          -- afterSep: first elem is "%---", then payload lines, then "%---", then "%end"
          let payloadLines = takeWhile (/= "%---") (drop 1 afterSep)
              wirePayload  = TE.encodeUtf8 (T.concat payloadLines)
          -- Check payload_bytes
          let actualLen = BS.length wirePayload
          when (actualLen /= payloadBytes hdr) $
            Left (PayloadSizeMismatch (payloadBytes hdr) actualLen)
          -- Reverse encoding
          jsonBytes <- reverseEncoding (payloadEncoding hdr) wirePayload
          -- Parse JSON
          case Aeson.decodeStrict jsonBytes of
            Nothing  -> Left (JsonParseError "failed to parse payload as JSON")
            Just val -> Right (Sealed (Capsule { hdr = hdr, payload = val }))
  where
    when False _ = Right ()
    when True  e = e

parseHeader :: [Text] -> Either DecodeError Header
parseHeader ls = do
  let kvs = mapMaybe parseLine ls
      look k = case lookup k kvs of
                 Nothing -> Left (MissingHeader k)
                 Just v  -> Right v
  schemaT    <- look "schema"
  utcT       <- look "generated_utc"
  digestT    <- look "digest"
  encodingT  <- look "payload_encoding"
  bytesT     <- look "payload_bytes"
  dig        <- parseDigest digestT
  enc        <- parseEncoding encodingT
  bytes      <- case reads (T.unpack bytesT) of
                  [(n, "")] -> Right n
                  _         -> Left (MalformedHeader "payload_bytes not a valid integer")
  utc        <- case parseISO8601 (T.unpack utcT) of
                  Nothing -> Left (MalformedHeader "generated_utc not valid ISO 8601")
                  Just t  -> Right t
  let mSig   = Sig . either (const BS.empty) id . Base16.decode . TE.encodeUtf8
                 <$> lookup "signature" kvs
      mSigner = KeyId <$> lookup "signer" kvs
      mPrev   = either (const Nothing) Just . parseDigest
                 =<< lookup "prev" kvs
      tagList = maybe [] (T.splitOn ",") (lookup "tags" kvs)
  pure Header
    { schema          = schemaT
    , generatedUtc    = utc
    , digest          = dig
    , payloadEncoding = enc
    , payloadBytes    = bytes
    , signature       = mSig
    , signer          = mSigner
    , prev            = mPrev
    , tags            = tagList
    }
  where
    parseLine t
      | T.isPrefixOf "%" t =
          let body = T.drop 1 t
          in case T.breakOn ": " body of
               (k, rest) | not (T.null rest) -> Just (k, T.drop 2 rest)
               _                              -> Nothing
      | otherwise = Nothing
    parseISO8601 = parseTimeM True defaultTimeLocale "%Y-%m-%dT%H:%M:%SZ"

-- ─── Chains ───────────────────────────────────────────────────────────────────

-- | Link a new capsule onto a prior sealed capsule.
-- Sets the 'prev' field of the new capsule's header.
chain :: ToJSON a => Sealed a -> Sealed b -> Sealed b
chain (Sealed (Capsule { hdr = priorHdr })) (Sealed (Capsule { hdr = newHdr, payload = p })) =
  Sealed $ Capsule
    { hdr     = newHdr { prev = Just (digest priorHdr) }
    , payload = p
    }

-- | Verify an ordered chain of capsules (C₀ … Cₙ).
verifyChain :: [Sealed Value] -> Either VerifyError ()
verifyChain []       = Right ()
verifyChain caps     = go 0 caps
  where
    go _ []           = Right ()
    go i [_]          = Right ()
    go i (c1:c2:rest) =
      let d1 = digest (hdr (unseal c1))
      in case prev (hdr (unseal c2)) of
           Nothing -> Left (ChainBreak i)
           Just p  ->
             if p == d1
               then go (i + 1) (c2 : rest)
               else Left (ChainBreak i)

-- ─── Example (in comments) ───────────────────────────────────────────────────

{-

-- Sealing a terpene record:
--
--   import Data.Aeson (object, (.=))
--   import Ppxl.V4
--
--   main :: IO ()
--   main = do
--     let terpene = object
--           [ "name"      .= ("β-caryophyllene" :: Text)
--           , "cas"       .= ("87-44-5" :: Text)
--           , "receptors" .= (["CB2", "TRPA1"] :: [Text])
--           ]
--     s <- seal Base64GzipJson Nothing terpene
--     -- Override schema lens (or use a wrapper record):
--     let s' = s { unseal = (unseal s)
--                    { hdr = (hdr (unseal s))
--                        { schema = "terpene-atlas/3.0.0"
--                        , tags   = ["terpene", "cannabinoid-adjacent"]
--                        }
--                    }
--                }
--     BS.writeFile "terpene.ppxl" (encode s')
--     putStrLn "Sealed."

-- Sealing a game-state snapshot and chaining a second turn:
--
--   import Ppxl.V4
--   import Data.Aeson (object, (.=))
--
--   sealTurn :: Int -> Value -> IO (Sealed Value)
--   sealTurn turn val = do
--     s <- seal Base64GzipJson Nothing val
--     pure s
--
--   main :: IO ()
--   main = do
--     let state1 = object ["turn" .= (1 :: Int), "score" .= (0 :: Int)]
--         state2 = object ["turn" .= (2 :: Int), "score" .= (42 :: Int)]
--     c1 <- sealTurn 1 state1
--     c2 <- sealTurn 2 state2
--     let c2chained = chain c1 c2
--     case verifyChain [fmap Aeson.toJSON c1, fmap Aeson.toJSON c2chained] of
--       Left err -> print err
--       Right () -> putStrLn "Chain verified."

-}

-- ─────────────────────────────────────────────────────────────────
-- Sealed under .ppxl/4  ·  Vaulted Delta · BNS Labs
-- ─────────────────────────────────────────────────────────────────
