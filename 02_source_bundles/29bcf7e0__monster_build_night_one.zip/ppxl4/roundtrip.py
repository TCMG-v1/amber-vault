#!/usr/bin/env python3
# ─────────────────────────────────────────────────────────────────
# roundtrip.py  ·  .ppxl/4 round-trip test
# Vaulted Delta · Bone & Saucer Labs
#
# Seals a synthetic game-state snapshot, writes example_capsule.ppxl,
# decodes and verifies it.  Prints "SEAL VERIFIED · digest=..." on success.
# ─────────────────────────────────────────────────────────────────

import os
import sys

# Allow importing ppxl4 from the same directory
sys.path.insert(0, os.path.dirname(__file__))

from ppxl4 import seal, decode, verify, canonical_json, compute_digest

# ─── Fake game-state snapshot ─────────────────────────────────────────────────

GAME_STATE = {
    "schema_version": "game-state/1.0.0",
    "turn": 1,
    "phase": "draw",
    "active_player": "alice",
    "players": [
        {
            "id": "alice",
            "hand": ["Verdant Spike", "Null Protocol", "Echo Shard"],
            "health": 20,
            "energy": 3,
        },
        {
            "id": "bob",
            "hand": ["Iron Mandate", "Void Leech"],
            "health": 18,
            "energy": 2,
        },
    ],
    "deck_state": [
        {"zone": "library", "count": 43},
        {"zone": "graveyard", "count": 2},
        {"zone": "exile", "count": 0},
    ],
    "battlefield": [
        {"card": "Ash Terminal", "controller": "alice", "tapped": False},
        {"card": "Red Tracer", "controller": "bob",   "tapped": True},
    ],
    "log": [
        "turn 1: alice draws 3 cards",
        "turn 1: bob draws 2 cards",
    ],
}

OUTPUT_FILE = os.path.join(os.path.dirname(__file__), "example_capsule.ppxl")

# ─── Seal ─────────────────────────────────────────────────────────────────────

print("─" * 64)
print(".ppxl/4 round-trip test")
print("─" * 64)

wire = seal(
    GAME_STATE,
    schema="game-state/1.0.0",
    encoding="base64+gzip+json",
    tags=["turn-1", "test", "vaulted-delta"],
    authors="Matthew Joseph Lansing (Bone & Saucer Labs / Vaulted Delta); Perplexity Computer",
)

with open(OUTPUT_FILE, "wb") as f:
    f.write(wire)

print(f"Sealed  → {OUTPUT_FILE}  ({len(wire)} bytes)")

# ─── Decode ───────────────────────────────────────────────────────────────────

with open(OUTPUT_FILE, "rb") as f:
    raw = f.read()

capsule = decode(raw)

print(f"Decoded → schema={capsule.schema!r}")
print(f"          encoding={capsule.payload_encoding!r}")
print(f"          generated_utc={capsule.generated_utc!r}")
print(f"          payload_bytes={capsule.payload_bytes}")
print(f"          tags={capsule.tags}")

# ─── Verify ───────────────────────────────────────────────────────────────────

payload = verify(capsule)

# Independently recompute the digest from the original object and compare
expected_digest = compute_digest(canonical_json(GAME_STATE))

if capsule.digest != expected_digest:
    print(f"FAIL · digest mismatch")
    print(f"  capsule.digest   = {capsule.digest}")
    print(f"  expected_digest  = {expected_digest}")
    sys.exit(1)

# Confirm payload round-trips exactly
if payload != GAME_STATE:
    print("FAIL · payload mismatch after decode")
    sys.exit(1)

print("─" * 64)
print(f"SEAL VERIFIED · digest={capsule.digest}")
print("─" * 64)

# ─────────────────────────────────────────────────────────────────
# Sealed under .ppxl/4  ·  Vaulted Delta · BNS Labs
# ─────────────────────────────────────────────────────────────────
