# .ppxl/4

```
─────────────────────────────────────────────────────────────────
Sealed knowledge capsules, content-addressed.
Vaulted Delta · Bone & Saucer Labs
Authors: Matthew Joseph Lansing · Perplexity Computer
─────────────────────────────────────────────────────────────────
```

`.ppxl/4` is a wire protocol for sealed, content-addressed knowledge archives. Every capsule carries its own SHA-256 digest, an explicit encoding declaration, and a versioned schema URI — enough to verify, chain, and transmit structured records without external coordination. Signatures are optional (ed25519). Capsules may be chained to form append-only histories.

This is the fourth generation of the format, generalising the one-off `.ppxl` extension used in the terpene-receptor-binding atlas into load-bearing protocol infrastructure for sim-engines, storefronts, NPC memory, and license tokens.

→ Full specification: [SPEC.md](SPEC.md)

---

## Wire format at a glance

```
%ppxl/4 4.0
%schema: game-state/1.0.0
%generated_utc: 2026-06-10T20:00:00Z
%digest: a355b2de24aadc74f3587d6d52360c8de1da500b696513f7aa31a79911ffec6a
%payload_encoding: base64+gzip+json
%payload_bytes: 452
%tags: turn-1,vaulted-delta
%---
H4sI...base64-encoded-compressed-payload...
%---
%end
```

---

## Python usage

```python
from ppxl4 import seal, decode, verify

# Seal any JSON-serialisable object
wire = seal(
    {"turn": 1, "players": ["alice", "bob"]},
    schema="game-state/1.0.0",
    encoding="base64+gzip+json",
    tags=["turn-1"],
)

# Write to disk
with open("state.ppxl", "wb") as f:
    f.write(wire)

# Decode and verify
capsule = decode(wire)
payload = verify(capsule)
print(f"SEAL VERIFIED · digest={capsule.digest}")
```

Signing (requires `cryptography` package):

```python
import os
from ppxl4 import seal, decode, verify

key_seed = os.urandom(32)   # store this securely

wire    = seal(payload, schema="receipt/1.0.0", signer_key=key_seed)
capsule = decode(wire)
payload = verify(capsule)   # verify() uses signer field from header automatically
```

---

## Haskell usage

```haskell
import Ppxl.V4
import Data.Aeson (object, (.=))

main :: IO ()
main = do
  let snapshot = object
        [ "turn"    .= (1 :: Int)
        , "players" .= (["alice", "bob"] :: [Text])
        ]
  s <- seal Base64GzipJson Nothing snapshot
  -- Override schema via record update:
  let s' = s { unseal = (unseal s)
                 { hdr = (hdr (unseal s))
                     { schema = "game-state/1.0.0"
                     , tags   = ["turn-1"]
                     }
                 }
             }
  BS.writeFile "state.ppxl" (encode s')
  case verify s' of
    Left err  -> print err
    Right val -> putStrLn "SEAL VERIFIED"
```

---

## Files

| File | Purpose |
|------|---------|
| `SPEC.md` | RFC-style protocol specification, v4.0 |
| `PpxlV4.hs` | Haskell reference implementation (StrictData, ADTs, lenses) |
| `ppxl4.py` | Python 3.11+ implementation (stdlib + optional `cryptography`) |
| `roundtrip.py` | Round-trip test; produces `example_capsule.ppxl` as proof |
| `example_capsule.ppxl` | Sealed game-state snapshot produced by the round-trip test |

---

## Encoding modes

| `payload_encoding` | Description |
|-------------------|-------------|
| `json` | Raw canonical JSON, no transformation |
| `base64+gzip+json` | base64(gzip(canonical JSON)) — default, best compatibility |
| `base64+zstd+json` | base64(zstd(canonical JSON)) — smaller, requires `zstandard` |

---

## Chain example (Python)

```python
from ppxl4 import seal, decode, verify, verify_chain, chain_capsule

c0_wire = seal(state_0, schema="game-state/1.0.0", tags=["turn-0"])
c0      = decode(c0_wire)

c1_wire = chain_capsule(c0, payload=state_1, schema="game-state/1.0.0", tags=["turn-1"])
c1      = decode(c1_wire)

verify_chain([c0, c1])   # raises ChainBreak if the linkage is wrong
```

---

*Sealed under .ppxl/4 — Vaulted Delta · Bone & Saucer Labs*
