"""
nodes.py — Pixel Palette nodes for ComfyUI

Operates on ComfyUI's standard IMAGE tensor (B, H, W, C) float32 in [0,1].
The PIXEL_PALETTE type is a small dict:
    {
        "rgb":   [[r,g,b], ...]  ints 0..255
        "hex":   ["#RRGGBB", ...]
        "meta":  { ...full JSON v2 payload... }
    }

All math here mirrors the web app (src/lib/process.js + color.js) so the
output is bit-identical when settings match.
"""

from __future__ import annotations
import json
import os
import math
import numpy as np
import torch

try:
    import folder_paths  # ComfyUI helper for path resolution
    INPUT_DIR = folder_paths.get_input_directory()
except Exception:
    INPUT_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "input")


# ============================================================
# color-space helpers (mirrors src/lib/color.js)
# ============================================================

def _srgb_to_linear(c: np.ndarray) -> np.ndarray:
    return np.where(c <= 0.04045, c / 12.92, ((c + 0.055) / 1.055) ** 2.4)


def _linear_to_srgb(c: np.ndarray) -> np.ndarray:
    return np.where(c <= 0.0031308, 12.92 * c, 1.055 * (np.clip(c, 0, None) ** (1 / 2.4)) - 0.055)


def rgb_to_oklab(rgb: np.ndarray) -> np.ndarray:
    """rgb: (...,3) float in [0,1]. returns oklab (...,3)."""
    rl = _srgb_to_linear(rgb[..., 0])
    gl = _srgb_to_linear(rgb[..., 1])
    bl = _srgb_to_linear(rgb[..., 2])
    l = 0.4122214708 * rl + 0.5363325363 * gl + 0.0514459929 * bl
    m = 0.2119034982 * rl + 0.6806995451 * gl + 0.1073969566 * bl
    s = 0.0883024619 * rl + 0.2817188376 * gl + 0.6299787005 * bl
    l_ = np.cbrt(l); m_ = np.cbrt(m); s_ = np.cbrt(s)
    L = 0.2104542553 * l_ + 0.7936177850 * m_ - 0.0040720468 * s_
    a = 1.9779984951 * l_ - 2.4285922050 * m_ + 0.4505937099 * s_
    b = 0.0259040371 * l_ + 0.7827717662 * m_ - 0.8086757660 * s_
    return np.stack([L, a, b], axis=-1)


# ============================================================
# dither kernels
# ============================================================

BAYER_2 = np.array([[0, 2], [3, 1]]) / 4.0 - 0.5
BAYER_4 = np.array([
    [0, 8, 2, 10],
    [12, 4, 14, 6],
    [3, 11, 1, 9],
    [15, 7, 13, 5],
]) / 16.0 - 0.5
BAYER_8 = np.array([
    [0, 32, 8, 40, 2, 34, 10, 42],
    [48, 16, 56, 24, 50, 18, 58, 26],
    [12, 44, 4, 36, 14, 46, 6, 38],
    [60, 28, 52, 20, 62, 30, 54, 22],
    [3, 35, 11, 43, 1, 33, 9, 41],
    [51, 19, 59, 27, 49, 17, 57, 25],
    [15, 47, 7, 39, 13, 45, 5, 37],
    [63, 31, 55, 23, 61, 29, 53, 21],
]) / 64.0 - 0.5

BAYER = {"bayer2": BAYER_2, "bayer4": BAYER_4, "bayer8": BAYER_8}

ERROR_KERNELS = {
    "floyd":    {"denom": 16, "entries": [(1, 0, 7), (-1, 1, 3), (0, 1, 5), (1, 1, 1)]},
    "atkinson": {"denom": 8,  "entries": [(1, 0, 1), (2, 0, 1), (-1, 1, 1), (0, 1, 1), (1, 1, 1), (0, 2, 1)]},
    "jarvis":   {"denom": 48, "entries": [
        (1, 0, 7), (2, 0, 5),
        (-2, 1, 3), (-1, 1, 5), (0, 1, 7), (1, 1, 5), (2, 1, 3),
        (-2, 2, 1), (-1, 2, 3), (0, 2, 5), (1, 2, 3), (2, 2, 1),
    ]},
}


# ============================================================
# palette mapping
# ============================================================

def _nearest_palette(pixels: np.ndarray, palette: np.ndarray, space: str) -> np.ndarray:
    """
    pixels : (N, 3) uint8 or float
    palette: (K, 3) uint8
    returns: (N, 3) uint8 mapped to nearest palette entry
    """
    if space == "oklab":
        px = pixels.astype(np.float32) / 255.0
        pa = palette.astype(np.float32) / 255.0
        px_lab = rgb_to_oklab(px)
        pa_lab = rgb_to_oklab(pa)
        # squared distance, batched
        d = np.sum((px_lab[:, None, :] - pa_lab[None, :, :]) ** 2, axis=2)
    else:
        px = pixels.astype(np.int32)
        pa = palette.astype(np.int32)
        d = np.sum((px[:, None, :] - pa[None, :, :]) ** 2, axis=2)
    idx = np.argmin(d, axis=1)
    return palette[idx]


def _apply_palette(image_u8: np.ndarray, palette: np.ndarray, dither: str, strength: float, space: str) -> np.ndarray:
    """
    image_u8 : (H, W, 3) uint8
    palette  : (K, 3) uint8
    returns  : (H, W, 3) uint8
    """
    h, w, _ = image_u8.shape

    if dither in BAYER:
        mat = BAYER[dither]
        mh, mw = mat.shape
        nudge = mat[np.arange(h)[:, None] % mh, np.arange(w)[None, :] % mw] * 32.0 * strength
        biased = np.clip(image_u8.astype(np.float32) + nudge[..., None], 0, 255)
        flat = biased.reshape(-1, 3)
        mapped = _nearest_palette(flat, palette, space)
        return mapped.reshape(h, w, 3).astype(np.uint8)

    if dither in ERROR_KERNELS:
        kernel = ERROR_KERNELS[dither]
        inv = strength / kernel["denom"]
        buf = image_u8.astype(np.float32).copy()
        out = np.zeros_like(buf, dtype=np.uint8)
        # process pixel-by-pixel (necessary for error diffusion)
        for y in range(h):
            for x in range(w):
                old = np.clip(buf[y, x], 0, 255)
                new = _nearest_palette(old.reshape(1, 3), palette, space)[0]
                out[y, x] = new
                err = old - new.astype(np.float32)
                for dx, dy, wgt in kernel["entries"]:
                    nx, ny = x + dx, y + dy
                    if 0 <= nx < w and 0 <= ny < h:
                        buf[ny, nx] += err * wgt * inv
        return out

    # no dither
    flat = image_u8.reshape(-1, 3)
    mapped = _nearest_palette(flat, palette, space)
    return mapped.reshape(h, w, 3).astype(np.uint8)


# ============================================================
# k-means (OKLab-space)
# ============================================================

def kmeans_palette(image_u8: np.ndarray, k: int, iterations: int = 12, max_samples: int = 50000, space: str = "oklab") -> np.ndarray:
    h, w, _ = image_u8.shape
    flat = image_u8.reshape(-1, 3)
    total = flat.shape[0]
    stride = max(1, total // max_samples)
    samples = flat[::stride].astype(np.float32) / 255.0
    if space == "oklab":
        pts = rgb_to_oklab(samples)
    else:
        pts = samples

    # k-means++ init
    rng = np.random.default_rng(0xC0FFEE)
    n = pts.shape[0]
    if n == 0:
        return np.array([[0, 0, 0]], dtype=np.uint8)
    centroids = [pts[rng.integers(0, n)]]
    for _ in range(min(k, n) - 1):
        dists = np.min(np.sum((pts[:, None, :] - np.stack(centroids)[None, :, :]) ** 2, axis=2), axis=1)
        s = dists.sum()
        if s <= 0:
            centroids.append(pts[rng.integers(0, n)])
            continue
        r = rng.random() * s
        cum = np.cumsum(dists)
        idx = int(np.searchsorted(cum, r))
        idx = min(idx, n - 1)
        centroids.append(pts[idx])
    C = np.stack(centroids)  # (k, 3)

    # Lloyd
    for _ in range(iterations):
        d = np.sum((pts[:, None, :] - C[None, :, :]) ** 2, axis=2)
        assign = np.argmin(d, axis=1)
        newC = C.copy()
        for i in range(C.shape[0]):
            mask = assign == i
            if mask.any():
                newC[i] = pts[mask].mean(axis=0)
        C = newC

    # convert centroids back to sRGB uint8
    if space == "oklab":
        # invert OKLab → sRGB
        L, a, b = C[:, 0], C[:, 1], C[:, 2]
        l_ = L + 0.3963377774 * a + 0.2158037573 * b
        m_ = L - 0.1055613458 * a - 0.0638541728 * b
        s_ = L - 0.0894841775 * a - 1.2914855480 * b
        lL = l_ ** 3; mL = m_ ** 3; sL = s_ ** 3
        r = +4.0767416621 * lL - 3.3077115913 * mL + 0.2309699292 * sL
        g = -1.2684380046 * lL + 2.6097574011 * mL - 0.3413193965 * sL
        bb = -0.0041960863 * lL - 0.7034186147 * mL + 1.7076147010 * sL
        rgb = np.stack([_linear_to_srgb(r), _linear_to_srgb(g), _linear_to_srgb(bb)], axis=-1)
    else:
        rgb = C
    return np.clip(np.round(rgb * 255), 0, 255).astype(np.uint8)


# ============================================================
# tensor <-> numpy helpers
# ============================================================

def tensor_to_u8(image: torch.Tensor) -> np.ndarray:
    """ComfyUI IMAGE -> (H,W,3) uint8 (uses first batch entry)"""
    arr = image[0].detach().cpu().numpy()
    arr = np.clip(arr * 255.0, 0, 255).astype(np.uint8)
    return arr


def u8_to_tensor(arr: np.ndarray) -> torch.Tensor:
    """(H,W,3) uint8 -> ComfyUI IMAGE (1,H,W,3) float32 in [0,1]"""
    t = torch.from_numpy(arr.astype(np.float32) / 255.0)
    return t.unsqueeze(0)


# ============================================================
# NODES
# ============================================================

DITHER_OPTIONS = ["none", "bayer2", "bayer4", "bayer8", "floyd", "atkinson", "jarvis"]
SPACE_OPTIONS = ["srgb", "oklab"]


class PixelPaletteLoadJSON:
    """Load a Pixel Palette .json file (schema pixel-palette/v2) from ComfyUI/input/."""

    @classmethod
    def INPUT_TYPES(cls):
        try:
            files = [f for f in os.listdir(INPUT_DIR) if f.lower().endswith(".json")]
        except Exception:
            files = []
        files.sort()
        return {
            "required": {
                "palette_json": (files if files else ["<none>"], {}),
            }
        }

    RETURN_TYPES = ("PIXEL_PALETTE",)
    RETURN_NAMES = ("palette",)
    FUNCTION = "load"
    CATEGORY = "PixelPalette"

    def load(self, palette_json: str):
        path = os.path.join(INPUT_DIR, palette_json)
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if "palette" not in data or "rgb" not in data["palette"]:
            raise ValueError(f"{palette_json} is not a Pixel Palette v2 JSON")
        rgb = np.array(data["palette"]["rgb"], dtype=np.uint8)
        hex_list = data["palette"]["hex"]
        return ({"rgb": rgb, "hex": hex_list, "meta": data},)


class PixelPaletteApply:
    """Quantize + dither an image to a Pixel Palette."""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "image": ("IMAGE",),
                "palette": ("PIXEL_PALETTE",),
                "dither": (DITHER_OPTIONS, {"default": "floyd"}),
                "strength": ("FLOAT", {"default": 0.6, "min": 0.0, "max": 1.5, "step": 0.05}),
                "color_space": (SPACE_OPTIONS, {"default": "oklab"}),
            }
        }

    RETURN_TYPES = ("IMAGE",)
    FUNCTION = "apply"
    CATEGORY = "PixelPalette"

    def apply(self, image, palette, dither, strength, color_space):
        u8 = tensor_to_u8(image)
        pal_rgb = palette["rgb"]
        out = _apply_palette(u8, pal_rgb, dither, float(strength), color_space)
        return (u8_to_tensor(out),)


class PixelPaletteExtract:
    """Extract a k-color palette from an image using k-means in OKLab space."""

    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "image": ("IMAGE",),
                "target_colors": ("INT", {"default": 16, "min": 2, "max": 256, "step": 1}),
                "color_space": (SPACE_OPTIONS, {"default": "oklab"}),
                "iterations": ("INT", {"default": 12, "min": 1, "max": 50, "step": 1}),
            }
        }

    RETURN_TYPES = ("PIXEL_PALETTE",)
    FUNCTION = "extract"
    CATEGORY = "PixelPalette"

    def extract(self, image, target_colors, color_space, iterations):
        u8 = tensor_to_u8(image)
        rgb = kmeans_palette(u8, int(target_colors), iterations=int(iterations), space=color_space)
        hex_list = [f"#{r:02X}{g:02X}{b:02X}" for r, g, b in rgb]
        return ({"rgb": rgb, "hex": hex_list, "meta": {"schema": "pixel-palette/v2", "source": "extracted"}},)
