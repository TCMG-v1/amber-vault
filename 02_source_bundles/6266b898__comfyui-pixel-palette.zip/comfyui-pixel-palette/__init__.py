"""
ComfyUI Pixel Palette — custom nodes
Companion to the Pixel Palette web tool. Load .json palettes exported from the
web app and apply them inside ComfyUI workflows.

Install:
  Copy or symlink this folder into ComfyUI/custom_nodes/
  Restart ComfyUI

Nodes:
  PixelPalette_LoadJSON  — load a .json palette (place it in ComfyUI/input/)
  PixelPalette_Apply     — quantize + dither an image against a palette
  PixelPalette_Extract   — pull a palette from an arbitrary IMAGE (k-means)
"""

from .nodes import (
    PixelPaletteLoadJSON,
    PixelPaletteApply,
    PixelPaletteExtract,
)

NODE_CLASS_MAPPINGS = {
    "PixelPalette_LoadJSON": PixelPaletteLoadJSON,
    "PixelPalette_Apply":    PixelPaletteApply,
    "PixelPalette_Extract":  PixelPaletteExtract,
}

NODE_DISPLAY_NAME_MAPPINGS = {
    "PixelPalette_LoadJSON": "Pixel Palette · Load JSON",
    "PixelPalette_Apply":    "Pixel Palette · Apply",
    "PixelPalette_Extract":  "Pixel Palette · Extract (k-means)",
}

__all__ = ["NODE_CLASS_MAPPINGS", "NODE_DISPLAY_NAME_MAPPINGS"]
