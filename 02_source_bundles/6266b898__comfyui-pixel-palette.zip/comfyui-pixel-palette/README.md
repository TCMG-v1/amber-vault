# Pixel Palette — ComfyUI Custom Nodes

Three custom nodes that bring the **Pixel Palette** visualizer's quantization + dithering pipeline into ComfyUI. Apply any palette you designed in the web app — or extract one on the fly with perceptual k-means.

All math runs in **OKLab perceptual color space** (Björn Ottosson, 2020) by default — the same engine the web tool uses — so palette mapping respects how humans actually perceive color difference, not naive RGB distance.

## Nodes

### `PixelPalette_LoadJSON`
Loads a `pixel-palette/v2` JSON file exported from the web app.

- **Input:** filename (string, dropdown of files in `ComfyUI/input/`)
- **Output:** `PIXEL_PALETTE`

Drop your exported `.json` into `ComfyUI/input/` and pick it from the list.

### `PixelPalette_Apply`
Quantizes an image to a palette with optional ordered or error-diffusion dithering.

- **Inputs:**
  - `image` (IMAGE)
  - `palette` (PIXEL_PALETTE)
  - `dither` — `none`, `bayer2`, `bayer4`, `bayer8`, `floyd-steinberg`, `atkinson`, `jarvis`
  - `strength` — 0.0–1.0
  - `space` — `oklab` (perceptual) or `srgb` (naive)
- **Output:** IMAGE

### `PixelPalette_Extract`
Extracts an N-color palette from an image via OKLab k-means (k-means++ seeding, 12 Lloyd iterations, configurable sample cap). Feed it straight into `PixelPalette_Apply`.

- **Inputs:**
  - `image` (IMAGE)
  - `k` — number of palette colors (2–64)
  - `samples` — pixel sample cap (1k–200k)
- **Output:** PIXEL_PALETTE

## Install

```bash
cd ComfyUI/custom_nodes/
# copy or symlink this folder here:
ln -s /path/to/comfyui-pixel-palette .
# or just:
cp -r /path/to/comfyui-pixel-palette .
```

Restart ComfyUI. The nodes will appear under the `image/pixel-palette` category.

**Dependencies:** `numpy`, `torch`, `Pillow` — all already present in ComfyUI's environment.

## Example Workflows

Two ready-to-use workflows live in `workflows/`:

- **`basic-quantize.json`** — `LoadImage → PixelPalette_LoadJSON → PixelPalette_Apply → PreviewImage`. Designs in the web app, drops here.
- **`kmeans-extract.json`** — `LoadImage → PixelPalette_Extract → PixelPalette_Apply → PreviewImage`. Auto-palette from any image, then re-dither it with Atkinson at 0.85 strength.

Drag either JSON onto the ComfyUI canvas to instantiate the graph.

## End-to-end with the Web App

1. Open the [Pixel Palette web app](https://www.perplexity.ai/computer/a/pixel-palette-3PUkkIF2RPqnEFXTdB0kfw), upload a source image, dial in dither + palette
2. Click **JSON** export → save the file
3. Drop the JSON into `ComfyUI/input/`
4. Click the **Send →** button in the web app to upload the working image to ComfyUI (`/upload/image`), then drag the auto-downloaded workflow.json onto your canvas
5. Run the graph — your palette is applied in pure Python with the same OKLab math the web app uses

## JSON Schema (`pixel-palette/v2`)

```json
{
  "schema": "pixel-palette/v2",
  "pipeline": {
    "color_space": "oklab",
    "quantization": { "mode": "kmeans", "k": 16 },
    "dither": { "type": "floyd-steinberg", "strength": 1.0 }
  },
  "palette": {
    "hex":  ["#1a1a2e", "..."],
    "rgb":  [[26, 26, 46], ...],
    "oklab":[[0.18, 0.01, -0.04], ...],
    "locked": [false, ...],
    "ordered": [0, 1, 2, ...]
  }
}
```

The Python loader reads `palette.rgb`. Other fields are advisory.

## Credits

- OKLab perceptual color space — [Björn Ottosson, 2020](https://bottosson.github.io/posts/oklab/)
- Floyd–Steinberg (1976), Atkinson (1980s Mac), Jarvis–Judice–Ninke (1976), Bayer (1973) dither matrices
- k-means++ seeding — Arthur & Vassilvitskii (2007)

Built alongside the Pixel Palette web visualizer. Have fun.
