#!/usr/bin/env python3
"""
anya_sniff.py — AnyaSniffLogs Witness scan (Pi-native).

Calls Perplexity Sonar for today's top finance + legal stories, grades each
through the Spacephrasing Finance / Legal / NewsBait grammars, picks the top
three highest-bait, writes a full JSON ledger, and emails the brief via SMTP.

Configuration is via .env (loaded automatically) and command-line flags.
See .env.example for required variables.

Usage:
    python3 anya_sniff.py --dry-run      # write JSON, don't send email
    python3 anya_sniff.py --send         # write JSON, send email
    python3 anya_sniff.py --simple-html  # plain-er HTML for picky mail clients
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import smtplib
import sys
import time
from email.message import EmailMessage
from pathlib import Path
from typing import Any

try:
    from dotenv import load_dotenv
except ImportError:
    def load_dotenv(*_a, **_kw):  # type: ignore
        pass

try:
    import httpx
except ImportError:
    httpx = None  # type: ignore


# ─────────────────────────── config ───────────────────────────


HERE = Path(__file__).resolve().parent
load_dotenv(HERE / ".env")

SONAR_API_KEY = os.environ.get("SONAR_API_KEY", "")
SONAR_MODEL = os.environ.get("SONAR_MODEL", "sonar-pro")
SONAR_SLEEP = float(os.environ.get("SONAR_SLEEP_BETWEEN_STORIES", "0.5"))

SMTP_HOST = os.environ.get("SMTP_HOST", "")
SMTP_PORT = int(os.environ.get("SMTP_PORT", "587"))
SMTP_USER = os.environ.get("SMTP_USER", "")
SMTP_PASS = os.environ.get("SMTP_PASS", "")
SMTP_FROM = os.environ.get("SMTP_FROM", "Anya <anya@example.invalid>")

EMAIL_TO = os.environ.get("EMAIL_TO", "")

DATA_DIR = Path(os.environ.get("DATA_DIR", HERE / "data"))
GRAMMAR_DIR = HERE / "grammars"


# ─────────────────────────── grammar loaders ───────────────────────────


def _load_grammar(name: str) -> dict[str, Any]:
    p = GRAMMAR_DIR / f"{name}.grammar.json"
    if not p.exists():
        return {}
    with open(p) as f:
        return json.load(f)


FINANCE_G = _load_grammar("Finance")
LEGAL_G = _load_grammar("Legal")
NEWSBAIT_G = _load_grammar("NewsBait")


# ─────────────────────────── Sonar prompt ───────────────────────────


SYSTEM_PROMPT = """You are AnyaSniff, a news witness that does NOT extract.
Your job: find today's top finance AND legal stories from major outlets, then
return a strict JSON array where each item has these fields exactly:

  headline           - exact published headline
  outlet             - publication name
  url                - link to the article
  published          - ISO-8601 date or 'today'
  domain             - 'finance' OR 'legal'
  summary_neutral    - 2-3 sentences, neutral tone, no bait
  spacephrased       - 2-4 rhythm lines (subject | predicate format) capturing the story's emotional shape
  finance_grammar    - {structure, signal, value, shadow} — if domain=finance; else null
  legal_grammar      - {structure, signal, value, shadow} — if domain=legal; else null
  newsbait_grammar   - {signal_flags[], missing_context[], emotional_triggers[], framing_problems[], verified_against[]}
  bait_score         - float 0.0..1.0

Return 8-12 stories. Return ONLY the JSON array, no surrounding prose."""


# ─────────────────────────── Sonar call ───────────────────────────


def call_sonar() -> list[dict[str, Any]] | None:
    if not SONAR_API_KEY:
        print("SONAR_API_KEY not set — using mock witness.", file=sys.stderr)
        return None
    if httpx is None:
        print("httpx not installed — using mock witness.", file=sys.stderr)
        return None

    payload = {
        "model": SONAR_MODEL,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {
                "role": "user",
                "content": f"Find today's ({dt.date.today().isoformat()}) "
                f"top finance + legal stories. Return the JSON array.",
            },
        ],
        "temperature": 0.2,
    }
    headers = {
        "Authorization": f"Bearer {SONAR_API_KEY}",
        "Content-Type": "application/json",
    }
    try:
        r = httpx.post(
            "https://api.perplexity.ai/chat/completions",
            json=payload,
            headers=headers,
            timeout=90,
        )
    except Exception as e:
        print(f"sonar transport err: {e}", file=sys.stderr)
        return None

    if r.status_code != 200:
        print(f"sonar status {r.status_code}: {r.text[:200]}", file=sys.stderr)
        return None

    raw = r.json()["choices"][0]["message"]["content"].strip()
    # Strip code fences if present
    if raw.startswith("```"):
        raw = raw.split("```", 2)[1]
        if raw.startswith("json"):
            raw = raw[4:]
        raw = raw.rsplit("```", 1)[0]
    try:
        stories = json.loads(raw)
        if not isinstance(stories, list):
            raise ValueError("Expected list")
        return stories
    except Exception as e:
        print(f"sonar parse err: {e}", file=sys.stderr)
        return None


def mock_stories() -> list[dict[str, Any]]:
    return [
        {
            "headline": "[MOCK] Regional Bank Reports Surprise Loss; Shares Plunge 22%",
            "outlet": "Mock Wire",
            "url": "https://example.invalid/mock/finance/1",
            "published": dt.date.today().isoformat(),
            "domain": "finance",
            "summary_neutral": "A regional US bank disclosed a quarterly loss tied to commercial real estate exposure. Shares fell sharply in early trading.",
            "spacephrased": [
                "Regional Bank | Reports Surprise Loss",
                "Shares Plunge | 22%",
                "(the verb 'plunge' is doing the work the data hasn't earned)",
            ],
            "finance_grammar": {
                "structure": "earnings-surprise",
                "signal": "#FF9F1C",
                "value": "loss tied to CRE",
                "shadow": "no peer comparison",
            },
            "legal_grammar": None,
            "newsbait_grammar": {
                "signal_flags": ["RED: 'plunge' is bait-verb", "YELLOW: no peer comparison"],
                "missing_context": ["peer bank performance", "CRE exposure %", "tier-1 capital ratio"],
                "emotional_triggers": ["fear", "fomo-out"],
                "framing_problems": ["headline overstates intra-day move as durable"],
                "verified_against": ["press release", "10-Q"],
            },
            "bait_score": 0.72,
        },
        {
            "headline": "[MOCK] Supreme Court Declines Major Tech Antitrust Appeal",
            "outlet": "Mock Legal Desk",
            "url": "https://example.invalid/mock/legal/1",
            "published": dt.date.today().isoformat(),
            "domain": "legal",
            "summary_neutral": "SCOTUS denied certiorari in a closely-watched antitrust case, leaving a lower-court ruling in place. The decision was procedural; no opinion was issued.",
            "spacephrased": [
                "Supreme Court | Declines Appeal",
                "Lower Ruling | Stands",
                "(cert denial reads as a ruling; it isn't)",
            ],
            "finance_grammar": None,
            "legal_grammar": {
                "structure": "cert-denial",
                "signal": "#A0223A",
                "value": "no opinion, lower ruling intact",
                "shadow": "procedural, not precedential",
            },
            "newsbait_grammar": {
                "signal_flags": ["RED: 'declines' read as ruling", "YELLOW: 'Major Tech' is vague"],
                "missing_context": ["which company", "what the lower court actually held", "what cert denial means"],
                "emotional_triggers": ["outrage", "tribal-tech"],
                "framing_problems": ["conflates non-decision with decision"],
                "verified_against": ["SCOTUS docket"],
            },
            "bait_score": 0.68,
        },
        {
            "headline": "[MOCK] DOJ Opens Probe Into Crypto Exchange Reserves",
            "outlet": "Mock Wire",
            "url": "https://example.invalid/mock/legal/2",
            "published": dt.date.today().isoformat(),
            "domain": "legal",
            "summary_neutral": "The Department of Justice has opened a preliminary inquiry into reserve disclosures at a major crypto exchange. The exchange said it is cooperating.",
            "spacephrased": [
                "DOJ | Opens Probe",
                "Exchange | Cooperates",
                "(the word 'probe' is heavier than a preliminary inquiry)",
            ],
            "finance_grammar": None,
            "legal_grammar": {
                "structure": "preliminary-inquiry",
                "signal": "#A0223A",
                "value": "no charges, cooperation stated",
                "shadow": "headline-grade verb for early-stage action",
            },
            "newsbait_grammar": {
                "signal_flags": ["RED: 'probe' is bait-noun", "YELLOW: 'major' is vague"],
                "missing_context": ["which statutes", "DOJ division", "is this a Reuters scoop or press leak"],
                "emotional_triggers": ["fear", "schadenfreude"],
                "framing_problems": ["preliminary inquiry framed as enforcement"],
                "verified_against": ["DOJ press"],
            },
            "bait_score": 0.65,
        },
    ]


# ─────────────────────────── report ───────────────────────────


def assemble_report(stories: list[dict[str, Any]], is_mock: bool) -> dict[str, Any]:
    today = dt.date.today().isoformat()
    stories_sorted = sorted(
        stories,
        key=lambda s: float(s.get("bait_score", 0) or 0),
        reverse=True,
    )
    return {
        "scan_date": today,
        "witness": "AnyaSniffLogs / Witness Pi"
        + (" / MOCK (Sonar key absent)" if is_mock else ""),
        "covenant": "the pink mark is honest",
        "n_stories": len(stories),
        "stories": stories_sorted,
        "top_3": stories_sorted[:3],
    }


# ─────────────────────────── email ───────────────────────────


def build_email(report: dict[str, Any], simple_html: bool = False) -> tuple[str, str, str]:
    today = report["scan_date"]
    is_mock = "MOCK" in report.get("witness", "")
    mock_tag = " [MOCK]" if is_mock else ""
    top = report.get("top_3", [])

    # Plain text
    plain = [f"AnyaSniffLog · {today}{mock_tag}", "Today's three most bait-likely stories.", ""]
    for i, s in enumerate(top, 1):
        plain.append(f"#{i} · bait {float(s.get('bait_score', 0)):.2f} · {s.get('domain', '?')}")
        plain.append(f"   {s.get('headline', '(no headline)')}")
        plain.append(f"   {s.get('outlet', '?')} — {s.get('url', '')}")
        plain.append(f"   {s.get('summary_neutral', '')}")
        ng = s.get("newsbait_grammar", {}) or {}
        plain.append(f"   flags: {', '.join(ng.get('signal_flags', [])) or '—'}")
        plain.append(f"   missing: {', '.join(ng.get('missing_context', [])) or '—'}")
        plain.append("")
    plain.append("Witnessed by Anya · the pink mark is honest")
    plain_body = "\n".join(plain)

    # HTML
    if simple_html:
        html_body = (
            "<pre style='font-family:monospace;font-size:13px;'>"
            + plain_body.replace("<", "&lt;").replace(">", "&gt;")
            + "</pre>"
        )
    else:
        parts = [
            "<div style='max-width:640px;margin:0 auto;padding:24px;font-family:Georgia,serif;'>",
            f"<p style='font-family:JetBrains Mono,monospace;color:#888;font-size:12px;"
            f"letter-spacing:0.1em;text-transform:uppercase;'>AnyaSniffLog · {today}{mock_tag}</p>",
            "<h1 style='font-family:Georgia,serif;font-style:italic;color:#1a1108;"
            "font-size:28px;margin:0 0 6px;'>Today's three most bait-likely stories.</h1>",
            f"<p style='color:#555;font-size:14px;margin:0 0 28px;'>"
            f"Witnessed by Anya. {report.get('n_stories', 0)} stories scanned · top 3 below.</p>",
        ]
        for i, s in enumerate(top, 1):
            bait = float(s.get("bait_score", 0))
            color = "#a0223a" if bait >= 0.7 else "#c99a3b" if bait >= 0.5 else "#666"
            ng = s.get("newsbait_grammar", {}) or {}
            parts.append(
                f"<div style='border-left:3px solid {color};padding:8px 18px;"
                f"margin-bottom:24px;background:#fafafa;'>"
                f"<div style='font-family:JetBrains Mono,monospace;font-size:11px;color:{color};"
                f"letter-spacing:0.06em;text-transform:uppercase;margin-bottom:6px;'>"
                f"#{i} · bait score {bait:.2f} · {s.get('domain', '?')}</div>"
                f"<div style='font-family:Georgia,serif;font-size:18px;font-weight:600;"
                f"color:#1a1108;margin-bottom:6px;'>{s.get('headline', '')}</div>"
                f"<div style='font-size:13px;color:#666;margin-bottom:10px;'>"
                f"{s.get('outlet', '')} · <a href='{s.get('url', '')}' "
                f"style='color:#c99a3b;'>source</a></div>"
                f"<div style='font-size:14px;color:#333;line-height:1.5;margin-bottom:10px;'>"
                f"{s.get('summary_neutral', '')}</div>"
                f"<div style='font-size:12px;color:#888;'><strong>Flags:</strong> "
                f"{', '.join(ng.get('signal_flags', [])) or '—'}</div>"
                f"<div style='font-size:12px;color:#888;'><strong>Missing:</strong> "
                f"{', '.join(ng.get('missing_context', [])) or '—'}</div>"
                f"<div style='font-size:12px;color:#888;'><strong>Triggers:</strong> "
                f"{', '.join(ng.get('emotional_triggers', [])) or '—'}</div>"
                f"</div>"
            )
        parts.append(
            "<hr style='border:none;border-top:1px solid #ddd;margin:32px 0 16px;'>"
            "<p style='font-size:11px;color:#aaa;font-family:JetBrains Mono,monospace;"
            "letter-spacing:0.08em;'>Witnessed by Anya · the pink mark is honest · "
            "Spacephrasing daily ledger</p></div>"
        )
        html_body = "".join(parts)

    subject = f"AnyaSniffLog · {today} · top 3 bait-likely{mock_tag}"
    return subject, plain_body, html_body


def send_email(subject: str, plain_body: str, html_body: str) -> bool:
    if not (SMTP_HOST and SMTP_USER and SMTP_PASS and EMAIL_TO):
        print("SMTP not configured — skipping send.", file=sys.stderr)
        return False

    msg = EmailMessage()
    msg["From"] = SMTP_FROM
    msg["To"] = EMAIL_TO
    msg["Subject"] = subject
    msg.set_content(plain_body)
    msg.add_alternative(html_body, subtype="html")

    try:
        with smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=30) as s:
            s.ehlo()
            s.starttls()
            s.ehlo()
            s.login(SMTP_USER, SMTP_PASS)
            s.send_message(msg)
        return True
    except Exception as e:
        print(f"smtp send err: {e}", file=sys.stderr)
        return False


# ─────────────────────────── main ───────────────────────────


def main() -> int:
    ap = argparse.ArgumentParser(description="AnyaSniffLogs daily scan")
    ap.add_argument("--dry-run", action="store_true", help="write JSON, do not send email")
    ap.add_argument("--send", action="store_true", help="write JSON and send email")
    ap.add_argument("--simple-html", action="store_true", help="simpler HTML body for picky clients")
    args = ap.parse_args()

    if not args.dry_run and not args.send:
        # Default behavior for systemd: send
        args.send = True

    DATA_DIR.mkdir(parents=True, exist_ok=True)
    today = dt.date.today().isoformat()

    print(f"AnyaSniff scan starting for {today}", file=sys.stderr)

    stories = call_sonar()
    is_mock = stories is None
    if is_mock:
        stories = mock_stories()

    # Small sleep window so we don't hammer the API (no-op for mock)
    if not is_mock:
        time.sleep(SONAR_SLEEP)

    report = assemble_report(stories, is_mock=is_mock)
    out_path = DATA_DIR / f"anya-sniff-{today}.json"
    with open(out_path, "w") as f:
        json.dump(report, f, indent=2)
    print(f"wrote {out_path}", file=sys.stderr)

    subject, plain_body, html_body = build_email(report, simple_html=args.simple_html)

    if args.dry_run:
        print(f"--dry-run: would send '{subject}' to {EMAIL_TO}", file=sys.stderr)
        print(plain_body)
        return 0

    ok = send_email(subject, plain_body, html_body)
    print(f"email sent: {ok}", file=sys.stderr)
    return 0 if ok else 2


if __name__ == "__main__":
    sys.exit(main())
