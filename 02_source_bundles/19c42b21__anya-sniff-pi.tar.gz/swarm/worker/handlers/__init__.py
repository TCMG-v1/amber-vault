# Handler package marker. Each module defines `async def run(input_: dict) -> dict`.
