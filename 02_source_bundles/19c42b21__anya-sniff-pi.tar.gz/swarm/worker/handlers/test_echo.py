"""test_echo.py — trivial handler used by `swarm ping` to verify the pipeline.

Job input:  {"message": "hello"}
Job result: {"echoed": "hello", "device_time": "..."}
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any


async def run(input_: dict[str, Any]) -> dict[str, Any]:
    return {
        "echoed": input_.get("message", ""),
        "device_time": datetime.now(timezone.utc).isoformat(),
    }
