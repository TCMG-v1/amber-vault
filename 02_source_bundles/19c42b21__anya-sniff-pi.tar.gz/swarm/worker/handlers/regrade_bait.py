"""regrade_bait.py — re-score yesterday's AnyaSniffLogs report with a local LLM.

Requires the worker to have a local Ollama (or compatible) endpoint at
$OLLAMA_HOST (default http://127.0.0.1:11434).

Job input:
  {
    "report_path": "/path/to/anya-sniff-YYYY-MM-DD.json",  # readable from the worker
    "model": "phi3:mini"                                    # optional override
  }

Job result:
  {
    "scored_at": "...",
    "model": "phi3:mini",
    "stories": [{"headline": "...", "original_bait": 0.72, "local_bait": 0.65, "delta": -0.07}, ...]
  }
"""
from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from typing import Any

try:
    import httpx
except ImportError:  # pragma: no cover
    httpx = None  # the worker will report this as a handler error


OLLAMA_HOST = os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434")
DEFAULT_MODEL = os.environ.get("REGRADE_MODEL", "phi3:mini")


GRADER_PROMPT = """You are a NewsBait grader. Given a story (headline, outlet, summary),
return a single float between 0.0 and 1.0 representing the likelihood the story is
written to bait the reader emotionally rather than inform. Return ONLY the float.
Headline: {headline}
Outlet: {outlet}
Summary: {summary}
Float:"""


async def _grade_one(client, model: str, story: dict[str, Any]) -> float:
    payload = {
        "model": model,
        "prompt": GRADER_PROMPT.format(
            headline=story.get("headline", ""),
            outlet=story.get("outlet", ""),
            summary=story.get("summary_neutral", ""),
        ),
        "stream": False,
        "options": {"temperature": 0.0},
    }
    r = await client.post(f"{OLLAMA_HOST}/api/generate", json=payload, timeout=60)
    r.raise_for_status()
    raw = r.json().get("response", "").strip().split()[0]
    try:
        return max(0.0, min(1.0, float(raw)))
    except ValueError:
        return -1.0  # unparseable; flag


async def run(input_: dict[str, Any]) -> dict[str, Any]:
    if httpx is None:
        raise RuntimeError("httpx not installed on this worker")

    report_path = input_["report_path"]
    model = input_.get("model", DEFAULT_MODEL)

    with open(report_path) as f:
        report = json.load(f)

    scored = []
    async with httpx.AsyncClient() as client:
        for s in report.get("stories", []):
            original = float(s.get("bait_score", 0.0))
            local = await _grade_one(client, model, s)
            scored.append(
                {
                    "headline": s.get("headline", "")[:120],
                    "original_bait": original,
                    "local_bait": local,
                    "delta": round(local - original, 3) if local >= 0 else None,
                }
            )

    return {
        "scored_at": datetime.now(timezone.utc).isoformat(),
        "model": model,
        "report_path": report_path,
        "stories": scored,
    }
