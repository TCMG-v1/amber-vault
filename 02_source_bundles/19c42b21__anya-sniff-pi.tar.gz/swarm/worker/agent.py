#!/usr/bin/env python3
"""
agent.py — capability-aware worker for the BNS-ai.ai laptop swarm.

Runs on any device with Python 3.11+. Connects to NATS JetStream on the
Witness Pi, advertises its capabilities, and pulls jobs whose
`requires` is a subset of those caps.

Design goals:
  - One file, ~250 lines, no framework
  - Clean SIGTERM behavior (laptop closes lid → in-flight job requeues)
  - Heartbeats every 30s so the swarm CLI can show who's online
  - Per-job-type handlers live under handlers/ — agent doesn't care what
    they do, only that they return a result dict

Usage:
    python3 agent.py \\
        --nats nats://swarm:PASSWORD@anya.local:4222 \\
        --device thinkpad-1 \\
        --caps internet,local-llm,gpu,long-running,filesystem-rw

Env equivalents:
    NATS_URL, SWARM_DEVICE, SWARM_CAPS  (comma-separated)
"""
from __future__ import annotations

import argparse
import asyncio
import importlib
import json
import os
import signal
import socket
import sys
import time
from datetime import datetime, timezone
from typing import Any

try:
    import nats
    from nats.aio.msg import Msg
    from nats.js.api import ConsumerConfig, AckPolicy, DeliverPolicy
except ImportError:
    sys.stderr.write("Missing dep: pip install nats-py\n")
    sys.exit(1)


# ─────────────────────────── config ───────────────────────────


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _parse_args() -> argparse.Namespace:
    ap = argparse.ArgumentParser(description="BNS-ai.ai swarm worker")
    ap.add_argument(
        "--nats",
        default=os.environ.get("NATS_URL", "nats://swarm:REPLACE_ME@anya.local:4222"),
    )
    ap.add_argument(
        "--device",
        default=os.environ.get("SWARM_DEVICE", socket.gethostname()),
        help="Stable device name. Default: hostname.",
    )
    ap.add_argument(
        "--caps",
        default=os.environ.get("SWARM_CAPS", "internet"),
        help="Comma-separated capability list this worker advertises.",
    )
    ap.add_argument(
        "--max-concurrent",
        type=int,
        default=1,
        help="Max jobs to run in parallel. Default 1 (recommended for laptops).",
    )
    ap.add_argument(
        "--heartbeat-interval",
        type=int,
        default=30,
        help="Seconds between presence heartbeats.",
    )
    return ap.parse_args()


# ─────────────────────────── handlers ───────────────────────────


HANDLER_PKG = "handlers"


def _load_handler(job_type: str):
    """Dynamically import handlers/<job_type>.py and return its `run` coroutine."""
    mod_name = f"{HANDLER_PKG}.{job_type.replace('-', '_')}"
    try:
        mod = importlib.import_module(mod_name)
    except ModuleNotFoundError:
        return None
    return getattr(mod, "run", None)


# ─────────────────────────── core ───────────────────────────


class Worker:
    def __init__(self, args: argparse.Namespace) -> None:
        self.nats_url = args.nats
        self.device = args.device
        self.caps = set(c.strip() for c in args.caps.split(",") if c.strip())
        self.max_concurrent = args.max_concurrent
        self.heartbeat_interval = args.heartbeat_interval
        self.nc: nats.NATS | None = None
        self.js = None
        self.shutdown = asyncio.Event()
        self.inflight: set[asyncio.Task] = set()

    async def connect(self) -> None:
        self.nc = await nats.connect(self.nats_url, name=f"worker-{self.device}")
        self.js = self.nc.jetstream()
        print(f"✓ connected to NATS as {self.device}; caps={sorted(self.caps)}")

    async def heartbeat_loop(self) -> None:
        subject = f"swarm.presence.{self.device}"
        while not self.shutdown.is_set():
            payload = {
                "device": self.device,
                "caps": sorted(self.caps),
                "ts": _now_iso(),
                "inflight": len(self.inflight),
            }
            try:
                await self.nc.publish(subject, json.dumps(payload).encode())
            except Exception as e:
                print(f"heartbeat err: {e}", file=sys.stderr)
            try:
                await asyncio.wait_for(
                    self.shutdown.wait(), timeout=self.heartbeat_interval
                )
            except asyncio.TimeoutError:
                pass

    def _eligible(self, job: dict[str, Any]) -> bool:
        required = set(job.get("requires", []))
        return required.issubset(self.caps)

    async def _execute(self, msg: Msg) -> None:
        try:
            job = json.loads(msg.data.decode())
        except Exception as e:
            print(f"bad job payload: {e}", file=sys.stderr)
            await msg.term()  # malformed; don't requeue
            return

        if not self._eligible(job):
            await msg.nak(delay=2)  # let someone else have it
            return

        job_type = job.get("type", "")
        handler = _load_handler(job_type)
        if handler is None:
            print(f"no handler for type={job_type!r}; nak", file=sys.stderr)
            await msg.nak(delay=10)
            return

        job_id = job.get("job_id", "<no-id>")
        print(f"→ claim {job_id} type={job_type} from {job.get('submitted_by', '?')}")
        started = time.time()
        try:
            result = await handler(job.get("input", {}))
            status = "completed"
            error: str | None = None
        except Exception as e:
            result = None
            status = "failed"
            error = f"{type(e).__name__}: {e}"
            print(f"✗ {job_id} failed: {error}", file=sys.stderr)

        elapsed = time.time() - started
        record = {
            "job_id": job_id,
            "type": job_type,
            "claimed_by": self.device,
            "claimed_at": _now_iso(),
            "completed_at": _now_iso(),
            "elapsed_seconds": round(elapsed, 3),
            "status": status,
            "result": result,
            "error": error,
        }
        await self.js.publish(
            f"swarm.result.{job_id}", json.dumps(record).encode()
        )
        await msg.ack()
        print(f"✓ {job_id} {status} in {elapsed:.2f}s")

    async def _task_wrapper(self, msg: Msg) -> None:
        try:
            await self._execute(msg)
        finally:
            self.inflight.discard(asyncio.current_task())

    async def consume(self) -> None:
        consumer = await self.js.pull_subscribe(
            subject="swarm.job.*",
            durable=f"worker-{self.device}",
            config=ConsumerConfig(
                ack_policy=AckPolicy.EXPLICIT,
                ack_wait=120,  # seconds
                max_deliver=3,
                deliver_policy=DeliverPolicy.ALL,
                filter_subject="swarm.job.*",
            ),
        )

        while not self.shutdown.is_set():
            if len(self.inflight) >= self.max_concurrent:
                await asyncio.sleep(0.5)
                continue
            try:
                msgs = await consumer.fetch(batch=1, timeout=2)
            except asyncio.TimeoutError:
                continue
            except Exception as e:
                if not self.shutdown.is_set():
                    print(f"fetch err: {e}", file=sys.stderr)
                await asyncio.sleep(1)
                continue

            for msg in msgs:
                task = asyncio.create_task(self._task_wrapper(msg))
                self.inflight.add(task)

    async def run(self) -> None:
        await self.connect()
        hb = asyncio.create_task(self.heartbeat_loop())
        consume = asyncio.create_task(self.consume())
        await self.shutdown.wait()
        print("→ shutting down; waiting for inflight jobs...")
        if self.inflight:
            await asyncio.gather(*self.inflight, return_exceptions=True)
        hb.cancel()
        consume.cancel()
        if self.nc:
            await self.nc.drain()
        print("✓ clean exit")


# ─────────────────────────── entry ───────────────────────────


def _install_signals(worker: Worker) -> None:
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        loop.add_signal_handler(sig, worker.shutdown.set)


async def _main_async() -> int:
    args = _parse_args()
    worker = Worker(args)
    _install_signals(worker)
    await worker.run()
    return 0


def main() -> int:
    # Ensure handler imports resolve relative to this file
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    return asyncio.run(_main_async())


if __name__ == "__main__":
    sys.exit(main())
