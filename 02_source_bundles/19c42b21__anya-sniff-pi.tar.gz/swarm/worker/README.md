# Worker agent — install on a ThinkPad (or any device that should claim work)

The worker is a single Python file (`agent.py`) plus a `handlers/` directory. It connects to NATS on the Witness Pi, advertises its capabilities, and claims jobs whose `requires` is a subset of those caps.

## Install on a ThinkPad (Linux)

### 1. Get the bundle

```bash
mkdir -p ~/anya-swarm
cd ~/anya-swarm
# copy or scp the swarm/ directory here
```

### 2. Python environment

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install nats-py httpx
```

### 3. Configure

Create `~/anya-swarm/.env`:

```ini
NATS_URL=nats://swarm:YOUR_PASSWORD@anya.local:4222
SWARM_DEVICE=thinkpad-1
SWARM_CAPS=internet,local-llm,gpu,long-running,filesystem-rw,tailscale
OLLAMA_HOST=http://127.0.0.1:11434
```

Use the password set in `/etc/nats-server.conf` on the Pi. Trim `SWARM_CAPS` honestly — if there's no GPU, don't claim `gpu`.

### 4. Run it once by hand

```bash
source .venv/bin/activate
export $(grep -v '^#' .env | xargs)
python3 worker/agent.py
```

You should see:

```
✓ connected to NATS as thinkpad-1; caps=['filesystem-rw', 'gpu', 'internet', 'local-llm', 'long-running', 'tailscale']
```

From another terminal on any device:

```bash
swarm ping
```

You should see a JSON result come back showing `claimed_by: thinkpad-1`.

### 5. Install as a user systemd service (auto-start on login, exit on logout)

```bash
mkdir -p ~/.config/systemd/user
cp ~/anya-swarm/worker/anya-worker.service ~/.config/systemd/user/
systemctl --user daemon-reload
systemctl --user enable --now anya-worker.service
```

The `--user` scope is intentional: the worker dies cleanly when you log out / close the lid, matching the laptop-swarm-on-the-fly model.

### 6. Verify

```bash
systemctl --user status anya-worker.service
journalctl --user -u anya-worker.service -f
```

## Install on a phone (Termux, optional)

Termux on Android can run the agent if you reduce caps. Recommended cap-set:

```ini
SWARM_CAPS=internet,audio-out,audio-in,tailscale
```

No `long-running`, no `filesystem-rw`. The agent will only claim short, network-only jobs.

```bash
pkg install python git
pip install nats-py httpx
cd ~/anya-swarm
export $(grep -v '^#' .env | xargs)
python3 worker/agent.py
```

Use Termux's `boot` package + a wakelock if you want it to run when the screen is off.

## Adding a new handler

Drop a file under `worker/handlers/<job_type>.py` exposing `async def run(input_: dict) -> dict`. Restart the worker. The agent dynamically imports handlers by job type — no registration step.

See `handlers/test_echo.py` for the minimal shape and `handlers/regrade_bait.py` for a real one.

## Capability honesty

If a worker advertises a capability it doesn't actually have, jobs will be claimed and then fail. The result stream will show repeated failures from that device — `swarm history` makes this visible. Honest cap declaration is the only thing keeping the swarm sane; the queue does not verify.
