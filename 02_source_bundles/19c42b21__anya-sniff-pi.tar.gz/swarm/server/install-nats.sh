#!/usr/bin/env bash
# install-nats.sh — install NATS JetStream on the Witness Pi as a systemd service.
# Run as the unprivileged user (NOT root). Will sudo only where required.
set -euo pipefail

NATS_VERSION="2.10.21"
ARCH="$(uname -m)"
case "$ARCH" in
  aarch64|arm64) NATS_ARCH="arm64" ;;
  x86_64) NATS_ARCH="amd64" ;;
  *) echo "Unsupported arch: $ARCH"; exit 1 ;;
esac

DL="https://github.com/nats-io/nats-server/releases/download/v${NATS_VERSION}/nats-server-v${NATS_VERSION}-linux-${NATS_ARCH}.tar.gz"

echo "→ downloading nats-server v${NATS_VERSION} (${NATS_ARCH})"
TMPDIR="$(mktemp -d)"
cd "$TMPDIR"
curl -sSL "$DL" -o nats.tgz
tar -xzf nats.tgz
sudo install -m 0755 "nats-server-v${NATS_VERSION}-linux-${NATS_ARCH}/nats-server" /usr/local/bin/nats-server

echo "→ creating data dir"
sudo mkdir -p /var/lib/nats
sudo chown "$USER:$USER" /var/lib/nats

echo "→ writing config"
sudo tee /etc/nats-server.conf >/dev/null <<EOF
# /etc/nats-server.conf — Witness Pi swarm queue
server_name: "anya-witness"

# Bind only to Tailscale + loopback. Adjust if your Tailscale interface differs.
host: "0.0.0.0"
port: 4222

# JetStream for durable queues
jetstream {
  store_dir: "/var/lib/nats"
  max_mem: 256MB
  max_file: 5GB
}

# Basic auth — replace with the value from .env after install
authorization {
  user: "swarm"
  password: "REPLACE_ME_FROM_ENV"
}

http_port: 8222  # monitoring at http://anya.local:8222/varz
EOF

echo "→ installing systemd unit"
sudo tee /etc/systemd/system/nats-server.service >/dev/null <<'EOF'
[Unit]
Description=NATS JetStream queue (Witness Pi swarm)
After=network-online.target
Wants=network-online.target

[Service]
ExecStart=/usr/local/bin/nats-server -c /etc/nats-server.conf
Restart=on-failure
RestartSec=3
User=nobody
Group=nogroup
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
EOF

echo "→ enabling service"
sudo systemctl daemon-reload
sudo systemctl enable --now nats-server.service

sleep 2
if curl -sf http://127.0.0.1:8222/varz | grep -q '"server_name":"anya-witness"'; then
  echo "✓ nats-server is up on anya.local:4222 (monitoring on :8222)"
else
  echo "✗ nats-server failed to start. Check: journalctl -u nats-server.service -e"
  exit 1
fi

echo
echo "→ NEXT STEPS"
echo "  1. Edit /etc/nats-server.conf and replace REPLACE_ME_FROM_ENV with a strong password"
echo "  2. Add the same password as NATS_PASSWORD in /opt/anya-sniff/.env"
echo "  3. sudo systemctl restart nats-server"
echo "  4. From a ThinkPad, run swarm/cli/swarm ping to verify connectivity"
