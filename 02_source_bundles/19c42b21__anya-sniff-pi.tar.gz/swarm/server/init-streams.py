#!/usr/bin/env python3
"""
init-streams.py — create the JetStream streams + consumers for the swarm.

Run once after install-nats.sh, on the Witness Pi.

Streams:
  - JOBS      durable work queue (subject: swarm.job.*)
  - RESULTS   completed-job ledger (subject: swarm.result.*)
  - PRESENCE  device heartbeats (subject: swarm.presence.*, short retention)
"""
from __future__ import annotations

import asyncio
import os
import sys

try:
    import nats
    from nats.js.api import StreamConfig, RetentionPolicy, StorageType
except ImportError:
    sys.stderr.write("Missing dep: pip install nats-py\n")
    sys.exit(1)

NATS_URL = os.environ.get("NATS_URL", "nats://swarm:REPLACE_ME@127.0.0.1:4222")


async def main() -> int:
    nc = await nats.connect(NATS_URL)
    js = nc.jetstream()

    streams = [
        StreamConfig(
            name="JOBS",
            subjects=["swarm.job.>"],
            retention=RetentionPolicy.WORK_QUEUE,  # claim-once semantics
            storage=StorageType.FILE,
            max_age=7 * 24 * 3600,  # 7 days
            max_msgs=100_000,
        ),
        StreamConfig(
            name="RESULTS",
            subjects=["swarm.result.>"],
            retention=RetentionPolicy.LIMITS,
            storage=StorageType.FILE,
            max_age=30 * 24 * 3600,  # 30 days
            max_msgs=100_000,
        ),
        StreamConfig(
            name="PRESENCE",
            subjects=["swarm.presence.>"],
            retention=RetentionPolicy.LIMITS,
            storage=StorageType.MEMORY,
            max_age=5 * 60,  # 5 minutes — heartbeats only
            max_msgs=1_000,
        ),
    ]

    for cfg in streams:
        try:
            existing = await js.stream_info(cfg.name)
            print(f"= stream {cfg.name} already exists ({existing.state.messages} msgs)")
        except Exception:
            await js.add_stream(cfg)
            print(f"+ created stream {cfg.name}")

    await nc.drain()
    print("✓ streams initialized")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
