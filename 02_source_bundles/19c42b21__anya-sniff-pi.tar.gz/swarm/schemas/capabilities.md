# Capability Vocabulary

Workers advertise a set of capabilities at startup; jobs declare a set they require.

A worker may claim a job **iff** `job.requires ⊆ worker.caps`.

Keep this list short. If a new capability is added, every device-config must be reviewed.

| Capability | Meaning | Devices that typically have it |
|---|---|---|
| `internet` | Outbound HTTPS works | All online devices |
| `local-llm` | Has a local LLM runtime (Ollama, llama.cpp, mlx) | ThinkPads with Ollama; Orion when online; possibly stockpi |
| `gpu` | Has a usable discrete or unified GPU for ML inference | ThinkPads with discrete GPU; Orion |
| `audio-out` | Has speakers reachable from the worker process | ThinkPads; Echo device |
| `audio-in` | Has a microphone reachable from the worker process | ThinkPads; Echo device; phones |
| `audio-verify` | Implements the art-and-sound verification protocol (acoustic hash compare against a reference) | Echo device only |
| `long-running` | Can hold a job >5 minutes without sleeping/lid-closing | ThinkPads on AC power; Pi; Orion. NOT phones, NOT laptops on battery |
| `printer` | Has a printer attached for AnyaBear photo-paper runs | Whichever ThinkPad is at the print station |
| `filesystem-rw` | Has write access to the shared workspace (Tailscale Sync, NFS, etc.) | All except phones |
| `tailscale` | On the Tailscale network (vs LAN-only) | Most authoring devices |

## Default cap-sets by device class

These are guidelines for the worker's `--caps` flag at startup.

### Witness Pi (`anya.local`)
```
internet, long-running, filesystem-rw, tailscale
```

### ThinkPad on AC power
```
internet, local-llm, gpu, audio-out, audio-in, long-running, filesystem-rw, tailscale
```

### ThinkPad on battery
Drop `long-running` from the AC list. Jobs that need long-running won't route to a battery-bound laptop.

### Phone (Termux)
```
internet, audio-out, audio-in, tailscale
```
Notably no `long-running` and no `filesystem-rw` — phones are claim-and-bail workers.

### Echo device (when wired)
```
internet, audio-out, audio-in, audio-verify, long-running, tailscale
```

### Orion (when online)
```
internet, local-llm, gpu, long-running, filesystem-rw, tailscale
```
Plus whatever specialized caps Orion advertises (TBD when it lands).

## How to add a new capability

1. Edit `job.schema.json` — add to the `capability` enum
2. Edit this file — add a row to the table above
3. Restart all worker agents so they validate against the new enum
4. Update at least one device-config to advertise the new cap
5. Update the `swarm submit` CLI helper so it knows about the new cap

## How to add a new job type

1. Edit `job.schema.json` — add to the `type` enum
2. Add a handler module under `swarm/worker/handlers/<type>.py`
3. Decide which capabilities the type requires; document in the handler docstring
4. Restart all worker agents
