# Swarm (optional, alongside Witness Pi)

This is the minimal NATS JetStream queue that lets the Witness Pi hand work to whatever ThinkPad / phone / Orion happens to be online. Skip this entire directory if you only want the daily news scan; the scan does NOT depend on it.

## What you get

- A small (~15MB resident) NATS server on `anya.local:4222`
- Three durable streams: `JOBS`, `RESULTS`, `PRESENCE`
- A worker agent that runs on any device and claims jobs matching its capabilities
- A `swarm` CLI to submit/inspect/cancel jobs

## What runs where

| Component | Runs on |
|---|---|
| `nats-server` | Witness Pi only |
| `init-streams.py` | Witness Pi, once at install |
| `worker/agent.py` | Every device that should claim work |
| `cli/swarm` | Any device with network reach to the Pi |

## Install on the Witness Pi

```bash
cd /opt/anya-sniff/swarm/server
bash install-nats.sh
# follow the printed NEXT STEPS to set the password
python3 init-streams.py
```

## Install on a ThinkPad (or other worker device)

See `worker/README.md`.

## CLI

```bash
swarm status              # who's online, what they can do
swarm queue               # what's pending
swarm history --since 1h  # what's completed recently
swarm submit \
  --type regrade-bait \
  --requires local-llm,long-running \
  --priority 5 \
  --input-file ./yesterdays-report.json
swarm cancel <job_id>
```

## Trust model

- NATS is bound to `0.0.0.0:4222` but should be **reachable only via Tailscale** in practice. Firewall the port from the public internet.
- Single shared `swarm:<password>` credential for now. If devices change hands or get lost, rotate the password and restart all workers.
- TLS / mTLS / per-device credentials are deliberately out of scope for this minimal version. Add them when the swarm grows past ~5 devices.

## Failure modes

| Failure | What happens |
|---|---|
| Worker dies mid-job | NATS work-queue redelivers after the ack-wait timeout (default 30s) |
| All workers offline | Jobs accumulate in `JOBS` stream until claimed or TTL expires (default 24h) |
| Pi reboots | Streams are file-backed; queue survives |
| NATS itself crashes | systemd restarts it; queue survives |
| ThinkPad lid closes | Worker process exits cleanly via SIGTERM; in-flight job is requeued |

## When to retire this

If, after running for a month, you find every job has been claimed by the same one device, the swarm is overkill — kill the NATS service and just `cron` the work directly on that device. The scaffolding is here so that the option is *available* without forcing you to use it.
