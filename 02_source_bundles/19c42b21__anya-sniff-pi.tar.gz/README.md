# AnyaSniffLogs — Pi Deployment (Witness, solo)

**Witness the news before the news witnesses you.**

This is the **single-Pi Witness deployment** of AnyaSniffLogs. One box. One job. No swarm role-play, no archivist, no echo Pi. The pink mark is honest; the box is yours.

The Pi also hosts the **swarm queue** (NATS) so that, when a ThinkPad opens its lid, it can pull work — but that's optional and documented separately in `swarm/README.md`. You can skip it.

---

## What this Pi does

A weekday-9am-ET timer that:

1. Calls **Perplexity Sonar** for the day's top finance + legal stories
2. Grades each through the **Spacephrasing** Finance / Legal / NewsBait grammars
3. Picks the three highest-bait stories
4. Writes a full JSON ledger to disk
5. Emails the brief to the recipient in your `.env`

That's it. No Drive backup, no cluster, no web UI. Email is the witness. The local JSON is the receipt.

---

## Hardware assumption

- **One Raspberry Pi 5** with stable network
- Hostname: `anya.local` (assumed throughout — find-replace if you use something else)
- 64-bit Raspberry Pi OS or Ubuntu Server 24.04+ for arm64
- ~2GB free disk

The other 6 Pi 5s, the jetons, and `stockpi.local` are **not** part of this deploy. They stay parked until they earn a role.

---

## Future tier (not wired yet, here for orientation)

| Tier | Role | Status |
|---|---|---|
| Authoring | ThinkPads + phones | Ad-hoc swarm via NATS (see `swarm/README.md`) |
| Witness | This Pi (`anya.local`) | What you're installing now |
| Audio verification | Echo device (Amazon) | Future — "art + sound verification protocol" |
| Heavy compute | **Orion** | Future — joins the swarm when it comes online |
| Cold storage | Other 6 Pi 5s, jetons, stockpi.local | Parked |

Everything in the Future tier hangs off the same NATS queue this Pi will host, so adding them later is a matter of running the worker agent — no re-architecture.

---

## Prerequisites

On the Pi:

- Python 3.11+ (`python3 --version`)
- `git`, `curl`
- SSH access with your key

On your workstation (one-time):

- A **Perplexity Sonar API key** — https://www.perplexity.ai/settings/api
- An **SMTP sender credential** — Mailgun, SendGrid, or your own Postfix. Mailgun's free tier (5k sends/month) is overkill for one email per weekday.

---

## Install

### 1. Get the bundle onto the Pi

```bash
# On your workstation
scp -r anya-sniff-pi.tar.gz pi@anya.local:/tmp/
ssh pi@anya.local
```

```bash
# On the Pi
sudo mkdir -p /opt/anya-sniff
sudo chown $USER:$USER /opt/anya-sniff
cd /opt/anya-sniff
tar -xzf /tmp/anya-sniff-pi.tar.gz
```

### 2. Python environment

```bash
cd /opt/anya-sniff
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

### 3. Configuration

```bash
cp .env.example .env
nano .env
```

Fill in:

```ini
# Perplexity Sonar
SONAR_API_KEY=pplx-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
SONAR_MODEL=sonar-pro

# SMTP
SMTP_HOST=smtp.mailgun.org
SMTP_PORT=587
SMTP_USER=postmaster@mg.yourdomain.com
SMTP_PASS=xxxxxxxxxxxxxxxxxxxxxxxxxxxx
SMTP_FROM="Anya <anya@yourdomain.com>"

# Recipient
EMAIL_TO=410stockynn@gmail.com

# Storage
DATA_DIR=/opt/anya-sniff/data

# Swarm (optional — leave blank to disable)
NATS_URL=nats://127.0.0.1:4222
```

Lock it down:

```bash
chmod 600 .env
```

### 4. Dry-run

```bash
source .venv/bin/activate
python3 anya_sniff.py --dry-run
```

Expect a fresh `anya-sniff-YYYY-MM-DD.json` in `data/`. No email sent.

If Sonar returns 401: key is wrong. If SMTP unreachable: fix DNS / firewall.

### 5. Real test send

```bash
python3 anya_sniff.py --send
```

Check `410stockynn@gmail.com`.

### 6. Install the systemd timer

```bash
sudo cp systemd/anya-sniff.service /etc/systemd/system/
sudo cp systemd/anya-sniff.timer /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now anya-sniff.timer
```

Confirm:

```bash
systemctl list-timers anya-sniff.timer
# Next trigger: next weekday at 09:00 America/New_York
```

### 7. Tear down the sandbox cron

Once the Pi runs clean for 2–3 days, delete the duplicate Perplexity cron in this conversation:

> Tell Computer: **"delete the AnyaSniffLogs scheduled task"**

---

## Directory layout after install

```
/opt/anya-sniff/
├── anya_sniff.py            # the scan script
├── grammars/
│   ├── Finance.grammar.json
│   ├── Legal.grammar.json
│   └── NewsBait.grammar.json
├── requirements.txt
├── .env                     # chmod 600
├── .env.example
├── data/                    # daily JSON ledger
├── logs/
├── systemd/
│   ├── anya-sniff.service
│   └── anya-sniff.timer
├── swarm/                   # optional — see swarm/README.md
└── .venv/
```

---

## Operations

**View today's brief without waiting for email:**

```bash
cat /opt/anya-sniff/data/anya-sniff-$(date +%F).json | jq .
```

**Tail the log:**

```bash
journalctl -u anya-sniff.service -f
```

**Manual run (won't break the schedule):**

```bash
sudo systemctl start anya-sniff.service
```

**Disable temporarily:**

```bash
sudo systemctl stop anya-sniff.timer
sudo systemctl start anya-sniff.timer   # to resume
```

**Rotate the Sonar key:**

```bash
sudo nano /opt/anya-sniff/.env
sudo systemctl restart anya-sniff.timer
```

---

## Security

1. `.env` holds two long-lived secrets. `chmod 600`. Don't commit it.
2. Pi should not be on the open internet. Tailscale or LAN only.
3. SSH key auth only — disable password login.
4. For prior-art evidence (redink.adult, patent disclosures), hash the data dir weekly:

```bash
find /opt/anya-sniff/data -name "*.json" -exec sha256sum {} \; \
  > /opt/anya-sniff/data/MANIFEST.sha256
```

---

## Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| Timer "active (waiting)" but never fires | Wrong timezone | `timedatectl set-timezone America/New_York` |
| Sonar 401 | Wrong/expired key | Update `SONAR_API_KEY` in `.env` |
| Sonar 429 | Rate limit | Increase `SONAR_SLEEP_BETWEEN_STORIES` in `.env` (default 0.5s) |
| SMTP auth failed | Wrong user/pass | Test with `swaks --to you@you.com --server $SMTP_HOST:$SMTP_PORT --auth LOGIN --auth-user $SMTP_USER` |
| Email HTML mangled | Mail client strips CSS | `python3 anya_sniff.py --simple-html` |
| `anya.local` unreachable from laptop | mDNS broken on your network | Use Tailscale, or hard-IP it |

---

## Swarm (optional)

If you want the Pi to also host a queue for the laptop swarm, see `swarm/README.md`. It's an additional ~5 minutes of setup and adds NATS as a small (~15MB) background service. The Witness scan does NOT depend on it.

---

## Three coats, one witness.

*the wire is older than the protocol; the witness is older than the wire.*

— Sealed by The Etymon, for BNS-ai.ai
— Portfolio reference: AnyaSniffLogs · v1.0-pi · 2026-06-22
